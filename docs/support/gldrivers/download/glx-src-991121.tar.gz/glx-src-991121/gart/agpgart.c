/*
 * AGPGART module version 0.04
 * Copyright (C) 1999 Jeff Hartmann
 * Copyright (C) 1999 Xi Graphics
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * JEFF HARTMANN, OR ANY OTHER CONTRIBUTORS BE LIABLE FOR ANY CLAIM, 
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR 
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE 
 * OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 */

/* mknod /dev/gart c 174 0 */

#include <linux/config.h>
#include <linux/version.h>
#include <linux/module.h>
#include <linux/types.h>
#include <linux/kernel.h>
#include <linux/sched.h>
#include <linux/mm.h>
#include <linux/string.h>
#include <linux/errno.h>
#include <linux/malloc.h>
#include <linux/pci.h>
#include <linux/init.h>
#include <linux/pagemap.h>
#include <linux/agpgart.h>
#include <asm/system.h>

#ifdef CONFIG_MTRR 
#include <asm/mtrr.h>
#endif

#ifdef CONFIG_DEVFS_FS
#include <linux/devfs_fs_kernel.h>
#endif

#include <asm/uaccess.h>
#include <asm/system.h>
#include <asm/io.h>
#include <asm/page.h>

#define TRUE 1
#define FALSE 0

#define AGPGART_MAJOR 174

#ifndef PCI_DEVICE_ID_VIA_82C691_0
#define PCI_DEVICE_ID_VIA_82C691_0      0x0691
#endif
#ifndef PCI_DEVICE_ID_VIA_82C691_1
#define PCI_DEVICE_ID_VIA_82C691_1      0x8691
#endif
#ifndef PCI_DEVICE_ID_INTEL_82443GX_0
#define PCI_DEVICE_ID_INTEL_82443GX_0   0x71a0
#endif
#ifndef min
# define min(a,b) (((a)<(b))?(a):(b))
#endif

MODULE_AUTHOR("Jeff Hartmann <jhartmann@precisioninsight.com>");
MODULE_PARM(gart_try_unsupported, "1i");
MODULE_PARM(gart_mode_mask, "1i");


static int gart_try_unsupported __initdata = 0; /* default to not trying vendor code on unsupported bridges */
static int gart_mode_mask __initdata = 1; /* default is agp 1x */

/* intel register */
#define INTEL_APBASE    0x10
#define INTEL_APSIZE  	0xb4
#define INTEL_ATTBASE 	0xb8
#define INTEL_AGPCTRL 	0xb0
#define INTEL_NBXCFG  	0x50
#define INTEL_ERRSTS  	0x91

/* VIA register */
#define VIA_APBASE      0x10
#define VIA_GARTCTRL    0x80
#define VIA_APSIZE     	0x84
#define VIA_ATTBASE	0x88

/* SiS registers */
#define SIS_APBASE   0x10
#define SIS_ATTBASE  0x90
#define SIS_APSIZE   0x94
#define SIS_TLBCNTRL 0x97
#define SIS_TLBFLUSH 0x98

static struct chipset_functions
{
  enum chipset_type type;
  u8 capndx;
  struct pci_dev *dev;
   
  int  (*fetch_size)(void);
  int  (*configure)(void);
  void (*agp_enable)(void);
  void (*cleanup)(void);
  void (*tlb_flush)(void);
} chipset;

struct gart_table_init
{
   int size;
   int num_entries;
   int page_order;
   u16 intel_size_values;
   u8  via_size_values;
   u8  sis_size_value;
};

static struct gart_table_init gart_init_values[] =
{
  /* VIA would support 1 & 2 MB apertures, but who wants 
   * such small sizes? ;-) */
     /*  size, 	number of entries, 	page order */
        {4,   	1024,		        0,		63, 252, 3},
        {8,   	2048,  			1,		62, 248, 19},
	{16,  	4096,  			2,		60, 240, 35},
	{32,  	8192,  			3,		56, 224, 51},
	{64,  	16384, 			4,		48, 192, 67},
	{128, 	32768, 			5,		32, 128, 83},
	{256, 	65536, 			6,		 0, 0,   99}
};

/* These really should be allocated on the fly, however in this
 * case since this is the only information in the file private
 * data, I wanted to minimize memory wastage. */

static int gart_controller = TRUE;
static int gart_client = FALSE;

static struct gart_table_init *gart_init;
static unsigned long table_bus_addr;
static unsigned long gart_map_phys;
static unsigned long gart_mask;
static int gart_mtrr;
static unsigned long *gart_table;
static unsigned long *gart_table_real;
static unsigned long *scratch_entries;
static char gart_in_use;
static enum agp_mode gart_mode;

#ifdef __SMP__
static atomic_t cpus_waiting;
#endif

#ifdef CONFIG_DEVFS_FS
static devfs_handle_t dev_handle = NULL;
#endif

static void flush_cache(void)
{
   asm volatile("wbinvd" : : : "memory" );
}

#ifdef __SMP__
static void ipi_handler(void *info)
{
   flush_cache();
   atomic_dec(&cpus_waiting);
   while( atomic_read(&cpus_waiting) > 0) barrier();
}

static void smp_flush_cache(void)
{
   atomic_set(&cpus_waiting, smp_num_cpus - 1);
   if(smp_call_function(ipi_handler, NULL, 1, 0) != 0)
     panic("agpgart: timed out waiting for the other CPUs\n");
   flush_cache();
   while (atomic_read (&cpus_waiting) > 0) barrier();
}
#endif

static void *gart_alloc_page(void)
{
   void *pt;

   pt = (void *) __get_free_page(GFP_KERNEL);
   if (pt == NULL)
     {
	return(NULL);
     }
   
   set_bit(PG_reserved, &mem_map[MAP_NR(pt)].flags);
   
   return(pt);
}

static void gart_destroy_page(void *pt)
{
   if(pt == NULL)
     return;
   
   clear_bit(PG_reserved, &mem_map[MAP_NR(pt)].flags);
   
   free_page((unsigned long) pt);
}

static int gart_insert_page(int gart_index, int size)
{
unsigned long tmp_value;
int i;
   
   if((gart_index > gart_init->num_entries) || 
      ((gart_index + size) > gart_init->num_entries) ||
      (size > 1024))
     {
	return(-EINVAL);
     }
   
   for(i= 0; i < size; i++)
     {
	tmp_value = gart_table[gart_index + i];
   
	if(tmp_value != 0)
	  {
	     return(-EBUSY);
	  }
     }
   
   memset(scratch_entries, 0, 4096);
   
   for(i = 0; i < size; i++)
     {
	scratch_entries[i] = (unsigned long) gart_alloc_page();
   
	if(scratch_entries[i] == (unsigned long) NULL)
	  {
	     for(i = 0; i < 4096; i++)
	       {
		  if(scratch_entries[i] != (unsigned long) NULL)
		    gart_destroy_page((void *) scratch_entries[i]);
	       }
	     return(-ENOMEM);
	  }
     }
   
   for(i = 0; i < size; i++)
     {	
	tmp_value = virt_to_bus((void *)scratch_entries[i]);
	tmp_value |= gart_mask;
	gart_table[gart_index + i] = tmp_value;
     }
   
   chipset.tlb_flush();
   return(0);
}

static int gart_remove_page(int gart_index, int size)
{
   void *tmp_ptr;
   unsigned long tmp_value;
   int i;
   
   if((gart_index > gart_init->num_entries) || 
      ((gart_index + size) > gart_init->num_entries) ||
      (size > 1024))
     {
	return(-EINVAL);
     }
   
   for(i= 0; i < size; i++)
     {
	tmp_value = gart_table[gart_index + i];
	
	if(tmp_value == 0)
	  {
	     return(-EINVAL);
	  }
     }

   for(i= 0; i < size; i++)
     {
	tmp_value = gart_table[gart_index + i];
	gart_table[gart_index + i] = 0; 
	tmp_value &= ~(gart_mask);
	tmp_ptr = (void *) bus_to_virt(tmp_value);
	gart_destroy_page(tmp_ptr);
     }
   
   chipset.tlb_flush();
   
   return(0);
}

static void generic_agp_enable(void)
{
struct pci_dev *device = NULL;
u32 command, scratch, cap_id;
u8 cap_ptr;
   
   pci_read_config_dword(chipset.dev,
			 chipset.capndx+4,
			 &command);
   
   /*
    * PASS1: go throu all devices that claim to be
    *        AGP devices and collect their data.
    */
   
   while ((device = pci_find_class(PCI_CLASS_DISPLAY_VGA << 8, device)) != NULL)
     {
	pci_read_config_dword(device, 0x04, &scratch);
	
	if (!(scratch & 0x00100000)) continue;
	
	pci_read_config_byte(device, 0x34, &cap_ptr);
	
	if (cap_ptr != 0x00) {
	   do {
	      pci_read_config_dword(device, cap_ptr, &cap_id);
	      
	      if ((cap_id & 0xff) != 0x02) cap_ptr = (cap_id >> 8) & 0xff;
	   }
	   while (((cap_id & 0xff) != 0x02) && (cap_ptr != 0x00));
	}
	if (cap_ptr != 0x00)
	  {
	     /*
	      * Ok, here we have a AGP device. Disable impossible settings,
	      * and adjust the readqueue to the minimum.
	      */
	     
	     pci_read_config_dword(device, cap_ptr +4, &scratch);
	     
	     /* adjust RQ depth */
	     command =
	       ((command & ~0xff000000) |
		min((command & 0xff000000), (scratch & 0xff000000)));
	     
	     /* disable SBA if it's not supported */
	     if (!((command & 0x00000200) && (scratch & 0x00000200)))
	       command &= ~0x00000200;
	     
	     /* disable FW if it's not supported */
	     if (!((command & 0x00000010) && (scratch & 0x00000010)))
	       command &= ~0x00000010;
	     
	     if (!((command & 4) && (scratch & 4)))
	       command &= ~0x00000004;
	     
	     if (!((command & 2) && (scratch & 2)))
	       command &= ~0x00000002;
	     
	     if (!((command & 1) && (scratch & 1)))
	       command &= ~0x00000001;
	    
             command = (command & ~7) | (command & gart_mode_mask);
	  }
     }
   
   /*
    * PASS2: Figure out the 4X/2X/1X setting and enable the
    *        target (our motherboard chipset).
    */
   
   if (command & 4) {
      gart_mode = AGP_MODE4X;
      command &= ~3; /* 4X */
   }
   if (command & 2) {
      gart_mode = AGP_MODE2X;
      command &= ~5; /* 2X */
   }
   if (command & 1) {
      gart_mode = AGP_MODE1X;
      command &= ~6; /* 1X */
   }
   
   command |= 0x00000100;
   
   pci_write_config_dword(chipset.dev,
			  chipset.capndx+8,
			  command);
  printk("Chipset command = %08x (at %x)\n", command, chipset.capndx+8);
   
   /*
    * PASS3: Go throu all AGP devices and update the
    *        command registers.
    */
   
   while ((device = pci_find_class(PCI_CLASS_DISPLAY_VGA << 8, device)) != NULL)
     {
	pci_read_config_dword(device, 0x04, &scratch);
	
	if (!(scratch & 0x00100000)) continue;
	
	pci_read_config_byte(device, 0x34, &cap_ptr);
	
	if (cap_ptr != 0x00) {
	   do {
	      pci_read_config_dword(device, cap_ptr, &cap_id);
	      
	      if ((cap_id & 0xff) != 0x02) cap_ptr = (cap_id >> 8) & 0xff;
	   }
	   while (((cap_id & 0xff) != 0x02) && (cap_ptr != 0x00));
	}
	
	if (cap_ptr != 0x00)
        {
	  pci_write_config_dword(device, cap_ptr +8, command);
          printk("Device command = %08x (at %x)\n", command, cap_ptr +8);
	}
     }
}

static int gart_ioctl(struct inode *inode, struct file *file, unsigned int cmd, unsigned long arg)
{
struct gart_entry user_entry;
struct gart_info user_info;
int *is_controller = file->private_data;
   
   switch(cmd)
     {
      case GARTIOCINSERT:
	
	if(*is_controller == FALSE)
	  {
	     return(-EPERM);
	  }
	
	if(copy_from_user(&user_entry, (void *)arg, sizeof(struct gart_entry)))
	  {
	     return(-EFAULT);
	  }

	return(gart_insert_page(user_entry.ofs, user_entry.size));
	break;
  	
      case GARTIOCREMOVE:
	
	if(*is_controller == FALSE)
	  {
	     return(-EPERM);
	  }

	if(copy_from_user(&user_entry, (void *)arg, sizeof(struct gart_entry)))
	  {
	     return(-EFAULT);
	  }

	return(gart_remove_page(user_entry.ofs, user_entry.size));
	break;
	
      case GARTIOCINFO:
	user_info.size = gart_init->size;
	user_info.num_of_slots = gart_init->num_entries;
	user_info.physical = gart_map_phys;
	user_info.type = chipset.type;
	user_info.mode = gart_mode;

	if(copy_to_user((void *)arg, &user_info, sizeof(struct gart_info)))
	  {
	     return(-EFAULT);
	  }
	return(0);
	break;
	
      case GARTIOCINIT:
	if(*is_controller == FALSE)
	  {
	     return(-EPERM);
	  }

	chipset.agp_enable();
	return(0);
     }
   return(-ENOTTY);
}

static int gart_create_table(int size /* in megs */)
{
   /* 4   megs requires one page	 - 4096   bytes - 1024  entries -  0 order */
   /* 8   megs requires two pages 	 - 8192   bytes - 2048  entries - 1 order */
   /* 16  megs requires four pages 	 - 16384  bytes - 4096  entries - 2 order */
   /* 32  megs requires eight pages 	 - 32768  bytes - 8192  entries - 3 order */
   /* 64  megs requires sixteen pages 	 - 65536  bytes - 16384 entries - 4 order */
   /* 128 megs requires thirty-two pages - 131072 bytes - 32768 entries - 5 order */
   /* 256 megs requires sixty-four pages - 262144 bytes - 65536 entries - 6 order */
      
   char *table;
   char *table_end;
   int i;
   
   for(i = 0, gart_init = NULL; i < 7 && gart_init == NULL; i++)
     {
	if(size == gart_init_values[i].size) 
	  {
	     gart_init = gart_init_values + i;
	  }
     }
   
   if(gart_init == NULL)
     {
	return(-EINVAL);
     }
   
   table = (char *) __get_free_pages(GFP_KERNEL, gart_init->page_order);
   
   if(table == NULL)
     {
	return(-ENOMEM);
     }
   
   table_bus_addr = virt_to_bus(table);
   table_end = table + ((PAGE_SIZE * (1 << gart_init->page_order)) - 1);

   for(i = MAP_NR(table); i < MAP_NR(table_end); i++)
     {
	set_bit(PG_reserved, &mem_map[i].flags);
     }  

   gart_table_real = (unsigned long *) table;
#ifdef __SMP__
   smp_flush_cache();
#else
   flush_cache();
#endif
#ifdef KERNEL_PATCH_REQUIRED
   gart_table = ioremap_nocache(virt_to_phys(table), (PAGE_SIZE * (1 << gart_init->page_order)));
#else
   gart_table = gart_table_real;
#endif
#ifdef __SMP__
   smp_flush_cache();
#else
   flush_cache();
#endif
   
   if(gart_table == NULL)
     {
	return(-ENOMEM);
     }

   memset(gart_table, 0, (PAGE_SIZE * (1 << gart_init->page_order)));
   
   return(0);
}

static int intel_fetch_size(void)
{
   int i;
   u16 temp;

   pci_read_config_word(chipset.dev, INTEL_APSIZE, &temp);
   
   i = 0;
   
   while(i < 7)
     {
	if(temp == gart_init_values[i].intel_size_values)
	  {
	     return(gart_init_values[i].size);
	  }
	     
	i++;
     }
   
   return(0);
}

static void intel_tlbflush(void)
{
#ifdef __SMP__
   smp_flush_cache();
#else
   flush_cache();
#endif
   
   pci_write_config_dword(chipset.dev, INTEL_AGPCTRL, 0x2200);
   pci_write_config_dword(chipset.dev, INTEL_AGPCTRL, 0x2280);
}

static int intel_configure(void)
{
   u32 temp;
   u16 temp2;

   /* aperture size */
   pci_write_config_word(chipset.dev, INTEL_APSIZE, gart_init->intel_size_values);
   /* address to map too */
   pci_read_config_dword(chipset.dev, INTEL_APBASE, &temp);
   gart_map_phys = (temp & PCI_BASE_ADDRESS_MEM_MASK);
   
   /* attbase - aperture base */
   pci_write_config_dword(chipset.dev, INTEL_ATTBASE, table_bus_addr);
   /* agpctrl */
   pci_write_config_dword(chipset.dev, INTEL_AGPCTRL, 0x2280);
   /* paccfg/nbxcfg */
   pci_read_config_word(chipset.dev, INTEL_NBXCFG, &temp2);
   printk("PACCFG/NBXCFG: %i\n", temp2);
   pci_write_config_word(chipset.dev, INTEL_NBXCFG, (temp2 & ~(1<<10)) | (1<<9));
   /* clear any possible error conditions */
   pci_write_config_byte(chipset.dev, INTEL_ERRSTS + 1, 7);
  
  return 0;
}

static void intel_cleanup(void)
{
   u16 temp;
   
   pci_read_config_word(chipset.dev, INTEL_NBXCFG, &temp);
   pci_write_config_word(chipset.dev, INTEL_NBXCFG, temp & ~(1<<9));
}

static int via_fetch_size(void)
{
   int i;
   u8 temp;

   pci_read_config_byte(chipset.dev, VIA_APSIZE, &temp);
   
   i = 0;
   
   while(i < 7)
     {
	if(temp == gart_init_values[i].via_size_values)
	  {
	     return(gart_init_values[i].size);
	  }
	i++;
     }
   
   return(0);
}

static int via_configure(void)
{
   u32 temp;

   /* aperture size */
   pci_write_config_byte(chipset.dev, VIA_APSIZE, gart_init->via_size_values);
   /* address to map too */
   pci_read_config_dword(chipset.dev, VIA_APBASE, &temp);
   gart_map_phys = (temp & PCI_BASE_ADDRESS_MEM_MASK);

   /* GART control register */
   pci_write_config_dword(chipset.dev, VIA_GARTCTRL, 0x0000000f);   

   /* attbase - aperture GATT base */
   pci_write_config_dword(chipset.dev, VIA_ATTBASE, (table_bus_addr & 0xfffff000)  | 3 );

  return 0;
}

static void via_cleanup(void)
{
#if THIS_WOULD_NOT_CAUSE_KERNEL_OOPS_ON_RE_INSMOD

   /* What on earth is wrong with this code, it follows the docs explictly
    * This stuff really needs to happen in modular code, could someone with
    * a VIA chipset please take a hard look at it.
    */
   
   pci_write_config_dword(chipset.dev, VIA_ATTBASE, 0);
   /* The docs say to set this to zero to get the aperture disabled */
   pci_write_config_byte(chipset.dev, VIA_APSIZE, 0);
   /* TODO: we should probably save the value from when we first read the chip instead of this */
   pci_write_config_byte(chipset.dev, VIA_APSIZE, gart_init->via_size_values);
#endif  
}

static void via_tlbflush(void)
{
#ifdef __SMP__
   smp_flush_cache();
#else
   flush_cache();
#endif

   pci_write_config_dword(chipset.dev, VIA_GARTCTRL, 0x0000008f);
   pci_write_config_dword(chipset.dev, VIA_GARTCTRL, 0x0000000f);
}

static int sis_fetch_size(void)
{
   u8 temp_size;
   int i;
   
   pci_read_config_byte(chipset.dev, SIS_APSIZE, &temp_size);
   
   i = 0;
   
   while(i < 7)
     {
	if((temp_size == gart_init_values[i].sis_size_value) ||
	   ((temp_size & ~(0x03)) == (gart_init_values[i].sis_size_value & ~(0x03))))
	  {
	     return(gart_init_values[i].size);
	  }
	i++;
     }
   return(0);
}


static void sis_tlbflush(void)
{
#ifdef __SMP__
   smp_flush_cache();
#else
   flush_cache();
#endif
      pci_write_config_byte(chipset.dev, SIS_TLBFLUSH, 0x02);
}

static int sis_configure(void)
{
u32 temp;
   
   pci_write_config_byte(chipset.dev, SIS_TLBCNTRL, 0x05);
   pci_read_config_dword(chipset.dev, SIS_APBASE, &temp);
   gart_map_phys = (temp & PCI_BASE_ADDRESS_MEM_MASK);
   pci_write_config_dword(chipset.dev, SIS_ATTBASE, table_bus_addr);
   pci_write_config_byte(chipset.dev, SIS_APSIZE, gart_init->sis_size_value);

   return(0);
}

static void sis_cleanup(void)
{
      u8 temp;
      
      pci_read_config_byte(chipset.dev, SIS_APSIZE, &temp);
      pci_write_config_byte(chipset.dev, SIS_APSIZE, (temp & ~(0x03)));
}

/* Rewritten totally, it should be alot more flexible now */

static void gart_find_supported(void)
{
   struct pci_dev *dev = NULL;
   u8 cap_ptr = 0x00;
   u32 cap_id, scratch;
   
   if ((dev = pci_find_class(PCI_CLASS_BRIDGE_HOST << 8, NULL)) == NULL)
     {
	chipset.type = NOT_SUPPORTED;
	return;
     }

   /* find capndx */
   pci_read_config_dword(dev, 0x04, &scratch);
   
   if (!(scratch & 0x00100000)) 
     {
	chipset.type = NOT_SUPPORTED;
	return;
     }
   
   pci_read_config_byte(dev, 0x34, &cap_ptr);
   
   if (cap_ptr != 0x00) {
      do {
	 pci_read_config_dword(dev, cap_ptr, &cap_id);
	 
	 if ((cap_id & 0xff) != 0x02) cap_ptr = (cap_id >> 8) & 0xff;
      }
      while (((cap_id & 0xff) != 0x02) && (cap_ptr != 0x00));
   }
   
   if(cap_ptr == 0x00)
     {
	chipset.type = NOT_SUPPORTED;
	return;
     }
   
   chipset.capndx = cap_ptr;
   chipset.agp_enable = generic_agp_enable;
   chipset.dev = dev;

   switch(dev->vendor)
     {
      case PCI_VENDOR_ID_INTEL:
	switch(dev->device)
	  {
	   case PCI_DEVICE_ID_INTEL_82443LX_0:
	     chipset.type 	= INTEL_LX;
	     gart_mask 		= 0x00000017;
	     
	     chipset.configure  	= intel_configure;
	     chipset.fetch_size 	= intel_fetch_size;
	     chipset.cleanup    	= intel_cleanup;
	     chipset.tlb_flush  	= intel_tlbflush;
	
	     return;
	     
	     break;
	   case PCI_DEVICE_ID_INTEL_82443BX_0:
	     chipset.type	= INTEL_BX;
	     gart_mask 		= 0x00000017;
	     
	     chipset.configure  	= intel_configure;
	     chipset.fetch_size 	= intel_fetch_size;
	     chipset.cleanup    	= intel_cleanup;
	     chipset.tlb_flush  	= intel_tlbflush;
	     
	     return;
	     
	   case PCI_DEVICE_ID_INTEL_82443GX_0:
	     chipset.type	= INTEL_GX;
	     gart_mask		= 0x00000017;
	     
	     chipset.configure  	= intel_configure;
	     chipset.fetch_size 	= intel_fetch_size;
	     chipset.cleanup    	= intel_cleanup;
	     chipset.tlb_flush  	= intel_tlbflush;
	     
	     return;	     

	     break;
	   default:
	     if(gart_try_unsupported != 0)
	       {
		  printk("Trying generic intel routines for device id: %x\n", dev->device);
		  chipset.type	= INTEL_GENERIC;
		  gart_mask 	= 0x00000017;
		  
		  chipset.configure  	= intel_configure;
		  chipset.fetch_size 	= intel_fetch_size;
		  chipset.cleanup    	= intel_cleanup;
		  chipset.tlb_flush  	= intel_tlbflush;
		  
		  return;
	       }
	     else
	       {
		  printk("Unsupported intel chipset, you might want to try gart_try_unsupported=1\n"); 
		  chipset.type = NOT_SUPPORTED;
		  return;
	       }
	  }
	break;
      case PCI_VENDOR_ID_VIA:
	switch(dev->device)
	  {
	   case PCI_DEVICE_ID_VIA_82C597_0:
	     chipset.type	= VIA_VP3;
	     gart_mask 		= 0; 
	     
	     chipset.configure 		= via_configure;
	     chipset.fetch_size 	= via_fetch_size;
	     chipset.cleanup 		= via_cleanup;
	     chipset.tlb_flush 		= via_tlbflush;
	     return;
	     
	     break;
	   case PCI_DEVICE_ID_VIA_82C598_0:
	     chipset.type 	= VIA_MVP3;
	     gart_mask 		= 0; 
	     
	     chipset.configure 		= via_configure;
	     chipset.fetch_size 	= via_fetch_size;
	     chipset.cleanup 		= via_cleanup;
	     chipset.tlb_flush 		= via_tlbflush;
	     return;
	     
	     break;
	   case PCI_DEVICE_ID_VIA_82C691_0:
	     chipset.type 	= VIA_APOLLO_PRO;
	     gart_mask 		= 0; 
	     
	     chipset.configure 		= via_configure;
	     chipset.fetch_size 	= via_fetch_size;
	     chipset.cleanup 		= via_cleanup;
	     chipset.tlb_flush 		= via_tlbflush;
	     return;
	     
	     break;
	   default:
	     if(gart_try_unsupported != 0)
	       {
		  printk("Trying generic via routines for device id: %x\n", dev->device);
		  chipset.type	= VIA_GENERIC;
		  gart_mask 	= 0;

		  chipset.configure    	= via_configure;
		  chipset.fetch_size 	= via_fetch_size;
		  chipset.cleanup 	= via_cleanup;
		  chipset.tlb_flush 	= via_tlbflush;
		  
		  return;
	       }
	     else
	       {
		  printk("Unsupported via chipset, you might want to try gart_try_unsupported=1\n"); 
		  chipset.type = NOT_SUPPORTED;
		  return;
	       }
	  }
	
	break;
      case PCI_VENDOR_ID_SI:
	switch(dev->device)
	  {
	   default:
	     if(gart_try_unsupported != 0)
	       {
		  printk("Trying generic SiS routines for device id: %x\n", dev->device);
		  chipset.type	= SIS_GENERIC;
		  gart_mask 	= 0;

		  chipset.configure    	= sis_configure;
		  chipset.fetch_size 	= sis_fetch_size;
		  chipset.cleanup 	= sis_cleanup;
		  chipset.tlb_flush 	= sis_tlbflush;
		  
		  return;
	       }
	     else
	       {
		  printk("Unsupported SiS chipset, you might want to try gart_try_unsupported=1\n"); 
		  chipset.type = NOT_SUPPORTED;
		  return;
	       }
	  }
	
      default:
	chipset.type = NOT_SUPPORTED;
	return;
     }
   return;
}

static ssize_t gart_read(struct file *file, char *buf, size_t count, loff_t *ppos)
{
   return -EINVAL;
}

static ssize_t gart_write(struct file *file, const char *buf, size_t count, loff_t *ppos)
{
   return -EINVAL;
}

static int gart_mmap(struct file *file, struct vm_area_struct *vma)
{
   /* Everyone can mmap, don't worry about checking */
   int size;
   
   size = vma->vm_end - vma->vm_start;
   if(size != (gart_init->size * 0x100000))
     {
	return(-EINVAL);
     }
   if(remap_page_range(vma->vm_start, gart_map_phys, 
		       size, vma->vm_page_prot))
     {
	return(-EAGAIN);
     }
   return(0);
}

static int gart_release(struct inode *inode, struct file *file)
{
   int i;
   void *tmp_ptr;
   unsigned long tmp_value;
   int *is_controller = file->private_data;
   
   if(*is_controller == TRUE)
     {
	for(i = 0; i < gart_init->num_entries; i++)
	  {
	     if(gart_table[i] != 0)
	       {
		  tmp_value = gart_table[i];
		  gart_table[i] = 0;
		  tmp_value &= ~(gart_mask);
		  tmp_ptr = (void *) bus_to_virt(tmp_value);
		  gart_destroy_page(tmp_ptr);
	       }
	  }
	
	gart_in_use = 0;
     }
   
   MOD_DEC_USE_COUNT;
   return 0;
}

static long long gart_lseek(struct file *file, long long offset, int origin)
{
   return -ESPIPE;
}					 

static int gart_open(struct inode *inode, struct file *file)
{
   int minor = MINOR(inode->i_rdev);
   
   if(minor != 0)
     return(-ENXIO);
   
   if(gart_in_use == 0) 
     {
	gart_in_use = 1;
	file->private_data = &gart_controller;
     }
   else
     file->private_data = &gart_client;
   
   MOD_INC_USE_COUNT;
   return(0);
}

static struct file_operations gart_fops =
{
   gart_lseek,
   gart_read,
   gart_write,
   NULL,
   NULL,
   gart_ioctl,
   gart_mmap,
   gart_open,
   NULL,
   gart_release
};

void gart_free_table(void)
{
   int i;
   char *table, *table_end;
   void *tmp_ptr;
   unsigned long tmp_value;
   
   
   for(i = 0; i < gart_init->num_entries; i++)
     {
	if(gart_table[i] != 0)
	  {
	     tmp_value = gart_table[i];
	     gart_table[i] = 0;
	     tmp_value &= ~(gart_mask);
	     tmp_ptr = (void *) bus_to_virt(tmp_value);
	     gart_destroy_page(tmp_ptr);
	  }
     }
#ifdef KERNEL_PATCH_REQUIRED   
   iounmap(gart_table);
#endif
      
   table = (char *)gart_table_real;   
   table_end = table + ((PAGE_SIZE * (1 << gart_init->page_order)) - 1);
     
   for(i = MAP_NR(table); i < MAP_NR(table_end); i++)
     {
	clear_bit(PG_reserved, &mem_map[i].flags);
     }   
      
   free_pages((unsigned long) gart_table_real, gart_init->page_order);
}

/* 
 * Main Initialization Function 
 */


static int gart_initialize(void)
{
int ret_val;
int size, old_size;

   gart_in_use = 0;
   gart_mode = AGP_MODE1X;

   printk( "Linux AGP GART interface v0.04 (c) Jeff Hartmann\n");
#ifdef CONFIG_DEVFS_FS
   if ((dev_handle = devfs_register("gart", 0, DEVFS_FL_NONE,
			AGPGART_MAJOR, 0,
			S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IFCHR,
			0, 0,
			&gart_fops, NULL)) == NULL)
#else
   if(register_chrdev(AGPGART_MAJOR, "agpgart", &gart_fops))
#endif
     {
	printk("agp_gart: unable to get major: %d\n", AGPGART_MAJOR);
	return(-EIO);
     }

   gart_find_supported();
   
   if (chipset.type == NOT_SUPPORTED)
     {
	printk("agp_gart: no supported devices found\n");
#ifdef CONFIG_DEVFS_FS
	devfs_unregister(dev_handle);
#else
        unregister_chrdev(AGPGART_MAJOR, "agpgart");
#endif
	return(-EINVAL);
     }
   
   scratch_entries = kmalloc(4096, GFP_KERNEL);
   
   if(scratch_entries == NULL)
     {
	printk("agp_gart: no memory available for scratch buffer\n");
#ifdef CONFIG_DEVFS_FS
	devfs_unregister(dev_handle);
#else
        unregister_chrdev(AGPGART_MAJOR, "agpgart");
#endif
	return(-ENOMEM);
     }
   
   old_size = size = chipset.fetch_size();
   ret_val = -1;
   
   while(size >= 4 && ret_val != 0)
     {
	ret_val = gart_create_table(size);
	size = size / 2;
     }
   
   if(ret_val != 0)
     {
	printk( "Unable to get memory for the GART table.\n");
	kfree(scratch_entries);
#ifdef CONFIG_DEVFS_FS
	devfs_unregister(dev_handle);
#else
        unregister_chrdev(AGPGART_MAJOR, "agpgart");
#endif
	return(-ENOMEM);
     }
   
   printk( "Got pages for a %i megabyte mapping for the agp aperature.\n",gart_init->size);
 
   chipset.configure();
   
   printk( "Mapped a %i megabyte agp aperature.\n", gart_init->size);
#ifdef CONFIG_MTRR
   gart_mtrr = mtrr_add(gart_map_phys, (gart_init->size * 0x100000), MTRR_TYPE_WRCOMB, 1);
#endif	
   return(0);
}

#ifdef MODULE
int init_module(void)
{
   return gart_initialize();
}

void cleanup_module(void)
{
#ifdef CONFIG_MTRR
   mtrr_del(gart_mtrr, gart_map_phys, (gart_init->size * 0x100000));
#endif
   chipset.cleanup();

   gart_free_table();

#ifdef CONFIG_DEVFS_FS
   devfs_unregister(dev_handle);
#else
   unregister_chrdev(AGPGART_MAJOR, "agpgart");
#endif
}
#else
/* Non modular code is horribly broken, do not bother using it */
void __init gart_setup(char *str, int *ints)
{
          int i;

          if (!strcmp(str,"gart_try_unsupported"))
                    gart_try_unsupported = ints[1];
}
#endif
