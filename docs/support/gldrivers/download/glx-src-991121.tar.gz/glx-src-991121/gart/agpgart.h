#ifndef __LINUX_AGPGART_H
#define __LINUX_AGPGART_H

enum chipset_type { NOT_SUPPORTED, INTEL_GENERIC, INTEL_LX, INTEL_BX, INTEL_GX,
                    VIA_GENERIC, VIA_VP3, VIA_MVP3, VIA_APOLLO_PRO, SIS_GENERIC};
enum agp_mode { AGP_MODE4X, AGP_MODE2X, AGP_MODE1X };

struct gart_info
{
   long physical;
   int size;
   int num_of_slots;
   enum chipset_type type;
   enum agp_mode mode;
};

/* Maximum size that can be allocated at once is 1024 entries */

struct gart_entry
{
   int ofs;
   int size;
};

#define GARTIOCINSERT _IOR('J', 1, struct gart_entry)
#define GARTIOCREMOVE _IOR('J', 2, struct gart_entry)
#define GARTIOCINFO   _IOW('J', 3, struct gart_info)
#define GARTIOCINIT   _IO ('J', 4)
#endif
