#include <stdio.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/time.h>
#include <linux/agpgart.h>

unsigned char *gart;
int gartfd;

int usec( void ) {
  struct timeval tv;
  struct timezone tz;
  
  gettimeofday( &tv, &tz );
  return (tv.tv_sec & 2047) * 1000000 + tv.tv_usec;
}

int MemoryBenchmark( void *buffer, int dwords ) {
  int             i;
  int             start, end;
  int             mb;
  int             *base;
  
  base = (int *)buffer;
  start = usec();
  for ( i = 0 ; i < dwords ; i += 8 ) {
    base[i] =
      base[i+1] =
      base[i+2] =
      base[i+3] =
      base[i+4] =
      base[i+5] =
      base[i+6] =
      base[i+7] = 0x15151515;         /* dmapad nops */
  }
  end = usec();
  mb = ( (float)dwords / 0x40000 ) * 1000000 / (end - start);
  printf("MemoryBenchmark: %i mb/s\n", mb );
  return mb;
}

int insert_gart(int page, int size)
{
   struct gart_entry entry;
   
   entry.ofs = page;
   entry.size = size;
   
   if(ioctl(gartfd, GARTIOCINSERT, &entry) != 0)
    {
      perror("ioctl(GARTIOCINSERT)");
      exit(1);
    }
}

int remove_gart(int page, int size)
{
   struct gart_entry entry;
   
   entry.ofs = page;
   entry.size = size;

  if (ioctl(gartfd, GARTIOCREMOVE, &entry) != 0)
    {
      perror("ioctl(GARTIOCREMOVE)");
      exit(1);
    }
}

int init_agp(void)
{
   if(ioctl(gartfd, GARTIOCINIT) != 0)
     {
	perror("ioctl(GARTIOCINIT)");
	exit(1);
     }
}

int xchangeDummy;

void FlushWriteCombining( void ) {
	__asm__ volatile( " push %%eax ; xchg %%eax, %0 ; pop %%eax" : : "m" (xchangeDummy));
	__asm__ volatile( " push %%eax ; push %%ebx ; push %%ecx ; push %%edx ; movl $0,%%eax ; cpuid ; pop %%edx ; pop %%ecx ; pop %%ebx ; pop %%eax" : /* no outputs */ :  /* no inputs */ );
}

void BenchMark()
{
  int i, worked = 1;

  i = MemoryBenchmark(gart, (1024 * 1024 * 4) / 4) +
    MemoryBenchmark(gart, (1024 * 1024 * 4) / 4) +
    MemoryBenchmark(gart, (1024 * 1024 * 4) / 4);
  
  printf("Average speed: %i mb/s\n", i /3);
  
  printf("Testing data integrity : ");
  fflush(stdout);
   
  FlushWriteCombining();
  
  for (i=0; i < 1024 * 1024 * 4; i++)
    {
      gart[i] = i % 256;
    }
   
  FlushWriteCombining();
   
  
  for (i=0; i < 1024 * 1024 * 4; i++)
    {
      if (gart[i] != i % 256)
	worked = 0;
    }
  
  if (!worked)
    printf("failed!\n");
  else
    printf("passed.\n");
}

int main()
{
  struct gart_info gi;
  int i;
  
  gartfd = open("/dev/gart", O_RDWR);
  if (gartfd == -1)
    {	
      perror("open");
      exit(1);
    }
  
  
  if (ioctl(gartfd, GARTIOCINFO, &gi) != 0)
    {
      perror("ioctl");
      exit(1);
    }
  
  printf("Gart size: %i\n", gi.size);
   
  gart = mmap(NULL, gi.size * 0x100000, PROT_READ | PROT_WRITE, MAP_SHARED, gartfd, 0);

  init_agp();
   
  if (gart == (unsigned char *) 0xffffffff)
    {
      perror("mmap");
      close(gartfd);
      exit(1);
    }	

  insert_gart(0, 1024);

  printf("Allocated 64 megs of GART memory\n");

  BenchMark();

  remove_gart(0, 1024);

  close(gartfd);
  
}

