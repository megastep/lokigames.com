#!/bin/sh
# autogen.sh
# Run this to generate all the initial makefiles, etc.

# some techniques borrowed from the Eterm distribution

# $Id: autogen.sh,v 1.2 1999/10/14 05:51:11 giles Exp $

echo "calling autoconf..."

(autoconf --version) < /dev/null > /dev/null 2>&1 || {
	echo
        echo "You must have autoconf installed to build the glx module."
        echo "Download the appropriate package for your distribution,"
        echo "or get the source tarball at ftp://ftp.gnu.org/pub/gnu/"
        exit 1
}
autoconf

if test -z "$*"; then
	echo ""
	echo "I am going to run ./configure with no arguments - this will "
	echo "only work if you've symlinked your Mesa source into the top "
	echo "level directory. Otherwise, you need to pass the location, "
	echo "and any other options you want, to configure through the "
	echo "./autogen.sh commandline"
	echo ""
fi
./configure "$@"
#fi

if [ -f cvs.motd ]; then
  echo "ATTENTION CVS Users!"
  echo ""
  cat cvs.motd
  echo ""
fi
