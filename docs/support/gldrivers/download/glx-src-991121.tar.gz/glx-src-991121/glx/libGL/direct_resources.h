#ifndef DIRECT_RESOURCE_H
#define DIRECT_RESOURCE_H


typedef struct {
   GCPtr ptr;
   GC gc;
   XGCValues xgcv;
   unsigned int mask;
} gc_map;

extern gc_map *find_gc_map_from_ptr( void *ptr );

/* Server side stuff
 */
extern GC find_client_gc_from_ptr( void *ptr );
extern Drawable find_client_drawable_from_ptr( void *ptr );

extern struct _GCOps fake_gcops;
extern ScreenRec directScreen;


#endif
