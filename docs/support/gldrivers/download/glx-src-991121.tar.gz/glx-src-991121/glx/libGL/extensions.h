/*
 * Code for OpenGL extensions:
 */
#ifndef GLX_EXTENSIONS_H
#define GLX_EXTENSIONS_H

#include "glxlib.h"
#include "glxcommon.h"

#if BUILD_COLOR_TABLE_EXT

void __glx_ColorTableEXT( GLenum target, GLenum internalFormat,
                          GLsizei width, GLenum format, GLenum type,
                          const GLvoid *table );
#endif



extern int __glx_send_vendor_private_with_reply( int opcode,
						 char *vp, 
						 size_t vp_sz,
						 xReply *reply,
						 char *data,
						 size_t data_sz );


#endif


