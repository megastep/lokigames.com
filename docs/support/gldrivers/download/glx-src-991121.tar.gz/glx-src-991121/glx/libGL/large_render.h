/* large_render.h,v 1.1 1998/10/10 11:36:58 ripperda Exp */

/*
 * GLX Server Extension
 * Copyright (C) 1996  Steven G. Parker  (sparker@cs.utah.edu)
 * Copyright (C) 1998, 1999  Terence Ripperda (ripperda@sgi.com)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * STEPHEN PARKER, TERENCE RIPPERDA, OR ANY OTHER CONTRIBUTORS BE LIABLE FOR 
 * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, 
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE 
 * OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */


/*
 * large_render.h,v
 * Revision 1.1  1998/10/10 11:36:58  ripperda
 * keep missing some of these new files..
 *
 */

#ifndef LARGE_RENDER_H
#define LARGE_RENDER_H 


#include "glxlib.h"

void __glx_CallLists(GLsizei n, GLenum type, const GLvoid* lists);
void __glx_PixelMapfv( GLenum map,  GLint mapsize, const  GLfloat* values);
void __glx_PixelMapuiv( GLenum map,  GLint mapsize, const  GLuint* values);
void __glx_PixelMapusv( GLenum map,  GLint mapsize, const  GLushort* values);
void __glx_PrioritizeTextures( GLint n, const  GLuint* textures, 
              const GLfloat* priorities);

#endif



