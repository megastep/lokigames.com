/* map.h,v 1.1 1998/10/10 11:36:59 ripperda Exp */


/*
 * GLX Server Extension
 * Copyright (C) 1996  Steven G. Parker  (sparker@cs.utah.edu)
 * Copyright (C) 1998, 1999  Terence Ripperda (ripperda@sgi.com)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * STEPHEN PARKER, TERENCE RIPPERDA, OR ANY OTHER CONTRIBUTORS BE LIABLE FOR 
 * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, 
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE 
 * OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */


/*
 * map.h,v
 * Revision 1.1  1998/10/10 11:36:59  ripperda
 * keep missing some of these new files..
 *
 */

#ifndef MAP_H
#define MAP_H


#include "glxlib.h"

void __glx_Map1d(GLenum target, GLdouble u1, GLdouble u2, GLint stride,
             GLint order, const GLdouble* points);

void __glx_Map1f(GLenum target, GLfloat u1, GLfloat u2, GLint stride,
             GLint order, const GLfloat* points);

void __glx_Map2d(GLenum target, GLdouble u1, GLdouble u2, GLint ustride,
             GLint uorder, GLdouble v1, GLdouble v2, GLint vstride,
             GLint vorder, const GLdouble* points);

void __glx_Map2f(GLenum target, GLfloat u1, GLfloat u2, GLint ustride,
             GLint uorder, GLfloat v1, GLfloat v2, GLint vstride,
             GLint vorder, const GLfloat* points);


#endif



