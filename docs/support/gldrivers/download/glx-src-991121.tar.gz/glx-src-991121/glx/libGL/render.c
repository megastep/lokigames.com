#include "glxlib.h"
#include "buffer_macros.h"
#include "glxcommon.h"
void __glx_Accum( GLenum op,  GLfloat value)
{
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 137, _size, 0);
	__GLX_PUT_enum(buffer, op);
	__GLX_PUT_float(buffer, value);
}

void __glx_AlphaFunc( GLenum func,  GLfloat ref)
{
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 159, _size, 0);
	__GLX_PUT_enum(buffer, func);
	__GLX_PUT_float(buffer, ref);
}

void __glx_Begin( GLenum mode)
{
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 4, _size, 0);
	__GLX_PUT_enum(buffer, mode);
}

void __glx_BindTexture( GLenum target,  GLuint texture)
{
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 4117, _size, 0);
	__GLX_PUT_enum(buffer, target);
	__GLX_PUT_uint(buffer, texture);
}

void __glx_BlendColorEXT( GLfloat red,  GLfloat green,  GLfloat blue,  GLfloat alpha)
{
	int _size=20;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 4096, _size, 0);
	__GLX_PUT_float(buffer, red);
	__GLX_PUT_float(buffer, green);
	__GLX_PUT_float(buffer, blue);
	__GLX_PUT_float(buffer, alpha);
}

void __glx_BlendEquationEXT( GLenum mode)
{
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 4097, _size, 0);
	__GLX_PUT_enum(buffer, mode);
}

void __glx_BlendFunc( GLenum sfactor,  GLenum dfactor)
{
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 160, _size, 0);
	__GLX_PUT_enum(buffer, sfactor);
	__GLX_PUT_enum(buffer, dfactor);
}

void __glx_CallList( GLuint list)
{
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 1, _size, 0);
	__GLX_PUT_uint(buffer, list);
}

void __glx_Clear( GLbitfield mask)
{
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 127, _size, 0);
	__GLX_PUT_bitfield(buffer, mask);
}

void __glx_ClearAccum( GLfloat red,  GLfloat green,  GLfloat blue,  GLfloat alpha)
{
	int _size=20;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 128, _size, 0);
	__GLX_PUT_float(buffer, red);
	__GLX_PUT_float(buffer, green);
	__GLX_PUT_float(buffer, blue);
	__GLX_PUT_float(buffer, alpha);
}

void __glx_ClearColor( GLfloat red,  GLfloat green,  GLfloat blue,  GLfloat alpha)
{
	int _size=20;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 130, _size, 0);
	__GLX_PUT_float(buffer, red);
	__GLX_PUT_float(buffer, green);
	__GLX_PUT_float(buffer, blue);
	__GLX_PUT_float(buffer, alpha);
}

void __glx_ClearDepth( GLdouble depth)
{
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 132, _size, 0);
	__GLX_PUT_double(buffer, depth);
}

void __glx_ClearIndex( GLfloat index)
{
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 129, _size, 0);
	__GLX_PUT_float(buffer, index);
}

void __glx_ClearStencil( GLint s)
{
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 131, _size, 0);
	__GLX_PUT_int(buffer, s);
}


	void __glx_ClipPlane(GLenum plane, const GLdouble* equation)

{
	int n_equation = 4;
	int _cnt;
	int _size=40;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 77, _size, 0);
	for(_cnt=0;_cnt<n_equation;_cnt++){
		__GLX_PUT_double(buffer, equation[_cnt]);
	}
	__GLX_PUT_enum(buffer, plane);
}

void __glx_Color3b( GLbyte r,  GLbyte g,  GLbyte b)
{
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 6, _size, 0);
	__GLX_PUT_byte(buffer, r);
	__GLX_PUT_byte(buffer, g);
	__GLX_PUT_byte(buffer, b);
}

void __glx_Color3bv(const  GLbyte* c)
{
	int n_c = 3;
	int _cnt;
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 6, _size, 0);
	for(_cnt=0;_cnt<n_c;_cnt++){
		__GLX_PUT_byte(buffer, c[_cnt]);
	}
}

void __glx_Color3d( GLdouble r,  GLdouble g,  GLdouble b)
{
	int _size=28;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 7, _size, 0);
	__GLX_PUT_double(buffer, r);
	__GLX_PUT_double(buffer, g);
	__GLX_PUT_double(buffer, b);
}

void __glx_Color3dv(const  GLdouble* c)
{
	int n_c = 3;
	int _cnt;
	int _size=28;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 7, _size, 0);
	for(_cnt=0;_cnt<n_c;_cnt++){
		__GLX_PUT_double(buffer, c[_cnt]);
	}
}

void __glx_Color3f( GLfloat r,  GLfloat g,  GLfloat b)
{
	int _size=16;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 8, _size, 0);
	__GLX_PUT_float(buffer, r);
	__GLX_PUT_float(buffer, g);
	__GLX_PUT_float(buffer, b);
}

void __glx_Color3fv(const  GLfloat* c)
{
	int n_c = 3;
	int _cnt;
	int _size=16;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 8, _size, 0);
	for(_cnt=0;_cnt<n_c;_cnt++){
		__GLX_PUT_float(buffer, c[_cnt]);
	}
}

void __glx_Color3i( GLint r,  GLint g,  GLint b)
{
	int _size=16;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 9, _size, 0);
	__GLX_PUT_int(buffer, r);
	__GLX_PUT_int(buffer, g);
	__GLX_PUT_int(buffer, b);
}

void __glx_Color3iv(const  GLint* c)
{
	int n_c = 3;
	int _cnt;
	int _size=16;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 9, _size, 0);
	for(_cnt=0;_cnt<n_c;_cnt++){
		__GLX_PUT_int(buffer, c[_cnt]);
	}
}

void __glx_Color3s( GLshort r,  GLshort g,  GLshort b)
{
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 10, _size, 0);
	__GLX_PUT_short(buffer, r);
	__GLX_PUT_short(buffer, g);
	__GLX_PUT_short(buffer, b);
}

void __glx_Color3sv(const  GLshort* c)
{
	int n_c = 3;
	int _cnt;
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 10, _size, 0);
	for(_cnt=0;_cnt<n_c;_cnt++){
		__GLX_PUT_short(buffer, c[_cnt]);
	}
}

void __glx_Color3ub( GLubyte r,  GLubyte g,  GLubyte b)
{
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 11, _size, 0);
	__GLX_PUT_ubyte(buffer, r);
	__GLX_PUT_ubyte(buffer, g);
	__GLX_PUT_ubyte(buffer, b);
}

void __glx_Color3ubv(const  GLubyte* c)
{
	int n_c = 3;
	int _cnt;
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 11, _size, 0);
	for(_cnt=0;_cnt<n_c;_cnt++){
		__GLX_PUT_ubyte(buffer, c[_cnt]);
	}
}

void __glx_Color3ui( GLuint r,  GLuint g,  GLuint b)
{
	int _size=16;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 12, _size, 0);
	__GLX_PUT_uint(buffer, r);
	__GLX_PUT_uint(buffer, g);
	__GLX_PUT_uint(buffer, b);
}

void __glx_Color3uiv(const  GLuint* c)
{
	int n_c = 3;
	int _cnt;
	int _size=16;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 12, _size, 0);
	for(_cnt=0;_cnt<n_c;_cnt++){
		__GLX_PUT_uint(buffer, c[_cnt]);
	}
}

void __glx_Color3us( GLushort r,  GLushort g,  GLushort b)
{
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 13, _size, 0);
	__GLX_PUT_ushort(buffer, r);
	__GLX_PUT_ushort(buffer, g);
	__GLX_PUT_ushort(buffer, b);
}

void __glx_Color3usv(const  GLushort* c)
{
	int n_c = 3;
	int _cnt;
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 13, _size, 0);
	for(_cnt=0;_cnt<n_c;_cnt++){
		__GLX_PUT_ushort(buffer, c[_cnt]);
	}
}

void __glx_Color4b( GLbyte r,  GLbyte g,  GLbyte b,  GLbyte a)
{
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 14, _size, 0);
	__GLX_PUT_byte(buffer, r);
	__GLX_PUT_byte(buffer, g);
	__GLX_PUT_byte(buffer, b);
	__GLX_PUT_byte(buffer, a);
}

void __glx_Color4bv(const  GLbyte* c)
{
	int n_c = 4;
	int _cnt;
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 14, _size, 0);
	for(_cnt=0;_cnt<n_c;_cnt++){
		__GLX_PUT_byte(buffer, c[_cnt]);
	}
}

void __glx_Color4d( GLdouble r,  GLdouble g,  GLdouble b,  GLdouble a)
{
	int _size=36;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 15, _size, 0);
	__GLX_PUT_double(buffer, r);
	__GLX_PUT_double(buffer, g);
	__GLX_PUT_double(buffer, b);
	__GLX_PUT_double(buffer, a);
}

void __glx_Color4dv(const  GLdouble* c)
{
	int n_c = 4;
	int _cnt;
	int _size=36;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 15, _size, 0);
	for(_cnt=0;_cnt<n_c;_cnt++){
		__GLX_PUT_double(buffer, c[_cnt]);
	}
}

void __glx_Color4f( GLfloat r,  GLfloat g,  GLfloat b,  GLfloat a)
{
	int _size=20;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 16, _size, 0);
	__GLX_PUT_float(buffer, r);
	__GLX_PUT_float(buffer, g);
	__GLX_PUT_float(buffer, b);
	__GLX_PUT_float(buffer, a);
}

void __glx_Color4fv(const  GLfloat* c)
{
	int n_c = 4;
	int _cnt;
	int _size=20;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 16, _size, 0);
	for(_cnt=0;_cnt<n_c;_cnt++){
		__GLX_PUT_float(buffer, c[_cnt]);
	}
}

void __glx_Color4i( GLint r,  GLint g,  GLint b,  GLint a)
{
	int _size=20;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 17, _size, 0);
	__GLX_PUT_int(buffer, r);
	__GLX_PUT_int(buffer, g);
	__GLX_PUT_int(buffer, b);
	__GLX_PUT_int(buffer, a);
}

void __glx_Color4iv(const  GLint* c)
{
	int n_c = 4;
	int _cnt;
	int _size=20;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 17, _size, 0);
	for(_cnt=0;_cnt<n_c;_cnt++){
		__GLX_PUT_int(buffer, c[_cnt]);
	}
}

void __glx_Color4s( GLshort r,  GLshort g,  GLshort b,  GLshort a)
{
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 18, _size, 0);
	__GLX_PUT_short(buffer, r);
	__GLX_PUT_short(buffer, g);
	__GLX_PUT_short(buffer, b);
	__GLX_PUT_short(buffer, a);
}

void __glx_Color4sv(const  GLshort* c)
{
	int n_c = 4;
	int _cnt;
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 18, _size, 0);
	for(_cnt=0;_cnt<n_c;_cnt++){
		__GLX_PUT_short(buffer, c[_cnt]);
	}
}

void __glx_Color4ub( GLubyte r,  GLubyte g,  GLubyte b,  GLubyte a)
{
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 19, _size, 0);
	__GLX_PUT_ubyte(buffer, r);
	__GLX_PUT_ubyte(buffer, g);
	__GLX_PUT_ubyte(buffer, b);
	__GLX_PUT_ubyte(buffer, a);
}

void __glx_Color4ubv(const  GLubyte* c)
{
	int n_c = 4;
	int _cnt;
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 19, _size, 0);
	for(_cnt=0;_cnt<n_c;_cnt++){
		__GLX_PUT_ubyte(buffer, c[_cnt]);
	}
}

void __glx_Color4ui( GLuint r,  GLuint g,  GLuint b,  GLuint a)
{
	int _size=20;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 20, _size, 0);
	__GLX_PUT_uint(buffer, r);
	__GLX_PUT_uint(buffer, g);
	__GLX_PUT_uint(buffer, b);
	__GLX_PUT_uint(buffer, a);
}

void __glx_Color4uiv(const  GLuint* c)
{
	int n_c = 4;
	int _cnt;
	int _size=20;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 20, _size, 0);
	for(_cnt=0;_cnt<n_c;_cnt++){
		__GLX_PUT_uint(buffer, c[_cnt]);
	}
}

void __glx_Color4us( GLushort r,  GLushort g,  GLushort b,  GLushort a)
{
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 21, _size, 0);
	__GLX_PUT_ushort(buffer, r);
	__GLX_PUT_ushort(buffer, g);
	__GLX_PUT_ushort(buffer, b);
	__GLX_PUT_ushort(buffer, a);
}

void __glx_Color4usv(const  GLushort* c)
{
	int n_c = 4;
	int _cnt;
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 21, _size, 0);
	for(_cnt=0;_cnt<n_c;_cnt++){
		__GLX_PUT_ushort(buffer, c[_cnt]);
	}
}

void __glx_ColorMask( GLboolean red,  GLboolean green,  GLboolean blue,  GLboolean alpha)
{
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 134, _size, 0);
	__GLX_PUT_boolean(buffer, red);
	__GLX_PUT_boolean(buffer, green);
	__GLX_PUT_boolean(buffer, blue);
	__GLX_PUT_boolean(buffer, alpha);
}

void __glx_ColorMaterial( GLenum face,  GLenum mode)
{
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 78, _size, 0);
	__GLX_PUT_enum(buffer, face);
	__GLX_PUT_enum(buffer, mode);
}

void __glx_CopyPixels( GLint x,  GLint y,  GLint width,  GLint height,  GLenum type)
{
	int _size=24;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 172, _size, 0);
	__GLX_PUT_int(buffer, x);
	__GLX_PUT_int(buffer, y);
	__GLX_PUT_int(buffer, width);
	__GLX_PUT_int(buffer, height);
	__GLX_PUT_enum(buffer, type);
}

void __glx_CopyTexImage1D( GLenum target,  GLint level,  GLenum internalFormat,  GLint x,  GLint y,  GLint width,  GLint border)
{
	int _size=32;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 4119, _size, 0);
	__GLX_PUT_enum(buffer, target);
	__GLX_PUT_int(buffer, level);
	__GLX_PUT_enum(buffer, internalFormat);
	__GLX_PUT_int(buffer, x);
	__GLX_PUT_int(buffer, y);
	__GLX_PUT_int(buffer, width);
	__GLX_PUT_int(buffer, border);
}

void __glx_CopyTexImage2D( GLenum target,  GLint level,  GLenum internalFormat,  GLint x,  GLint y,  GLint width,  GLint height,  GLint border)
{
	int _size=36;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 4120, _size, 0);
	__GLX_PUT_enum(buffer, target);
	__GLX_PUT_int(buffer, level);
	__GLX_PUT_enum(buffer, internalFormat);
	__GLX_PUT_int(buffer, x);
	__GLX_PUT_int(buffer, y);
	__GLX_PUT_int(buffer, width);
	__GLX_PUT_int(buffer, height);
	__GLX_PUT_int(buffer, border);
}

void __glx_CopyTexSubImage1D( GLenum target,  GLint level,  GLint offset,  GLint x,  GLint y,  GLint width)
{
	int _size=28;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 4121, _size, 0);
	__GLX_PUT_enum(buffer, target);
	__GLX_PUT_int(buffer, level);
	__GLX_PUT_int(buffer, offset);
	__GLX_PUT_int(buffer, x);
	__GLX_PUT_int(buffer, y);
	__GLX_PUT_int(buffer, width);
}

void __glx_CopyTexSubImage2D( GLenum target,  GLint level,  GLint xoffset,  GLint yoffset,  GLint x,  GLint y,  GLint width,  GLint height)
{
	int _size=36;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 4122, _size, 0);
	__GLX_PUT_enum(buffer, target);
	__GLX_PUT_int(buffer, level);
	__GLX_PUT_int(buffer, xoffset);
	__GLX_PUT_int(buffer, yoffset);
	__GLX_PUT_int(buffer, x);
	__GLX_PUT_int(buffer, y);
	__GLX_PUT_int(buffer, width);
	__GLX_PUT_int(buffer, height);
}

void __glx_CullFace( GLenum mode)
{
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 79, _size, 0);
	__GLX_PUT_enum(buffer, mode);
}

void __glx_DepthFunc( GLenum func)
{
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 164, _size, 0);
	__GLX_PUT_enum(buffer, func);
}

void __glx_DepthMask( GLboolean flag)
{
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 135, _size, 0);
	__GLX_PUT_boolean(buffer, flag);
}

void __glx_DepthRange( GLdouble near,  GLdouble far)
{
	int _size=20;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 174, _size, 0);
	__GLX_PUT_double(buffer, near);
	__GLX_PUT_double(buffer, far);
}

void __glx_Disable( GLenum cap)
{
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 138, _size, 0);
	__GLX_PUT_enum(buffer, cap);
}

void __glx_DrawBuffer( GLenum mode)
{
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 126, _size, 0);
	__GLX_PUT_enum(buffer, mode);
}

void __glx_EdgeFlag( GLboolean flag)
{
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 22, _size, 0);
	__GLX_PUT_boolean(buffer, flag);
}

void __glx_EdgeFlagv(const  GLboolean* flag)
{
	int n_flag = 1;
	int _cnt;
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 22, _size, 0);
	for(_cnt=0;_cnt<n_flag;_cnt++){
		__GLX_PUT_boolean(buffer, flag[_cnt]);
	}
}

void __glx_Enable( GLenum cap)
{
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 139, _size, 0);
	__GLX_PUT_enum(buffer, cap);
}

void __glx_End()
{
	int _size=4;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 23, _size, 0);
}

void __glx_EvalCoord1d( GLdouble u0)
{
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 151, _size, 0);
	__GLX_PUT_double(buffer, u0);
}

void __glx_EvalCoord1dv(const  GLdouble* u)
{
	int n_u = 1;
	int _cnt;
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 151, _size, 0);
	for(_cnt=0;_cnt<n_u;_cnt++){
		__GLX_PUT_double(buffer, u[_cnt]);
	}
}

void __glx_EvalCoord1f( GLfloat u0)
{
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 152, _size, 0);
	__GLX_PUT_float(buffer, u0);
}

void __glx_EvalCoord1fv(const  GLfloat* u)
{
	int n_u = 1;
	int _cnt;
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 152, _size, 0);
	for(_cnt=0;_cnt<n_u;_cnt++){
		__GLX_PUT_float(buffer, u[_cnt]);
	}
}

void __glx_EvalCoord2d( GLdouble u0,  GLdouble u1)
{
	int _size=20;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 153, _size, 0);
	__GLX_PUT_double(buffer, u0);
	__GLX_PUT_double(buffer, u1);
}

void __glx_EvalCoord2dv(const  GLdouble* u)
{
	int n_u = 2;
	int _cnt;
	int _size=20;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 153, _size, 0);
	for(_cnt=0;_cnt<n_u;_cnt++){
		__GLX_PUT_double(buffer, u[_cnt]);
	}
}

void __glx_EvalCoord2f( GLfloat u0,  GLfloat u1)
{
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 154, _size, 0);
	__GLX_PUT_float(buffer, u0);
	__GLX_PUT_float(buffer, u1);
}

void __glx_EvalCoord2fv(const  GLfloat* u)
{
	int n_u = 2;
	int _cnt;
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 154, _size, 0);
	for(_cnt=0;_cnt<n_u;_cnt++){
		__GLX_PUT_float(buffer, u[_cnt]);
	}
}

void __glx_EvalMesh1( GLenum mode,  GLint i1,  GLint i2)
{
	int _size=16;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 155, _size, 0);
	__GLX_PUT_enum(buffer, mode);
	__GLX_PUT_int(buffer, i1);
	__GLX_PUT_int(buffer, i2);
}

void __glx_EvalMesh2( GLenum mode,  GLint i1,  GLint i2,  GLint j1,  GLint j2)
{
	int _size=24;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 157, _size, 0);
	__GLX_PUT_enum(buffer, mode);
	__GLX_PUT_int(buffer, i1);
	__GLX_PUT_int(buffer, i2);
	__GLX_PUT_int(buffer, j1);
	__GLX_PUT_int(buffer, j2);
}

void __glx_EvalPoint1( GLint i)
{
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 156, _size, 0);
	__GLX_PUT_int(buffer, i);
}

void __glx_EvalPoint2( GLint i,  GLint j)
{
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 158, _size, 0);
	__GLX_PUT_int(buffer, i);
	__GLX_PUT_int(buffer, j);
}

void __glx_Fogf( GLenum pname,  GLfloat param)
{
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 80, _size, 0);
	__GLX_PUT_enum(buffer, pname);
	__GLX_PUT_float(buffer, param);
}

void __glx_Fogfv( GLenum pname, const  GLfloat* params)
{
	int n_params = GLX_fog_size(pname);
	int _cnt;
	int _size=8+(4*GLX_fog_size(pname));
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 81, _size, 0);
	__GLX_PUT_enum(buffer, pname);
	for(_cnt=0;_cnt<n_params;_cnt++){
		__GLX_PUT_float(buffer, params[_cnt]);
	}
}

void __glx_Fogi( GLenum pname,  GLint param)
{
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 82, _size, 0);
	__GLX_PUT_enum(buffer, pname);
	__GLX_PUT_int(buffer, param);
}

void __glx_Fogiv( GLenum pname, const  GLint* params)
{
	int n_params = GLX_fog_size(pname);
	int _cnt;
	int _size=8+(4*GLX_fog_size(pname));
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 83, _size, 0);
	__GLX_PUT_enum(buffer, pname);
	for(_cnt=0;_cnt<n_params;_cnt++){
		__GLX_PUT_int(buffer, params[_cnt]);
	}
}

void __glx_FrontFace( GLenum mode)
{
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 84, _size, 0);
	__GLX_PUT_enum(buffer, mode);
}

void __glx_Frustum( GLdouble left,  GLdouble right,  GLdouble bottom,  GLdouble top,  GLdouble near,  GLdouble far)
{
	int _size=52;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 175, _size, 0);
	__GLX_PUT_double(buffer, left);
	__GLX_PUT_double(buffer, right);
	__GLX_PUT_double(buffer, bottom);
	__GLX_PUT_double(buffer, top);
	__GLX_PUT_double(buffer, near);
	__GLX_PUT_double(buffer, far);
}

void __glx_Hint( GLenum target,  GLenum mode)
{
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 85, _size, 0);
	__GLX_PUT_enum(buffer, target);
	__GLX_PUT_enum(buffer, mode);
}

void __glx_IndexMask( GLuint mask)
{
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 136, _size, 0);
	__GLX_PUT_uint(buffer, mask);
}

void __glx_Indexd( GLdouble c)
{
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 24, _size, 0);
	__GLX_PUT_double(buffer, c);
}

void __glx_Indexdv(const  GLdouble* c)
{
	int n_c = 1;
	int _cnt;
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 24, _size, 0);
	for(_cnt=0;_cnt<n_c;_cnt++){
		__GLX_PUT_double(buffer, c[_cnt]);
	}
}

void __glx_Indexf( GLfloat c)
{
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 25, _size, 0);
	__GLX_PUT_float(buffer, c);
}

void __glx_Indexfv(const  GLfloat* c)
{
	int n_c = 1;
	int _cnt;
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 25, _size, 0);
	for(_cnt=0;_cnt<n_c;_cnt++){
		__GLX_PUT_float(buffer, c[_cnt]);
	}
}

void __glx_Indexi( GLint c)
{
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 26, _size, 0);
	__GLX_PUT_int(buffer, c);
}

void __glx_Indexiv(const  GLint* c)
{
	int n_c = 1;
	int _cnt;
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 26, _size, 0);
	for(_cnt=0;_cnt<n_c;_cnt++){
		__GLX_PUT_int(buffer, c[_cnt]);
	}
}

void __glx_Indexs( GLshort c)
{
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 27, _size, 0);
	__GLX_PUT_short(buffer, c);
}

void __glx_Indexsv(const  GLshort* c)
{
	int n_c = 1;
	int _cnt;
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 27, _size, 0);
	for(_cnt=0;_cnt<n_c;_cnt++){
		__GLX_PUT_short(buffer, c[_cnt]);
	}
}

void __glx_Indexubv(const  GLubyte* c)
{
	int n_c = 1;
	int _cnt;
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 194, _size, 0);
	for(_cnt=0;_cnt<n_c;_cnt++){
		__GLX_PUT_ubyte(buffer, c[_cnt]);
	}
}

void __glx_InitNames()
{
	int _size=4;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 121, _size, 0);
}

void __glx_LightModelf( GLenum pname,  GLfloat param)
{
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 90, _size, 0);
	__GLX_PUT_enum(buffer, pname);
	__GLX_PUT_float(buffer, param);
}

void __glx_LightModelfv( GLenum pname, const  GLfloat* params)
{
	int n_params = GLX_lightmodel_size(pname);
	int _cnt;
	int _size=8+(4*GLX_lightmodel_size(pname));
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 91, _size, 0);
	__GLX_PUT_enum(buffer, pname);
	for(_cnt=0;_cnt<n_params;_cnt++){
		__GLX_PUT_float(buffer, params[_cnt]);
	}
}

void __glx_LightModeli( GLenum pname,  GLint param)
{
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 92, _size, 0);
	__GLX_PUT_enum(buffer, pname);
	__GLX_PUT_int(buffer, param);
}

void __glx_LightModeliv( GLenum pname, const  GLint* params)
{
	int n_params = GLX_lightmodel_size(pname);
	int _cnt;
	int _size=8+(4*GLX_lightmodel_size(pname));
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 93, _size, 0);
	__GLX_PUT_enum(buffer, pname);
	for(_cnt=0;_cnt<n_params;_cnt++){
		__GLX_PUT_int(buffer, params[_cnt]);
	}
}

void __glx_Lightf( GLenum light,  GLenum pname,  GLfloat param)
{
	int _size=16;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 86, _size, 0);
	__GLX_PUT_enum(buffer, light);
	__GLX_PUT_enum(buffer, pname);
	__GLX_PUT_float(buffer, param);
}

void __glx_Lightfv( GLenum light,  GLenum pname, const  GLfloat* params)
{
	int n_params = GLX_light_size(pname);
	int _cnt;
	int _size=12+(4*GLX_light_size(pname));
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 87, _size, 0);
	__GLX_PUT_enum(buffer, light);
	__GLX_PUT_enum(buffer, pname);
	for(_cnt=0;_cnt<n_params;_cnt++){
		__GLX_PUT_float(buffer, params[_cnt]);
	}
}

void __glx_Lighti( GLenum light,  GLenum pname,  GLint param)
{
	int _size=16;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 88, _size, 0);
	__GLX_PUT_enum(buffer, light);
	__GLX_PUT_enum(buffer, pname);
	__GLX_PUT_int(buffer, param);
}

void __glx_Lightiv( GLenum light,  GLenum pname, const  GLint* params)
{
	int n_params = GLX_light_size(pname);
	int _cnt;
	int _size=12+(4*GLX_light_size(pname));
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 89, _size, 0);
	__GLX_PUT_enum(buffer, light);
	__GLX_PUT_enum(buffer, pname);
	for(_cnt=0;_cnt<n_params;_cnt++){
		__GLX_PUT_int(buffer, params[_cnt]);
	}
}

void __glx_LineStipple( GLint factor,  GLushort pattern)
{
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 94, _size, 0);
	__GLX_PUT_int(buffer, factor);
	__GLX_PUT_ushort(buffer, pattern);
}

void __glx_LineWidth( GLfloat width)
{
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 95, _size, 0);
	__GLX_PUT_float(buffer, width);
}

void __glx_ListBase( GLuint base)
{
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 3, _size, 0);
	__GLX_PUT_uint(buffer, base);
}

void __glx_LoadIdentity()
{
	int _size=4;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 176, _size, 0);
}

void __glx_LoadMatrixd(const  GLdouble* m)
{
	int n_m = 16;
	int _cnt;
	int _size=132;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 178, _size, 0);
	for(_cnt=0;_cnt<n_m;_cnt++){
		__GLX_PUT_double(buffer, m[_cnt]);
	}
}

void __glx_LoadMatrixf(const  GLfloat* m)
{
	int n_m = 16;
	int _cnt;
	int _size=68;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 177, _size, 0);
	for(_cnt=0;_cnt<n_m;_cnt++){
		__GLX_PUT_float(buffer, m[_cnt]);
	}
}

void __glx_LoadName( GLuint name)
{
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 122, _size, 0);
	__GLX_PUT_uint(buffer, name);
}

void __glx_LogicOp( GLenum opcode)
{
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 161, _size, 0);
	__GLX_PUT_enum(buffer, opcode);
}


	void __glx_MapGrid1d(int un, double u1, double u2)

{
	int _size=24;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 147, _size, 0);
	__GLX_PUT_double(buffer, u1);
	__GLX_PUT_double(buffer, u2);
	__GLX_PUT_int(buffer, un);
}

void __glx_MapGrid1f( GLint un,  GLfloat u1,  GLfloat u2)
{
	int _size=16;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 148, _size, 0);
	__GLX_PUT_int(buffer, un);
	__GLX_PUT_float(buffer, u1);
	__GLX_PUT_float(buffer, u2);
}


	void __glx_MapGrid2d(int un, double u1, double u2, int vn, double v1, double v2)

{
	int _size=44;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 149, _size, 0);
	__GLX_PUT_double(buffer, u1);
	__GLX_PUT_double(buffer, u2);
	__GLX_PUT_double(buffer, v1);
	__GLX_PUT_double(buffer, v2);
	__GLX_PUT_int(buffer, un);
	__GLX_PUT_int(buffer, vn);
}

void __glx_MapGrid2f( GLint un,  GLfloat u1,  GLfloat u2,  GLint vn,  GLfloat v1,  GLfloat v2)
{
	int _size=28;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 150, _size, 0);
	__GLX_PUT_int(buffer, un);
	__GLX_PUT_float(buffer, u1);
	__GLX_PUT_float(buffer, u2);
	__GLX_PUT_int(buffer, vn);
	__GLX_PUT_float(buffer, v1);
	__GLX_PUT_float(buffer, v2);
}

void __glx_Materialf( GLenum face,  GLenum pname,  GLfloat param)
{
	int _size=16;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 96, _size, 0);
	__GLX_PUT_enum(buffer, face);
	__GLX_PUT_enum(buffer, pname);
	__GLX_PUT_float(buffer, param);
}

void __glx_Materialfv( GLenum face,  GLenum pname, const  GLfloat* params)
{
	int n_params = GLX_material_size(pname);
	int _cnt;
	int _size=12+(4*GLX_material_size(pname));
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 97, _size, 0);
	__GLX_PUT_enum(buffer, face);
	__GLX_PUT_enum(buffer, pname);
	for(_cnt=0;_cnt<n_params;_cnt++){
		__GLX_PUT_float(buffer, params[_cnt]);
	}
}

void __glx_Materiali( GLenum face,  GLenum pname,  GLint param)
{
	int _size=16;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 98, _size, 0);
	__GLX_PUT_enum(buffer, face);
	__GLX_PUT_enum(buffer, pname);
	__GLX_PUT_int(buffer, param);
}

void __glx_Materialiv( GLenum face,  GLenum pname, const  GLint* params)
{
	int n_params = GLX_material_size(pname);
	int _cnt;
	int _size=12+(4*GLX_material_size(pname));
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 99, _size, 0);
	__GLX_PUT_enum(buffer, face);
	__GLX_PUT_enum(buffer, pname);
	for(_cnt=0;_cnt<n_params;_cnt++){
		__GLX_PUT_int(buffer, params[_cnt]);
	}
}

void __glx_MatrixMode( GLenum mode)
{
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 179, _size, 0);
	__GLX_PUT_enum(buffer, mode);
}

void __glx_MultMatrixd(const  GLdouble* m)
{
	int n_m = 16;
	int _cnt;
	int _size=132;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 181, _size, 0);
	for(_cnt=0;_cnt<n_m;_cnt++){
		__GLX_PUT_double(buffer, m[_cnt]);
	}
}

void __glx_MultMatrixf(const  GLfloat* m)
{
	int n_m = 16;
	int _cnt;
	int _size=68;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 180, _size, 0);
	for(_cnt=0;_cnt<n_m;_cnt++){
		__GLX_PUT_float(buffer, m[_cnt]);
	}
}

void __glx_Normal3b( GLbyte x,  GLbyte y,  GLbyte z)
{
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 28, _size, 0);
	__GLX_PUT_byte(buffer, x);
	__GLX_PUT_byte(buffer, y);
	__GLX_PUT_byte(buffer, z);
}

void __glx_Normal3bv(const  GLbyte* v)
{
	int n_v = 3;
	int _cnt;
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 28, _size, 0);
	for(_cnt=0;_cnt<n_v;_cnt++){
		__GLX_PUT_byte(buffer, v[_cnt]);
	}
}

void __glx_Normal3d( GLdouble x,  GLdouble y,  GLdouble z)
{
	int _size=28;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 29, _size, 0);
	__GLX_PUT_double(buffer, x);
	__GLX_PUT_double(buffer, y);
	__GLX_PUT_double(buffer, z);
}

void __glx_Normal3dv(const  GLdouble* v)
{
	int n_v = 3;
	int _cnt;
	int _size=28;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 29, _size, 0);
	for(_cnt=0;_cnt<n_v;_cnt++){
		__GLX_PUT_double(buffer, v[_cnt]);
	}
}

void __glx_Normal3f( GLfloat x,  GLfloat y,  GLfloat z)
{
	int _size=16;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 30, _size, 0);
	__GLX_PUT_float(buffer, x);
	__GLX_PUT_float(buffer, y);
	__GLX_PUT_float(buffer, z);
}

void __glx_Normal3fv(const  GLfloat* v)
{
	int n_v = 3;
	int _cnt;
	int _size=16;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 30, _size, 0);
	for(_cnt=0;_cnt<n_v;_cnt++){
		__GLX_PUT_float(buffer, v[_cnt]);
	}
}

void __glx_Normal3i( GLint x,  GLint y,  GLint z)
{
	int _size=16;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 31, _size, 0);
	__GLX_PUT_int(buffer, x);
	__GLX_PUT_int(buffer, y);
	__GLX_PUT_int(buffer, z);
}

void __glx_Normal3iv(const  GLint* v)
{
	int n_v = 3;
	int _cnt;
	int _size=16;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 31, _size, 0);
	for(_cnt=0;_cnt<n_v;_cnt++){
		__GLX_PUT_int(buffer, v[_cnt]);
	}
}

void __glx_Normal3s( GLshort x,  GLshort y,  GLshort z)
{
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 32, _size, 0);
	__GLX_PUT_short(buffer, x);
	__GLX_PUT_short(buffer, y);
	__GLX_PUT_short(buffer, z);
}

void __glx_Normal3sv(const  GLshort* v)
{
	int n_v = 3;
	int _cnt;
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 32, _size, 0);
	for(_cnt=0;_cnt<n_v;_cnt++){
		__GLX_PUT_short(buffer, v[_cnt]);
	}
}

void __glx_Ortho( GLdouble left,  GLdouble right,  GLdouble bottom,  GLdouble top,  GLdouble near,  GLdouble far)
{
	int _size=52;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 182, _size, 0);
	__GLX_PUT_double(buffer, left);
	__GLX_PUT_double(buffer, right);
	__GLX_PUT_double(buffer, bottom);
	__GLX_PUT_double(buffer, top);
	__GLX_PUT_double(buffer, near);
	__GLX_PUT_double(buffer, far);
}

void __glx_PassThrough( GLfloat token)
{
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 123, _size, 0);
	__GLX_PUT_float(buffer, token);
}

void __glx_PixelTransferf( GLenum pname,  GLfloat param)
{
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 166, _size, 0);
	__GLX_PUT_enum(buffer, pname);
	__GLX_PUT_float(buffer, param);
}

void __glx_PixelTransferi( GLenum pname,  GLint param)
{
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 167, _size, 0);
	__GLX_PUT_enum(buffer, pname);
	__GLX_PUT_int(buffer, param);
}

void __glx_PixelZoom( GLfloat xfactor,  GLfloat yfactor)
{
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 165, _size, 0);
	__GLX_PUT_float(buffer, xfactor);
	__GLX_PUT_float(buffer, yfactor);
}

void __glx_PointSize( GLfloat size)
{
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 100, _size, 0);
	__GLX_PUT_float(buffer, size);
}

void __glx_PolygonMode( GLenum face,  GLenum mode)
{
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 101, _size, 0);
	__GLX_PUT_enum(buffer, face);
	__GLX_PUT_enum(buffer, mode);
}

void __glx_PolygonOffset( GLfloat factor,  GLfloat units)
{
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 192, _size, 0);
	__GLX_PUT_float(buffer, factor);
	__GLX_PUT_float(buffer, units);
}

void __glx_PopAttrib()
{
	int _size=4;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 141, _size, 0);
}

void __glx_PopMatrix()
{
	int _size=4;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 183, _size, 0);
}

void __glx_PopName()
{
	int _size=4;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 124, _size, 0);
}

void __glx_PushAttrib( GLbitfield mask)
{
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 142, _size, 0);
	__GLX_PUT_bitfield(buffer, mask);
}

void __glx_PushMatrix()
{
	int _size=4;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 184, _size, 0);
}

void __glx_PushName( GLuint name)
{
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 125, _size, 0);
	__GLX_PUT_uint(buffer, name);
}

void __glx_RasterPos2d( GLdouble x,  GLdouble y)
{
	int _size=20;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 33, _size, 0);
	__GLX_PUT_double(buffer, x);
	__GLX_PUT_double(buffer, y);
}

void __glx_RasterPos2dv(const  GLdouble* v)
{
	int n_v = 2;
	int _cnt;
	int _size=20;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 33, _size, 0);
	for(_cnt=0;_cnt<n_v;_cnt++){
		__GLX_PUT_double(buffer, v[_cnt]);
	}
}

void __glx_RasterPos2f( GLfloat x,  GLfloat y)
{
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 34, _size, 0);
	__GLX_PUT_float(buffer, x);
	__GLX_PUT_float(buffer, y);
}

void __glx_RasterPos2fv(const  GLfloat* v)
{
	int n_v = 2;
	int _cnt;
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 34, _size, 0);
	for(_cnt=0;_cnt<n_v;_cnt++){
		__GLX_PUT_float(buffer, v[_cnt]);
	}
}

void __glx_RasterPos2i( GLint x,  GLint y)
{
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 35, _size, 0);
	__GLX_PUT_int(buffer, x);
	__GLX_PUT_int(buffer, y);
}

void __glx_RasterPos2iv(const  GLint* v)
{
	int n_v = 2;
	int _cnt;
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 35, _size, 0);
	for(_cnt=0;_cnt<n_v;_cnt++){
		__GLX_PUT_int(buffer, v[_cnt]);
	}
}

void __glx_RasterPos2s( GLshort x,  GLshort y)
{
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 36, _size, 0);
	__GLX_PUT_short(buffer, x);
	__GLX_PUT_short(buffer, y);
}

void __glx_RasterPos2sv(const  GLshort* v)
{
	int n_v = 2;
	int _cnt;
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 36, _size, 0);
	for(_cnt=0;_cnt<n_v;_cnt++){
		__GLX_PUT_short(buffer, v[_cnt]);
	}
}

void __glx_RasterPos3d( GLdouble x,  GLdouble y,  GLdouble z)
{
	int _size=28;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 37, _size, 0);
	__GLX_PUT_double(buffer, x);
	__GLX_PUT_double(buffer, y);
	__GLX_PUT_double(buffer, z);
}

void __glx_RasterPos3dv(const  GLdouble* v)
{
	int n_v = 3;
	int _cnt;
	int _size=28;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 37, _size, 0);
	for(_cnt=0;_cnt<n_v;_cnt++){
		__GLX_PUT_double(buffer, v[_cnt]);
	}
}

void __glx_RasterPos3f( GLfloat x,  GLfloat y,  GLfloat z)
{
	int _size=16;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 38, _size, 0);
	__GLX_PUT_float(buffer, x);
	__GLX_PUT_float(buffer, y);
	__GLX_PUT_float(buffer, z);
}

void __glx_RasterPos3fv(const  GLfloat* v)
{
	int n_v = 3;
	int _cnt;
	int _size=16;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 38, _size, 0);
	for(_cnt=0;_cnt<n_v;_cnt++){
		__GLX_PUT_float(buffer, v[_cnt]);
	}
}

void __glx_RasterPos3i( GLint x,  GLint y,  GLint z)
{
	int _size=16;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 39, _size, 0);
	__GLX_PUT_int(buffer, x);
	__GLX_PUT_int(buffer, y);
	__GLX_PUT_int(buffer, z);
}

void __glx_RasterPos3iv(const  GLint* v)
{
	int n_v = 3;
	int _cnt;
	int _size=16;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 39, _size, 0);
	for(_cnt=0;_cnt<n_v;_cnt++){
		__GLX_PUT_int(buffer, v[_cnt]);
	}
}

void __glx_RasterPos3s( GLshort x,  GLshort y,  GLshort z)
{
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 40, _size, 0);
	__GLX_PUT_short(buffer, x);
	__GLX_PUT_short(buffer, y);
	__GLX_PUT_short(buffer, z);
}

void __glx_RasterPos3sv(const  GLshort* v)
{
	int n_v = 3;
	int _cnt;
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 40, _size, 0);
	for(_cnt=0;_cnt<n_v;_cnt++){
		__GLX_PUT_short(buffer, v[_cnt]);
	}
}

void __glx_RasterPos4d( GLdouble x,  GLdouble y,  GLdouble z,  GLdouble w)
{
	int _size=36;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 41, _size, 0);
	__GLX_PUT_double(buffer, x);
	__GLX_PUT_double(buffer, y);
	__GLX_PUT_double(buffer, z);
	__GLX_PUT_double(buffer, w);
}

void __glx_RasterPos4dv(const  GLdouble* v)
{
	int n_v = 4;
	int _cnt;
	int _size=36;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 41, _size, 0);
	for(_cnt=0;_cnt<n_v;_cnt++){
		__GLX_PUT_double(buffer, v[_cnt]);
	}
}

void __glx_RasterPos4f( GLfloat x,  GLfloat y,  GLfloat z,  GLfloat w)
{
	int _size=20;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 42, _size, 0);
	__GLX_PUT_float(buffer, x);
	__GLX_PUT_float(buffer, y);
	__GLX_PUT_float(buffer, z);
	__GLX_PUT_float(buffer, w);
}

void __glx_RasterPos4fv(const  GLfloat* v)
{
	int n_v = 4;
	int _cnt;
	int _size=20;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 42, _size, 0);
	for(_cnt=0;_cnt<n_v;_cnt++){
		__GLX_PUT_float(buffer, v[_cnt]);
	}
}

void __glx_RasterPos4i( GLint x,  GLint y,  GLint z,  GLint w)
{
	int _size=20;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 43, _size, 0);
	__GLX_PUT_int(buffer, x);
	__GLX_PUT_int(buffer, y);
	__GLX_PUT_int(buffer, z);
	__GLX_PUT_int(buffer, w);
}

void __glx_RasterPos4iv(const  GLint* v)
{
	int n_v = 4;
	int _cnt;
	int _size=20;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 43, _size, 0);
	for(_cnt=0;_cnt<n_v;_cnt++){
		__GLX_PUT_int(buffer, v[_cnt]);
	}
}

void __glx_RasterPos4s( GLshort x,  GLshort y,  GLshort z,  GLshort w)
{
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 44, _size, 0);
	__GLX_PUT_short(buffer, x);
	__GLX_PUT_short(buffer, y);
	__GLX_PUT_short(buffer, z);
	__GLX_PUT_short(buffer, w);
}

void __glx_RasterPos4sv(const  GLshort* v)
{
	int n_v = 4;
	int _cnt;
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 44, _size, 0);
	for(_cnt=0;_cnt<n_v;_cnt++){
		__GLX_PUT_short(buffer, v[_cnt]);
	}
}

void __glx_ReadBuffer( GLenum mode)
{
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 171, _size, 0);
	__GLX_PUT_enum(buffer, mode);
}

void __glx_Rectd( GLdouble x1,  GLdouble y1,  GLdouble x2,  GLdouble y2)
{
	int _size=36;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 45, _size, 0);
	__GLX_PUT_double(buffer, x1);
	__GLX_PUT_double(buffer, y1);
	__GLX_PUT_double(buffer, x2);
	__GLX_PUT_double(buffer, y2);
}

void __glx_Rectdv(const  GLdouble* v1, const  GLdouble* v2)
{
	int n_v1 = 2;
	int _cnt;
	int n_v2 = 2;
	int _size=36;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 45, _size, 0);
	for(_cnt=0;_cnt<n_v1;_cnt++){
		__GLX_PUT_double(buffer, v1[_cnt]);
	}
	for(_cnt=0;_cnt<n_v2;_cnt++){
		__GLX_PUT_double(buffer, v2[_cnt]);
	}
}

void __glx_Rectf( GLfloat x1,  GLfloat y1,  GLfloat x2,  GLfloat y2)
{
	int _size=20;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 46, _size, 0);
	__GLX_PUT_float(buffer, x1);
	__GLX_PUT_float(buffer, y1);
	__GLX_PUT_float(buffer, x2);
	__GLX_PUT_float(buffer, y2);
}

void __glx_Rectfv(const  GLfloat* v1, const  GLfloat* v2)
{
	int n_v1 = 2;
	int _cnt;
	int n_v2 = 2;
	int _size=20;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 46, _size, 0);
	for(_cnt=0;_cnt<n_v1;_cnt++){
		__GLX_PUT_float(buffer, v1[_cnt]);
	}
	for(_cnt=0;_cnt<n_v2;_cnt++){
		__GLX_PUT_float(buffer, v2[_cnt]);
	}
}

void __glx_Recti( GLint x1,  GLint y1,  GLint x2,  GLint y2)
{
	int _size=20;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 47, _size, 0);
	__GLX_PUT_int(buffer, x1);
	__GLX_PUT_int(buffer, y1);
	__GLX_PUT_int(buffer, x2);
	__GLX_PUT_int(buffer, y2);
}

void __glx_Rectiv(const  GLint* v1, const  GLint* v2)
{
	int n_v1 = 2;
	int _cnt;
	int n_v2 = 2;
	int _size=20;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 47, _size, 0);
	for(_cnt=0;_cnt<n_v1;_cnt++){
		__GLX_PUT_int(buffer, v1[_cnt]);
	}
	for(_cnt=0;_cnt<n_v2;_cnt++){
		__GLX_PUT_int(buffer, v2[_cnt]);
	}
}

void __glx_Rects( GLshort x1,  GLshort y1,  GLshort x2,  GLshort y2)
{
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 48, _size, 0);
	__GLX_PUT_short(buffer, x1);
	__GLX_PUT_short(buffer, y1);
	__GLX_PUT_short(buffer, x2);
	__GLX_PUT_short(buffer, y2);
}

void __glx_Rectsv(const  GLshort* v1, const  GLshort* v2)
{
	int n_v1 = 2;
	int _cnt;
	int n_v2 = 2;
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 48, _size, 0);
	for(_cnt=0;_cnt<n_v1;_cnt++){
		__GLX_PUT_short(buffer, v1[_cnt]);
	}
	for(_cnt=0;_cnt<n_v2;_cnt++){
		__GLX_PUT_short(buffer, v2[_cnt]);
	}
}

void __glx_Rotated( GLdouble angle,  GLdouble x,  GLdouble y,  GLdouble z)
{
	int _size=36;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 185, _size, 0);
	__GLX_PUT_double(buffer, angle);
	__GLX_PUT_double(buffer, x);
	__GLX_PUT_double(buffer, y);
	__GLX_PUT_double(buffer, z);
}

void __glx_Rotatef( GLfloat angle,  GLfloat x,  GLfloat y,  GLfloat z)
{
	int _size=20;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 186, _size, 0);
	__GLX_PUT_float(buffer, angle);
	__GLX_PUT_float(buffer, x);
	__GLX_PUT_float(buffer, y);
	__GLX_PUT_float(buffer, z);
}

void __glx_Scaled( GLdouble x,  GLdouble y,  GLdouble z)
{
	int _size=28;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 187, _size, 0);
	__GLX_PUT_double(buffer, x);
	__GLX_PUT_double(buffer, y);
	__GLX_PUT_double(buffer, z);
}

void __glx_Scalef( GLfloat x,  GLfloat y,  GLfloat z)
{
	int _size=16;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 188, _size, 0);
	__GLX_PUT_float(buffer, x);
	__GLX_PUT_float(buffer, y);
	__GLX_PUT_float(buffer, z);
}

void __glx_Scissor( GLint x,  GLint y,  GLint width,  GLint height)
{
	int _size=20;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 103, _size, 0);
	__GLX_PUT_int(buffer, x);
	__GLX_PUT_int(buffer, y);
	__GLX_PUT_int(buffer, width);
	__GLX_PUT_int(buffer, height);
}

void __glx_ShadeModel( GLenum mode)
{
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 104, _size, 0);
	__GLX_PUT_enum(buffer, mode);
}

void __glx_StencilFunc( GLenum func,  GLint ref,  GLuint mask)
{
	int _size=16;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 162, _size, 0);
	__GLX_PUT_enum(buffer, func);
	__GLX_PUT_int(buffer, ref);
	__GLX_PUT_uint(buffer, mask);
}

void __glx_StencilMask( GLuint mask)
{
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 133, _size, 0);
	__GLX_PUT_uint(buffer, mask);
}

void __glx_StencilOp( GLenum fail,  GLenum zfail,  GLenum zpass)
{
	int _size=16;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 163, _size, 0);
	__GLX_PUT_enum(buffer, fail);
	__GLX_PUT_enum(buffer, zfail);
	__GLX_PUT_enum(buffer, zpass);
}

void __glx_TexCoord1d( GLdouble v)
{
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 49, _size, 0);
	__GLX_PUT_double(buffer, v);
}

void __glx_TexCoord1dv(const  GLdouble* v)
{
	int n_v = 1;
	int _cnt;
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 49, _size, 0);
	for(_cnt=0;_cnt<n_v;_cnt++){
		__GLX_PUT_double(buffer, v[_cnt]);
	}
}

void __glx_TexCoord1f( GLfloat v)
{
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 50, _size, 0);
	__GLX_PUT_float(buffer, v);
}

void __glx_TexCoord1fv(const  GLfloat* v)
{
	int n_v = 1;
	int _cnt;
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 50, _size, 0);
	for(_cnt=0;_cnt<n_v;_cnt++){
		__GLX_PUT_float(buffer, v[_cnt]);
	}
}

void __glx_TexCoord1i( GLint v)
{
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 51, _size, 0);
	__GLX_PUT_int(buffer, v);
}

void __glx_TexCoord1iv(const  GLint* v)
{
	int n_v = 1;
	int _cnt;
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 51, _size, 0);
	for(_cnt=0;_cnt<n_v;_cnt++){
		__GLX_PUT_int(buffer, v[_cnt]);
	}
}

void __glx_TexCoord1s( GLshort v)
{
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 52, _size, 0);
	__GLX_PUT_short(buffer, v);
}

void __glx_TexCoord1sv(const  GLshort* v)
{
	int n_v = 1;
	int _cnt;
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 52, _size, 0);
	for(_cnt=0;_cnt<n_v;_cnt++){
		__GLX_PUT_short(buffer, v[_cnt]);
	}
}

void __glx_TexCoord2d( GLdouble s,  GLdouble t)
{
	int _size=20;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 53, _size, 0);
	__GLX_PUT_double(buffer, s);
	__GLX_PUT_double(buffer, t);
}

void __glx_TexCoord2dv(const  GLdouble* v)
{
	int n_v = 2;
	int _cnt;
	int _size=20;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 53, _size, 0);
	for(_cnt=0;_cnt<n_v;_cnt++){
		__GLX_PUT_double(buffer, v[_cnt]);
	}
}

void __glx_TexCoord2f( GLfloat s,  GLfloat t)
{
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 54, _size, 0);
	__GLX_PUT_float(buffer, s);
	__GLX_PUT_float(buffer, t);
}

void __glx_TexCoord2fv(const  GLfloat* v)
{
	int n_v = 2;
	int _cnt;
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 54, _size, 0);
	for(_cnt=0;_cnt<n_v;_cnt++){
		__GLX_PUT_float(buffer, v[_cnt]);
	}
}

void __glx_TexCoord2i( GLint s,  GLint t)
{
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 55, _size, 0);
	__GLX_PUT_int(buffer, s);
	__GLX_PUT_int(buffer, t);
}

void __glx_TexCoord2iv(const  GLint* v)
{
	int n_v = 2;
	int _cnt;
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 55, _size, 0);
	for(_cnt=0;_cnt<n_v;_cnt++){
		__GLX_PUT_int(buffer, v[_cnt]);
	}
}

void __glx_TexCoord2s( GLshort s,  GLshort t)
{
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 56, _size, 0);
	__GLX_PUT_short(buffer, s);
	__GLX_PUT_short(buffer, t);
}

void __glx_TexCoord2sv(const  GLshort* v)
{
	int n_v = 2;
	int _cnt;
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 56, _size, 0);
	for(_cnt=0;_cnt<n_v;_cnt++){
		__GLX_PUT_short(buffer, v[_cnt]);
	}
}

void __glx_TexCoord3d( GLdouble s,  GLdouble t,  GLdouble u)
{
	int _size=28;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 57, _size, 0);
	__GLX_PUT_double(buffer, s);
	__GLX_PUT_double(buffer, t);
	__GLX_PUT_double(buffer, u);
}

void __glx_TexCoord3dv(const  GLdouble* v)
{
	int n_v = 3;
	int _cnt;
	int _size=28;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 57, _size, 0);
	for(_cnt=0;_cnt<n_v;_cnt++){
		__GLX_PUT_double(buffer, v[_cnt]);
	}
}

void __glx_TexCoord3f( GLfloat s,  GLfloat t,  GLfloat u)
{
	int _size=16;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 58, _size, 0);
	__GLX_PUT_float(buffer, s);
	__GLX_PUT_float(buffer, t);
	__GLX_PUT_float(buffer, u);
}

void __glx_TexCoord3fv(const  GLfloat* v)
{
	int n_v = 3;
	int _cnt;
	int _size=16;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 58, _size, 0);
	for(_cnt=0;_cnt<n_v;_cnt++){
		__GLX_PUT_float(buffer, v[_cnt]);
	}
}

void __glx_TexCoord3i( GLint s,  GLint t,  GLint u)
{
	int _size=16;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 59, _size, 0);
	__GLX_PUT_int(buffer, s);
	__GLX_PUT_int(buffer, t);
	__GLX_PUT_int(buffer, u);
}

void __glx_TexCoord3iv(const  GLint* v)
{
	int n_v = 3;
	int _cnt;
	int _size=16;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 59, _size, 0);
	for(_cnt=0;_cnt<n_v;_cnt++){
		__GLX_PUT_int(buffer, v[_cnt]);
	}
}

void __glx_TexCoord3s( GLshort s,  GLshort t,  GLshort u)
{
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 60, _size, 0);
	__GLX_PUT_short(buffer, s);
	__GLX_PUT_short(buffer, t);
	__GLX_PUT_short(buffer, u);
}

void __glx_TexCoord3sv(const  GLshort* v)
{
	int n_v = 3;
	int _cnt;
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 60, _size, 0);
	for(_cnt=0;_cnt<n_v;_cnt++){
		__GLX_PUT_short(buffer, v[_cnt]);
	}
}

void __glx_TexCoord4d( GLdouble s,  GLdouble t,  GLdouble u,  GLdouble v)
{
	int _size=36;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 61, _size, 0);
	__GLX_PUT_double(buffer, s);
	__GLX_PUT_double(buffer, t);
	__GLX_PUT_double(buffer, u);
	__GLX_PUT_double(buffer, v);
}

void __glx_TexCoord4dv(const  GLdouble* v)
{
	int n_v = 4;
	int _cnt;
	int _size=36;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 61, _size, 0);
	for(_cnt=0;_cnt<n_v;_cnt++){
		__GLX_PUT_double(buffer, v[_cnt]);
	}
}

void __glx_TexCoord4f( GLfloat s,  GLfloat t,  GLfloat u,  GLfloat v)
{
	int _size=20;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 62, _size, 0);
	__GLX_PUT_float(buffer, s);
	__GLX_PUT_float(buffer, t);
	__GLX_PUT_float(buffer, u);
	__GLX_PUT_float(buffer, v);
}

void __glx_TexCoord4fv(const  GLfloat* v)
{
	int n_v = 4;
	int _cnt;
	int _size=20;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 62, _size, 0);
	for(_cnt=0;_cnt<n_v;_cnt++){
		__GLX_PUT_float(buffer, v[_cnt]);
	}
}

void __glx_TexCoord4i( GLint s,  GLint t,  GLint u,  GLint v)
{
	int _size=20;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 63, _size, 0);
	__GLX_PUT_int(buffer, s);
	__GLX_PUT_int(buffer, t);
	__GLX_PUT_int(buffer, u);
	__GLX_PUT_int(buffer, v);
}

void __glx_TexCoord4iv(const  GLint* v)
{
	int n_v = 4;
	int _cnt;
	int _size=20;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 63, _size, 0);
	for(_cnt=0;_cnt<n_v;_cnt++){
		__GLX_PUT_int(buffer, v[_cnt]);
	}
}

void __glx_TexCoord4s( GLshort s,  GLshort t,  GLshort u,  GLshort v)
{
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 64, _size, 0);
	__GLX_PUT_short(buffer, s);
	__GLX_PUT_short(buffer, t);
	__GLX_PUT_short(buffer, u);
	__GLX_PUT_short(buffer, v);
}

void __glx_TexCoord4sv(const  GLshort* v)
{
	int n_v = 4;
	int _cnt;
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 64, _size, 0);
	for(_cnt=0;_cnt<n_v;_cnt++){
		__GLX_PUT_short(buffer, v[_cnt]);
	}
}

void __glx_TexEnvf( GLenum target,  GLenum pname,  GLfloat param)
{
	int _size=16;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 111, _size, 0);
	__GLX_PUT_enum(buffer, target);
	__GLX_PUT_enum(buffer, pname);
	__GLX_PUT_float(buffer, param);
}

void __glx_TexEnvfv( GLenum target,  GLenum pname, const  GLfloat* params)
{
	int n_params = GLX_texenv_size(pname);
	int _cnt;
	int _size=12+(4*GLX_texenv_size(pname));
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 112, _size, 0);
	__GLX_PUT_enum(buffer, target);
	__GLX_PUT_enum(buffer, pname);
	for(_cnt=0;_cnt<n_params;_cnt++){
		__GLX_PUT_float(buffer, params[_cnt]);
	}
}

void __glx_TexEnvi( GLenum target,  GLenum pname,  GLint param)
{
	int _size=16;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 113, _size, 0);
	__GLX_PUT_enum(buffer, target);
	__GLX_PUT_enum(buffer, pname);
	__GLX_PUT_int(buffer, param);
}

void __glx_TexEnviv( GLenum target,  GLenum pname, const  GLint* params)
{
	int n_params = GLX_texenv_size(pname);
	int _cnt;
	int _size=12+(4*GLX_texenv_size(pname));
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 114, _size, 0);
	__GLX_PUT_enum(buffer, target);
	__GLX_PUT_enum(buffer, pname);
	for(_cnt=0;_cnt<n_params;_cnt++){
		__GLX_PUT_int(buffer, params[_cnt]);
	}
}

void __glx_TexGend( GLenum coord,  GLenum pname,  GLdouble param)
{
	int _size=20;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 115, _size, 0);
	__GLX_PUT_enum(buffer, coord);
	__GLX_PUT_enum(buffer, pname);
	__GLX_PUT_double(buffer, param);
}

void __glx_TexGendv( GLenum coord,  GLenum pname, const  GLdouble* params)
{
	int n_params = GLX_texgen_size(pname);
	int _cnt;
	int _size=12+(8*GLX_texgen_size(pname));
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 116, _size, 0);
	__GLX_PUT_enum(buffer, coord);
	__GLX_PUT_enum(buffer, pname);
	for(_cnt=0;_cnt<n_params;_cnt++){
		__GLX_PUT_double(buffer, params[_cnt]);
	}
}

void __glx_TexGenf( GLenum coord,  GLenum pname,  GLfloat param)
{
	int _size=16;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 117, _size, 0);
	__GLX_PUT_enum(buffer, coord);
	__GLX_PUT_enum(buffer, pname);
	__GLX_PUT_float(buffer, param);
}

void __glx_TexGenfv( GLenum coord,  GLenum pname, const  GLfloat* params)
{
	int n_params = GLX_texgen_size(pname);
	int _cnt;
	int _size=12+(4*GLX_texgen_size(pname));
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 118, _size, 0);
	__GLX_PUT_enum(buffer, coord);
	__GLX_PUT_enum(buffer, pname);
	for(_cnt=0;_cnt<n_params;_cnt++){
		__GLX_PUT_float(buffer, params[_cnt]);
	}
}

void __glx_TexGeni( GLenum coord,  GLenum pname,  GLint param)
{
	int _size=16;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 119, _size, 0);
	__GLX_PUT_enum(buffer, coord);
	__GLX_PUT_enum(buffer, pname);
	__GLX_PUT_int(buffer, param);
}

void __glx_TexGeniv( GLenum coord,  GLenum pname, const  GLint* params)
{
	int n_params = GLX_texgen_size(pname);
	int _cnt;
	int _size=12+(4*GLX_texgen_size(pname));
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 120, _size, 0);
	__GLX_PUT_enum(buffer, coord);
	__GLX_PUT_enum(buffer, pname);
	for(_cnt=0;_cnt<n_params;_cnt++){
		__GLX_PUT_int(buffer, params[_cnt]);
	}
}

void __glx_TexParameterf( GLenum target,  GLenum pname,  GLfloat param)
{
	int _size=16;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 105, _size, 0);
	__GLX_PUT_enum(buffer, target);
	__GLX_PUT_enum(buffer, pname);
	__GLX_PUT_float(buffer, param);
}

void __glx_TexParameterfv( GLenum target,  GLenum pname, const  GLfloat* params)
{
	int n_params = GLX_texparameter_size(pname);
	int _cnt;
	int _size=12+(4*GLX_texparameter_size(pname));
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 106, _size, 0);
	__GLX_PUT_enum(buffer, target);
	__GLX_PUT_enum(buffer, pname);
	for(_cnt=0;_cnt<n_params;_cnt++){
		__GLX_PUT_float(buffer, params[_cnt]);
	}
}

void __glx_TexParameteri( GLenum target,  GLenum pname,  GLint param)
{
	int _size=16;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 107, _size, 0);
	__GLX_PUT_enum(buffer, target);
	__GLX_PUT_enum(buffer, pname);
	__GLX_PUT_int(buffer, param);
}

void __glx_TexParameteriv( GLenum target,  GLenum pname, const  GLint* params)
{
	int n_params = GLX_texparameter_size(pname);
	int _cnt;
	int _size=12+(4*GLX_texparameter_size(pname));
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 108, _size, 0);
	__GLX_PUT_enum(buffer, target);
	__GLX_PUT_enum(buffer, pname);
	for(_cnt=0;_cnt<n_params;_cnt++){
		__GLX_PUT_int(buffer, params[_cnt]);
	}
}

void __glx_Translated( GLdouble x,  GLdouble y,  GLdouble z)
{
	int _size=28;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 189, _size, 0);
	__GLX_PUT_double(buffer, x);
	__GLX_PUT_double(buffer, y);
	__GLX_PUT_double(buffer, z);
}

void __glx_Translatef( GLfloat x,  GLfloat y,  GLfloat z)
{
	int _size=16;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 190, _size, 0);
	__GLX_PUT_float(buffer, x);
	__GLX_PUT_float(buffer, y);
	__GLX_PUT_float(buffer, z);
}

void __glx_Vertex2d( GLdouble x,  GLdouble y)
{
	int _size=20;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 65, _size, 0);
	__GLX_PUT_double(buffer, x);
	__GLX_PUT_double(buffer, y);
}

void __glx_Vertex2dv(const  GLdouble* v)
{
	int n_v = 2;
	int _cnt;
	int _size=20;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 65, _size, 0);
	for(_cnt=0;_cnt<n_v;_cnt++){
		__GLX_PUT_double(buffer, v[_cnt]);
	}
}

void __glx_Vertex2f( GLfloat x,  GLfloat y)
{
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 66, _size, 0);
	__GLX_PUT_float(buffer, x);
	__GLX_PUT_float(buffer, y);
}

void __glx_Vertex2fv(const  GLfloat* v)
{
	int n_v = 2;
	int _cnt;
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 66, _size, 0);
	for(_cnt=0;_cnt<n_v;_cnt++){
		__GLX_PUT_float(buffer, v[_cnt]);
	}
}

void __glx_Vertex2i( GLint x,  GLint y)
{
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 67, _size, 0);
	__GLX_PUT_int(buffer, x);
	__GLX_PUT_int(buffer, y);
}

void __glx_Vertex2iv(const  GLint* v)
{
	int n_v = 2;
	int _cnt;
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 67, _size, 0);
	for(_cnt=0;_cnt<n_v;_cnt++){
		__GLX_PUT_int(buffer, v[_cnt]);
	}
}

void __glx_Vertex2s( GLshort x,  GLshort y)
{
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 68, _size, 0);
	__GLX_PUT_short(buffer, x);
	__GLX_PUT_short(buffer, y);
}

void __glx_Vertex2sv(const  GLshort* v)
{
	int n_v = 2;
	int _cnt;
	int _size=8;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 68, _size, 0);
	for(_cnt=0;_cnt<n_v;_cnt++){
		__GLX_PUT_short(buffer, v[_cnt]);
	}
}

void __glx_Vertex3d( GLdouble x,  GLdouble y,  GLdouble z)
{
	int _size=28;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 69, _size, 0);
	__GLX_PUT_double(buffer, x);
	__GLX_PUT_double(buffer, y);
	__GLX_PUT_double(buffer, z);
}

void __glx_Vertex3dv(const  GLdouble* v)
{
	int n_v = 3;
	int _cnt;
	int _size=28;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 69, _size, 0);
	for(_cnt=0;_cnt<n_v;_cnt++){
		__GLX_PUT_double(buffer, v[_cnt]);
	}
}

void __glx_Vertex3f( GLfloat x,  GLfloat y,  GLfloat z)
{
	int _size=16;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 70, _size, 0);
	__GLX_PUT_float(buffer, x);
	__GLX_PUT_float(buffer, y);
	__GLX_PUT_float(buffer, z);
}

void __glx_Vertex3fv(const  GLfloat* v)
{
	int n_v = 3;
	int _cnt;
	int _size=16;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 70, _size, 0);
	for(_cnt=0;_cnt<n_v;_cnt++){
		__GLX_PUT_float(buffer, v[_cnt]);
	}
}

void __glx_Vertex3i( GLint x,  GLint y,  GLint z)
{
	int _size=16;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 71, _size, 0);
	__GLX_PUT_int(buffer, x);
	__GLX_PUT_int(buffer, y);
	__GLX_PUT_int(buffer, z);
}

void __glx_Vertex3iv(const  GLint* v)
{
	int n_v = 3;
	int _cnt;
	int _size=16;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 71, _size, 0);
	for(_cnt=0;_cnt<n_v;_cnt++){
		__GLX_PUT_int(buffer, v[_cnt]);
	}
}

void __glx_Vertex3s( GLshort x,  GLshort y,  GLshort z)
{
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 72, _size, 0);
	__GLX_PUT_short(buffer, x);
	__GLX_PUT_short(buffer, y);
	__GLX_PUT_short(buffer, z);
}

void __glx_Vertex3sv(const  GLshort* v)
{
	int n_v = 3;
	int _cnt;
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 72, _size, 0);
	for(_cnt=0;_cnt<n_v;_cnt++){
		__GLX_PUT_short(buffer, v[_cnt]);
	}
}

void __glx_Vertex4d( GLdouble x,  GLdouble y,  GLdouble z,  GLdouble w)
{
	int _size=36;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 73, _size, 0);
	__GLX_PUT_double(buffer, x);
	__GLX_PUT_double(buffer, y);
	__GLX_PUT_double(buffer, z);
	__GLX_PUT_double(buffer, w);
}

void __glx_Vertex4dv(const  GLdouble* v)
{
	int n_v = 4;
	int _cnt;
	int _size=36;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 73, _size, 0);
	for(_cnt=0;_cnt<n_v;_cnt++){
		__GLX_PUT_double(buffer, v[_cnt]);
	}
}

void __glx_Vertex4f( GLfloat x,  GLfloat y,  GLfloat z,  GLfloat w)
{
	int _size=20;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 74, _size, 0);
	__GLX_PUT_float(buffer, x);
	__GLX_PUT_float(buffer, y);
	__GLX_PUT_float(buffer, z);
	__GLX_PUT_float(buffer, w);
}

void __glx_Vertex4fv(const  GLfloat* v)
{
	int n_v = 4;
	int _cnt;
	int _size=20;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 74, _size, 0);
	for(_cnt=0;_cnt<n_v;_cnt++){
		__GLX_PUT_float(buffer, v[_cnt]);
	}
}

void __glx_Vertex4i( GLint x,  GLint y,  GLint z,  GLint w)
{
	int _size=20;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 75, _size, 0);
	__GLX_PUT_int(buffer, x);
	__GLX_PUT_int(buffer, y);
	__GLX_PUT_int(buffer, z);
	__GLX_PUT_int(buffer, w);
}

void __glx_Vertex4iv(const  GLint* v)
{
	int n_v = 4;
	int _cnt;
	int _size=20;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 75, _size, 0);
	for(_cnt=0;_cnt<n_v;_cnt++){
		__GLX_PUT_int(buffer, v[_cnt]);
	}
}

void __glx_Vertex4s( GLshort x,  GLshort y,  GLshort z,  GLshort w)
{
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 76, _size, 0);
	__GLX_PUT_short(buffer, x);
	__GLX_PUT_short(buffer, y);
	__GLX_PUT_short(buffer, z);
	__GLX_PUT_short(buffer, w);
}

void __glx_Vertex4sv(const  GLshort* v)
{
	int n_v = 4;
	int _cnt;
	int _size=12;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 76, _size, 0);
	for(_cnt=0;_cnt<n_v;_cnt++){
		__GLX_PUT_short(buffer, v[_cnt]);
	}
}

void __glx_Viewport( GLint x,  GLint y,  GLint width,  GLint height)
{
	int _size=20;
	char* buffer=NULL;
	__GLX_GET_RENDER_BUFFER(buffer, 191, _size, 0);
	__GLX_PUT_int(buffer, x);
	__GLX_PUT_int(buffer, y);
	__GLX_PUT_int(buffer, width);
	__GLX_PUT_int(buffer, height);
}

