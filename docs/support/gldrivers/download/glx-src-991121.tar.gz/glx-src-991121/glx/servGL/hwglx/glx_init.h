
/*
 * GLX Server Extension
 * Copyright (C) 1999 Terence Ripperda (ripperda@sgi.com)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * STEVEN PARKER, TERENCE RIPPERDA, OR ANY OTHER CONTRIBUTORS BE LIABLE FOR
 * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE
 * OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */


#define SOFTWARE_MODE       0

#define MGA_G200            1
#define MGA_G400            2

#define NV_RIVA128          3
#define NV_RIVATNT          4
#define NV_RIVATNT2         5

#define ATI_RAGEPRO         6


extern unsigned int glx_chipset;


GLboolean (*hwInitVisuals)(VisualPtr *, DepthPtr *, int *, int *, int *, VisualID *, unsigned long, int);

#if BUILD_UNIFIED
GLboolean mgaInitGLX(void);
GLboolean nvInitGLX(void);
GLboolean nvInitVisuals(VisualPtr *, DepthPtr *, int *, int *, int *, VisualID *, unsigned long, int);
#endif
