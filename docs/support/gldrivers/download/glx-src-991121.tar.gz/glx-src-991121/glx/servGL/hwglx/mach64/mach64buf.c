/* $Id: mach64buf.c,v 1.1 1999/10/28 03:43:46 gareth Exp $ */

/*
 * GLX Hardware Device Driver for ATI Rage Pro
 * Copyright (C) 1999 Gareth Hughes
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * WITTAWAT YAMWONG, OR ANY OTHER CONTRIBUTORS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE
 * OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * Based on MGA driver: mgabuf.c 1.4
 *
 *    Gareth Hughes <garethh@bell-labs.com>
 */

#include <stdlib.h>

#include "vga.h"

#include "mach64lib.h"


#define BASEADDR		((unsigned char *) mach64LinearBase)

static int mach64InitBuffer( mach64BufferPtr buf, int Attrib, int Size,
			     int Width, int Height, int Pitch )
{
    int		ofs;
    int		Format, Type;
    int		PitchAlign, OrgAlign;
#if 0 /* FIXME: GH */
    mach64UI32	maccess;
#endif

    buf->magic = mach64BufferMagic;
    buf->Attrib = Attrib;
    buf->refcount = 0;
    Type = Attrib & MACH64_TYPE_MASK;
    Format = Attrib & MACH64_PF_MASK;
    buf->UseCardMemory = 1;

    switch ( Type )
    {
    case MACH64_COLORBUFFER:
	/*
	 * input:
	 * Attrib,Width,Height
	 * if Pitch == 0, Pitch will be calcualted from Width
	 */
	buf->Drawable = 1;
	buf->Setup[0] = MACH64_SETUP_0;
	buf->Setup[5] = MACH64_SETUP_5;

	switch ( Format )
	{
	case MACH64_PF_INDEX:
	    buf->BytesPerPixel = 1;
#if 0 /* FIXME: GH */
	    maccess = MA_pwidth_8;
#endif
	    break;
	case MACH64_PF_565:
	    buf->BytesPerPixel = 2;
#if 0 /* FIXME: GH */
	    maccess = MA_pwidth_16;
#endif
	    break;
	case MACH64_PF_555:
	    buf->BytesPerPixel = 2;
#if 0 /* FIXME: GH */
	    maccess = MA_pwidth_16 | MA_dit555_enable;
#endif
	    break;
	case MACH64_PF_888:
	    buf->BytesPerPixel = 3;
#if 0 /* FIXME: GH */
	    maccess = MA_pwidth_24;
#endif
	    break;
	case MACH64_PF_8888:
	    buf->BytesPerPixel = 4;
#if 0 /* FIXME: GH */
	    maccess = MA_pwidth_32;
#endif
	    break;
	default:
	    return -1;
	}

	OrgAlign = 6;
	PitchAlign = (1 << OrgAlign);

	Pitch = (Width+PitchAlign-1 ) & ~(PitchAlign - 1);
	buf->Pitch = Pitch;
	buf->Size = Pitch*buf->BytesPerPixel*Height;
	if ((buf->MemBlock = mmAllocMem( cardHeap, buf->Size, OrgAlign, 0 )) == 0)
	    return -1;
	ofs = buf->MemBlock->ofs;

#if 0 /* FIXME: GH */
	buf->Setup[MACH64_SETUP_PITCH] = Pitch & ~P_iy_MASK;
#endif
	buf->Setup[MACH64_SETUP_DSTORG] = ofs;
#if 0 /* FIXME: GH */
	buf->Setup[MACH64_SETUP_MACCESS] = maccess;
	buf->Setup[MACH64_SETUP_CXBNDRY] = (Width-1) << CXB_cxright_SHIFT;
#endif
	buf->Setup[MACH64_SETUP_YTOP] = 0;
	buf->Setup[MACH64_SETUP_YBOT] = (Height-1)*Pitch;
	buf->Setup[MACH64_SETUP_PLNWT] = ~0;
	buf->Setup[MACH64_SETUP_ZORG] = 0;
	buf->SetupSize = MACH64_SETUP_SIZE;

	buf->Width = Width;
	buf->Height = Height;
	buf->BufAddr = &BASEADDR[ofs];
	break;

    case MACH64_ZBUFFER16:
    case MACH64_ZBUFFER32:
	/*
	 * input:
	 * Attrib,Pitch,Height,DGAFrameBuffer
	 */
	buf->SetupSize = 0;
	if (Type == MACH64_ZBUFFER32)
	    buf->BytesPerPixel = 4;
	else
	    buf->BytesPerPixel = 2;
	buf->Size = Pitch * Height * buf->BytesPerPixel;
	/* try to allocate it in the second 4mb bank if possible */
	if ( (buf->MemBlock = mmAllocMem( cardHeap, buf->Size,9, 0x400000 ) ) == 0) {
	    /* oh well, try for anywhere */
	    if ((buf->MemBlock = mmAllocMem( cardHeap, buf->Size, 9, 0 )) == 0)
		return -1;
	}
	ofs = buf->MemBlock->ofs;
	buf->Setup[MACH64_SETUP_DSTORG] = buf->Setup[MACH64_SETUP_ZORG] = ofs;
	buf->BufAddr = &BASEADDR[ofs];
	buf->Height = Height;
	buf->Pitch = Pitch;
	break;

    case MACH64_MISCBUFFER:
	/*
	 * Input: Attrib, Size,
	 */
	buf->SetupSize = 0;
	buf->Size = Size;
	if ((Width & 7) != 0)
	    return -1;
	if ((buf->MemBlock = mmAllocMem( cardHeap, Size, 8, 0 )) == 0)
	    return -1;
	ofs = buf->MemBlock->ofs;
	buf->Setup[MACH64_SETUP_DSTORG] = ofs;
	buf->BufAddr = &BASEADDR[ofs];
	break;

    default:
	return -1;
    }
    return 0;
}

mach64BufferPtr mach64CreateBuffer( int Attrib, int Size, int Width,
				    int Height, int Pitch )
{
    mach64BufferPtr	buf;

    buf = (mach64BufferPtr)calloc(1,sizeof(mach64Buffer));
    if (!buf)
	return NULL;
    if (mach64InitBuffer(buf,Attrib,Size,Width,Height,Pitch) == -1) {
	free(buf);
	return NULL;
    }
    buf->next = mach64glx.bufferList;
    mach64glx.bufferList = buf;
    return buf;
}

mach64BufferPtr mach64CreatePrimaryBuffer( int Attrib, int Width, int Height,
					   int Pitch )
{
    mach64BufferPtr buf;

    Attrib = (Attrib & ~MACH64_TYPE_MASK) | MACH64_COLORBUFFER;
    buf = mach64CreateBuffer(Attrib,0,Width,Height,Pitch);
    if (!buf)
	return NULL;
    mmMarkReserved(buf->MemBlock);

    return buf;
}

static void FreeBuffer( mach64BufferPtr buf )
{
    mach64BufferPtr p,priv;

    p = mach64glx.bufferList;
    priv = 0;
    while (p && p != buf) {
	priv = p;
	p = p->next;
    }
    if (p){
	if (priv){
	    priv->next = buf->next;
	}else{
	    mach64glx.bufferList = buf->next;
	}
    }
    if (mmFreeMem(buf->MemBlock) == -1) {
	mach64Error("Could not free buffer %08x\n",buf->MemBlock->ofs);
	mmDumpMemInfo( cardHeap );
    }
    buf->magic = 0;
    if(buf->CachedContent){
	free(buf->CachedContent);
    }
    free(buf);
}

int mach64DestroyBuffer( mach64BufferPtr buf )
{
    mach64BufferPtr	p;

    if (!buf)
	return 0;
    if (buf->magic != mach64BufferMagic)
	return -1;
    if (--(buf->refcount) > 0)
	return 0;

    switch (buf->Attrib & MACH64_TYPE_MASK) {
    case MACH64_ZBUFFER16:
    case MACH64_ZBUFFER32:
	p = mach64glx.bufferList;
	while (p) {
	    if (p->HasZORG && p->ZBuffer == buf) {
		p->HasZORG = 0;
		p->ZBuffer = 0;
		p->SetupSize = MACH64_SETUP_SIZE;
	    }
	    p = p->next;
	}
	break;

    default:
	mach64DetachZBuffer(buf);
    }
    FreeBuffer(buf);
    return 0;
}

mach64BufferPtr mach64AttachZBuffer( mach64BufferPtr parent,
				     mach64BufferPtr zb, int Type )
{
    if (!parent || !parent->Drawable)
	return NULL;
    if (zb && (parent->Height != zb->Height || parent->Pitch != zb->Pitch))
	return NULL;
    mach64DetachZBuffer(parent);
    if (!zb)
	if ((zb = mach64CreateBuffer(Type,0,0,parent->Height,parent->Pitch)) == NULL)
	    return NULL;
#if 0 /* FIXME: GH */
    if (zb->Attrib == MACH64_ZBUFFER16)
	MACH64_SET_FIELD(parent->Setup[MACH64_SETUP_MACCESS],MA_zwidth_MASK,MA_zwidth_16);
    else if (zb->Attrib == MACH64_ZBUFFER32)
	MACH64_SET_FIELD(parent->Setup[MACH64_SETUP_MACCESS],MA_zwidth_MASK,MA_zwidth_32);
    else
	return NULL;
#endif
    parent->HasZORG = 1;
    parent->Setup[MACH64_SETUP_ZORG] = zb->Setup[MACH64_SETUP_ZORG];
    parent->SetupSize = MACH64_SETUP_SIZE;
    parent->ZBuffer = zb;
    zb->refcount++;
    return zb;
}

void mach64DetachZBuffer( mach64BufferPtr parent )
{
    mach64BufferPtr	zb;

    if (!VALID_MACH64_BUFFER(parent) || !parent->HasZORG)
	return;
    zb = parent->ZBuffer;
    parent->HasZORG = 0;
    parent->SetupSize = MACH64_SETUP_SIZE;

    if (VALID_MACH64_BUFFER(zb) && --(zb->refcount) <= 0) {
	FreeBuffer(zb);
    }
    parent->ZBuffer = NULL;
}

int mach64IsValidBuffer( mach64BufferPtr buf )
{
    mach64BufferPtr	p;

    if (!VALID_MACH64_BUFFER(buf))
	return 1;
    p = mach64glx.bufferList;
    while (p && p != buf)
	p = p->next;
    if (p != buf)
	return 2;
    if (buf->SetupSize > 0 ||
	((buf->Attrib & MACH64_TYPE_MASK) == MACH64_COLORBUFFER)) {
	if (buf->Setup[0] != MACH64_SETUP_0 ||
	    buf->Setup[5] != MACH64_SETUP_5 ||
	    buf->SetupSize > (sizeof(buf->Setup)/sizeof(mach64UI32))) {
	    return 3;
	}
    }
    return 0;
}


/*
 * Local Variables:
 * mode: c
 * c-basic-offset: 4
 * End:
 */
