/* $Id: mach64buf.h,v 1.1 1999/10/28 03:43:46 gareth Exp $ */

/*
 * GLX Hardware Device Driver for ATI Rage Pro
 * Copyright (C) 1999 Gareth Hughes
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * WITTAWAT YAMWONG, OR ANY OTHER CONTRIBUTORS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE
 * OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * Based on MGA driver: mgabuf.h 1.3
 *
 *    Gareth Hughes <garethh@bell-labs.com>
 */

#ifndef __MACH64_BUF_H__
#define __MACH64_BUF_H__

#include "mach64common.h"
#include "mm.h"

#define mach64BufferMagic		0x65e813a1
#define VALID_MACH64_BUFFER( b )	( (b) && ( (b)->magic == mach64BufferMagic ) )

/* mach64_buffer_t.Attrib */
#define MACH64_TYPE_MASK	0xf
#define MACH64_COLORBUFFER	1
#define MACH64_ZBUFFER16	2
#define MACH64_MISCBUFFER	3
#define MACH64_ZBUFFER32	4
#define MACH64_TEXBUFFER	5
/* if type == MACH64_COLORBUFFER */
#define MACH64_PF_MASK		0xf0
#define MACH64_PF_INDEX		0
#define MACH64_PF_565		(1 << 4)
#define MACH64_PF_555		(9 << 4)
#define MACH64_PF_888		(3 << 4)
#define MACH64_PF_8888		(10 << 4)
#define MACH64_PF_HASALPHA	(8 << 4)
/* if type == MACH64_TEXBUFFER */
#define MACH64_TW4		(0 << 4)
#define MACH64_TW8		(1 << 4)
#define MACH64_TW15		(2 << 4)
#define MACH64_TW16		(3 << 4)
#define MACH64_TW12		(4 << 4)
#define MACH64_TW32		(6 << 4)
#define MACH64_TW422		(10 << 4)

#define MACH64_TEXCACHE		(1 << 8)

/* mach64_buffer_t.Setup */
#define MACH64_SETUP_0		0x27262023
#define MACH64_SETUP_PITCH	1
#define MACH64_SETUP_CXBNDRY	2
#define MACH64_SETUP_YTOP	3
#define MACH64_SETUP_YBOT	4
#define MACH64_SETUP_5		0x030701ae
#define MACH64_SETUP_DSTORG	6
#define MACH64_SETUP_MACCESS	7
#define MACH64_SETUP_PLNWT	8
#define MACH64_SETUP_ZORG	9
#define MACH64_SETUP_SIZE	10

/* Some phony ones for the reg_dirty bitfield:
 */
#define MACH64_SETUP_DWGCTL	11
#define MACH64_SETUP_ALPHACTRL	12


struct mach64_buffer_t
{
    mach64UI32	magic;
    struct mach64_buffer_t *next;
    int		refcount;

    int		Attrib;

    int		Drawable:1;
    int		HasZORG:1;
    int		Viewable:1;
    int		UseCardMemory:1; /* If this frame buffer resides in card memory? */

    mach64UI32	Setup[MACH64_SETUP_SIZE];
    int		SetupSize;

    void	*BufAddr;	/* pointer to buffer in users space */
    void	*CachedContent;	/* If this isn't NULL it points to a
				   copy of the buffer in primary memory */
    PMemBlock	MemBlock;
    int		Width, Height;	/* in pixels */
    int		Pitch;		/* in pixels */
    int		BytesPerPixel;
    int		Size;
    struct mach64_buffer_t *ZBuffer;
};
typedef struct mach64_buffer_t mach64Buffer;
typedef struct mach64_buffer_t *mach64BufferPtr;


mach64BufferPtr mach64CreateBuffer( int Attrib, int Size, int Width,
				    int Height, int Pitch );
mach64BufferPtr mach64CreatePrimaryBuffer( int Attrib, int Width, int Height,
					   int Pitch );
int mach64DestroyBuffer( mach64BufferPtr buf );
mach64BufferPtr mach64AttachZBuffer( mach64BufferPtr parent,
				     mach64BufferPtr zb, int Type );
void mach64DetachZBuffer( mach64BufferPtr parent );

/* return 0 if valid */
int mach64IsValidBuffer( mach64BufferPtr buf );

#endif


/*
 * Local Variables:
 * mode: c
 * c-basic-offset: 4
 * End:
 */
