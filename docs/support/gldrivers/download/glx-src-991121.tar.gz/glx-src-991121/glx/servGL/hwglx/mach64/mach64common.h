/* $Id: mach64common.h,v 1.1 1999/10/28 03:43:47 gareth Exp $ */

/*
 * GLX Hardware Device Driver for ATI Rage Pro
 * Copyright (C) 1999 Gareth Hughes
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * WITTAWAT YAMWONG, OR ANY OTHER CONTRIBUTORS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE
 * OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * Based on MGA driver: mgacommon.h 1.2
 *
 *    Gareth Hughes <garethh@bell-labs.com>
 */

#ifndef __MACH64_COMMON_H__
#define __MACH64_COMMON_H__

#define MACH64_MAXFIFO		64

typedef unsigned int mach64UI32;
typedef unsigned short mach64UI16;
typedef unsigned char mach64UI8;
typedef int mach64I32;
typedef short mach64I16;
typedef char mach64I8;

typedef mach64UI8 mach64Color[4];


struct mach64_context_t;
typedef struct mach64_context_t mach64Context;
typedef struct mach64_context_t *mach64ContextPtr;

#if 0 /* FIXME: GH */
extern int		mach64ydstorg;
extern unsigned char	*mach64MMIOBase;
#endif
extern int		mach64BitsPerPixel;

#endif
