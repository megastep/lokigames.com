/* $Id: mach64context.c,v 1.1 1999/10/28 03:43:47 gareth Exp $ */

/*
 * GLX Hardware Device Driver for ATI Rage Pro
 * Copyright (C) 1999 Gareth Hughes
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * WITTAWAT YAMWONG, OR ANY OTHER CONTRIBUTORS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE
 * OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * Based on MGA driver: mgacontext.c 1.9
 *
 *    Gareth Hughes <garethh@bell-labs.com>
 */

#include "xsmesaP.h"
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <GL/gl.h>

#include "mach64context.h"
#include "mach64lib.h"
#include "rage_mac.h"
#include "mach64log.h"
#include "mach64dd.h"
#if 0 /* FIXME: GH */
#include "mach64pipeline.h"
#include "mach64render.h"
#include "mach64tris.h"
#endif


mach64ContextPtr mach64CreateContext( GLcontext *ctx )
{
    mach64ContextPtr	c;

    c = (mach64ContextPtr) calloc( 1, sizeof(mach64Context) );
    if ( !c ) {
	return NULL;
    }

    c->magic = mach64ContextMagic;
    c->gl_ctx = ctx;
#if 0 /* FIXME: GH */
    c->regDWGCTL = ( DC_clipdis_disable | (0xC << DC_bop_SHIFT) |
		     DC_shftzero_enable | DC_zmode_nozcmp |
		     DC_atype_zi );

    c->regALPHACTRL = AC_src_one | AC_dst_zero | AC_amode_FCOL |
	AC_astipple_disable | AC_aten_disable | AC_atmode_noacmp |
	AC_alphasel_fromtex;
#endif

    c->renderindex = -1;		/* impossible value */
    c->new_state = ~0;
    c->reg_dirty = ~0;

    c->TextureMode = ctx->Texture.Unit[0].EnvMode;

    /* XXX Fix me: callback not registered when main VB is created.
     */
    if ( ctx->VB ) {
#if 0 /* FIXME: GH */
	mach64DDRegisterVB( ctx->VB );
#endif
    } else {
	fprintf(stderr, "**** Didn't create vb driver data\n");
    }

    if ( ctx->NrPipelineStages ) {
#if 0 /* FIXME: GH */
	ctx->NrPipelineStages =
	    mach64DDRegisterPipelineStages( ctx->PipelineStage,
					    ctx->PipelineStage,
					    ctx->NrPipelineStages );
#endif
    }

    if ( !getenv("MGA_NO_FAST_PATH") )
    {
#if 0 /* FIXME: GH */
	ctx->Driver.BuildPrecalcPipeline = mach64DDBuildPrecalcPipeline;

	/* This isn't quite finished.  It's also not very fast yet.
	 */
	if ( getenv("MGA_FAST_IMMEDIATE") ) {
	    ctx->Driver.BuildEltPipeline = mach64DDBuildImmediatePipeline;
	}
#endif
    } else {
  	mach64Msg( 1, "enabling MGA_NO_FAST_PATH" );
    }

#if 0 /* FIXME: GH */
    mach64DDRenderInit();
    mach64DDTrifuncInit();
    mach64DDFastPathInit();
    mach64DDSetupInit();
    mach64DDExtensionsInit( ctx );

    mach64InitFogAttrib( &c->Fog );
#endif
    mach64Msg( 2, "mach64CreateContext(): successful.\n" );
    return c;
}

int mach64DestroyContext( mach64ContextPtr ctx )
{
    if ( !ctx ) {
	return 0;
    }
    if ( ctx->magic != mach64ContextMagic ) {
	return -1;
    }
    if ( --(ctx->refcount) > 0 ) {
	return 0;
    }

#if 0 /* FIXME: GH */
    mach64DestroyContextTextures( ctx );
#endif

    if ( ctx == mach64Ctx ) {
    	mach64Ctx = NULL;
    }
    ctx->magic = 0;
    free( ctx );
    mach64Msg( 2, "mach64DestroyContext(): successfully destroyed.\n" );
    return 0;
}


/*
 * Local Variables:
 * mode: c
 * c-basic-offset: 4
 * End:
 */
