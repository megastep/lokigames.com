/* $Id: mach64context.h,v 1.1 1999/10/28 03:43:47 gareth Exp $ */

/*
 * GLX Hardware Device Driver for ATI Rage Pro
 * Copyright (C) 1999 Gareth Hughes
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * WITTAWAT YAMWONG, OR ANY OTHER CONTRIBUTORS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE
 * OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * Based on MGA driver: mgacontext.h 1.9
 *
 *    Gareth Hughes <garethh@bell-labs.com>
 */

#ifndef __MGA_CONTEXT_H__
#define __MGA_CONTEXT_H__


#include "mesaglx/types.h"

#include "mach64common.h"
#include "mach64buf.h"
#if 0 /* FIXME: GH */
#include "mach64tex.h"
#include "mach64fog.h"
#include "mach64vb.h"
#endif

#define mach64ContextMagic		0x47323030
#define VALID_MACH64_CONTEXT( ctx )	( (ctx) && ( (ctx)->magic == mach64ContextMagic ) )

/* for SoftwareFallback */
#define FALLBACK_ALPHATEST	1
#define FALLBACK_BLENDING	2
#define FALLBACK_TEXTURE	4



/* For mach64Ctx->new_state.
 */
#define MACH64_NEW_DEPTH	0x1
#define MACH64_NEW_ALPHA	0x2
#define MACH64_NEW_FOG		0x4
#define MACH64_NEW_CLIP		0x8
#define MACH64_NEW_MASK		0x10
#define MACH64_NEW_TEXTURE	0x20
#define MACH64_NEW_CULL		0x40
#define MACH64_NEW_CONTEXT	0x100


typedef void (*mach64_interp_func)( GLfloat t,
				    GLfloat *result,
				    const GLfloat *in,
				    const GLfloat *out );


struct mach64_context_t
{
    mach64UI32		magic;
    int			refcount;

    mach64BufferPtr	DB;
    GLcontext		*gl_ctx;

    mach64UI32		regDWGCTL;
    mach64UI32		regALPHACTRL;
    mach64UI32		regSTENCIL;
    mach64UI32		regSTENCILCTL;

    int			TextureMode;
#if 0 /* FIXME: GH */
    struct mach64_fog_attrib Fog;
#endif

    /* shared texture palette */
    mach64UI16		GlobalPalette[256];

    int			SoftwareFallback;  /* or'ed values of FALLBACK_* */

    /* Support for CVA and the fast paths */
    unsigned int	setupdone;
    unsigned int	setupindex;
    unsigned int	renderindex;
    unsigned int	using_fast_path;
    unsigned int	using_immediate_fast_path;
    mach64_interp_func	interp;

    /* Shortcircuit some state changes */
    points_func		PointsFunc;
    line_func		LineFunc;
    triangle_func	TriangleFunc;
    quad_func		QuadFunc;

    /* Manage our own state */
    GLuint		new_state;
    GLuint		reg_dirty;

    GLfloat		map[16];
};

mach64ContextPtr mach64CreateContext( GLcontext *ctx ); /* Do I need visual info? */
int mach64DestroyContext( mach64ContextPtr ctx );
int mach64BindBuffer( mach64ContextPtr ctx, mach64BufferPtr buf );

#if 0 /* FIXME: GH */
extern GLuint mach64DDRegisterPipelineStages( struct gl_pipeline_stage *out,
					      const struct gl_pipeline_stage *in,
					      GLuint nr );

extern GLboolean mach64DDBuildPrecalcPipeline( GLcontext *ctx );
#endif


/*
 * Driver functions that uses mach64Ctx or mach64DB and can be called
 * directly from API such as glClear() should use CHECK_CONTEXT
 * before doing anything with mach64Ctx and mach64DB.
 *
 * Drawing functions such as Triangle are protected by CHECK_CONTEXT
 * in mach64RenderVB, so that they don't need it.
 *
 * mach64DB will be invalid when the frame buffer have to be reallocate
 * but there was not enough video memory avialable.
 * TODO: fix this.
 */
#define CHECK_CONTEXT( x )						\
    do {								\
	if ( !VALID_MACH64_CONTEXT( mach64Ctx ) ||			\
	     !VALID_MACH64_BUFFER( mach64DB ) ) {			\
	    x								\
	}								\
    } while ( 0 )

#endif
