/* $Id: mach64dd.c,v 1.1 1999/10/28 03:43:47 gareth Exp $ */

/*
 * GLX Hardware Device Driver for ATI Rage Pro
 * Copyright (C) 1999 Gareth Hughes
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * WITTAWAT YAMWONG, OR ANY OTHER CONTRIBUTORS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE
 * OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * Based on MGA driver: mgadd.c 1.13
 *
 *    Gareth Hughes <garethh@bell-labs.com>
 */


#include "xsmesaP.h"
#include "mesaglx/types.h"
#include "vbrender.h"
#include "glx_log.h"

#include "vga.h"
#include "vgaPCI.h"

#include <stdio.h>

#include "mm.h"
#include "rage_mac.h"
#include "mach64lib.h"
#include "mach64glx.h"
#if 0 /* FIXME: GH */
#include "mach64clear.h"
#endif
#include "mach64dd.h"
#if 0 /* FIXME: GH */
#include "mach64direct.h"
#include "mach64depth.h"
#endif
#include "mach64log.h"
#include "mach64state.h"
#if 0 /* FIXME: GH */
#include "mach64span.h"
#include "mach64tex.h"
#include "mach64tris.h"
#include "mach64vb.h"
#endif
#include "extensions.h"
#include "vb.h"
#include "dd.h"


#if 0 /* FIXME: GH */
extern int mach64ydstorg;
extern int mach64maccess;
#endif
extern int __glx_is_server;
extern void xsmesa_setup_DD_pointers( GLcontext *ctx );
extern int xf86VTSema;


/***************************************
 * Mesa's Driver Functions
 ***************************************/


const GLubyte *mach64DDGetString( GLcontext *ctx, GLenum name )
{
    switch ( name )
    {
    case GL_VENDOR:
	return "vendor-string for GLX-Mach64 *** EARLY DEVELOPMENT ***";
    case GL_RENDERER:
	return "GLX-Mach64 *** EARLY DEVELOPMENT ***";
    default:
	return 0;
    }
}


void mach64DDExtensionsInit( GLcontext *ctx )
{
    /* CVA only available for direct contexts.
     */
    if ( __glx_is_server ) {
	gl_extensions_disable( ctx, "GL_EXT_compiled_vertex_array" );
    }

   /* No support for multitexture
    */
    gl_extensions_disable( ctx, "GL_EXT_multitexture" );
    gl_extensions_disable( ctx, "GL_SGIS_multitexture" );
    gl_extensions_disable( ctx, "GL_ARB_multitexture" );

    /* we don't support point parameters in hardware yet */
    gl_extensions_disable( ctx, "GL_EXT_point_parameters" );

    /* No support for fancy imaging stuff.  This should kill off
    * a few rogue fallbacks.
    */
    gl_extensions_disable( ctx, "ARB_imaging" );
    gl_extensions_disable( ctx, "GL_EXT_blend_minmax" );
    gl_extensions_disable( ctx, "GL_EXT_blend_logic_op" );
    gl_extensions_disable( ctx, "GL_EXT_blend_subtract" );
    gl_extensions_disable( ctx, "GL_INGR_blend_func_separate" );
}


static GLint mach64GetParameteri( const GLcontext *ctx, GLint param )
{
    switch ( param )
    {
    case DD_HAVE_HARDWARE_FOG:
	return 0; /* actually we have one but it doesn't work well. */
    default:
	mach64Error( "mach64GetParameteri(): unknown parameter!\n" );
	return 0; /* Should I really return 0? */
    }
}


static int mach64CanUseHardware( const GLcontext *ctx )
{
    XSMesaContext xsmesa = (XSMesaContext) ctx->DriverCtx;
    XSMesaBuffer xsmbuf = xsmesa->xsm_buffer;
    /*
     * FIXME: This check will fail, and thus we won't set up the driver
     * correctly and will use the software rendering functions - GH.
     */
    CHECK_CONTEXT( return 0; );

    /* We shouldn't really be relying so much on mach64Ctx - should go
     * straight from ctx->DriverCtx->....  Perhaps this should be
     * reworked to remove one level of indirection.
     */
    if ( ctx != mach64Ctx->gl_ctx ) {
	FatalError( "mach64Ctx->gl_ctx != ctx in mach64CanUseHardware()" );
    }

    if ( !mach64DB || !mach64DB->Drawable || !xsmbuf->buffer == XIMAGE) {
	return 0;
    }

    return 1;
}


/*
 * if we can't hardware accelerate the context now, but could
 * before (the window was sized up to the point a buffer alloc failed)
 * then just have software mesa do everything.
 */
static void mach64_setup_DD_pointers_no_accel( GLcontext *ctx )
{
    /* disable hardware accel. */
    mach64Msg( 5, "no hw accel.\n" );

    ctx->Driver.RenderStart  = NULL;
    ctx->Driver.RenderFinish = NULL;
    ctx->Driver.NearFar = NULL;
    ctx->Driver.GetParameteri = NULL;
    ctx->Driver.RasterSetup = NULL;
    ctx->Driver.TexEnv = NULL;
    ctx->Driver.TexImage = NULL;
    ctx->Driver.BindTexture = NULL;
    ctx->Driver.DeleteTexture = NULL;
    ctx->Driver.TexParameter = NULL;

    xsmesa_setup_DD_pointers( ctx );
    ctx->Driver.UpdateState = mach64_setup_DD_pointers;
}



void mach64_setup_DD_pointers( GLcontext *ctx )
{
    if ( !mach64CanUseHardware( ctx ) ) {
	mach64_setup_DD_pointers_no_accel( ctx );
	/* FIXME: GH - do this here to show we're kinda working... */
	ctx->Driver.GetString = mach64DDGetString;
	return;
    }

    xsmesa_setup_DD_pointers( ctx );

    mach64DDInitStatePointers( ctx );

#if 0 /* FIXME: GH */
    ctx->Driver.Viewport = mach64DDViewport;
    ctx->Driver.DepthRange = mach64DDDepthRange;
#endif
    ctx->Driver.GetString = mach64DDGetString;
    ctx->Driver.UpdateState = mach64DDUpdateState;
#if 0 /* FIXME: GH */
    ctx->Driver.RegisterVB = mach64DDRegisterVB;
    ctx->Driver.UnregisterVB = mach64DDUnregisterVB;
    ctx->Driver.Clear = mach64Clear;
#endif
    ctx->Driver.GetParameteri = mach64GetParameteri;
#if 0 /* FIXME: GH */
    ctx->Driver.TexEnv = mach64TexEnv;
    ctx->Driver.TexImage = mach64TexImage;
    ctx->Driver.TexSubImage = mach64TexSubImage;
    ctx->Driver.BindTexture = mach64BindTexture;
    ctx->Driver.DeleteTexture = mach64DeleteTexture;
    ctx->Driver.TexParameter = mach64TexParameter;
    ctx->Driver.UpdateTexturePalette = mach64UpdateTexturePalette;
    ctx->Driver.IsTextureResident = mach64IsTextureResident;
#endif

    ctx->Driver.TriangleCaps = ( DD_TRI_CULL |
				 DD_TRI_LIGHT_TWOSIDE |
				 DD_TRI_OFFSET );

#if 0 /* FIXME: GH */
    mach64DDInitSpans( ctx );

    if ( mach64DB->HasZORG )
    {
	ctx->Driver.ReadDepthSpanFloat = mach64_read_depth_span_float;
	ctx->Driver.ReadDepthSpanInt = mach64_read_depth_span_int;

	if ( ctx->Depth.Test )
	{
	    switch ( ctx->Depth.Func )
	    {
	    case GL_LESS:
		ctx->Driver.DepthTestSpan = mach64_depth_test_span_less;
		ctx->Driver.DepthTestPixels = mach64_depth_test_pixels_less;
		break;
	    case GL_GREATER:
		ctx->Driver.DepthTestSpan = mach64_depth_test_span_greater;
		ctx->Driver.DepthTestPixels = mach64_depth_test_pixels_greater;
		break;
	    default:
		ctx->Driver.DepthTestSpan = mach64_depth_test_span_generic;
		ctx->Driver.DepthTestPixels = mach64_depth_test_pixels_generic;
		break;
	    }
	}
    }
#endif

    /* Also do the normal GL state-change checks. */
    mach64DDUpdateState( ctx );
}


/*
 * Local Variables:
 * mode: c
 * c-basic-offset: 4
 * End:
 */
