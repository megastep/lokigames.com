/* $Id: mach64dma.c,v 1.1 1999/10/28 03:43:47 gareth Exp $ */

/*
 * GLX Hardware Device Driver for ATI Rage Pro
 * Copyright (C) 1999 Gareth Hughes
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * WITTAWAT YAMWONG, OR ANY OTHER CONTRIBUTORS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE
 * OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * Based on MGA driver: mgadma.c ???
 *
 *    Gareth Hughes <garethh@bell-labs.com>
 */

#include <stdlib.h>
#include <errno.h>
#include <unistd.h>
#include <sys/mman.h>
#include <stdio.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>

#include "mm.h"
#include "mach64buf.h"
#include "mach64dd.h"
#include "rage_mac.h"
#include "mach64lib.h"
#include "mach64log.h"
#if 0 /* FIXME: GH */
#include "mach64direct.h"
#endif
#include "mach64state.h"

#include "pb.h"

/* public vars */
mach64Dma_buffer	*dma_buffer;	/* dmaBuffers[ activeDmaBuffer ] */


/* This will be overwritten from the default values when glx.so is
 * loaded on the client.
 */
void mach64ServerDmaFlush( int wait );
void    (*mach64DoDmaFlush)( int ) = mach64ServerDmaFlush;
mach64UI32	mach64ActiveDmaBuffer = 0;


/*
   Before we submit a dma command buffer, we write SYNC_DMA_BUSY to DWGSYNC.
   The last command in the dma buffer will clear DWGSYNC.
   The X server might also change the value in DWGSYNC, but the register
   locking guarantees that dma will complete first.  We will spin until
   timeout in waitDmaCompletion() if the X server ever happens to use
   our magic value.

   Any time DWGSYNC is read and it holds SYNC_DMA_BUSY, then dma is still
   active and we need to wait until it is cleared.
*/
#define SYNC_DMA_BUSY		0xea832534	/* just a random number */


static	mach64UI32	registersLocked;	/* true when the registers are memory protected */

static void UnlockRegisters( void );
void mach64DmaResetBuffer( void );
static void mach64FlushPseudoDma( void );

void mach64SetSyncBusy( void )
{
#if 0 /* FIXME: GH */
    /* set the DWGSYNC register to our magic value */
    OUTREG( MACH64REG_DWGSYNC, SYNC_DMA_BUSY );
    while ( INREG( MACH64REG_DWGSYNC ) != SYNC_DMA_BUSY ) {
	/* X might have left something drawing */
    }
#endif
}

static void delay( void )
{ }

/*
 * mach64WaitForDmaCompletion
 *
 */
#define	TIMEOUT_USEC		1000000

int mach64WaitForDmaCompletion( void )
{
    int		startTime;
    int		curTime;
    int		i;

    if ( mach64glx.skipDma ) {
	return 0;
    }

    startTime = 0;
    curTime = 0;

    while ( 1 )
    {
	if ( !MACH64_ISBUSY() ) {
	    break;
	}

	curTime = usec();
	if ( ( startTime == 0 ) || ( curTime < startTime /*wrap case*/ ) ) {
	    startTime = curTime;
	} else if ( curTime - startTime > TIMEOUT_USEC ) {
	    mach64Msg( 1, "waitForDmaCompletion timed out\n" );
	    break;
	}

	/* spin in place a bit so we aren't hammering the register */
	for ( i = 0 ; i < 10000 ; i++ ) {
	    delay();
	}
    }

    mach64Msg( 10, "waitForDmaCompletion, usec: %d\n", curTime - startTime );
    if ( MACH64_ISBUSY() ) {
	mach64Msg( 1, "waitForDmaCompletion: still going!\n" );
    }

    if ( registersLocked ) {
	UnlockRegisters();
    }

    return curTime - startTime;
}

/*
 * mach64DmaResetBuffer
 */
void mach64DmaResetBuffer()
{
    mach64UI32	*table_ptr;

    dma_buffer = dmaBuffers[ mach64ActiveDmaBuffer ];
    dma_buffer->tableDwords = 0;
    dma_buffer->bufferDwords = 0;

    /* Initialize the first descriptor table entry. */
    table_ptr = dma_buffer->virtualTable;

    /* FIXME: This is the 8MB offset.  We know the true offset somewhere... */
    table_ptr[DMA_FRAME_BUF_OFFSET] = MACH64REG_BM_ADDR + 0x7ff800;
    table_ptr[DMA_SYS_MEM_ADDR] = dma_buffer->physicalBuffer;
    table_ptr[DMA_COMMAND] = 0x40000000;
    table_ptr[DMA_RESERVED] = 0;

    /* This is required because each dma buffer is finished by a
     * return to 2d state, as expected by the X server.  Could
     * alternately do the stuff to make the fallback inside the
     * signal handler, but this way is nicer if we ever support
     * multiple direct clients.
     */
    if ( mach64DB && mach64Ctx ) {
	if ( MESA_VERBOSE & VERBOSE_DRIVER ) {
	    fprintf( stderr, "needEnter3D and ENTER3D in mach64DmaResetBuffer\n" );
	}
	mach64Ctx->new_state |= MACH64_NEW_CONTEXT;
    }
}


static void UnlockRegisters( void )
{
    mprotect( mach64MMIOBase, 0x1000, PROT_READ | PROT_WRITE );
    registersLocked = 0;
}

static void RegisterAccessSignalHandler( int signal )
{
    if ( !registersLocked ) {
	mach64Msg( 10, "RegisterAccessSignalHandler() without registersLocked\n" );
	FatalError( "RegisterAccessSignalHandler() without registersLocked\n" );
    }

    /* someone has tried to access hardware registers, so make
       sure dma is completed */
    mach64Msg( 10, "RegisterAccessSignalHandler()\n" );
    mach64glx.c_signals++;
    mach64WaitForDmaCompletion();
    mach64Msg( 10, "Leaving RASH()\n" );
}

static void LockRegisters( void )
{
    /* cause a SIGSEGV if the X server tries to write a hardware register */
    mprotect( mach64MMIOBase, 0x3000, /* PROT_NONE */ PROT_READ );
    signal( SIGSEGV, RegisterAccessSignalHandler );
    registersLocked = 1;
}

int	xchangeDummy;

#ifndef NO_MTRR
static void FlushWriteCombining( void )
{
#ifdef USE_X86_ASM
    __asm__ volatile( " push %%eax ; xchg %%eax, %0 ; pop %%eax" : : "m" (xchangeDummy) );
    __asm__ volatile( " push %%eax ; push %%ebx ; push %%ecx ; push %%edx ; movl $0,%%eax ; cpuid ; pop %%edx ; pop %%ecx ; pop %%ebx ; pop %%eax" : /* no outputs */ :  /* no inputs */ );
#endif
}
#endif

/*
 * mach64FlushRealDma
 */
void mach64FlushRealDma( void )
{
    int		count;
    mach64UI32	dmaEnd;

    if ( mach64glx.skipDma ) {
	return;
    }
    mach64Msg( 11, "mach64FlushRealDma()\n" );

#ifndef	NO_MTRR
    /* make sure any write combining data is flushed */
    FlushWriteCombining();
#endif

    /* if we are using a card memory buffer, do a read to
       guarantee the store buffer is flushed */
    xchangeDummy = dma_buffer->virtualBuffer[dma_buffer->bufferDwords];

    /* program the physical registers to start dma going */
    count = dma_buffer->bufferDwords;
    dmaEnd = dma_buffer->physicalBuffer + count*4;

    OUTREG( MACH64REG_BUS_CNTL,
	    INREG( MACH64REG_BUS_CNTL ) | BUS_master_enable );

    /* FIXME: Add 16k circular buffer size (0x0) to register header */
    OUTREG( MACH64REG_BM_GUI_TABLE, dma_buffer->physicalTable | 0x0 );

    OUTREG( MACH64REG_SRC_CNTL, INREG( MACH64REG_SRC_CNTL ) |
	    SRC_bm_enable | SRC_bm_gui_sync | SRC_bm_op_sysmem_to_reg );

    /* initiate the transfer */
    MACH64DMAINITIATE();

    /* if we are going to run async, throw a signal if X tries to use
       the hardware registers */
    if ( mach64glx.dmaDriver == 3 ) {
	LockRegisters();
    }
}

/*
 * mach64DmaFlush
 * Send all pending commands off to the hardware.
 * If we are running async, the hardware will be drawing
 * while we return to do other things.
 */
void mach64ServerDmaFlush( int wait )
{
    int		start, end, i;
    DMALOCALS;

    /* if the buffer only contained an ENTER3D, just change in place */
    if ( !dma_buffer->bufferDwords ) {
	if ( wait ) {
	    mach64WaitForDmaCompletion();
	}
	mach64DmaResetBuffer();
	return;
    }

    mach64glx.c_dmaFlush++;

    if ( registersLocked ) {
	UnlockRegisters();
    }

    /* wait for the last buffer to complete */
    if ( !mach64WaitForDmaCompletion() ) {
	mach64glx.hardwareWentIdle = 1;
    }

    mach64SetSyncBusy();


    /* Add the commands at the end of the buffer to go back to
     * drawing on the front buffer the way the X server expects.
     */
#if 0 /* FIXME: GH */
    memcpy( dma_buffer->virtualBuffer + dma_buffer->bufferDwords,
	    mach64FrontBuffer->Setup,
	    sizeof(mach64UI32) * mach64FrontBuffer->SetupSize );
    dma_buffer->bufferDwords += mach64FrontBuffer->SetupSize;
#endif

#if 0 /* FIXME: GH - we don't need to do this, as the card tells us
	 when dma is done */
    /* add a draw sync command at the end so we can tell when dma is done */
    MACH64DMAGETPTR( 4 );
    DMAOUTREG( MACH64REG_DMAPAD, 0 );
    DMAOUTREG( MACH64REG_DMAPAD, 0 );
    DMAOUTREG( MACH64REG_DMAPAD, 0 );
    DMAOUTREG( MACH64REG_DWGSYNC, 0 );
    DMAADVANCE();
#endif

    /* correctly terminate the descriptor table entries. */
    mach64Msg( 1, "Terminating DMA descriptor table...\n" );

    MACH64DMATERMINATE();

    mach64Msg( 1, "  table entries: %d buffer cmds: %d\n", dma_buffer->tableDwords / 4, dma_buffer->bufferDwords / 2 );

    for ( i = 0 ; i < dma_buffer->tableDwords / 4 ; i++ )
    {
	mach64Msg( 1, "    entry: %d addr: %p cmd: 0x%x\n", i, dma_buffer->virtualTable[4*i+1], dma_buffer->virtualTable[4*i+2] );
    }

    /* collect timing information if we are going syncronously */
    if ( mach64glx.dmaDriver != 3 ) {
	start = usec();
    } else {
	start = end = 0;
    }

    if ( mach64glx.dmaDriver < 2 ) {
	mach64FlushPseudoDma();
    } else {
	mach64FlushRealDma();
	if ( ( mach64glx.dmaDriver == 2 ) || wait ) {
	    /* wait until the dma completes */
	    mach64WaitForDmaCompletion();
	}
    }


    if ( mach64glx.dmaDriver != 3 ) {
	end = usec();
    }

    mach64Msg( 9, "flushmode %i, buffer %i: prim dwords:%i  usec:%i\n",
	       mach64glx.dmaDriver,  mach64ActiveDmaBuffer,
	       dma_buffer->bufferDwords, end - start );

    /* swap to using the other buffer */
    mach64ActiveDmaBuffer ^= 1;

    mach64DmaResetBuffer();
}

/*
 * mach64DmaFlush
 */
void mach64DmaFlush( void )
{
    mach64DoDmaFlush( 0 );
}

/*
 * mach64DmaFinish
 */
void mach64DmaFinish( void )
{
    mach64DoDmaFlush( 1 );
}



/*
 * mach64DmaOverflow
 * This is called when MACH64DMAGETPTR is at the end of the buffer
 */
void mach64DmaOverflow( int newDwords )
{
    mach64Msg( 9, "mach64DmaOverflow(%i)\n", newDwords );
    FatalError( "mach64DmaOverflow(%i)\n", newDwords );

    /* flush all the current commands so we will have another
       empty buffer */
    mach64DmaFlush();

    /* Overflow can happen anywhere, so normal update mechanisms
     * aren't sufficient.  FIXME: this may be a problem if
     * texture upload caused the overflow, because the updateHwState
     * may cause recursion into it...
     */
    if ( mach64Ctx ) {
	mach64Ctx->new_state |= MACH64_NEW_CONTEXT;
#if 0 /* FIXME: GH */
	mach64DDUpdateHwState( mach64Ctx->gl_ctx );
#endif
    }

    mach64glx.c_overflows++;
    if ( newDwords > dma_buffer->maxBufferDwords ) {
	FatalError("mach64DmaOverflow > maxBufferDwords");
    }
}

/*
 * mach64WaitDrawingEngine
 * This will not return until the drawing engine has completed
 * drawing pixels and it is safe to read or write the framebuffer
 * for software rendering.
 */
int mach64WaitDrawingEngine( void )
{
    /* note this for the performance block display */
    mach64glx.c_drawWaits++;

    /* make sure all pending dma has completed */
    mach64DmaFinish();

    return 0;
}

/*
 * mach64DmaExecute
 * Add a block of data to the dma buffer
 */
void mach64DmaExecute( mach64UI32 *code, int dwords )
{
    if ( (dma_buffer->maxBufferDwords - dma_buffer->bufferDwords) < dwords )
    {
	mach64DmaFlush();
    }
    memcpy( dma_buffer->virtualBuffer + dma_buffer->bufferDwords,
	    code, sizeof(mach64UI32) * dwords );
    dma_buffer->bufferDwords += dwords;
}



/*
 * mach64FlushPseudoDma
 * Hand feed a dma buffer to the card, simulating secondary dma as needed.
 * This will parse the buffer even if skipdma is set, allowing safe
 * range checking.
 */
static void mach64FlushPseudoDma( void )
{
    mach64UI32	save;
    mach64UI32	*src, *p;
    int		i, j;
    int		mode;
    int		dwords;
    int		count;

    count = dma_buffer->bufferDwords;

    mach64Msg( 20, "primary pseudoDma: %i dwords\n", count );

    mach64glx.hardwareWentIdle = 1;

    if ( !mach64glx.skipDma ) {
#if 0 /* FIXME: GH */
	save = INREG(MACH64REG_OPMODE);
	OUTREG( MACH64REG_OPMODE,(save & OM_dmamod_MASK) | (TT_GENERAL<<2) );
#endif
    }

    p = pseudoDmaVirtual;

    src = dma_buffer->virtualBuffer;
    for ( i = 0 ; i < count ; )
    {
	src = dma_buffer->virtualBuffer + i;

#if 0 /* FIXME: GH */
	/* check for a secondary dma start */
	if ( *(mach64UI8 *)src == ADRINDEX(MACH64REG_SECADDRESS) )
	{
	    mach64UI32	start, end;

	    start = src[1];
	    end = src[2];

	    mode = start & 3;
	    start = ( start & ~3 ) - dma_buffer->physicalAddress;
	    end = ( end & ~3 ) - dma_buffer->physicalAddress;

	    if ( ( start >> 2 ) < dma_buffer->maxPrimaryDwords ) {
		FatalError( "mach64FlushPseudoDma: start before buffer: %i", start );
	    }

	    if ( ( end >> 2 ) > dma_buffer->maxSecondaryDwords + dma_buffer->maxPrimaryDwords ) {
		FatalError( "mach64FlushPseudoDma: end after buffer: %i", end );
	    }

	    if ( start >= end ) {
		FatalError( "mach64FlushPseudoDma: start >= end: %i, %i", start, end );
	    }

	    dwords = ( end - start ) >> 2;

	    src = dma_buffer->virtualAddress + ( start >> 2 );

	    mach64Msg( 20, "secondary pseudoDma: %i dwords, mode %i\n", dwords, mode );

	    if ( !mach64glx.skipDma )
	    {
		OUTREG( MACH64REG_OPMODE,(save & OM_dmamod_MASK) | (mode<<2) );

		for ( j = 0 ; j < dwords ; j++ ) {
		    p[j] = src[j];
		}

		/* we will fetch a new general index word immediately */
		OUTREG( MACH64REG_OPMODE,(save & OM_dmamod_MASK) | (TT_GENERAL<<2) );
	    }
	    i += 3;
	    continue;
	}

	if ( !mach64glx.skipDma ) {
	    p[0] = src[0];
	    p[1] = src[1];
	    p[2] = src[2];
	    p[3] = src[3];
	    p[4] = src[4];
	}

	i += 5;
	if ( i > count ) {
	    FatalError( "mach64FlushPseudoDma: didn't end with a full quad" );
	}
#endif
    }

    if ( !mach64glx.skipDma ) {
#if 0 /* FIXME: GH */
	OUTREG( MACH64REG_OPMODE, save );
#endif
    }
}


/*
 * Local Variables:
 * mode: c
 * c-basic-offset: 4
 * End:
 */
