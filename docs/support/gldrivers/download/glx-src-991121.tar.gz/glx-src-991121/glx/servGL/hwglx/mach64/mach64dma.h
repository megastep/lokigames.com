/* $Id: mach64dma.h,v 1.1 1999/10/28 03:43:47 gareth Exp $ */

/*
 * GLX Hardware Device Driver for ATI Rage Pro
 * Copyright (C) 1999 Gareth Hughes
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * WITTAWAT YAMWONG, OR ANY OTHER CONTRIBUTORS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE
 * OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * Based on MGA driver: mgadma.h ???
 *
 *    Gareth Hughes <garethh@bell-labs.com>
 */

#ifndef __MACH64_DMA_H__
#define __MACH64_DMA_H__

#include "mach64common.h"
#include "mm.h"

/*
 * The Rage Pro DMA stream operates in 4K chunks of dword pairs, in the
 * following format:
 *
 * ADDR (in MM offset format)
 * DATA
 * ADDR (in MM offset format)
 * DATA
 * ADDR (in MM offset format)
 * DATA
 * ....
 *
 * The data is accessed through descriptor tables, with each descriptor
 * entry consisting of 4 dwords:
 *
 * BM_FRAME_BUF_OFFSET	- Frame buffer offset for data transfer
 * BM_SYSTEM_MEM_ADDR	- Physical system memory address for data transfer
 * BM_COMMAND		- Count of bytes to transfer (4K max) + flags
 * RESERVED		- Always set to 0
 *
 * For more info, see the mach64 Programmer's Guide, section 8.10
 */

/*
 * Not sure how this compares with the G200, but the Rage Pro has two
 * banks of registers, with bank 0 at (aperture base + memmap offset - 1KB)
 * and bank 1 at (aperture base + memmap offset - 2KB).  But, to send them
 * via DMA, we need to encode them as memory map select rather than physical
 * offsets.
 */
#define DWMREG0		0x0400
#define DWMREG0_END	0x07ff
#define DWMREG1		0x0000
#define DWMREG1_END	0x03ff

#define ISREG0(r)	( ( (r) >= DWMREG0 ) && ( (r) <= DWMREG0_END ) )
#define ADRINDEX0(r)	(mach64UI8)( (r - DWMREG0) >> 2 )
#define ADRINDEX1(r)	(mach64UI8)( ( (r - DWMREG1) >> 2 ) | 0x0100 )
#define ADRINDEX(r)	( ISREG0(r) ? ADRINDEX0(r) : ADRINDEX1(r) )

#define MACH64_ADDRGEN( i0, i1, i2, i3 )	\
    ( ADRINDEX(i0) |				\
    ( ADRINDEX(i1) << 8 ) |			\
    ( ADRINDEX(i2) << 16 ) |			\
    ( ADRINDEX(i3) << 24 ) )

#define DMA_FRAME_BUF_OFFSET	0
#define DMA_SYS_MEM_ADDR	1
#define DMA_COMMAND		2
#define DMA_RESERVED		3

/* the main initialization of the entire mach64 hardware driver */
GLboolean mach64InitGLX( void );

/* a flush command will guarantee that all data added to the dma buffer
is on its way to the card, and will eventually complete with no more
intervention.  If running with pseudo dma, this will be the same as a finish
call, but if async dma is active then the card will be executing the commands
while the cpu is doing other work.  A protected memory region keeps X server
interaction with the hardware registers safe. */
void mach64DmaFlush( void );

/* the overflow function is called when a block can't be allocated
in the current dma buffer.  It flushes the current buffer and
records some information */
void mach64DmaOverflow( int newDwords );

/* a finish command will guarantee that all dma commands have actually
been consumed by the card.  Note that there may still be a couple primitives
that have not yet been executed out of the internal FIFO, so this does not
guarantee that the drawing engine is idle. */
void mach64DmaFinish( void );

/* a mach64WaitDrawingEngine command will guarantee that the framebuffer
is safe to read or write for software rendering */
int mach64WaitDrawingEngine( void );

typedef enum
{
    TT_GENERAL,
    TT_BLIT,
    TT_VECTOR,
    TT_VERTEX
} transferType_t;

/* pre-generated blocks of register commands can be added to the dma buffer
with mach64DmaExecute().  This is used to set the state registers and texture
registers.  The dwords size MUST be a multiple of 5, pad the index bytes with
nops (0x15) and extra data dwords if needed */
void mach64DmaExecute( mach64UI32 *code, int dwords );

/* for routines that need to add a variable stream of register writes, use
the MACH64DMAGETPTR() / DMAOUTREG() / DMAADVANCE() interface.  Call
mach64DmaGetPtr() with a length in dwords that is guaranteed to be greater
than what you will be writing.  Using a large value, like 100, does not
waste anything.  Program all the registers you need with DMAOUTREG(),
or the MACH64DMA_* macros, which use DMAOUTREG().  When you have finished,
call DMAADVANCE(), which will add any necessary padding and commit the
data to the dma buffer

DMALOCALS must be included at the top of all functions that use these
macros to declare temporary variables.

*/

typedef struct _dma_buffer
{
    mach64UI32	physicalTable;		/* descriptor table */
    mach64UI32 	*virtualTable;
    mach64UI32	physicalBuffer;
    mach64UI32 	*virtualBuffer;

    mach64UI32	tableDwords;		/* amount currently allocated */
    mach64UI32	maxTableDwords;
    mach64UI32	bufferDwords;		/* amount currently allocated */
    mach64UI32	maxBufferDwords;
} mach64Dma_buffer;

/* cardHeap is the 8 / 16 / 32 megs of memory on the video card */
extern	memHeap_t	*cardHeap;
extern	mach64UI32	cardPhysical;
extern	unsigned char	*cardVirtual;

/* sysmemHeap is system memory we have been given after the area used
   by the kernel */
extern	memHeap_t	*sysmemHeap;
extern	mach64UI32	sysmemPhysical;	/* 0 if we don't have a physical mapping */
extern	unsigned char	*sysmemVirtual;

/* textureHeap will point to either cardHeap or sysmemHeap */
extern	memHeap_t	*textureHeap;
extern	mach64UI32	textureHeapPhysical;	/* 0 if we aren't using PCI texturing */
extern	unsigned char	*textureHeapVirtual;	/* correct for either local or PCI heaps */

extern	mach64UI32	*pseudoDmaVirtual;	/* our local mapping of pdma window */

extern	mach64Dma_buffer	*dma_buffer;

/* These are only required by mach64direct.c:
 */
extern mach64UI32	mach64ActiveDmaBuffer;
extern void (*mach64DoDmaFlush)( int );
extern mach64Dma_buffer	*dmaBuffers[2];

extern int use_agp;

extern int mach64WaitForDmaCompletion( void );
extern void mach64DmaResetBuffer( void );

#define MACH64_CHUNKSIZE	0x1000

#define DMALOCALS	int outcount; mach64UI32 *dma_ptr; mach64UI32 *table_ptr

#define MACH64DMAUPDATE()						\
    do {								\
	table_ptr[DMA_COMMAND] |= MACH64_CHUNKSIZE;			\
	table_ptr += 4;							\
	table_ptr[DMA_FRAME_BUF_OFFSET] = MACH64REG_BM_ADDR + 0x7ff800;	\
	table_ptr[DMA_SYS_MEM_ADDR] =					\
	    dma_buffer->physicalBuffer + dma_buffer->bufferDwords * 4;	\
	table_ptr[DMA_COMMAND] = 0x40000000;				\
	table_ptr[DMA_RESERVED] = 0;					\
    } while ( 0 )

#define MACH64DMATERMINATE()						\
    do {								\
	table_ptr = (dma_buffer->virtualTable + dma_buffer->tableDwords);\
	table_ptr[DMA_COMMAND] |=					\
	    ( dma_buffer->bufferDwords % MACH64_CHUNKSIZE );		\
	table_ptr[DMA_COMMAND] |= 0x80000000;				\
	dma_buffer->tableDwords += 4;					\
    } while ( 0 )

#define MACH64DMAGETPTR( length )					\
    if ( (dma_buffer->maxBufferDwords - dma_buffer->bufferDwords) < length )\
	mach64DmaOverflow( length );					\
    dma_ptr = (dma_buffer->virtualBuffer + dma_buffer->bufferDwords);	\
    table_ptr = (dma_buffer->virtualTable + dma_buffer->tableDwords);	\
    outcount = 0;

#define DMAOUTREG( reg, val )						\
    do {								\
	dma_ptr[ outcount++ ] = ADRINDEX( reg );			\
	dma_ptr[ outcount++ ] = val;					\
	dma_buffer->bufferDwords += 2;					\
	if ( (dma_buffer->bufferDwords % MACH64_CHUNKSIZE) == 0 ) {	\
	    MACH64DMAUPDATE();						\
	    dma_buffer->tableDwords += 4;				\
	}								\
    } while ( 0 )


#define DMAADVANCE()
#if 0
    do {								\
	if ( outcount & 3 ) {						\
	    while ( outcount & 3) {					\
		tempIndex[outcount++] = 0x15;				\
	    }								\
	    dma_ptr[0] = *(int *)tempIndex;				\
	    dma_buffer->number_of_dwords += 5;				\
	}								\
    } while ( 0 )
#endif



#if 0
#define MGADMAGETPTR(length)
    if( (dma_buffer->maxPrimaryDwords - dma_buffer->primaryDwords) < length)
	mgaDmaOverflow(length);
    dma_ptr = (dma_buffer->virtualAddress + dma_buffer->primaryDwords);
    outcount = 0;

#define DMAOUTREG(reg ,val)
    do {
	tempIndex[outcount]=ADRINDEX(reg);
	dma_ptr[1+outcount]=val;
	if ( ++outcount == 4 ) {
	    outcount = 0;
	    dma_ptr[0]=*(int *)tempIndex;
	    dma_ptr+=5;
	    dma_buffer->primaryDwords += 5;
	}
    } while(0)

#define DMAADVANCE()
    do {
	if ( outcount & 3 ) {
	    while(outcount & 3) {
		tempIndex[outcount++]=0x15;
	    }
	    dma_ptr[0]=*(int *)tempIndex;
	    dma_buffer->primaryDwords += 5;
	}
    } while(0)
#endif

/*
 * To start the DMA transfer, we need to initiate a GUI operation.  We can
 * write any value to the register, as it is only used to start the engine.
 */
#define MACH64DMAINITIATE()	OUTREG( MACH64REG_DST_HEIGHT_WIDTH, 0x0000 )

#endif
