/* $Id: mach64dmainit.c,v 1.1 1999/10/28 03:43:47 gareth Exp $ */

/*
 * GLX Hardware Device Driver for ATI Rage Pro
 * Copyright (C) 1999 Gareth Hughes
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * WITTAWAT YAMWONG, OR ANY OTHER CONTRIBUTORS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE
 * OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * Based on MGA driver: mgadmainit.c ???
 *
 *    Gareth Hughes <garethh@bell-labs.com>
 */

/*
 * This file is only entered at startup.  After machInitGLX completes,
 * nothing here will be executed again.
 */

#include <stdlib.h>
#include <errno.h>
#include <unistd.h>
#include <sys/mman.h>
#include <stdio.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>

#include "context.h"
#include "depth.h"
#include "macros.h"
#include "texstate.h"
#include "triangle.h"
#include "vb.h"
#include "types.h"

#include "xsmesaP.h"
#include "glx_log.h"
#include "mesaglx/context.h"
#include "mesaglx/matrix.h"
#include "mesaglx/types.h"

#define GC XXGC
#include "gcstruct.h"
#include "pixmapstr.h"
#include "servermd.h" /* PixmapBytePad */
#include "scrnintstr.h"
#include "regionstr.h"
#include "windowstr.h"
#undef GC

#include "vga.h"
#include "vgaPCI.h"
#include "mach64.h"
#include "xaa/xf86xaa.h"

#include "mm.h"
#include "mach64buf.h"
#include "mach64dd.h"
#include "rage_mac.h"
#include "mach64lib.h"
#include "mach64log.h"
#if 0 /* FIXME: GH */
#include "mach64direct.h"
#endif
#include "mach64glx.h"

#ifndef NO_MTRR

#define MTRR_NEED_STRINGS
#include <errno.h>
#include <asm/mtrr.h>
#include <sys/ioctl.h>

static int mtrr;

#if defined(USE_X86_ASM)
#include "X86/common_x86asm.h"
#endif

#endif

/* AGP kernel module interface */

enum chipset_type { NOT_SUPPORTED, INTEL_GENERIC, INTEL_LX, INTEL_BX, INTEL_GX,
                    VIA_GENERIC, VIA_VP3, VIA_MVP3, VIA_APOLLO_PRO, SIS_GENERIC};
enum agp_mode { AGP_MODE4X, AGP_MODE2X, AGP_MODE1X };

struct gart_info
{
    long physical;
    int size;
    int num_of_slots;
    enum chipset_type type;
    enum agp_mode mode;
};

/* Maximum size that can be allocated at once is 1024 entries */

struct gart_entry
{
    int ofs;
    int size;
};

#define GARTIOCINSERT _IOR('J', 1, struct gart_entry)
#define GARTIOCREMOVE _IOR('J', 2, struct gart_entry)
#define GARTIOCINFO   _IOW('J', 3, struct gart_info)
#define GARTIOCINIT   _IO ('J', 4)



/*

GLX_MACH64_DMA=0	: virtual buffer, pseudo dma
GLX_MACH64_DMA=1	: physical buffer, pseudo dma
GLX_MACH64_DMA=2	: physical buffer, real dma
GLX_MACH64_DMA=3	: physical buffer, real dma, async

GLX_MACH64_DMAADR=92	: put the physical buffer at offset 92 * 0x100000
			: use GLX_MACH64_DMAADR=AGP to use agp memory
GLX_MACH64_DMASIZE=4	: use 4 * 0x100000 bytes of memory for the buffers

GLX_MACH64_CMDSIZE=4	: use 4 * 0x100000 bytes for commands, the rest for textures
GLX_MACH64_TABLESIZE=16	: use 16 * 0x4000 bytes for the descriptor tables

GLX_MACH64_CARDCMDS=1	: put command buffers on card memory ( DOESN'T WORK! )
GLX_MACH64_SYSTEMTEXTURE = 1	: put textures in main pci/agp memory instead of on card

*/

memHeap_t	*cardHeap;
mach64UI32	cardPhysical;
unsigned char	*cardVirtual;

memHeap_t	*textureHeap;
mach64UI32	textureHeapPhysical;	/* 0 if we aren't using system memory texturing */
unsigned char	*textureHeapVirtual;	/* correct for either local or PCI heaps */

memHeap_t	*sysmemHeap;		/* physical memory, if available */
mach64UI32	sysmemBytes;		/* size of memory block */
mach64UI32	sysmemPhysical;		/* 0 if we don't have a physical mapping */
unsigned char	*sysmemVirtual;

mach64UI32	*pseudoDmaVirtual;	/* our local mapping of pdma window */

int	use_agp;	/* will be set to "PDEA_pagpxfer_enable" if enabled or 0 if not */
int	gartfd;
void	*gartbuf;
struct gart_info gartinf;


/* private vars */
mach64Dma_buffer	*dmaBuffers[2];


static	mach64UI32	bufferBytes;		/* size of buffer */
static	mach64UI32	bufferPhysical;		/* 0 if we don't have a physical mapping */
static	unsigned char	*bufferVirtual;

static mach64UI32	tableBytes;		/* size of descriptor table */


/* FIXME: GH */
int __glx_is_server = 1;

void mach64DmaResetBuffer( void );
void mach64SetSyncBusy( void );


/*
 * MapPseudoDmaWindow
 *
 * GH: Our pseudo DMA will merely use programmed I/O to send the buffered
 * commands.  I'll add this later.
 */
static void MapPseudoDmaWindow( void )
{
#if 0 /* FIXME: GH */
    mach64UI32	pseudoDmaPhysical;

    pseudoDmaPhysical =  (pcibusRead(MACH64PciTag, 0x00000018)) & 0xff800000;
    pseudoDmaVirtual =
	xf86MapVidMem( mach64InfoRec.scrnIndex, EXTENDED_REGION,
		       (pointer) ((unsigned long) pseudoDmaPhysical),
		       0x800000 );
    mach64Msg( 1, "pseudoDmaPhysical : %p\n", pseudoDmaPhysical );
    mach64Msg( 1, "pseudoDmaVirtual : %p\n", pseudoDmaVirtual );
#endif
}

static const char *getenvSafe( const char *name )
{
    const char	*r;

    r = getenv( name );
    if ( !r ) {
	return "";
    }
    return r;
}

static int IsPowerOfTwo( int val )
{
    int		i;

    for ( i = 0 ; i < 32 ; i++ ) {
	if ( val == ( 1 << i ) ) {
	    return 1;
	}
    }
    return 0;
}


static void mach64CloseMTRR( void )
{
#ifndef NO_MTRR
    close( mtrr );
#endif
}

static void mach64OpenMTRR( void )
{
#ifndef NO_MTRR
    if ( ( mtrr = open( "/proc/mtrr", O_WRONLY, 0 ) ) == -1 )
    {
	if ( errno == ENOENT ) {
	    mach64Error( "/proc/mtrr not found: MTRR not enabled\n" );
	}  else {
	    mach64Error( "Error opening /proc/mtrr: %s\n", strerror( errno ) );
	    mach64Error( "MTRR not enabled\n" );
	}
	return;
    }
    atexit( mach64CloseMTRR );
#endif
}


int CoverRangeWithMTRR( int base, int range, int type )
{
    int		count;
    int		size;

    count = 0;
#ifndef NO_MTRR
    mach64Msg( 1,"CoverRangeWithMTRR( 0x%x, 0x%x, %i )\n", base, range, type );

    while ( range )
    {
	/* see how big of an mtrr we can make */

	/* size must be a power of 2 */
	for ( size = 2048 ; ; )
	{
	    size *= 2;

	    /* the base must be a multiple of the size */
	    if ( base != size * ( base / size ) ) {
		size >>= 1;
		break;
	    }

	    if ( size > range ) {
		size >>= 1;
		break;
	    }
	}

	/* set it if we aren't just checking the number */
	if ( type != -1 )
	{
	    struct mtrr_sentry sentry;

	    sentry.base = base;
	    sentry.size = size;
	    sentry.type = type;

	    mach64Msg( 1, "MTRR fragment added: addr=0x%x size=0x%x type=%i\n",
		       sentry.base, sentry.size, sentry.type );
	    if ( ioctl( mtrr, MTRRIOC_ADD_ENTRY, &sentry ) == -1 ) {
		mach64Error( "Error doing ioctl(2) on /proc/mtrr: %s\n",
			     strerror( errno ) );
	    }
	}

	base += size;
	range -= size;
	count++;
    }

    mach64Msg( 1, "------\n" );
#endif

    return count;
}

/*
 * SetWriteCombining
 *
 * Checks for unsetting an existing MTRR if needed
 */
static void SetWriteCombining( long physical, int bytes )
{
#ifndef NO_MTRR
    struct mtrr_sentry sentry;
    struct mtrr_gentry gentry;
    int i;

    if ( !mtrr ) {
	return;
    }

    /* remove any MTRR that conver the range */
    for ( i = 0 ; i < 128 ; i++ )
    {
	gentry.regnum = i;
	if ( ioctl( mtrr, MTRRIOC_GET_ENTRY, &gentry ) == -1 ) {
	    break;
	}
	mach64Msg( 1, "MTRR reg %i: addr=0x%x size=0x%x type=%i\n",
		   i, gentry.base, gentry.size, gentry.type );
	if ( gentry.base >= physical + bytes ) {
	    continue;
	}
	if ( gentry.base + gentry.size <= physical ) {
	    continue;
	}

	/* we must delete this entry */
	sentry.base = gentry.base;
	sentry.size = gentry.size;
	if ( ioctl( mtrr, MTRRIOC_DEL_ENTRY, &sentry ) == -1 ) {
	    mach64Error( "Error doing MTRRIOC_DEL_ENTRY on /proc/mtrr: %s\n",
			 strerror( errno ) );
	} else {
	    mach64Msg( 1, "MTRRIOC_DEL_ENTRY succeeded\n" );
	}

	/* recreate fragments around the new region if necessary */
	if ( gentry.base < physical ) {
	    CoverRangeWithMTRR( gentry.base, physical - sentry.base,
				gentry.type );
	}
	if ( gentry.base + gentry.size > physical + bytes ) {
	    CoverRangeWithMTRR( physical + bytes,
				gentry.base + gentry.size - sentry.base,
				gentry.type );
	}

	/* because we deleted an entry, we need to check this index again */
	i--;
    }

    /* set this range to write combining */
    sentry.base = physical;
    sentry.size = bytes;
    sentry.type = 1; /* write-combining */

    if ( ioctl( mtrr, MTRRIOC_ADD_ENTRY, &sentry ) == -1 ) {
	mach64Error( "Error doing ioctl(2) on /proc/mtrr: %s\n",
		     strerror( errno ) );
	mach64Error( "MTRR not enabled\n" );
    } else {
	mach64Msg( 1, "MTRR enabled: write-combining, addr=0x%x size=0x%x\n",
		  sentry.base, sentry.size );
    }

#endif
}


static void MemoryBenchmark( void *buffer, int dwords )
{
    int		i;
    int		start, end;
    int		mb;
    int 	*base;

    base = (int *)buffer;

    start = usec();
    for ( i = 0 ; i < dwords ; i += 8 ) {
	base[i] =
	    base[i+1] =
	    base[i+2] =
	    base[i+3] =
	    base[i+4] =
	    base[i+5] =
	    base[i+6] =
	    base[i+7] = 0x15151515;		/* dmapad nops */
    }
    end = usec();

    mb = ( (float)dwords / 0x40000 ) * 1000000 / ( end - start );

    mach64Msg( 1, "MemoryBenchmark: %i mb/s\n", mb );

    /* make the last command a DWGSYNC for DmaBenchmark */
    dwords -= dwords % 5;
    base[dwords-5] = 0x15151593;
}

static void DmaBenchmark( unsigned int physical, int dwords )
{
    int		start, end;
    int		mb;
    float	fsec;
    mach64UI32	dmaEnd;

    mach64SetSyncBusy();

    /* only test a full quad of registers */
    dwords -= dwords % 5;

    dmaEnd = physical + dwords*4;
    start = usec();

#if 0 /* FIXME: GH */
    OUTREG( MACH64REG_PRIMADDRESS, physical );
    OUTREG( MACH64REG_PRIMEND, dmaEnd | use_agp);
#endif

    mach64WaitForDmaCompletion();

    end = usec();

    fsec = ( end - start ) / 1000000.0;

    mb = ( (float)dwords * 4 / 0x100000 ) / fsec;

    mach64Msg( 1, "DmaBenchmark 0x%x bytes, %5.3f sec: %i mb/s\n",
	       dwords*4, fsec, mb );
}

/*
 * VisualDmaTest
 * This will scroll a half meg image on the screen using dma
 */
static void VisualDmaTest( void )
{
#if 0 /* FIXME: GH */
    int		*dest, *destPtr;
    int		cmd;
    int		i, j, k, r, g, b;
    DMALOCALS;
    int		*test;

    test = malloc( 16*1024*1024 );

    /* start the primary commands */
    for ( j = 0 ; j < 1280-512 ; j += 5 )
    {
	dest = mach64AllocSecondaryBuffer( 512*256 );
	mach64glx.warp_serieStart = mach64AllocSecondaryBuffer(0);	// FIXME: do this better...

	/* fill in the secondary buffer */
	destPtr = dest;
        for ( i = 0 ; i < 512 ; i++ ) {
	    for ( k = 0 ; k < 256 ; k++ ) {
		int	pix;

		r = i * 255 / 512;
		g = k * 255 / 256;
		b = 128;
		pix = MACH64PACKCOLOR565(r,g,b) |
		    ( MACH64PACKCOLOR565(r,g,b) << 16 );
		*destPtr++ = pix;
	    }
	}


	/* XY destination, linear iload */
	cmd = DC_opcod_iload | 		/* image load */
	    DC_atype_rpl |			/* raster replace mode */
	    DC_linear_linear | 		/* linear source */
	    DC_bltmod_bfcol |		/* source data is pre-formatted color */
	    (0xC << DC_bop_SHIFT)  | 	/* use source bit op */
	    DC_sgnzero_enable |		/* normal scanning direction */
	    DC_shftzero_enable |	/* required for iload */
	    DC_clipdis_enable;		/* don't use the clip rect */

	for ( i = 0 ; i < 512 ; i+=20 ) {
	    MACH64DMAGETPTR( 20 );

	    MACH64DMA_YDSTLEN( i, 512 );	/* top to bottom */
	    MACH64DMA_FXBNDRY( j, 511+j );	/* full width */

	    DMAOUTREG( MACH64REG_AR0, 512 * 512 - 1); /* source pixel count */
	    DMAOUTREG( MACH64REG_AR3, 0 );	/* required */

	    /* pad if needed so the exec is at the end of a quad */
	    DMAOUTREG( MACH64REG_DMAPAD, 0 );
	    DMAOUTREG( MACH64REG_DMAPAD, 0 );
	    DMAOUTREG( MACH64REG_DMAPAD, 0 );

	    MACH64DMA_DWGCTL_EXEC(cmd);

	    DMAADVANCE();

	    /* send the secondary data */
	    mach64SecondaryDma( TT_BLIT, dest, 512*256 );
	}

	mach64DmaFlush();

	/* pound on memory some */
	for ( i = 0 ; i < 4*1024*1024 ; i++ ) {
	    test[i] = test[(i+2*1024*1024)&(4*1024*1024-1)];
	}
	//mach64FlushRealDma();
    }

    free( test );
#endif
}

/*
 * NonVisualDmaTest
 * Build up a half meg of dummy commands and send them to the card.
 */
static void NonVisualDmaTest( void )
{
    int		i, j, k;
    DMALOCALS;

    mach64Msg( 1, "Starting DMA test...\n" );

    for ( i = 0 ; i < 4 ; i++ )
    {
	for ( j = 0 ; j < 0x9f ; j++ )
	{
	    MACH64DMAGETPTR( 32 );

	    for ( k = 0 ; k < 4 ; k++ )
	    {
		/* Just send some dummy commands. */
		DMAOUTREG( MACH64REG_Z_CNTL,
			   Z_tst_disable | Z_test_zalways );
		DMAOUTREG( MACH64REG_ALPHA_TST_CNTL,
			   ALPHA_tst_disable | ALPHA_test_aalways );

		DMAOUTREG( MACH64REG_Z_CNTL,
			   Z_tst_disable | Z_test_znever );
		DMAOUTREG( MACH64REG_ALPHA_TST_CNTL,
			   ALPHA_tst_disable | ALPHA_test_anever );
	    }

	    DMAADVANCE();
	}

	//mach64DmaFlush();
    }

    mach64Msg( 1, "  table entries: %d buffer cmds: %d\n", dma_buffer->tableDwords / 4, dma_buffer->bufferDwords / 2 );

    for ( i = 0 ; i < dma_buffer->tableDwords / 4 ; i++ )
    {
	mach64Msg( 1, "    entry: %d addr: %p cmd: 0x%x\n", i, dma_buffer->virtualTable[4*i+1], dma_buffer->virtualTable[4*i+2] );
    }

    mach64Msg( 1, "Flushing buffers...\n" );
    mach64DmaFlush();
}


static void AllocateCardDmaBuffer( void )
{
    PMemBlock	block;

    bufferBytes = 0x100000;
    block = mmAllocMem( cardHeap, bufferBytes, 8, 0 );
    if ( !block ) {
	mach64Msg( 1, "failed to allocate 0x%x bytes from cardHeap for command buffers.\n",
		   bufferBytes );
	return;
    }
    mach64Msg( 1, "allocated 0x%x bytes from cardHeap for command buffers.\n",
	       bufferBytes );
    bufferVirtual = cardVirtual + mmOffset( block );
    bufferPhysical = cardPhysical + mmOffset( block );
}

static void AllocatePhysicalDmaBuffer( void )
{
    PMemBlock	block;

    /* determine total size of buffer */
    bufferBytes = mach64glx.cmdSize;
    if ( !bufferBytes ) {
	mach64Msg(1,"defaulting to GLX_MACH64_CMDSIZE = 4\n" );
	bufferBytes = 4;
    } else {
	mach64Msg(1,"using GLX_MACH64_CMDSIZE = %i\n", bufferBytes );
    }
    bufferBytes *= 0x100000;

    block = mmAllocMem( sysmemHeap, bufferBytes, 8, 0 );
    if ( !block ) {
	mach64Msg( 1, "failed to allocate 0x%x bytes from sysmemHeap for command buffers.\n",
		   bufferBytes );
	return;
    }
    mach64Msg( 1, "allocated 0x%x bytes from sysmemHeap for command buffers.\n",
	       bufferBytes );
    bufferVirtual = sysmemVirtual + mmOffset( block );
    bufferPhysical = sysmemPhysical + mmOffset( block );
}

static void AllocateVirtualDmaBuffer( void )
{
    /* determine total size of buffer */
    bufferBytes = mach64glx.cmdSize;
    if ( !bufferBytes ) {
	mach64Msg( 1, "defaulting to GLX_MACH64_CMDSIZE = 4\n" );
	bufferBytes = 4;
    } else {
	mach64Msg( 1, "using GLX_MACH64_CMDSIZE = %i\n", bufferBytes );
    }

    bufferBytes *= 0x100000;
    bufferVirtual = malloc( bufferBytes + 0x1000);
    /* align it to page size, might help on something used as much as this */
    bufferVirtual = (pointer)(((unsigned long) bufferVirtual & ~0xFFF) + 0x1000);
    mach64Msg( 1, "allocated 0x%x bytes from virtual memory for command buffers.\n",
	       bufferBytes );
}

static void OptimizeDMA( void )
{
#if 0 /* FIXME: GH */
    int		option;

    /* turn on enhmemacc */
    option = pcibusRead( mach64PciTag, 0x40 );
    pcibusWrite(mach64PciTag, 0x00000040, option | (1<<22) );
#endif
}


static int IsSDRAM( void )
{
#if 0 /* FIXME: GH */
    int		option;

    option = pcibusRead( mach64PciTag, 0x40 );
    if ( option & ( 1<<14 ) ) {
	mach64Msg( 1, "    SGRAM features enabled\n" );
	return 0;
    }
#endif
    return 1;
}



/*
 * AllocateCommandBuffers
 * The dma command buffers can be either virtual or in the sysmemHeap
 * I never got card allocated buffers functioning reliably...
 */
static void AllocateCommandBuffers( void )
{
    /* try to allocate the command buffers in either sysmem or cardmem */
    if ( mach64glx.dmaDriver > 0 ) {
	if ( mach64glx.cardCmds ) {
	    AllocateCardDmaBuffer();
	} else if ( sysmemHeap ) {
	    AllocatePhysicalDmaBuffer();
	}
    }

    /* if we didn't get real memory, get a virtual buffer and use PDMA */
    if ( !bufferPhysical ) {
	mach64glx.dmaDriver = 0;
	AllocateVirtualDmaBuffer();
    }

    if ( __glx_is_server )
    {
	/* benchmark the writing speed to the command buffer */
	MemoryBenchmark( bufferVirtual, bufferBytes / 4 );
	MemoryBenchmark( bufferVirtual, bufferBytes / 4 );

	/* benchmark the read speed of the card's dma */
	if ( mach64glx.dmaDriver >= 2 )
	{
	    DmaBenchmark( (unsigned int)bufferPhysical, bufferBytes / 4 );
	    DmaBenchmark( (unsigned int)bufferPhysical, bufferBytes / 4 );
	    DmaBenchmark( (unsigned int)bufferPhysical, bufferBytes / 4 );
	    DmaBenchmark( (unsigned int)bufferPhysical, bufferBytes / 4 );
	    DmaBenchmark( (unsigned int)bufferPhysical, bufferBytes / 4 );

	    if ( !use_agp )
	    {
		OptimizeDMA();
		DmaBenchmark( (unsigned int)bufferPhysical, bufferBytes / 4 );
		DmaBenchmark( (unsigned int)bufferPhysical, bufferBytes / 4 );
		DmaBenchmark( (unsigned int)bufferPhysical, bufferBytes / 4 );
		DmaBenchmark( (unsigned int)bufferPhysical, bufferBytes / 4 );
		DmaBenchmark( (unsigned int)bufferPhysical, bufferBytes / 4 );
	    }
	}
    }

    /* determine size of descriptor tables */
    tableBytes = mach64glx.tableSize;
    if ( !tableBytes ) {
	mach64Msg( 1, "defaulting to GLX_MACH64_TABLESIZE = 16\n" );
	tableBytes = 16;
    } else {
	mach64Msg( 1, "using GLX_MACH64_TABLESIZE = %i\n", tableBytes );
    }
    tableBytes *= 0x400;

    /* always leave enough room for a X server setup and DWGSYNC after
       overflow checks */

    /*
     * GH: It it critical that the tables are aligned to their size, ie. the
     * default 16k table should be 16k-aligned.  We should really enforce
     * this...
     */

    /* setup the two buffers that will be ping-ponged */
    dmaBuffers[0] = malloc( sizeof(mach64Dma_buffer) );
    memset( dmaBuffers[0], '\0', sizeof(mach64Dma_buffer) );

    dmaBuffers[0]->virtualTable = (mach64UI32 *)bufferVirtual;
    dmaBuffers[0]->physicalTable = bufferPhysical;
    dmaBuffers[0]->virtualBuffer = (mach64UI32 *)bufferVirtual + tableBytes / 4;
    dmaBuffers[0]->physicalBuffer = bufferPhysical + tableBytes;
    dmaBuffers[0]->maxTableDwords = tableBytes / 4;
    dmaBuffers[0]->maxBufferDwords = bufferBytes / 8 - dmaBuffers[0]->maxTableDwords;

    dmaBuffers[1] = malloc( sizeof(mach64Dma_buffer) );
    memset( dmaBuffers[1], '\0', sizeof(mach64Dma_buffer) );

    dmaBuffers[1]->virtualTable = (mach64UI32 *)bufferVirtual + bufferBytes / 8;
    dmaBuffers[1]->physicalTable = bufferPhysical + bufferBytes / 2;
    dmaBuffers[1]->virtualBuffer = (mach64UI32 *)bufferVirtual + bufferBytes / 8 + tableBytes / 4;
    dmaBuffers[1]->physicalBuffer = bufferPhysical + bufferBytes / 2 + tableBytes;
    dmaBuffers[1]->maxTableDwords = tableBytes / 4;
    dmaBuffers[1]->maxBufferDwords = bufferBytes / 8 - dmaBuffers[0]->maxTableDwords;

    mach64Msg( 1, "dmaBuffers[]->maxTableDwords = %i\n",
	       dmaBuffers[0]->maxTableDwords );
    mach64Msg( 1, "dmaBuffers[]->maxBufferDwords = %i\n",
	       dmaBuffers[0]->maxBufferDwords );

    mach64DmaResetBuffer();

    mmDumpMemInfo( sysmemHeap );
}


#if 0 /* FIXME: GH */
/*
 * AllocateGARTMemory
 */
static int AllocateGARTMemory( size_t size )
{
    int i, j, k, m, pages = (size + 4095) / 4096;
    struct gart_entry entry;

    gartfd = open("/dev/gart", O_RDWR);
    if (gartfd == -1)
    {
	mach64Msg(1, "unable to open /dev/gart: %s\n", sys_errlist[errno]);
	return -1;
    }

    if (ioctl(gartfd, GARTIOCINFO, &gartinf) != 0)
    {
	mach64Msg(1, "error doing ioctl(GARTIOCINFO): %s\n", sys_errlist[errno]);
	mach64Msg(1, "first attempt\n");
	close(gartfd);
	return -1;
    }

    gartbuf = mmap(NULL, gartinf.size * 0x100000, PROT_READ | PROT_WRITE, MAP_SHARED, gartfd, 0);
    if (gartbuf == (void *)0xffffffff)
    {
	mach64Msg(1, "mmap() on /dev/gart failed: %s\n", sys_errlist[errno]);
	close(gartfd);
	return -1;
    }

    if (__glx_is_server)
    {
        if(ioctl(gartfd, GARTIOCINIT) != 0)
	{
	    mach64Msg(1, "Error initializing AGP point to point connection\n");
	    close(gartfd);
	    return -1;
	}
        /* Call information function a second time for the agp mode */

        if (ioctl(gartfd, GARTIOCINFO, &gartinf) != 0)
	{
	    mach64Msg(1, "error doing ioctl(GARTIOCINFO): %s\n", sys_errlist[errno]);
	    mach64Msg(1, "second attempt\n");

	    close(gartfd);
	    return -1;
	}
        if(gartinf.mode == AGP_MODE2X && !MACH64_IS_G400(MACH64chipset))
	{
	    mach64Msg(1, "enabling agp 2x pll encoding\n");
	    OUTREG(MACH64REG_AGP_PLL, AGP_PLL_agp2xpllen_enable);
	}
    }
    else
    {
	return 0;
    }

    i = pages / 1024;
    j = pages % 1024;
    for(k = 0; k < i; k++)
    {
        entry.ofs = k * 1024;
        entry.size = 1024;
        if(ioctl(gartfd, GARTIOCINSERT, &entry))
	{
	    /* free previous pages */

	    for(m = 0; m < k; m++)
	    {
		entry.ofs = m * 1024;
		entry.size = 1024;
		ioctl(gartfd, GARTIOCREMOVE, &entry);
	    }

	    mach64Msg(1, "GART: allocation of %i pages failed\n", pages);
	}
    }
    if(j != 0)
    {
        entry.ofs = (i + 1) * 1024;
        entry.size = j;
        if(ioctl(gartfd, GARTIOCINSERT, &entry))
	{
	    /* free previous pages */
	    for(m = 0; m < i; m++)
	    {
		entry.ofs = m * 1024;
		entry.size = 1024;
		ioctl(gartfd, GARTIOCREMOVE, &entry);
	    }

	    mach64Msg(1, "GART: allocation of %i pages failed\n", pages);
	}
    }

    return 0;
}
#endif


/*
 * AllocateSystemMemory
 * Looks at environment variables to determine if a block
 * of physical memory has been left for graphics after the
 * memory available to the kernel.
 * System memory can be used for dma command buffers or
 * textures.
 */
static void AllocateSystemMemory( void )
{
    int		fd;
    char	*adr;

    sysmemPhysical = 0;
    sysmemVirtual = 0;
    sysmemHeap = 0;

    if ( !mach64glx.dmaDriver ) {
	return;
    }

    /* determine total requested size of buffer */
    sysmemBytes = mach64glx.dmaSize;
    if ( !sysmemBytes ) {
	mach64Msg( 1, "GLX_MACH64_DMASIZE not set, skipping physical allocation\n" );
	return;
    }
    sysmemBytes *= 0x100000;

    /* try AGP memory */
    adr = getenv( "GLX_MACH64_DMAADR" );
    if ( adr && !strcasecmp( adr, "AGP" ) )
    {
#if 0 /* FIXME: GH */
	if ( !AllocateGARTMemory( sysmemBytes ) )
	{
	    sysmemPhysical = gartinf.physical;
	    sysmemVirtual = (unsigned char *)gartbuf;
	    sysmemHeap = mmInit( sysmemBytes );

	    mach64Msg( 1, "AGP Aperture: %p\n", sysmemPhysical );
	    mach64Msg( 1, "sysmemSize: %p\n", sysmemBytes );

	    use_agp = PDEA_pagpxfer_enable /* | PDEA_primnostart_enable */ ;
	    mach64Msg(1, "use_agp = %x\n", use_agp);
	    return;
	}
	mach64Msg(1, "AllocateGARTMemory failed.\n" );
	return;
#endif
    }

    /* mach64glx.dmaDriverADR should be set to a value >= the
       mem= kernel parm */
    sysmemPhysical = mach64glx.dmaAdr;
    if ( sysmemPhysical < 16 ) {
	mach64Msg( 1, "unlikely GLX_MACH64_DMAADR=%i, skipping physical allocation\n", bufferPhysical );
	return;
    }
    sysmemPhysical *= 0x100000;



    /* FIXME!!!: should check sysmemPhysical against /proc/meminfo */

    fd = open( "/dev/mem", O_RDWR );
    if ( fd < 0 ) {
	mach64Msg( 1, "failed to open /dev/mem\n" );
	return;
    }

    sysmemVirtual = (unsigned char *)
	mmap( NULL, sysmemBytes, PROT_READ | PROT_WRITE,
	      MAP_SHARED, fd, (off_t)sysmemPhysical );
    if ( sysmemVirtual == MAP_FAILED ) {
	mach64Msg( 1, "failed to mmap sysmem\n" );
	close( fd );
	return;
    }

    /* FIXME: should verify the memory exists with read / write test */

    /* set to write combining */
    if ( __glx_is_server )
    {
 	/* due to MTRR fragmentation issues, we can't do this for all
           memory ranges - except on the K6... */
  	if ( IsPowerOfTwo( sysmemPhysical ) ||
	     ( gl_identify_x86_cpu_features() & GL_CPU_3Dnow ) )
	{
	    mach64Msg( 1, "Setting write combining on system heap.\n" );
	    SetWriteCombining( sysmemPhysical, sysmemBytes );
  	}
	else
	{
	    mach64Msg( 1, "Can't set write combining on system heap, not power of two.\n" );
  	}
    }

    /* create a heap */
    sysmemHeap = mmInit( sysmemBytes );

    mach64Msg( 1, "sysmemPhysical: %p\n", sysmemPhysical );
    mach64Msg( 1, "sysmemVirtual: %p\n", sysmemVirtual );
    mach64Msg( 1, "sysmemSize: %p\n", sysmemBytes );

}

/*
 * ChooseTextureHeap
 * Determine if textures should be stored in the cardHeap or the
 * sysmemHeap.
 */
static void ChooseTextureHeap( void )
{
    /* share textures on the card memory until proven otherwise */
    textureHeap = cardHeap;
    textureHeapVirtual = (unsigned char *)mach64LinearBase;
    textureHeapPhysical = 0;

    /* if we don't have a system memory heap, textures MUST be on the card */
    if ( !sysmemHeap ) {
	mach64Msg( 1, "No sysmemHeap, textures must be stored on card\n" );
	return;
    }

    /* see if we should use the system heap for textures or just dma commands */
    if ( !mach64glx.systemTexture ) {
	mach64Msg( 1, "GLX_MACH64_SYSTEMTEXTURE not set, textures will be stored on card\n" );
	return;
    }

    /* make sure there is some memory left for textures */
    if ( sysmemBytes < bufferBytes + 1024*1024 ) {
	mach64Msg( 1, "sysmemBytes < bufferBytes + 1meg, textures will be stored on card\n" );
	return;
    }

    textureHeap = sysmemHeap;
    textureHeapVirtual = sysmemVirtual;
    textureHeapPhysical = sysmemPhysical;

    mach64Msg( 1, "Texturing from sysmemHeap\n" );
}


/*
 * mach64DmaInit
 *
*/
void mach64DmaInit(void)
{
#if 0 /* FIXME: GH */
    mach64UI32 devctrl;
#endif

    /* Server init - queries environment variables.  The client
     * gets these values from the sever and initializes them in
     * mach64direct.c
     */
    if ( __glx_is_server )
    {
	mach64glx.dmaDriver = atoi( getenvSafe("GLX_MACH64_DMA") );
	mach64glx.dmaSize = atoi( getenvSafe("GLX_MACH64_DMASIZE") );
	mach64glx.dmaAdr = atoi( getenvSafe("GLX_MACH64_DMAADR") );
	mach64glx.cmdSize = atoi( getenvSafe("GLX_MACH64_CMDSIZE") );
	mach64glx.cardCmds = atoi( getenvSafe("GLX_MACH64_CARDCMDS") );
	mach64glx.systemTexture = atoi( getenvSafe("GLX_MACH64_SYSTEMTEXTURE") );
	mach64glx.tableSize = atoi( getenvSafe("GLX_MACH64_TABLESIZE") );
    }


#if 0 /* FIXME: GH */
    devctrl = pcibusRead( mach64PciTag, 0x04 );
    mach64Msg( 1, "devctrl = %08x\n", devctrl );
#endif

    use_agp = 0;

    if ( __glx_is_server )
    {
	/* prepare to set write combining */
	mach64OpenMTRR();

	/* set write combining on the framebuffer */
	SetWriteCombining( mach64InfoRec.physBase, mach64InfoRec.physSize );
    }

    /* get some system memory and make it write combining if we can */
    AllocateSystemMemory();

#if 0 /* FIXME: GH */
    /* set up the matrox pdma memory window */
    MapPseudoDmaWindow();
#endif

    /* read the command environment variable */
    mach64Msg( 1, "mach64DmaInit: GLX_MACH64_DMA = %i\n", mach64glx.dmaDriver );

    /* setup the two command buffers in the apropriate memory space */
    AllocateCommandBuffers();

    /* check for using a PCI texture heap */
    ChooseTextureHeap();

    /* prepare the first buffer for use */
    mach64DmaResetBuffer();
}

/*
 * CreateFrontBuffer
 * Called during initialization to set up parameters needed
 * for the swapbuffers blit.
 */
static mach64BufferPtr CreateFrontBuffer( void )
{
    int			Attrib;
    mach64BufferPtr	buf;

    switch ( mach64InfoRec.depth )
    {
    case 15:
	Attrib = MACH64_PF_555;
	break;
    case 16:
	Attrib = MACH64_PF_565;
	break;
    case 24:
	if ( mach64BitsPerPixel == 24 ) {
	    Attrib = MACH64_PF_888;	/* we can't render to this, but we can blit to it */
	} else {
	    Attrib = MACH64_PF_8888;
	}
	break;
    default:
	mach64Error( "No support for %d bits per pixel.\n",
		     mach64BitsPerPixel );
	return NULL;
    }

    buf = mach64CreatePrimaryBuffer( Attrib,
				     mach64InfoRec.virtualX,
				     mach64InfoRec.virtualY,
				     mach64InfoRec.displayWidth );

    /* enable hardware dithering in 16 bit modes */
    switch ( Attrib & MACH64_PF_MASK )
    {
    case MACH64_PF_555:
    case MACH64_PF_565:
#if 0 /* FIXME: GH */
	buf->Setup[MACH64_SETUP_MACCESS] |= MA_dit555_enable |
	    MA_nodither_enable; /* xf86 default */
#endif
	break;
    }
    buf->Setup[MACH64_SETUP_CXBNDRY] = 0x0fff0000;
    buf->Setup[MACH64_SETUP_YTOP] = 0;
    buf->Setup[MACH64_SETUP_YBOT] = 0x00ffffff;
    return buf;
}

/*
 * mach64ScratchRegTest
 *
 * Do a simple read/write test to the Mach64's scratch registers.  Defined
 * in the mach64 Programmer's Guide.
 */
void mach64ScratchRegTest()
{
    int		tmp;

    tmp = INREG( MACH64REG_SCRATCH_REG0 );
    OUTREG( MACH64REG_SCRATCH_REG0, 0x55555555 );

    if ( INREG( MACH64REG_SCRATCH_REG0 ) != 0x55555555 )
    {
	mach64Error( "Mach64 probe failed on read 1 of SCRATCH_REG0 %x\n",
		     MACH64REG_SCRATCH_REG0 );
    }
    else
    {
	mach64Msg( 1, "SCRATCH_REG0 read 1 successful\n" );

	OUTREG( MACH64REG_SCRATCH_REG0, 0xaaaaaaaa );

	if ( INREG( MACH64REG_SCRATCH_REG0 ) != 0xaaaaaaaa ) {
	    mach64Error( "Mach64 probe failed on read 2 of SCRATCH_REG0 %x\n",
			 MACH64REG_SCRATCH_REG0 );
	} else {
	    mach64Msg( 1, "SCRATCH_REG0 read 2 successful\n" );
	}
    }

    OUTREG( MACH64REG_SCRATCH_REG0, tmp );
}

/*
 * This function should only verify that the current hardware is supported.
 * It should do no setup. As we support various Matrox chipsets, perhaps it
 * should return an indicator of which chipset is present.
 */
GLboolean det_hwGfx()
{
    mach64Msg( 1, "Detected 0x%x Chip ID\n", mach64ChipType );

    /* is this the best way check for mach64 presence? */
    if ( !MACH64_IS_RAGEPRO( mach64ChipType ) ) {
	mach64Error( "mach64ChipType not set, no mach64 hardware?\n" );
	return GL_FALSE;
    }

    /* FIXME: implement support for other depths... */
    if( ( mach64InfoRec.depth != 15 ) &&
	( mach64InfoRec.depth != 16 ) &&
	( mach64InfoRec.depth != 24 ) )
    {
	mach64Error( "Unsupported depth: %d, only 15,16, and 24 bpp are supported right now\n",
		     mach64InfoRec.depth );
	return GL_FALSE;
    }

    return GL_TRUE;
}

/*
 * mach64InitLogging
 *
 */
void mach64InitLogging( void )
{
    char	*logName;

    /* open the logfile and set loglevel */
    logName = getenv( "GLX_MACH64_LOGFILE" );
    if ( __glx_is_server )
    {
	mach64OpenLog( logName );
    }
    else
    {
	/* direct rendering clients use a different file
	   so they don't stomp on the server's log */
	if ( logName )
	{
	    char	newName[1024];

	    strcpy( newName, logName );
	    strcat( newName, "_direct" );
	    mach64OpenLog( newName );
	}
    }

    if ( getenv( "GLX_MACH64_LOGLEVEL" ) ) {
	mach64SetLogLevel( atoi( getenv( "GLX_MACH64_LOGLEVEL" ) ) );
    } else {
	mach64SetLogLevel( DBG_LEVEL_BASE );
    }
}


/*
 * mach64DumpRegisters
 */
void mach64DumpRegisters( void )
{
#if 0 /* FIXME: GH */
    int		i, r;

    mach64Msg( 1, "Configuration registers:\n" );
    for ( i = 0 ; i < 256 ; i+=4 ) {
	r = pcibusRead( mach64PciTag, i );
	mach64Msg(1, "0x%2x : 0x%8x\n", i, r );
    }

    mach64Msg(1, "Drawing registers:\n" );
    for ( i = 0x1c00 ; i < 0x1dff ; i+= 4 ) {
	r = INREG( i );
	mach64Msg(1, "0x%2x : 0x%8x\n", i, r );
    }
    for ( i = 0x2180 ; i < 0x2dff ; i+= 4 ) {
	r = INREG( i );
	mach64Msg(1, "0x%2x : 0x%8x\n", i, r );
    }
#endif
}

/*
 * mach64InitGLX
 * This is the initial entry point for the mach64 hardware driver,
 * called at X server module load time, or libGL direct rendering
 * init time.
 */
GLboolean mach64InitGLX( void )
{
    /*
     * Set up our linear aperture pointers now.  This is an attempt to
     * make the mach64 GLX module a little more similar to the G200 one.
     * We have to be a little fancy about calculating the register mapping,
     * as the standard X server doesn't know about the 3D acceleration
     * registers.
     *
     * mach64LinearBase == vgaLinearBase, the main aperture
     * mach64MMIOBase == MGAMMIOBase, the memory-mapped registers
     */
    mach64LinearBase = mach64VideoMem;
    mach64MMIOBase = mach64MemRegMap;
    mach64BitsPerPixel = mach64InfoRec.depth;

    /*
     * Begin usual GLX module initialization.
     */
    mach64InitLogging();

    mach64Msg( 1, "virtual (x, y) (%d, %d)\n",
	       mach64InfoRec.virtualX, mach64InfoRec.virtualY );
    mach64Msg( 1, "width: %d\n", mach64InfoRec.displayWidth );
    mach64Msg( 1, "depth: %d\n", mach64InfoRec.depth );
    mach64Msg( 1, "memBase: 0x%08x\n", mach64LinearBase );
    mach64Msg( 1, "videoRam: 0x%08x\n", mach64InfoRec.videoRam );

    mach64Msg( 1, "registers bank0: 0x%08x bank1: 0x%8x\n",
	       mach64MMIOBase + 0x400, mach64MMIOBase );

    /* Perform a quick register read/write test. */
    mach64ScratchRegTest();

    /* Enable the block 1 registers. */
    MACH64_WAITFREE();
    OUTREG( MACH64REG_BUS_CNTL,
	    INREG( MACH64REG_BUS_CNTL ) | BUS_ext_reg_enable );

    /* check to make sure that we are on an apropriate chip and not
       running in 8bpp mode */
    if ( !det_hwGfx() ) {
	return GL_FALSE;
    }

    /* start up our card memory manager */
    cardHeap = mmInit( mach64InfoRec.videoRam * 1024 );
    if ( !cardHeap ) {
	mach64Msg( 1, "cardHeap creation failed, exiting!\n" );
	return GL_FALSE;	/* really shouldn't happen */
    }
    cardPhysical = (mach64UI32) mach64InfoRec.physBase;
    cardVirtual = (unsigned char *)mach64LinearBase;

    /* reserve memory used by the desktop screen and set up
       some hardware acceleration values needed to draw to it */
    mach64FrontBuffer = CreateFrontBuffer();
    if ( !mach64FrontBuffer) {
	mach64Error( "Cannot create front buffer.\n" );
	return GL_FALSE;	/* really shouldn't happen */
    }

    /* reserve memory for the second bank of memory mapped registers */
    mmReserveMem( cardHeap, (mach64InfoRec.videoRam-1) * 1024, 1024 );

#if 0 /* FIXME: GH */
    /* reserve memory X uses for pixmap acceleration */
    mmReserveMem( cardHeap, xf86AccelInfoRec.PixmapCacheMemoryStart,
		  xf86AccelInfoRec.PixmapCacheMemoryEnd -
		  xf86AccelInfoRec.PixmapCacheMemoryStart);
#endif

#if 0 /* FIXME: GH */
    /* reserve last 1KB if hardware cursor is active*/
    if (MACH64dac.isHwCursor) {
	mmReserveMem( cardHeap, (mach64InfoRec.videoRam-1)*1024,1024);
    }
#endif
    /* the remaining memory is available for back buffers, depth
       buffers, and textures */
    mmDumpMemInfo( cardHeap );

    /* init the dma system */
    mach64DmaInit();


    /* FIXME: what other GLXProcs pointers should we change? */
    GLXProcs.CreateContext = mach64GLXCreateContext;
    GLXProcs.DestroyContext = mach64GLXDestroyContext;
    GLXProcs.SwapBuffers = mach64GLXSwapBuffers;
    GLXProcs.CreateImage = mach64GLXCreateImage;
    GLXProcs.DestroyImage = mach64GLXDestroyImage;
    GLXProcs.CreateDepthBuffer = mach64GLXCreateDepthBuffer;
    GLXProcs.MakeCurrent = mach64GLXMakeCurrent;
    GLXProcs.BindBuffer = mach64GLXBindBuffer;
    GLXProcs.SwapBuffers = mach64GLXSwapBuffers;
#if 0 /* FIXME: GH */
    GLXProcs.VendorPrivate = mach64GLXVendorPrivate;
    GLXProcs.AllowDirect = mach64GLXAllowDirect;
#endif

    if ( !__glx_is_server ) {
#if 0 /* FIXME: GH */
	GLXProcs.ValidateFrontBuffer = mach64ClientGetGeometry;
#endif
    }

    /* these vars can be changed between invocations of direct clients */
    if ( getenv("GLX_MACH64_NULLPRIMS") ) {
	mach64Msg( 1, "enabling GLX_MACH64_NULLPRIMS\n" );
	mach64glx.nullprims = 1;
    }
    if ( getenv("GLX_MACH64_SKIPDMA") ) {
	mach64Msg( 1, "enabling GLX_MACH64_SKIPDMA\n" );
	mach64glx.skipDma = 1;
    }
    if ( getenv("GLX_MACH64_BOXES") ) {
	mach64Msg( 1, "enabling GLX_MACH64_BOXES\n" );
	mach64glx.boxes = 1;
    }
    if ( getenv("GLX_MACH64_NOFALLBACK") ) {
	mach64Msg( 1, "enabling GLX_MACH64_NOFALLBACK\n" );
	mach64glx.noFallback = 1;
    }
    if ( getenv("GLX_MACH64_NOSGRAM") || IsSDRAM() ) {
	mach64Msg( 1, "enabling GLX_MACH64_NOSGRAM\n" );
	mach64glx.nosgram = 1;
    }

    /* test by blitting to screen */
    //VisualDmaTest();

    /* test by dumping commands to card */
    if ( getenv("GLX_MACH64_DMATEST") ) {
	NonVisualDmaTest();
    }

    //mach64DumpRegisters();

    mach64Error( "mach64InitGLX completed\n" );
    return GL_TRUE;
}


/*
 * Local Variables:
 * mode: c
 * c-basic-offset: 4
 * End:
 */
