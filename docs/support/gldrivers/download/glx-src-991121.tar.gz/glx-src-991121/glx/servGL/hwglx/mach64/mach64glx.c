/* $Id: mach64glx.c,v 1.1 1999/10/28 03:43:47 gareth Exp $ */

/*
 * GLX Hardware Device Driver for ATI Rage Pro
 * Copyright (C) 1999 Gareth Hughes
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * WITTAWAT YAMWONG, OR ANY OTHER CONTRIBUTORS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE
 * OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * Based on MGA driver: mgaglx.c 1.6
 *
 *    Gareth Hughes <garethh@bell-labs.com>
 */

#include <stdlib.h>

#include "context.h"
#include "depth.h"
#include "macros.h"
#include "texstate.h"
#include "triangle.h"
#include "vb.h"
#include "types.h"

#include "xsmesaP.h"
#include "glx_log.h"
#include "mesaglx/context.h"
#include "mesaglx/matrix.h"
#include "mesaglx/types.h"

#define GC XXGC
#include "gcstruct.h"
#include "pixmapstr.h"
#include "servermd.h" /* PixmapBytePad */
#include "scrnintstr.h"
#include "regionstr.h"
#include "windowstr.h"
#undef GC

#include "vga.h"
#include "vgaPCI.h"
#include "mach64.h"
#include "xaa/xf86xaa.h"

#include "mm.h"
#include "mach64buf.h"
#include "mach64dd.h"
#include "rage_mac.h"
#include "mach64lib.h"
#include "mach64log.h"
#if 0 /* FIXME: GH */
#include "mach64direct.h"
#endif

extern int		xf86VTSema;
extern XSMesaContext	XSMesa;

/* our collected globals */
mach64Glx_t	mach64glx;

/* our linear aperture and two-bank memory mapped registers */
pointer 	mach64LinearBase;
pointer 	mach64MMIOBase;
int		mach64BitsPerPixel;


static void mach64ServerSwapBuffers( XSMesaBuffer b );

void (*mach64GLXSwapBuffers)(XSMesaBuffer b) = mach64ServerSwapBuffers;


/* are these for the multi-hardware glx support? */
GLboolean (*hwInitGLX)() = mach64InitGLX;
GLboolean (*hwInitVisuals)( VisualPtr *, DepthPtr *, int *, int *,
			    int *, VisualID *, unsigned long, int ) = NULL;

void mach64DumpDB( mach64BufferPtr buf )
{
    /*int i;*/

    mmDumpMemInfo( cardHeap );
    mach64Msg( 1, "Dump DB:\n" );
    mach64Msg( 1, "  %s %s\n",
	       ( buf->Drawable ) ? "Drawable" : "-",
	       ( buf->HasZORG ) ? "HasZORG" : "-" );
    /*
    for ( i = 0 ; i < sizeof(buf->Setup) / sizeof(mach64UI32) ; i++ ) {
	mach64Msg( 1, "  %d: 0x%08x\n", i, buf->Setup[i] );
    }
    */
    mach64Msg( 1, "  w,h,p = %d,%d,%d\n",
	       buf->Width, buf->Height, buf->Pitch );
    mach64Msg( 1, "End Dump DB\n" );
}

void mach64GLXCreateDepthBuffer( GLcontext* ctx )
{
    XSMesaContext	xsmesa = (XSMesaContext) ctx->DriverCtx;
    mach64BufferPtr	buf, zb = 0;

    mach64Msg( 1, "mach64GLXCreateDepthBuffer\n" );

    /* deallocate current depth buffer if present */
    if ( ctx->Buffer->Depth )
    {
	free( ctx->Buffer->Depth );
	ctx->Buffer->Depth = NULL;
    }

    if ( ( xsmesa->xsm_buffer->db_state == BACK_XIMAGE ) &&
	 ( ( buf = (mach64BufferPtr)
	         xsmesa->xsm_buffer->backimage->devPriv ) != 0 ) )
    {
#if DEPTH_BITS==16
	zb = mach64AttachZBuffer( buf, NULL, MACH64_ZBUFFER16 );
#elif DEPTH_BITS==32
	zb = mach64AttachZBuffer( buf, NULL, MACH64_ZBUFFER32 );
#endif
	if ( !zb )
	{
	    /* We need a depth buffer, but cannot allocate it. So, disable
	       hardware acceleration. */
	    buf->Drawable = 0;
	    mach64Error( "mach64GLXCreateDepthBuffer(): mach64AttachZBuffer() failed!\n" );
	}
	if ( mach64glx.logLevel >= 1 )  {
	    mach64DumpDB( buf );
	}
    }
    /* allocate new depth buffer, but don't initialize it */
    /* FIXME: we shouldn't need to do this if we got a hardware buffer */
    ctx->Buffer->Depth = (GLdepth *)
	malloc( ctx->Buffer->Width * ctx->Buffer->Height * sizeof(GLdepth) );
    if ( !ctx->Buffer->Depth )
    {
	/* out of memory */
	ctx->Depth.Test = GL_FALSE;
	mach64Error( "Couldn't allocate depth buffer\n" );
    }
}

/*
 * mach64GLXDestroyImage
 */
void mach64GLXDestroyImage( GLXImage* image )
{
    if ( image->devPriv )
    {
	mach64DestroyBuffer( (mach64BufferPtr)image->devPriv );
	if ( mach64glx.logLevel >= 10 )  {
	    mmDumpMemInfo( cardHeap );
	}
    }
    else if ( image->data )
    {
	free( image->data );
    }

    xfree( image );
}

/*
 * mach64GLXCreateImage
 * We can't accelerate rendering to images
 */
GLXImage *mach64GLXCreateImage( WindowPtr pwindow, int depth,
				int width, int height )
{
    int			Attrib;
    mach64BufferPtr	buf;
    GLXImage		*image = (GLXImage *) xalloc( sizeof(GLXImage) );

    if ( !image ) {
	return ( NULL );
    }
    image->pwin = pwindow;
    image->width = width;
    image->height = height;
    image->bits_per_pixel = depth;
    image->data = 0;
    image->devPriv = NULL;

    Attrib = -1;

    switch ( depth )
    {
    case 8:
	Attrib = MACH64_PF_INDEX;
	break;
    case 15:
	Attrib = MACH64_PF_555;
	break;
    case 16:
	Attrib = MACH64_PF_565;
	break;
    case 24:	/* we can't render into a 24 bit image, so use a 32 bit one */
    case 32:
	Attrib = MACH64_PF_8888;
	break;
    default:
	mach64Error( "Unknown width in GLXCreateImage\n" );
	break;
    }

    if ( Attrib != -1 ) {
	buf = mach64CreateBuffer( Attrib | MACH64_COLORBUFFER,
				  0, width, height, 0 );
    } else {
	buf = NULL;
    }

    image->devPriv = (void *) buf;
    if ( !image->devPriv )
    {
	image->bytes_per_line = PixmapBytePad( width, depth );
	image->data = (char *) malloc( image->height * image->bytes_per_line );
	if ( !image->data ) {
	    mach64Error( "mach64GLXCreateImage: malloc failed." );
	    xfree( image );
	    image = NULL;
	}
    }
    else
    {
	buf->refcount++;
	image->bytes_per_line = buf->Pitch * buf->BytesPerPixel;
	/* How can I draw XImage with any line pad? */
	/* e.g. bytes_per_line != PixmapBytePad */
	/* My work around: adjust width instead */
	image->width = buf->Pitch;
	image->data = buf->BufAddr;
	if ( mach64glx.logLevel >= 1 )  {
	    mmDumpMemInfo( cardHeap );
	}
    }
    return image;
}


/*
 * mach64BackToFront24
 * Special code to blit from a 32 bit back buffer to a 24 bit depth buffer
 */
static int mach64BackToFront24( DrawablePtr drawable, mach64BufferPtr buf )
{
    RegionPtr	prgnClip;
    BoxPtr	pbox;
    int 	i, nbox;
    int 	xorg, yorg, pitch;
    DMALOCALS;

    prgnClip = &((WindowPtr)drawable)->clipList;
    pbox = REGION_RECTS( prgnClip );
    nbox = REGION_NUM_RECTS( prgnClip );
    if( !nbox ) {
	/* window is completely covered */
	return Success;
    }

    xorg = drawable->x;
    yorg = drawable->y;
    pitch = buf->Pitch;

    /* get out of 3D mode for the blit */
    mach64DmaExecute( mach64FrontBuffer->Setup, mach64FrontBuffer->SetupSize );

    /* This is handled by the flush */
    /*mach64glx.needEnter3D = 1;*/
    fprintf( stderr, "needEnter3D in mach64BackToFront24\n" );

    /* add the blit commands to the dma buffer */
    MACH64DMAGETPTR( 8000 );

#if 0 /* FIXME: GH */
    /* we are going to treat the buffers as 8bpp and copy three pixel
       wide strips to move the 24 bit rgb values.  */
    MACH64DMA_DSTORG(mach64FrontBuffer->Setup[MACH64_SETUP_DSTORG]);
    MACH64DMA_MACCESS(0);	/* 8bpp */
    MACH64DMA_PITCH( mach64FrontBuffer->Pitch * 3 );

    MACH64DMA_SRCORG(buf->Setup[MACH64_SETUP_DSTORG]);
    DMAOUTREG(MACH64REG_AR5,pitch * 4);

    MACH64DMA_DWGCTL(DC_opcod_bitblt | DC_atype_rpl | DC_linear_xy |
		     DC_solid_disable | DC_arzero_disable | DC_sgnzero_enable |
		     DC_shftzero_enable | (0xC << DC_bop_SHIFT) | DC_bltmod_bfcol |
		     DC_pattern_disable | DC_transc_disable | DC_clipdis_disable);

    /* xy bitblt each visible rectangle */
    for (i=nbox; i > 0; i--)
    {
	int	c;
	int	x = pbox->x1 - xorg;
	int	y = pbox->y1 - yorg;
	int	src;
	int	dest;

	dest = pbox->x1 * 3;
	src = ( x + y*pitch ) * 4;
	for ( c = pbox->x1 ; c < pbox->x2 ; c++ ) {
	    DMAOUTREG(MACH64REG_AR0,src + 2);
	    DMAOUTREG(MACH64REG_AR3,src);
	    MACH64DMA_FXBNDRY( dest, dest+2 );
	    MACH64DMA_YDSTLEN_EXEC(pbox->y1, pbox->y2 - pbox->y1 );
	    src += 4;
	    dest += 3;
	}
	pbox++;
    }

    MACH64DMA_SRCORG(0);
#endif
    DMAADVANCE();

    return Success;
}

/*
 * mach64BackToFront
 * Blit the visible rectangles from the back buffer to the screen
 * Can't really do this from a direct context - don't have the clip
 * info, and getting it would be a lot slower than just sending a
 * request to the server to do the blit there.
 */
int mach64BackToFront( DrawablePtr drawable, mach64BufferPtr buf )
{
    RegionPtr	prgnClip;
    BoxPtr	pbox;
    int 	i, nbox;
    int 	xorg, yorg, pitch;
    DMALOCALS;

    if ( !VALID_MACH64_BUFFER( buf ) ) {
	mach64Error( "BackToFront(): invalid back buffer\n" );
	return BadMatch;
    }
    if ( !VALID_MACH64_BUFFER( mach64FrontBuffer ) ) {
	mach64Error( "BackToFront(): invalid mach64FrontBuffer\n" );
	return BadMatch;
    }
    if ( !xf86VTSema ) {
	mach64Error( "BackToFront(): !xf86VTSema\n" );
	return BadMatch;	/* Is this really an error? */
    }
    if ( ( drawable->width != buf->Width ) ||
	 ( drawable->height != buf->Height ) ||
	 ( drawable->type != DRAWABLE_WINDOW ) )
    {
	mach64Error( "BackToFront(): bad drawable\n" );
	return BadMatch;
    }

    /* 24 bit case is a seperate hack */
    if ( mach64BitsPerPixel == 24 ) {
	return mach64BackToFront24( drawable, buf );
    }
    prgnClip = &((WindowPtr)drawable)->clipList;
    pbox = REGION_RECTS( prgnClip );
    nbox = REGION_NUM_RECTS( prgnClip );
    if( !nbox ) {
	/* window is completely covered */
	return Success;
    }

    xorg = drawable->x;
    yorg = drawable->y;
    pitch = buf->Pitch;
    /* get out of 3D mode for the blit */
    mach64DmaExecute( mach64FrontBuffer->Setup, mach64FrontBuffer->SetupSize );

    /* This will always be taken care of by mach64DmaFlush... */
    /*mach64glx.needEnter3D = 1;*/

    if ( MESA_VERBOSE & VERBOSE_DRIVER ) {
	fprintf( stderr, "needEnter3D in mach64BackToFront\n" );
    }

    /* add the blit commands to the dma buffer */
    MACH64DMAGETPTR( 10 + 10 * nbox );

#if 0 /* FIXME: GH */
    MACH64DMA_DSTORG(mach64FrontBuffer->Setup[MACH64_SETUP_DSTORG]);
    MACH64DMA_SRCORG(buf->Setup[MACH64_SETUP_DSTORG]);
    DMAOUTREG(MACH64REG_AR5,pitch);
    MACH64DMA_DWGCTL(DC_opcod_bitblt | DC_atype_rpl | DC_linear_xy |
		     DC_solid_disable | DC_arzero_disable | DC_sgnzero_enable |
		     DC_shftzero_enable | (0xC << DC_bop_SHIFT) | DC_bltmod_bfcol |
		     DC_pattern_disable | DC_transc_disable | DC_clipdis_disable);

    /* xy bitblt each visible rectangle */
    for (i=nbox; i > 0; i--)
    {
	int	x = pbox->x1 - xorg;
	int	y = pbox->y1 - yorg;
	int	w = pbox->x2 - pbox->x1;
	int	h = pbox->y2 - pbox->y1;
	int	start = x + y*pitch;

	DMAOUTREG(MACH64REG_AR0,start + w - 1);
	DMAOUTREG(MACH64REG_AR3,start);

	MACH64DMA_FXBNDRY(pbox->x1,pbox->x2-1);
	MACH64DMA_YDSTLEN_EXEC(pbox->y1,h);
	pbox++;
    }

    MACH64DMA_SRCORG(0);
#endif
    DMAADVANCE();

    return Success;
}


/*
 * ClearBox
 * Add hardware commands to draw a filled box for the
 * debugging display.
 */
static void ClearBox( int x, int y, int w, int h, int r, int g, int b )
{
    mach64UI32	cmd;
    DMALOCALS;

    MACH64DMAGETPTR( 32 );

#if 0 /* FIXME: GH */
    cmd = DC_opcod_trap | DC_arzero_enable | DC_sgnzero_enable |
	DC_shftzero_enable | (0xC << DC_bop_SHIFT)  |
	DC_atype_rstr | DC_solid_enable;

    MACH64DMA_FCOL(mach64PackColor(r,g,b,255));
    MACH64DMA_YDSTLEN(y,h);
    MACH64DMA_FXBNDRY(x,x+w);
    MACH64DMA_DWGCTL_EXEC(cmd);
#endif

    DMAADVANCE();
}


/*
 * performanceBoxes
 * Draw some small boxesin the corner of the buffer
 * based on some performance information
 */
void mach64PerformanceBoxes( int is_direct )
{
    int		w, x, t;

    if ( !mach64glx.boxes || !mach64DB ) {
	return;
    }

    /* make sure we are drawing to the correct place */
    mach64DmaExecute( mach64DB->Setup, mach64DB->SetupSize );

    /* draw a box to show we are active, so if it is't seen
       it means that it is completely software based rendering  */
    /* draw a purple box if we are direct rendering */
    if ( is_direct ) {			/* purple = direct (client dma) rendering */
	ClearBox( 4, 4, 8, 8, 255, 0, 255 );
    } else if ( mach64glx.dmaDriver ) {	/* white = server dma rendering */
	ClearBox( 4, 4, 8, 8, 255, 255, 255 );
    } else {				/* grey = servery PDMA */
	ClearBox( 4, 4, 8, 8, 128, 128, 128 );
    }

    /* draw a red box if we had to wait for drawing to complete
       (software render or texture swap) */
    if ( mach64glx.c_drawWaits ) {
	ClearBox( 16, 4, 8, 8, 255, 0, 0 );
	mach64glx.c_drawWaits = 0;
    }

    /* draw a blue box if the register protection signal was hit */
    if ( mach64glx.c_signals ) {
	ClearBox( 28, 4, 8, 8, 0, 0, 255 );
	mach64glx.c_signals = 0;
    }

    /* draw a yellow box if textures were swapped */
    if ( mach64glx.c_textureSwaps ) {
	ClearBox( 40, 4, 8, 8, 255, 255, 0 );
	mach64glx.c_textureSwaps = 0;
    }


    /* draw a green box if we had to wait for dma to complete (full
       utilization) on the previous frame */
    if ( !mach64glx.hardwareWentIdle ) {
	ClearBox( 64, 4, 8, 8, 0, 255, 0 );
    }
    mach64glx.hardwareWentIdle = 0;

    /* show buffer utilization */
    if ( mach64glx.c_dmaFlush > 1 ) {
	/* draw a solid bar if we flushed more than one buffer */
	ClearBox( 4, 16, 252, 4, 255, 32, 32 );
    } else {
	/* draw bars to represent the utilization of primary buffer */
	ClearBox( 4, 16, 252, 4, 32, 32, 32 );
	t = dma_buffer->maxBufferDwords;
	w = 252 * dma_buffer->bufferDwords / t;
	if ( w < 1 ) {
	    w = 1;
	}
	ClearBox( 4, 16, w, 4, 196, 128, 128 );
	x = 252 * dma_buffer->maxBufferDwords / t;
#if 0 /* FIXME: GH */
	w = 252 * dma_buffer->secondaryDwords / t;
#endif
	if ( w < 1 ) {
	    w = 1;
	}
	ClearBox( 4+x, 16, w, 4, 196, 128, 128 );
    }
    mach64glx.c_dmaFlush = 0;
}


/*
 * Copy the back buffer to the front buffer.  If there's no back buffer
 * this is a no-op.  Only called in indirect contexts.
 */
static void mach64ServerSwapBuffers( XSMesaBuffer b )
{
#ifdef PROFILE
    GLdouble		t0 = gl_time();
#endif
    mach64BufferPtr	buf;

    /* make sure mesa gives us everything */
    /* 3.1 leaves unsent verts without this, but there is probably
       a better internal call to get them sent... */
    if ( mach64Ctx && mach64Ctx->gl_ctx ) {
	glFlush();
    }

    if ( !b->db_state )
    {
	/* not double buffered, so do nothing */
    }
    else
    {
	ValidateGC( b->frontbuffer, b->cleargc );

	if ( b->backimage )
	{
	    if ( ( ( buf = (mach64BufferPtr)
		         b->backimage->devPriv ) != NULL ) && buf->Drawable )
	    {

		/* diagnostic drawing tools */
		mach64PerformanceBoxes( 0 );

		/* hardware accelerated back to front blit */
		mach64BackToFront( (DrawablePtr)b->frontbuffer,buf );

		/* make sure all dma is going to get executed */
		/* if everything has gone well, this will be the only
		   flush each frame */
		mach64DmaFlush();
	    }
	    else
	    {
		/* Use backimage's dimension (not buffer's) */
		(*b->cleargc->ops->PutImage)( (DrawablePtr)b->frontbuffer,
					      b->cleargc,
					      b->frontbuffer->depth,
					      0, 0,
					      b->backimage->width,
					      b->backimage->height,
					      0, ZPixmap, b->backimage->data );
	    }
	}
	else
	{
	    /* Copy pixmap to window on server */
	    (*b->cleargc->ops->CopyArea)( (DrawablePtr)b->backpixmap,
					  b->frontbuffer,
					  b->cleargc,
					  0, 0, b->width, b->height,
					  0, 0 );
	}
    }

    /* report performance counters */
    mach64Msg( 9, "swapBuffers: c_triangles:%i  c_lines:%i c_points:%i c_setup:%i c_textures:%i\n",
	       mach64glx.c_triangles, mach64glx.c_lines, mach64glx.c_points,
	       mach64glx.c_setupPointers, mach64glx.c_textureSwaps );

    mach64glx.c_triangles = 0;
    mach64glx.c_lines = 0;
    mach64glx.c_points = 0;
    mach64glx.c_setupPointers = 0;

    mach64Msg( 9, "---------------------------------------------------------\n" );

#ifdef PROFILE
    XSMesa->gl_ctx->SwapCount++;
    XSMesa->gl_ctx->SwapTime += gl_time() - t0;
#endif
}


/*
 * DoMakeCurrent
 * Changing either the context or the buffer will force this.
 */
static int DoMakeCurrent( XSMesaContext c, XSMesaBuffer b )
{
    mach64ContextPtr	ctx, oldctx = mach64Ctx;
    mach64BufferPtr	buf, oldbuf = mach64DB;

    mach64Msg( 10, "DoMakeCurrent( %p, %p )\n", c, b );

    mach64Ctx = NULL;
    mach64DB = NULL;

    if ( c )
    {
	ctx = c->hw_ctx;
	if ( !VALID_MACH64_CONTEXT( ctx ) ) {
	    return -1;
	}
    }
    else
    {
	ctx = NULL;
    }

    if ( b && ( b->buffer == XIMAGE ) )
    {
	buf = (mach64BufferPtr) b->backimage->devPriv;
	if ( buf->magic != mach64BufferMagic ) {
	    return -1;
	}
	if ( !buf->Drawable ) {
	    buf = NULL;
	}
    }
    else
    {
	buf = NULL;
    }

    if ( !ctx && buf ) {
	return -1;
    }
    if ( !ctx ) {
	return 0;
    }

    ctx->DB = buf;

    /* valid conditions to render with */
    mach64Ctx = ctx;
    mach64DB = ctx->DB;

    /* Even this is overkill: */
    if ( ( oldctx != ctx ) || ( oldbuf != mach64DB ) )
    {
	mach64Ctx->new_state |= MACH64_NEW_CONTEXT;

	if ( MESA_VERBOSE & VERBOSE_DRIVER ) {
	    fprintf( stderr, "needEnter3D in DoMakeCurrent\n" );
	}
    }

    return 0;
}


/*
 * mach64GLXMakeCurrent
 * Note that GLX calls this every batch of commands,
 * so it will show up several times a frame even if
 * the client application isn't issuing makeCurrent calls.
 */
GLboolean mach64GLXMakeCurrent( XSMesaContext c )
{
    if ( c == XSMesa ) {
	return ( GL_TRUE );
    }

    /* mesa 3.1 will sometimes leave unflushed vertexes */
    if ( XSMesa ) {
	glFlush();
    }

    mach64Msg( 10, "mach64GLXMakeCurrent( %p )\n", c );
    XSMesa = c;
    if ( c )
    {
	DoMakeCurrent( c, c->xsm_buffer );
	gl_make_current( c->gl_ctx,
			 ( c->xsm_buffer ) ? c->xsm_buffer->gl_buffer : NULL );
    }
    else
    {
	/* detach */
	DoMakeCurrent( NULL, NULL );
	gl_make_current( NULL, NULL );
    }

    return GL_TRUE;
}

/*
 * Bind buffer b to context c and make c the current rendering context.
 */
GLboolean mach64GLXBindBuffer( XSMesaContext c, XSMesaBuffer b )
{
    mach64Msg( 10, "mach64GLXBindBuffer( %p, %p )\n", c, b );

    DoMakeCurrent( c, b );
    return XSMesaBindBuffer( c, b );
}


/*
 * Create a new XSMesaContext.
 * Input:  v - XSMesaVisual
 *         share_list - another XSMesaContext with which to share display
 *                      lists or NULL if no sharing is wanted.
 * Return:  an XSMesaContext or NULL if error.
 */
XSMesaContext mach64GLXCreateContext( XSMesaVisual v,
				      XSMesaContext share_list )
{
    XSMesaContext	c;

    mach64Msg( 0, "### Creating new xsmesa context for Rage Pro...\n" );

    c = (XSMesaContext) calloc( 1, sizeof(struct xsmesa_context) );
    if ( ! c ) {
        return NULL;
    }

    c->gl_ctx = gl_create_context( v->gl_visual,
				   ( share_list ) ? share_list->gl_ctx : NULL,
				   (void *) c,
				   GL_TRUE /* direct rendering */ );
    if ( !c->gl_ctx ) {
        free( c );
        return NULL;
    }

    c->xsm_visual = v;
    c->xsm_buffer = NULL;       /* set later by XSMesaMakeCurrent */
    c->pixelformat = v->dithered_pf;    /* Dithering is enabled by default */
    c->hw_ctx = (void *) mach64CreateContext( c->gl_ctx );
    if ( !c->hw_ctx ) {
	mach64Error( "Cannot create hardware specific context.\n" );
	return NULL;
    }
    ((mach64ContextPtr)(c->hw_ctx))->refcount++;
    c->gl_ctx->Driver.UpdateState = mach64_setup_DD_pointers;

    mach64Msg( 1, "mach64GLXCreateContext succeeded: %p\n", c );

    return c;
}

void mach64GLXDestroyContext( XSMesaContext c )
{
    mach64Msg( 1, "mach64GLXDestroyContext( %p )\n", c );

    /* make sure all drawing is completed */
    mach64WaitDrawingEngine();

    if ( mach64DestroyContext( (mach64ContextPtr) c->hw_ctx ) != 0 ) {
	mach64Error( "mach64GLXDestroyContext(): mach64DestroyContext() failed!\n" );
    }

    XSMesaDestroyContext( c );
    if ( XSMesa == c ) {
	XSMesa = 0;
    }
}


/*
 * Local Variables:
 * mode: c
 * c-basic-offset: 4
 * End:
 */
