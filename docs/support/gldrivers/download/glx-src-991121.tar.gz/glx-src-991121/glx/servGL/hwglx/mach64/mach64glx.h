/* $Id: mach64glx.h,v 1.1 1999/10/28 03:43:47 gareth Exp $ */

/*
 * GLX Hardware Device Driver for ATI Rage Pro
 * Copyright (C) 1999 Gareth Hughes
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * WITTAWAT YAMWONG, OR ANY OTHER CONTRIBUTORS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE
 * OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * Based on MGA driver: mgaglx.h 1.4
 *
 *    Gareth Hughes <garethh@bell-labs.com>
 */

#ifndef __MACH64_GLX_H__
#define __MACH64_GLX_H__

void mach64DumpDB( mach64BufferPtr buf );
void mach64GLXCreateDepthBuffer( GLcontext* ctx );
void mach64GLXDestroyImage( GLXImage* image );
GLXImage* mach64GLXCreateImage( WindowPtr pwindow, int depth,
				int width, int height );
GLboolean mach64GLXMakeCurrent( XSMesaContext c );
GLboolean mach64GLXBindBuffer( XSMesaContext c, XSMesaBuffer b );
XSMesaContext mach64GLXCreateContext( XSMesaVisual v,
				      XSMesaContext share_list );
void mach64GLXDestroyContext( XSMesaContext c );

extern int mach64BackToFront( DrawablePtr drawable, mach64BufferPtr buf );
extern void (*mach64GLXSwapBuffers)( XSMesaBuffer b );
extern void mach64PerformanceBoxes( int is_direct );


#endif
