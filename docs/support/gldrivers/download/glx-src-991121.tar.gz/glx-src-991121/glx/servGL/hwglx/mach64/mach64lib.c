/* $Id: mach64lib.c,v 1.1 1999/10/28 03:43:47 gareth Exp $ */

/*
 * GLX Hardware Device Driver for ATI Rage Pro
 * Copyright (C) 1999 Gareth Hughes
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * WITTAWAT YAMWONG, OR ANY OTHER CONTRIBUTORS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE
 * OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * Based on MGA driver: mgalib.c 1.4
 *
 *    Gareth Hughes <garethh@bell-labs.com>
 */

#include <unistd.h> /* for usleep() */
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>
#include <sys/mman.h>
#include <stdio.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>

#include "mesaglx/types.h" /* DEPTH_BITS */

#include "rage_mac.h"
#include "mm.h"
#include "mach64lib.h"
#include "mach64log.h"

mach64BufferPtr		mach64DB = NULL;
mach64BufferPtr		mach64FrontBuffer = NULL;
mach64ContextPtr	mach64Ctx = NULL;

int usec( void )
{
    struct timeval	tv;
    struct timezone	tz;

    gettimeofday( &tv, &tz );

    return (tv.tv_sec & 2047) * 1000000 + tv.tv_usec;
}


void mach64SoftReset()
{
#if 0 /* FIXME: GH */
    /*
     * Soft reset
     * This will reset 3D engine. If you don't do this, 3D drawing may not work
     * correctly. (esp. line with depth)
     * I have to do soft reset every time I turn on my computer.
     * If you don't use 3d line, everything should be ok w/o reset.
     */
    OUTREG( MACH64REG_RST, R_softreset_enable );
    usleep( 20 ); /* in spec. minimum 10us */
    OUTREG( MACH64REG_RST, R_softreset_disable );
#endif
}

/*
 * - Palette format is TW16 (RGB565)
 * - pal MUST be padded as follow: sizeof(pal) = (len+1)/2 dword
 * - After the call you must reprogramm MACCESS and PITCH. It depends on
 *   which context you are in. (ie 2D or 3D)
 */
void mach64LoadTexturePalette( mach64UI16 *pal, mach64UI8 start,
			       mach64UI16 len )
{
    int		n;
    mach64UI32	*data = (mach64UI32 *) pal;
    DMALOCALS;

    MACH64DMAGETPTR( 16 + len/2 );

#if 0 /* FIXME: GH */
    DMAOUTREG(MACH64REG_AR0,len-1);
    DMAOUTREG(MACH64REG_AR3,0);
    MACH64DMA_PITCH(1024);
    MACH64DMA_YDSTLEN(start,len);
    DMAOUTREG(MACH64REG_YDSTORG,0);
    DMAOUTREG(MACH64REG_FXBNDRY,0);
    DMAOUTREG(MACH64REG_MACCESS,MA_pwidth_16 | MA_tlutload_enable);
    MACH64DMA_DWGCTL_EXEC(DC_opcod_iload | DC_atype_rstr | DC_linear_linear |
		       DC_shftzero_enable | DC_sgnzero_enable |
		       (0xc << DC_bop_SHIFT) | DC_bltmod_bfcol);
    DMAADVANCE();
    for (n=0; n<((len+1)/2); n++)
	DMAOUTREG(MACH64REG_DMAPAD, data[n]);
    DMAADVANCE();
#endif

    MACH64DMAGETPTR( 10 );
    mach64Msg( 7, "mach64LoadTexturePalette: mach64FrontBuffer = %d\n", mach64FrontBuffer );
#if 0 /* FIXME: GH */
    DMAOUTREG(MACH64REG_YDSTORG,MACH64ydstorg); /* for X server */
    if ( mach64FrontBuffer ) {
  	DMAOUTREG(MACH64REG_MACCESS,mach64FrontBuffer->Setup[MACH64_SETUP_MACCESS]);
  	DMAOUTREG(MACH64REG_PITCH,mach64FrontBuffer->Setup[MACH64_SETUP_PITCH]);
    } else {
	DMAOUTREG(MACH64REG_PITCH,mach64DB->Setup[MACH64_SETUP_PITCH]);
    	DMAOUTREG(MACH64REG_MACCESS,mach64DB->Setup[MACH64_SETUP_MACCESS]);
    }
#endif
    DMAADVANCE();
    mach64WaitDrawingEngine();
}


/*
 * Local Variables:
 * mode: c
 * c-basic-offset: 4
 * End:
 */
