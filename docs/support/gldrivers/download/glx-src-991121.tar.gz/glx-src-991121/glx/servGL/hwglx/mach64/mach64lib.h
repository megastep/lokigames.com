/* $Id: mach64lib.h,v 1.1 1999/10/28 03:43:47 gareth Exp $ */

/*
 * GLX Hardware Device Driver for ATI Rage Pro
 * Copyright (C) 1999 Gareth Hughes
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * WITTAWAT YAMWONG, OR ANY OTHER CONTRIBUTORS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE
 * OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * Based on MGA driver: mgalib.h 1.7
 *
 *    Gareth Hughes <garethh@bell-labs.com>
 */

#ifndef __MACH64_LIB_H__
#define __MACH64_LIB_H__

#include <stdio.h>

#include "mach64common.h"
#include "mach64buf.h"
#include "mach64context.h"
#include "mm.h"
#include "rage_mac.h"
#include "mach64log.h"
#include "mach64dma.h"

#ifndef MESA31
#error "The Mach64 driver now requires Mesa 3.1 or higher"
#endif

extern mach64BufferPtr	mach64DB;
extern mach64BufferPtr	mach64FrontBuffer;
extern mach64ContextPtr	mach64Ctx;
extern int		mach64In3DContext;

typedef struct
{
    mach64BufferPtr	bufferList;

    /* logging stuff */
    mach64UI32		logLevel;
    FILE		*logFile;

    /* dma stuff */
    mach64UI32		dmaDriver;
    mach64UI32		dmaSize;
    mach64UI32		dmaAdr;
    mach64UI32		cmdSize;
    mach64UI32		cardCmds;
    mach64UI32		systemTexture;
    mach64UI32		tableSize;

#if 0 /* FIXME: GH */
    /* bookkeeping for textureing */
    struct mach64_texture_object_s *TexObjList;
    struct mach64_texture_object_s *currentTextureObject[2];
    mach64UI16 		*currentTexturePalette;
    mach64UI32		deferTextureLoads;
    mach64UI32		default32BitTextures;
    mach64UI32		swapBuffersCount;
    struct gl_texture_object *currentMesaTexture;
#endif

    /* options */
    mach64UI32		nullprims;	/* skip all primitive generation */
    mach64UI32		boxes;		/* draw performance boxes */
    mach64UI32		noFallback;	/* don't fall back to software, do best-effort rendering */
    mach64UI32		nosgram;	/* don't block clears */
    mach64UI32		skipDma;	/* don't send anything to the hardware */

    /* performance counters */
    mach64UI32		c_textureUtilization;
    mach64UI32		c_textureSwaps;
    mach64UI32		c_setupPointers;
    mach64UI32		c_triangles;
    mach64UI32		c_points;
    mach64UI32		c_lines;
    mach64UI32		c_drawWaits;
    mach64UI32		c_signals;
    mach64UI32		c_dmaFlush;
    mach64UI32		c_overflows;

    mach64UI32		hardwareWentIdle; /* cleared each swapbuffers, set if
					     a waitfordmacompletion ever exited
					     without having to wait */

    mach64UI32		timeTemp;	/* for time counting in logfiles */
} mach64Glx_t;

extern mach64Glx_t	mach64glx;

int usec( void );
void mach64LibInit();
void mach64SoftReset();

int mach64MakeCurrent( mach64ContextPtr ctx, mach64BufferPtr buf );

#define MACH64PACKCOLOR555( r, g, b, a )				\
    ((((r) & 0xf8) << 7) | (((g) & 0xf8) << 2) | (((b) & 0xf8) >> 3) |	\
     ((a) ? 0x8000 : 0))

#define MACH64PACKCOLOR565( r, g, b )					\
    ((((r) & 0xf8) << 8) | (((g) & 0xfc) << 3) | (((b) & 0xf8) >> 3))

#define MACH64PACKCOLOR888( r, g, b )					\
    (((r) << 16) | ((g) << 8) | (b))

#define MACH64PACKCOLOR8888( r, g, b, a )				\
    (((a) << 24) | ((r) << 16) | ((g) << 8) | (b))

#define MACH64PACKCOLOR4444( r, g, b, a )				\
    ((((a) & 0xf0) << 8) | (((r) & 0xf0) << 4) | ((g) & 0xf0) | ((b) >> 4))

static __inline__ mach64UI32 mach64PackColor( mach64UI8 r, mach64UI8 g,
					      mach64UI8 b, mach64UI8 a )
{
    switch ( mach64DB->Attrib & MACH64_PF_MASK )
    {
    case MACH64_PF_555:
	return MACH64PACKCOLOR555( r, g, b, a );
    case MACH64_PF_565:
	return MACH64PACKCOLOR565( r, g, b );
    case MACH64_PF_888:
	return MACH64PACKCOLOR888( r, g, b );
    case MACH64_PF_8888:
	return MACH64PACKCOLOR8888( r, g, b, a );
    default:
	return 0;
    }
}

#endif


/*
 * Local Variables:
 * mode: c
 * c-basic-offset: 4
 * End:
 */
