/* $Id: mach64state.c,v 1.1 1999/10/28 03:43:47 gareth Exp $ */

/*
 * GLX Hardware Device Driver for ATI Rage Pro
 * Copyright (C) 1999 Gareth Hughes
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * WITTAWAT YAMWONG, OR ANY OTHER CONTRIBUTORS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE
 * OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * Based on MGA driver: mgastate.c ???
 *
 *    Gareth Hughes <garethh@bell-labs.com>
 */

#include <stdio.h>

#include "xsmesaP.h"

#include "types.h"
#include "pb.h"
#include "dd.h"

#include "glx_log.h"
#include "mm.h"
#include "rage_mac.h"
#include "mach64lib.h"
#include "mach64glx.h"
#include "mach64dd.h"
#include "mach64context.h"
#include "mach64state.h"
#if 0 /* FIXME: GH */
#include "mach64depth.h"
#include "mach64tex.h"
#endif
#include "mach64log.h"
#if 0 /* FIXME: GH */
#include "mach64vb.h"
#include "mach64tris.h"
#endif

/* FIXME: GH */
#define MACH64_CONTEXT(ctx)	((mach64ContextPtr)(((XSMesaContext)(ctx)->DriverCtx)->hw_ctx))


static void mach64UpdateZMode( const GLcontext *ctx )
{
#if 0 /* FIXME: GH */
    int		zmode = 0;

    if ( ctx->Depth.Test && mach64DB->HasZORG )
    {
	switch( ctx->Depth.Func )
	{
	case GL_NEVER:
	    zmode = DC_zmode_nozcmp; break;
	case GL_ALWAYS:
	    zmode = DC_zmode_nozcmp; break;
	case GL_LESS:
	    zmode = DC_zmode_zlt; break;
	case GL_LEQUAL:
	    zmode = DC_zmode_zlte; break;
	case GL_EQUAL:
	    zmode = DC_zmode_ze; break;
	case GL_GREATER:
	    zmode = DC_zmode_zgt; break;
	case GL_GEQUAL:
	    zmode = DC_zmode_zgte; break;
	case GL_NOTEQUAL:
	    zmode = DC_zmode_zne; break;
	default:
	    break;
	}
	if ( ctx->Depth.Mask ) {
	    zmode |= DC_atype_zi;
	} else {
	    zmode |= DC_atype_i;
	}
    }
    else
    {
	zmode |= DC_zmode_nozcmp | DC_atype_i;
    }

    mach64Ctx->regDWGCTL &= DC_zmode_MASK & DC_atype_MASK;
    mach64Ctx->regDWGCTL |= zmode;

    mach64Ctx->reg_dirty |= (1<<MACH64_SETUP_DWGCTL);
#endif
}


static void mach64DDAlphaFunc( GLcontext *ctx, GLenum func, GLclampf ref )
{
    MACH64_CONTEXT(ctx)->new_state |= MACH64_NEW_ALPHA;
}


static void mach64DDBlendEquation( GLcontext *ctx, GLenum mode )
{
    MACH64_CONTEXT(ctx)->new_state |= MACH64_NEW_ALPHA;
}

static void mach64DDBlendFunc( GLcontext *ctx, GLenum sfactor, GLenum dfactor )
{
    MACH64_CONTEXT(ctx)->new_state |= MACH64_NEW_ALPHA;
}

static void mach64DDBlendFuncSeparate( GLcontext *ctx, GLenum sfactorRGB,
				       GLenum dfactorRGB, GLenum sfactorA,
				       GLenum dfactorA )
{
    MACH64_CONTEXT(ctx)->new_state |= MACH64_NEW_ALPHA;
}



static void mach64DDLightModelfv( GLcontext *ctx, GLenum pname,
				  const GLfloat *param )
{
    if ( pname == GL_LIGHT_MODEL_COLOR_CONTROL ) {
	MACH64_CONTEXT(ctx)->new_state |= MACH64_NEW_TEXTURE;
    }
}


static void mach64DDShadeModel( GLcontext *ctx, GLenum mode )
{
    if ( 0 ) {
	MACH64_CONTEXT(ctx)->new_state |= MACH64_NEW_TEXTURE;
    }
}


static void mach64DDDepthFunc( GLcontext *ctx, GLenum func )
{
    MACH64_CONTEXT(ctx)->new_state |= MACH64_NEW_DEPTH;
}

static void mach64DDDepthMask( GLcontext *ctx, GLboolean flag )
{
    MACH64_CONTEXT(ctx)->new_state |= MACH64_NEW_DEPTH;
}


static void mach64DDFogfv( GLcontext *ctx, GLenum pname, const GLfloat *param )
{
    MACH64_CONTEXT(ctx)->new_state |= MACH64_NEW_FOG;
}




/* =============================================================
 * Alpha blending
 */


static void mach64UpdateAlphaMode( GLcontext *ctx )
{
#if 0 /* FIXME: GH */
    int		a = 0;

    /* determine source of alpha for blending and testing */
    if ( ctx->Texture.Enabled != TEXTURE0_2D )
    {
	a |= AC_alphasel_diffused;
    }
    else
    {
	switch ( mach64Ctx->TextureMode )
	{
	case GL_DECAL:
	case GL_REPLACE:
	    a |= AC_alphasel_fromtex;
	    break;
	case GL_BLEND:
	case GL_MODULATE:
	    a |= AC_alphasel_modulated;
	    break;
	default:
	    mach64Error( "mach64UpdateAlphaMode(): not supported texture mode %d\n",
			 mach64Ctx->TextureMode );
	}
    }


    /* alpha test control */
    if ( ctx->Color.AlphaEnabled )
    {
	GLubyte		ref = ctx->Color.AlphaRef;

	switch ( ctx->Color.AlphaFunc )
	{
	case GL_NEVER:
	    a |= AC_atmode_alt;
	    ref = 0;
	    break;
	case GL_LESS:
	    a |= AC_atmode_alt;
	    break;
	case GL_GEQUAL:
	    a |= AC_atmode_agte;
	    break;
	case GL_LEQUAL:
	    a |= AC_atmode_alte;
	    break;
	case GL_GREATER:
	    a |= AC_atmode_agt;
	    break;
	case GL_NOTEQUAL:
	    a |= AC_atmode_ane;
	    break;
	case GL_EQUAL:
	    a |= AC_atmode_ae;
	    break;
	case GL_ALWAYS:
	    a |= AC_atmode_noacmp;
	    break;
	default:
	}
	a |= MACH64_FIELD( AC_atref, ref );
    }

    /* blending control */
    if ( ctx->Color.BlendEnabled )
    {
	switch ( ctx->Color.BlendSrcRGB )
	{
	case GL_ZERO:
	    a |= AC_src_zero; break;
	case GL_SRC_ALPHA:
	    a |= AC_src_src_alpha; break;
	case GL_ONE:
	    a |= AC_src_one; break;
	case GL_DST_COLOR:
	    a |= AC_src_dst_color; break;
	case GL_ONE_MINUS_DST_COLOR:
	    a |= AC_src_om_dst_color; break;
	case GL_ONE_MINUS_SRC_ALPHA:
	    a |= AC_src_om_src_alpha; break;
	case GL_DST_ALPHA:
	    if ( mach64DB->Attrib & MACH64_PF_HASALPHA ) {
		a |= AC_src_dst_alpha;
	    } else {
		a |= AC_src_one;
	    }
	    break;
	case GL_ONE_MINUS_DST_ALPHA:
	    if ( mach64DB->Attrib & MACH64_PF_HASALPHA ) {
		a |= AC_src_om_dst_alpha;
	    } else {
		a |= AC_src_zero;
	    }
	    break;
	case GL_SRC_ALPHA_SATURATE:
	    a |= AC_src_src_alpha_sat;
	    break;
	default:		/* never happens */
	}

	switch ( ctx->Color.BlendDstRGB )
	{
	case GL_SRC_ALPHA:
	    a |= AC_dst_src_alpha; break;
	case GL_ONE_MINUS_SRC_ALPHA:
	    a |= AC_dst_om_src_alpha; break;
	case GL_ZERO:
	    a |= AC_dst_zero; break;
	case GL_ONE:
	    a |= AC_dst_one; break;
	case GL_SRC_COLOR:
	    a |= AC_dst_src_color; break;
	case GL_ONE_MINUS_SRC_COLOR:
	    a |= AC_dst_om_src_color; break;
	case GL_DST_ALPHA:
	    if ( mach64DB->Attrib & MACH64_PF_HASALPHA ) {
		a |= AC_dst_dst_alpha;
	    } else {
		a |= AC_dst_one;
	    }
	    break;
	case GL_ONE_MINUS_DST_ALPHA:
	    if ( mach64DB->Attrib & MACH64_PF_HASALPHA ) {
		a |= AC_dst_om_dst_alpha;
	    } else {
		a |= AC_dst_zero;
	    }
	    break;
	default:		/* never happens */
	}
    }
    else
    {
	a |= AC_src_one|AC_dst_zero;
    }

    mach64Ctx->regALPHACTRL = AC_amode_alpha_channel |
	AC_astipple_disable | AC_aten_disable | AC_atmode_noacmp | a;

    mach64Ctx->reg_dirty |= 1<<MACH64_SETUP_ALPHACTRL;
#endif
}



/* =============================================================
 * Hardware clipping
 */

static void mach64UpdateClipping( const GLcontext *ctx )
{
    int		x1,x2,y1,y2;

    if ( ctx->Scissor.Enabled )
    {
	x1 = ctx->Scissor.X;
	x2 = ctx->Scissor.X + ctx->Scissor.Width - 1;
	y1 = mach64DB->Height - ctx->Scissor.Y - ctx->Scissor.Height;
	y2 = mach64DB->Height - ctx->Scissor.Y - 1;
    }
    else
    {
	x1 = 0;
	y1 = 0;
	x2 = mach64DB->Width - 1;
	y2 = mach64DB->Height - 1;
    }

    if ( x1 < 0 ) x1 = 0;
    if ( y1 < 0 ) y1 = 0;
    if ( x2 >= mach64DB->Width ) x2 = mach64DB->Width - 1;
    if ( y2 >= mach64DB->Height ) y2 = mach64DB->Height - 1;

    if ( ( x1 > x2 ) || ( y1 > y2 ) ) {
	x1 = 0; x2 = 0;
	y2 = 0; y1 = 1;
    }

#if 0 /* FIXME: GH */
    mach64DB->Setup[MACH64_SETUP_CXBNDRY] = (MACH64_FIELD(CXB_cxright,x2) |
					     MACH64_FIELD(CXB_cxleft,x1));
    mach64DB->Setup[MACH64_SETUP_YTOP] = y1*mach64DB->Pitch;
    mach64DB->Setup[MACH64_SETUP_YBOT] = y2*mach64DB->Pitch;


    mach64Ctx->reg_dirty |= ((1<<MACH64_SETUP_CXBNDRY) |
			     (1<<MACH64_SETUP_YTOP) |
			     (1<<MACH64_SETUP_YBOT));
#endif
}


static void mach64DDScissor( GLcontext *ctx, GLint x, GLint y,
			     GLsizei w, GLsizei h )
{
    MACH64_CONTEXT(ctx)->new_state |= MACH64_NEW_CLIP;
}


/* =============================================================
 * Culling
 */

#define _CULL_DISABLE 0
#define _CULL_NEGATIVE ((1<<11)|(1<<5)|(1<<16))
#define _CULL_POSITIVE (1<<11)

static void set_cull( int mode )
{
    DMALOCALS;
    MACH64DMAGETPTR( 4 );

#if 0 /* FIXME: GH */
    DMAOUTREG( MACH64REG_WFLAG, mode );
#endif

    DMAADVANCE();
}


void mach64UpdateCull( GLcontext *ctx )
{
    if ( !ctx->Polygon.CullFlag || ( ctx->PB->primitive != GL_POLYGON ) )
    {
	set_cull( _CULL_DISABLE );
    }
    else
    {
	switch ( ctx->Polygon.CullFaceMode )
	{
	case GL_BACK:
	    if( ctx->Polygon.FrontFace == GL_CCW ) {
		set_cull( _CULL_NEGATIVE );
	    } else {
		set_cull( _CULL_POSITIVE );
	    }
	    break;
	case GL_FRONT:
	    if( ctx->Polygon.FrontFace == GL_CCW ) {
		set_cull( _CULL_POSITIVE );
	    } else {
		set_cull( _CULL_NEGATIVE );
	    }
	    break;
	case GL_FRONT_AND_BACK:
	    set_cull( _CULL_DISABLE );
	    break;
	default:
	    break;
	}
    }
}


static void mach64DDCullFace( GLcontext *ctx, GLenum mode )
{
    MACH64_CONTEXT(ctx)->new_state |= MACH64_NEW_CULL;
}

static void mach64DDFrontFace( GLcontext *ctx, GLenum mode )
{
    MACH64_CONTEXT(ctx)->new_state |= MACH64_NEW_CULL;
}



/* =============================================================
 * Color masks
 */

/* Mesa calls this from the wrong place:
 */
static GLboolean mach64DDColorMask( GLcontext *ctx,
				    GLboolean r, GLboolean g,
				    GLboolean b, GLboolean a )
{
    GLuint	mask;

    mask = mach64PackColor( ctx->Color.ColorMask[RCOMP],
			    ctx->Color.ColorMask[GCOMP],
			    ctx->Color.ColorMask[BCOMP],
			    ctx->Color.ColorMask[ACOMP] );

    switch ( mach64DB->Attrib & MACH64_PF_MASK )
    {
    case MACH64_PF_555:
    case MACH64_PF_565:
	mask = mask | (mask << 16);
	break;
    }

    if ( mach64DB->Setup[MACH64_SETUP_PLNWT] != mask )
    {
	mach64DB->Setup[MACH64_SETUP_PLNWT] = mask;
	MACH64_CONTEXT(ctx)->new_state |= MACH64_NEW_MASK;
#if 0 /* FIXME: GH */
	mach64Ctx->reg_dirty |= (1<<MACH64_SETUP_PLNWT);
#endif
    }

    return 1;
}



/* =============================================================
 */

static void mach64DDEnable( GLcontext *ctx, GLenum cap, GLboolean state )
{
    switch ( cap )
    {
    case GL_ALPHA_TEST:
	MACH64_CONTEXT(ctx)->new_state |= MACH64_NEW_ALPHA;
	break;
    case GL_BLEND:
	MACH64_CONTEXT(ctx)->new_state |= MACH64_NEW_ALPHA;
	break;
    case GL_DEPTH_TEST:
	MACH64_CONTEXT(ctx)->new_state |= MACH64_NEW_DEPTH;
	break;
    case GL_SCISSOR_TEST:
	MACH64_CONTEXT(ctx)->new_state |= MACH64_NEW_CLIP;
	break;
    case GL_FOG:
	MACH64_CONTEXT(ctx)->new_state |= MACH64_NEW_FOG;
	break;
    case GL_CULL_FACE:
	MACH64_CONTEXT(ctx)->new_state |= MACH64_NEW_CULL;
	break;
    case GL_TEXTURE_2D:
	/* This doesn't get checked yet, but I'll get it working once
	 * John's mach64tex.c rework is done.
	 */
	MACH64_CONTEXT(ctx)->new_state |= MACH64_NEW_TEXTURE;
	break;
    default:
	;
    }
}


/* Don't use the regs parm yet.
 */
void mach64UpdateRegs( GLcontext *ctx, GLuint regs )
{
    DMALOCALS;
    mach64DmaExecute( mach64DB->Setup, mach64DB->SetupSize );

    MACH64DMAGETPTR( 2 );
#if 0 /* FIXME: GH */
    DMAOUTREG( MACH64REG_DWGCTL, mach64Ctx->regDWGCTL );
    DMAOUTREG( MACH64REG_ALPHACTRL, mach64Ctx->regALPHACTRL );
#endif
    DMAADVANCE();
}


/* =============================================================
 */

void mach64DDPrintState( const char *msg, GLuint state )
{
    mach64Msg( 1, "%s (0x%x): %s%s%s%s%s%s%s%s\n",
	       msg,
	       state,
	       (state & MACH64_NEW_DEPTH)   ? "depth, " : "",
	       (state & MACH64_NEW_ALPHA)   ? "alpha, " : "",
	       (state & MACH64_NEW_FOG)     ? "fog, " : "",
	       (state & MACH64_NEW_CLIP)    ? "clip, " : "",
	       (state & MACH64_NEW_MASK)    ? "colormask, " : "",
	       (state & MACH64_NEW_CULL)    ? "cull, " : "",
	       (state & MACH64_NEW_TEXTURE) ? "texture, " : "",
	       (state & MACH64_NEW_CONTEXT) ? "context, " : "" );
}

void mach64DDUpdateHwState( GLcontext *ctx )
{
    int new_state = MACH64_CONTEXT(ctx)->new_state;

    new_state = ~0;	// JDC: temporary

    if ( new_state )
    {
	mach64Msg( 15, "mach64DDUpdateHwState\n" );

	MACH64_CONTEXT(ctx)->new_state = 0;

	if ( MESA_VERBOSE & VERBOSE_DRIVER ) {
	    mach64DDPrintState( "UpdateHwState", new_state );
	}

	if ( new_state & MACH64_NEW_DEPTH ) mach64UpdateZMode( ctx );
	if ( new_state & MACH64_NEW_ALPHA ) mach64UpdateAlphaMode( ctx );
#if 0 /* FIXME: GH */
	if ( new_state & MACH64_NEW_FOG )   mach64UpdateFogAttrib( mach64Ctx );
#endif
	if ( new_state & MACH64_NEW_CLIP )  mach64UpdateClipping( ctx );
	if ( new_state & MACH64_NEW_CULL )  mach64UpdateCull( ctx );

	if ( new_state & MACH64_NEW_CONTEXT ) {
	    MACH64_CONTEXT(ctx)->reg_dirty = ~0;
	}
	if ( new_state & MACH64_NEW_TEXTURE ) {
#if 0 /* FIXME: GH */
	    mach64UpdateTextureState( ctx );
#endif
	}

	if ( MACH64_CONTEXT(ctx)->reg_dirty ) {
	    mach64UpdateRegs( ctx, MACH64_CONTEXT(ctx)->reg_dirty );
	}
    }
}



void mach64DDInitStatePointers( GLcontext *ctx )
{
    ctx->Driver.Enable = mach64DDEnable;
    ctx->Driver.LightModelfv = mach64DDLightModelfv;
    ctx->Driver.AlphaFunc = mach64DDAlphaFunc;
    ctx->Driver.BlendEquation = mach64DDBlendEquation;
    ctx->Driver.BlendFunc = mach64DDBlendFunc;
    ctx->Driver.BlendFuncSeparate = mach64DDBlendFuncSeparate;
    ctx->Driver.DepthFunc = mach64DDDepthFunc;
    ctx->Driver.DepthMask = mach64DDDepthMask;
    ctx->Driver.Fogfv = mach64DDFogfv;
    ctx->Driver.Scissor = mach64DDScissor;
    ctx->Driver.CullFace = mach64DDCullFace;
    ctx->Driver.FrontFace = mach64DDFrontFace;
    ctx->Driver.ShadeModel = mach64DDShadeModel;
    ctx->Driver.ColorMask = mach64DDColorMask;
    ctx->Driver.ReducedPrimitiveChange = mach64DDReducedPrimitiveChange;
    ctx->Driver.RenderStart = mach64DDUpdateHwState;
    ctx->Driver.RenderFinish = 0;
}



void mach64DDReducedPrimitiveChange( GLcontext *ctx, GLenum prim )
{
    mach64UpdateCull( ctx );
}


#define INTERESTED	( ~( NEW_MODELVIEW | NEW_PROJECTION |		\
			     NEW_TEXTURE_MATRIX |			\
			     NEW_USER_CLIP | NEW_CLIENT_STATE |		\
			     NEW_TEXTURE_ENABLE ) )

void mach64DDUpdateState( GLcontext *ctx )
{
    mach64glx.c_setupPointers++;


#if 0
    /* Find a better way to do this.
     */
    if ( !mach64CanUseHardware( ctx ) ) {
	mach64_setup_DD_pointers_no_accel( ctx );
	return;
    }
#endif


    /* Include mach64UpdateTextureState here temporarily until John's
     * rework of mach64tex.c is done.
     */
    ctx->NewState = ~0;	// JDC: temporary
    if ( ctx->NewState & INTERESTED ) {
#if 0 /* FIXME: GH */
	mach64DDChooseRenderState( ctx );
	mach64ChooseRasterSetupFunc( ctx );
#endif
    }

    /* TODO: stop mesa from clobbering these.
     */
    ctx->Driver.PointsFunc = mach64Ctx->PointsFunc;
    ctx->Driver.LineFunc = mach64Ctx->LineFunc;
    ctx->Driver.TriangleFunc = mach64Ctx->TriangleFunc;
    ctx->Driver.QuadFunc = mach64Ctx->QuadFunc;
}


/*
 * Local Variables:
 * mode: c
 * c-basic-offset: 4
 * End:
 */
