/* $Id: rage_mac.h,v 1.1 1999/10/28 03:43:47 gareth Exp $ */

/*
 * GLX Hardware Device Driver for ATI Rage Pro
 * Copyright (C) 1999 Gareth Hughes
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * WITTAWAT YAMWONG, OR ANY OTHER CONTRIBUTORS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE
 * OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *
 *    Gareth Hughes <garethh@bell-labs.com>
 */

#ifndef __RAGE_MAC_H__
#define __RAGE_MAC_H__

#include "vga.h"
#include "vgaPCI.h"

#define GC XXGC
#include "mach64.h"
#include "regmach64.h"
#undef GC
#include "xf86_OSproc.h"

#include "rage_reg.h"

/*
 * FIXME: GH - This all needs updating...
 */

#define MACH64_SET_FIELD( reg, mask, val )			\
    reg = ((reg) & (mask)) | ((val) & ~(mask))
#define MACH64_FIELD( field, val )				\
    ( ( (val) << (field ## _SHIFT) ) & ~(field ## _MASK) )

#define mach64F1800( x )	(((mach64I32) (x)) & 0x0003ffff)
#define mach64F1715( x )	((mach64I32) ((x) * (1 << 15)))
#define mach64F0915( x )	(((mach64I32) ((x) * (1 << 15))) & 0x00ffffff)
#define mach64F2400( x )	(((mach64I32) (x)) & 0x00ffffff)
#define mach64F2200( x )	(((mach64I32) (x)) & 0x003fffff)
#define mach64F3315( x, msb, lsb )				\
     msb = ((mach64UI32) (x)) >> 17;				\
     lsb = (mach64UI32)((x) - (msb << 17)) * (1 << 15));
#define mach64F1220( x )	((mach64I32)((x) * (1 << 20)))
#define mach64F1616( x )	((mach64I32)((x) * (1 << 16)))

/* Global initialization */

#define MACH64DMA_PITCH( x )		DMAOUTREG( MACH64REG_PITCH, x )
#define MACH64DMA_DSTORG( x )		DMAOUTREG( MACH64REG_DSTORG, x )
#define MACH64DMA_SRCORG( x )		DMAOUTREG( MACH64REG_SRCORG, x )
#define MACH64DMA_MACCESS( x )		DMAOUTREG( MACH64REG_MACCESS, x )
#define MACH64DMA_CXBNDRY( x )		DMAOUTREG( MACH64REG_CXBNDRY, x )
#define MACH64DMA_YTOP( x )		DMAOUTREG( MACH64REG_YTOP, x )
#define MACH64DMA_YBOT( x )		DMAOUTREG( MACH64REG_YBOT, x )
#define MACH64DMA_PLNWT( x )		DMAOUTREG( MACH64REG_PLNWT, x )
#define MACH64DMA_ZORG( x )		DMAOUTREG( MACH64REG_ZORG, x )
#define MACH64DMA_DWGCTL( x )		DMAOUTREG( MACH64REG_DWGCTL, x )
#define MACH64DMA_DWGCTL_EXEC( x )	DMAOUTREG( MACH64REG_DWGCTL + MACH64REG_MACH64_EXEC, x )

#define MACH64DMA_FCOL( x )		DMAOUTREG( MACH64REG_FCOL, x )
#define MACH64DMA_ALPHACTRL( x )	DMAOUTREG( MACH64REG_ALPHACTRL, x )
#define MACH64DMA_SGN( x )		DMAOUTREG( MACH64REG_SGN, x )
#define MACH64DMA_FXBNDRY( x1, x2 )	DMAOUTREG( MACH64REG_FXBNDRY, ((x2) << 16) | (x1) )
#define MACH64DMA_YDSTLEN( y, LEN )	DMAOUTREG( MACH64REG_YDSTLEN, ((y) << 16) | (LEN) )
#define MACH64DMA_YDSTLEN_EXEC( y, LEN ) DMAOUTREG( MACH64REG_YDSTLEN + MACH64REG_MACH64_EXEC, \
						    ((y) << 16) | (LEN) )
#define MACH64DMA_LEN( x )		DMAOUTREG( MACH64REG_LEN, x )
#define MACH64DMA_LEN_EXEC( x )		DMAOUTREG( MACH64REG_LEN + MACH64REG_MACH64_EXEC, x )


#define MACH64DMA_A( start, xinc, yinc )		\
    do {						\
	DMAOUTREG( MACH64REG_ALPHASTART, start );	\
	DMAOUTREG( MACH64REG_ALPHAXINC, xinc );		\
    	DMAOUTREG( MACH64REG_ALPHAYINC, yinc );		\
    } while ( 0 )
#define MACH64DMA_R( start, xinc, yinc )		\
    do {						\
	DMAOUTREG( MACH64REG_DR4, start );		\
	DMAOUTREG( MACH64REG_DR6, xinc );		\
	DMAOUTREG( MACH64REG_DR7, yinc );		\
    } while ( 0 )
#define MACH64DMA_G( start, xinc, yinc )		\
    do {						\
	DMAOUTREG( MACH64REG_DR8, start );		\
	DMAOUTREG( MACH64REG_DR10, xinc );		\
	DMAOUTREG( MACH64REG_DR11, yinc );		\
    } while ( 0 )
#define MACH64DMA_B( start, xinc, yinc )		\
    do {						\
	DMAOUTREG( MACH64REG_DR12, start );		\
	DMAOUTREG( MACH64REG_DR14, xinc );		\
	DMAOUTREG( MACH64REG_DR15, yinc );		\
    } while ( 0 )


#define MACH64DMA_SPECR( start, xinc, yinc )		\
    do {						\
	DMAOUTREG( MACH64REG_SPECRSTART, start );	\
	DMAOUTREG( MACH64REG_SPECRXINC, xinc );		\
	DMAOUTREG( MACH64REG_SPECRYINC, yinc );		\
    } while ( 0 )
#define MACH64DMA_SPECG( start, xinc, yinc )		\
    do {						\
	DMAOUTREG( MACH64REG_SPECGSTART, start );	\
	DMAOUTREG( MACH64REG_SPECGXINC, xinc );		\
	DMAOUTREG( MACH64REG_SPECGYINC, yinc );		\
    } while ( 0 )
#define MACH64DMA_SPECB( start, xinc, yinc )		\
    do {						\
	DMAOUTREG( MACH64REG_SPECBSTART, start );	\
	DMAOUTREG( MACH64REG_SPECBXINC, xinc );		\
	DMAOUTREG( MACH64REG_SPECBYINC, yinc );		\
    } while ( 0 )


#define MACH64DMA_Z16( start, xinc, yinc )		\
    do {						\
	DMAOUTREG( MACH64REG_DR0, start );		\
	DMAOUTREG( MACH64REG_DR2, xinc );		\
	DMAOUTREG( MACH64REG_DR3, yinc );		\
    } while ( 0 )


#define MACH64DMA_FOG( start, xinc, yinc, col )		\
    do {						\
	DMAOUTREG( MACH64REG_FOGSTART, start );		\
	DMAOUTREG( MACH64REG_FOGXINC, xinc );		\
	DMAOUTREG( MACH64REG_FOGYINC, yinc );		\
	DMAOUTREG( MACH64REG_FOGCOL, col );		\
    } while ( 0 )


#define MACH64DMA_S( start, xinc, yinc )		\
    do {						\
	DMAOUTREG( MACH64REG_TMR6, start );		\
	DMAOUTREG( MACH64REG_TMR0, xinc );		\
	DMAOUTREG( MACH64REG_TMR1, yinc );		\
    } while ( 0 )
#define MACH64DMA_T( start, xinc, yinc )		\
    do {						\
	DMAOUTREG( MACH64REG_TMR7, start );		\
	DMAOUTREG( MACH64REG_TMR2, xinc );		\
	DMAOUTREG( MACH64REG_TMR3, yinc );		\
    } while ( 0 )
#define MACH64DMA_Q( start, xinc, yinc )		\
    do {						\
	DMAOUTREG( MACH64REG_TMR8, start );		\
	DMAOUTREG( MACH64REG_TMR4, xinc );		\
	DMAOUTREG( MACH64REG_TMR5, yinc );		\
    } while ( 0 )


#define MACH64DMA_LSLOPE( dx, dy, sgn, err )				\
    do {								\
	DMAOUTREG( MACH64REG_AR0, mach64F1800( dy ) );			\
	if ( (dx) >= 0 ) {						\
	    DMAOUTREG( MACH64REG_AR1, mach64F2400( -(dx)+(err) ) );	\
	    DMAOUTREG( MACH64REG_AR2, mach64F1800( -(dx) ) );		\
	    MACH64_SET_FIELD( sgn, S_sdxl_MASK, S_sdxl_pos );		\
	} else {							\
	    DMAOUTREG( MACH64REG_AR1, mach64F2400( (dx)+(dy)-(err)-1 ) ); \
	    DMAOUTREG( MACH64REG_AR2, mach64F1800( dx ) );		\
	    MACH64_SET_FIELD( sgn, S_sdxl_MASK, S_sdxl_neg );		\
	}								\
    } while ( 0 )

#define MACH64DMA_RSLOPE( dx, dy, sgn, err )				\
    do {								\
	DMAOUTREG( MACH64REG_AR6, mach64F1800( dy ) );			\
	if ( (dx) >= 0 ) {						\
	    DMAOUTREG( MACH64REG_AR4, mach64F1800( -(dx)+(err) ) );	\
	    DMAOUTREG( MACH64REG_AR5, mach64F1800( -(dx) ) );		\
	    MACH64_SET_FIELD( sgn, S_sdxr_MASK, S_sdxr_pos );		\
	} else {							\
	    DMAOUTREG( MACH64REG_AR4, mach64F1800( (dx)+(dy)-(err)-1 ) ); \
	    DMAOUTREG( MACH64REG_AR5, mach64F1800( dx ) );		\
	    MACH64_SET_FIELD( sgn, S_sdxr_MASK, S_sdxr_neg );		\
	}								\
    } while ( 0 )

/* Line programming */
#define MACH64DMA_AUTO_LINE( x1, y1, x2, y2 )				\
    do {								\
	DMAOUTREG( MACH64REG_XYSTRT,					\
		   (y1 << XYSA_y_start_SHIFT) | (x1 & ~XYSA_x_start_MASK) ); \
	DMAOUTREG( MACH64REG_XYEND,					\
		   (y2 << XYEA_y_end_SHIFT) | (x2 & ~XYEA_x_end_MASK) ); \
    } while ( 0 )

#endif
