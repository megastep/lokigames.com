#include <stdlib.h>
#include <signal.h>

#include "context.h"
#include "depth.h"
#include "macros.h"
#include "texstate.h"
#include "triangle.h"
#include "vb.h"
#include "types.h"

#include "xsmesaP.h"
#include "glx_log.h"
#include "mesaglx/context.h"
#include "mesaglx/matrix.h"
#include "mesaglx/types.h"

#define GC XXGC
#include "gcstruct.h"
#include "pixmapstr.h"
#include "servermd.h" /* PixmapBytePad */
#include "scrnintstr.h"
#include "regionstr.h"
#include "windowstr.h"
#undef GC

#include "vga.h"
#include "vgaPCI.h"
#include "mga.h"
#include "xaa/xf86xaa.h"

#include "mm.h"
#include "mgabuf.h"
#include "mgadd.h"
#include "g200_mac.h"
#include "mgalib.h"
#include "mgalog.h"
#include "mgadirect.h"
#include "mgadma.h"
#include "mgaglx.h"

#include "glx_clients.h"

#ifndef NO_MTRR
#define MTRR_NEED_STRINGS
#include <errno.h>
#include <asm/mtrr.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <unistd.h>
int mtrr;
void mgaCloseMTRR();
#endif

#include "xf86_OSproc.h"



static void mgaClientDMAFlush( int wait );
static void mgaClientSwapBuffers( XSMesaBuffer b ) ;
static void mgaClientReleaseHardware( void );

/* 
 */
#define GLX_START                X_GLXDirectPrivateStart

#define X_GLXMgaSwapBuffers   (GLX_START+2)
#define X_GLXMgaDmaFlush      (GLX_START+3)
#define X_GLXMgaFBGeom        (GLX_START+4)


/* Nice thing about direct rendering is that the server *is* the
 * client, in the sense that they should both be the same executable
 * image 'glx.so'.  This means that most of the protocol structs can
 * be private to this file.
 */
typedef struct {   
   char init_fn[20];		/* The first element is always the
				 * name of the function for the client
				 * to call to initialize glx.so.  */

   int screenNum;		/* not respected - assumed to be zero */

   int vgaInfoVirtualX;
   int vgaInfoVirtualY;
   int vgaInfoDepth;
   int vgaInfoDisplayWidth;
   int vgaInfoVideoRam;
   int vgaInfoChipID;
   unsigned long vgaInfoPhysBase;

   char vgaInfoChipset[80];
   int vgaBitsPerPixel;
   int vgaLinearSize;

   int MGAdacIsHWCursor;
   int MGAchipset;
   int MGAydstorg;
   pciTagRec MGAPciTag;
   Bool MGAUsePCIRetry;

   int xf86PixmapCacheMemoryStart;
   int xf86PixmapCacheMemoryEnd;
   int xf86PCIFlags;

   int mgaglx_dma;
   int mgaglx_dmaadr;
   int mgaglx_dmasize;
   int mgaglx_systemtexture;
   int mgaglx_cardcmds;
   int mgaglx_cmdsize;

   int mgaActiveDmaBuffer;
   int glx_first_visual;

} mgaDirectHWInfo;


extern int __glx_is_server;
extern int __glx_first_visual;
extern int vgaLinearSize;
extern ClientPtr direct_client;
extern int __glXNumClients();
extern Bool MGAUsePCIRetry;

static ClientRec fake_client;


static int (*send_vendor_private)( int opcode,
				   char *vp, 
				   size_t vp_sz,
				   xReply *reply,
				   char *data,
				   size_t data_sz ) = 0;


ClientPtr mgaGLXClientInit( mgaDirectHWInfo *hw, 
			    int (*send_func)(),
			    void (**release_hook)( void ))
{
   __glx_is_server = 0;

   send_vendor_private = send_func;

   mgaDoDmaFlush = mgaClientDMAFlush;
   mgaGLXSwapBuffers = mgaClientSwapBuffers;

   direct_client = &fake_client;
   direct_client->index = 1;

   memset(&vga256InfoRec, 0, sizeof(vga256InfoRec));
   memset(&MGAdac, 0, sizeof(MGAdac));
   memset(&xf86AccelInfoRec, 0, sizeof(xf86AccelInfoRec));
   
   vgaLinearSize = hw->vgaLinearSize;
   vga256InfoRec.virtualX = hw->vgaInfoVirtualX;
   vga256InfoRec.virtualY = hw->vgaInfoVirtualY;
   vga256InfoRec.depth = hw->vgaInfoDepth;
   vga256InfoRec.displayWidth = hw->vgaInfoDisplayWidth;
   vga256InfoRec.videoRam = hw->vgaInfoVideoRam;
   vga256InfoRec.chipID = hw->vgaInfoChipID;
   vga256InfoRec.physBase = hw->vgaInfoPhysBase;
   vga256InfoRec.chipset = hw->vgaInfoChipset;
   vgaBitsPerPixel = hw->vgaBitsPerPixel;

   /* Better to have specific mm ranges in the struct.  Better still to 
    * unify card mem-mgmt over multiple clients.  Leave it like this for now.
    */
   xf86AccelInfoRec.PixmapCacheMemoryStart = hw->xf86PixmapCacheMemoryStart;
   xf86AccelInfoRec.PixmapCacheMemoryEnd = hw->xf86PixmapCacheMemoryEnd;
   xf86AccelInfoRec.ServerInfoRec = &vga256InfoRec;

   MGAdac.isHwCursor = hw->MGAdacIsHWCursor;
   
   MGAPciTag = hw->MGAPciTag;
   MGAchipset = hw->MGAchipset;
   MGAydstorg = hw->MGAydstorg;
   MGAUsePCIRetry = hw->MGAUsePCIRetry;
   xf86PCIFlags = hw->xf86PCIFlags;
   mgaglx.dmaDriver = hw->mgaglx_dma;
   mgaglx.dmaAdr = hw->mgaglx_dmaadr;
   mgaglx.dmaSize = hw->mgaglx_dmasize;
   mgaglx.cmdSize = hw->mgaglx_cmdsize;
   mgaglx.cardCmds = hw->mgaglx_cardcmds;
   mgaglx.systemTexture = hw->mgaglx_systemtexture;
   __glx_first_visual = hw->glx_first_visual;

   mgaActiveDmaBuffer = hw->mgaActiveDmaBuffer;

   vgaLinearBase = xf86MapVidMem(hw->screenNum, 
				 LINEAR_REGION,
				 (pointer) vga256InfoRec.physBase,
				 vgaLinearSize);

   if (vgaLinearBase == (pointer) -1) {
      mgaError("failed to map vga linear region");
      mgaClientReleaseHardware();
      return 0;
   }

   *release_hook = mgaClientReleaseHardware;
   return direct_client;
}

static void mgaClientReleaseHardware( void )
{
   if (vgaLinearBase != (pointer) -1) {
      xf86UnMapVidMem(0,
		      LINEAR_REGION,
		      (pointer) vga256InfoRec.physBase,
		      vgaLinearSize);
      vgaLinearBase = 0;
   }
}


static int mgaGLXGoDirect( ClientPtr client )
{
   xGLXGetStringReply reply;
   mgaDirectHWInfo *hw;
   int l;

   /* Allow only one direct client, which must be the only active
    * client, and must be on the local server.  
    */
   if (direct_client || !__glx_is_server || __glXNumClients() != 1 || 
       !LocalClient(client)) 
      return BadAccess;

   if (mgaglx.dmaDriver < 2) {
      mgaError("Direct clients only allowed with real dma");
      return BadMatch;
   }

   mgaDmaFlush();

   direct_client = client;
   hw = (mgaDirectHWInfo *)malloc( sizeof(*hw) );

   /* Name of function to call to revive the struct.  Client will
    * receive buf in reply to its go_direct request.  Client will map
    * glx.so, and use buf as a string argument to dlsym(), to retreive
    * a function to call, namely mgaGLXClientInit.  It will then call
    * that function passing hw as its argument.
    *
    * hw should contain all the information necessary to get glx.so
    * talking to hardware from the client.
    */
   strcpy(hw->init_fn, "mgaGLXClientInit");   

   hw->screenNum = 0;		/* oh really? */
   hw->vgaInfoVirtualX = vga256InfoRec.virtualX;
   hw->vgaInfoVirtualY = vga256InfoRec.virtualY;
   hw->vgaInfoDepth = vga256InfoRec.depth;
   hw->vgaInfoDisplayWidth = vga256InfoRec.displayWidth;
   hw->vgaInfoVideoRam = vga256InfoRec.videoRam;
   hw->vgaInfoChipID = vga256InfoRec.chipID;
   hw->vgaInfoPhysBase = vga256InfoRec.physBase;

   strncpy(hw->vgaInfoChipset, vga256InfoRec.chipset, 80);
   hw->vgaInfoChipset[79] = 0;

   hw->vgaBitsPerPixel = vgaBitsPerPixel;
   hw->vgaLinearSize = vgaLinearSize;
   hw->xf86PixmapCacheMemoryStart = xf86AccelInfoRec.PixmapCacheMemoryStart;
   hw->xf86PixmapCacheMemoryEnd = xf86AccelInfoRec.PixmapCacheMemoryEnd;   
   hw->xf86PCIFlags = xf86PCIFlags;
   hw->MGAdacIsHWCursor = MGAdac.isHwCursor;
   hw->MGAPciTag = MGAPciTag;
   hw->MGAchipset = MGAchipset;
   hw->MGAydstorg = MGAydstorg;
   hw->MGAUsePCIRetry = MGAUsePCIRetry;
   hw->mgaglx_dma = mgaglx.dmaDriver;
   hw->mgaglx_dmaadr = mgaglx.dmaAdr;
   hw->mgaglx_dmasize = mgaglx.dmaSize;
   hw->mgaglx_cmdsize = mgaglx.cmdSize;
   hw->mgaglx_cardcmds = mgaglx.cardCmds;
   hw->mgaglx_systemtexture = mgaglx.systemTexture;

   hw->mgaActiveDmaBuffer = mgaActiveDmaBuffer;
   hw->glx_first_visual = __glx_first_visual;

   reply.type=X_Reply;
   reply.sequenceNumber = client->sequence;
   reply.length=0;
   reply.n=l=(sizeof(*hw)+3)/4;

   WriteToClient(client, sizeof(xGLXGetStringReply), (char*)&reply);
   WriteToClient(client, sizeof(int)*l, (char*)hw);

   return client->noClientException;
}



static int mgaGLXReleaseDirect( ClientPtr client )
{
   if (__glx_is_server && direct_client && direct_client == client) {
      direct_client = 0;
      return Success;
   }

   return BadAccess;
}




/* =======================================================================
 * Dma flush
 */
typedef struct  {
   CARD32 dma_primaryDwords;
   CARD32 dma_buffer_id;	/* validation only */
   CARD32 dma_sync;
} DmaFlushReq;


typedef struct {
    BYTE type;
    CARD8 xpad;
    CARD16 sequenceNumber;
    CARD32 length;
    CARD32 dma_buffer_id;	/* new active id */   
} DmaFlushReply;

static int flushed = 0;



static int mgaGLXDirectDMAFlush( ClientPtr client, 
				 xGLXVendorPrivateReq *stuff )
{
   DmaFlushReq *vp = (DmaFlushReq *)(stuff + 1);
   xReply reply;
   DmaFlushReply *rep = (DmaFlushReply *)&reply;	
   extern void mgaServerDmaFlush( int );


   if (client != direct_client) 
      return BadAccess;

   if ( mgaActiveDmaBuffer != vp->dma_buffer_id ) 
   {
      mgaError("someone's been playing with dma on the server\n");
      return BadImplementation;
   }

   dma_buffer->primaryDwords = vp->dma_primaryDwords;

   mgaServerDmaFlush( vp->dma_sync );

   rep->type = X_Reply;
   rep->length = 0;	
   rep->sequenceNumber = client->sequence;
   rep->dma_buffer_id = mgaActiveDmaBuffer;
   
   WriteToClient( client, sizeof(xReply), (char *) &reply );
	
   return client->noClientException;
}


static void mgaClientDMAFlush( int wait ) 
{
   if ( 1 ) {
      DmaFlushReq vp;
      xReply reply;

      vp.dma_buffer_id = mgaActiveDmaBuffer;
      vp.dma_primaryDwords = dma_buffer->primaryDwords;
      vp.dma_sync = wait;
      flushed = !wait;

      if (send_vendor_private( X_GLXMgaDmaFlush,
			       (char *)&vp, sizeof(vp), 
			       &reply, 0, 0 ))
      {
	 DmaFlushReply *rep = (DmaFlushReply *)&reply;
	 mgaActiveDmaBuffer = rep->dma_buffer_id;
      }
   } else if (wait) {

      if (!flushed) {
	 /* These cause lockups when a direct client starts with warp.  */
	 return;
      }

      if (MESA_VERBOSE & VERBOSE_DRIVER)
	 fprintf(stderr, "\n\nprimary dwords: %d\n",
	      dma_buffer->primaryDwords );

      mgaWaitForDmaCompletion();
   }

   mgaDmaResetBuffer();
}


/* =======================================================================
 * Geometry request 
 *   - could just use XGetGeom, but this is simpler, really.
 */
typedef struct  {
   CARD32 drawable;
} FBGeomReq;


typedef struct {
   BYTE type;
   CARD8 xpad;
   CARD16 sequenceNumber;
   CARD32 length;
   CARD16 width;
   CARD16 height;
} FBGeomReply;


static int mgaGLXDirectGetGeometry( ClientPtr client, 
				    xGLXVendorPrivateReq *stuff )
{
   xReply reply;
   DrawablePtr frontbuf;
   FBGeomReq *vp = (FBGeomReq *)(stuff + 1);
   FBGeomReply *rep = (FBGeomReply *)&reply;	

   if (client != direct_client) 
      return BadAccess;

   frontbuf = LookupIDByClass( vp->drawable, RC_DRAWABLE );   
   if (!frontbuf) 
      return GLXBadDrawable;

   rep->type = X_Reply;
   rep->length = 0;	
   rep->sequenceNumber = client->sequence;
   rep->width = frontbuf->width;
   rep->height = frontbuf->height;
   
   WriteToClient( client, sizeof(xReply), (char *) &reply );
	
   return client->noClientException;
}


void mgaClientGetGeometry( DrawablePtr d ) 
{
   FBGeomReq vp;
   xReply reply;

   vp.drawable = d->id;    
   
   if (send_vendor_private( X_GLXMgaFBGeom,
			    (char *)&vp, sizeof(vp), 
			    &reply, 0, 0 ))
   {
      FBGeomReply *rep = (FBGeomReply *)&reply;
      d->width = rep->width;
      d->height = rep->height;
   }
}




/* ===========================================================================
 * Buffer swap
 *   - Combines dma flush, buffer swap and get geometry.
 */

/* Need to issue the swap commands from the server as the client
 * doesn't have the clip rects.  This isn't so bad as we would want to
 * do a dma flush immediately afterwards anyhow.
 */
typedef struct {
   CARD16 back_width;
   CARD16 back_height;
   CARD16 back_pitch;
   CARD16 notused;		/* not needed either */
   CARD32 back_setup[MGA_SETUP_SIZE];
   CARD32 back_setup_size;
   CARD32 front_drawable;
   CARD32 dma_primaryDwords;
   CARD32 dma_secondaryDwords;	/* only needed for performance boxes */
   CARD32 dma_buffer_id;	/* validation only */
   CARD32 attrib;
   CARD32 flag;
} SwapBufferReq;

typedef struct {
   BYTE type;
   CARD8 xpad;
   CARD16 sequenceNumber;
   CARD32 length;
   CARD32 dma_buffer_id;	/* new active id */   
   CARD16 width;
   CARD16 height;
} SwapBufferReply;

#define FLG_TEX_SWAP 0x1

static int mgaGLXDirectSwapBuffers( ClientPtr client, 
				    xGLXVendorPrivateReq *stuff )
{
   SwapBufferReq *vp = (SwapBufferReq *)(stuff+1);
   xReply reply;
   SwapBufferReply *rep = (SwapBufferReply *)&reply;	
   mgaBufferPtr old = mgaDB;
   mgaBuffer backbuf;
   DrawablePtr frontbuf;
   int i;

   if (client != direct_client) 
      return BadAccess;

   if ( mgaActiveDmaBuffer != vp->dma_buffer_id ) 
   {
      fprintf(stderr, "somebody's been playing with dma on the server %d %ld\n",
	      mgaActiveDmaBuffer, vp->dma_buffer_id);

      return BadImplementation;
   }

   dma_buffer->primaryDwords = vp->dma_primaryDwords;

   frontbuf = LookupIDByClass( vp->front_drawable, RC_DRAWABLE );   

   if (!frontbuf) {
      return GLXBadDrawable;
   }

   backbuf.magic = mgaBufferMagic; 
   backbuf.Width = vp->back_width;
   backbuf.Height = vp->back_height;
   backbuf.Pitch = vp->back_pitch;
   backbuf.Attrib = vp->attrib;

   for (i = 0 ; i < MGA_SETUP_SIZE ; i++)
      backbuf.Setup[i] = vp->back_setup[i];

   backbuf.SetupSize = vp->back_setup_size;

   if (vp->flag & FLG_TEX_SWAP) mgaglx.c_textureSwaps++;

   mgaDB=&backbuf;
   dma_buffer->secondaryDwords = vp->dma_secondaryDwords;
   mgaPerformanceBoxes( 1 );
   dma_buffer->secondaryDwords = 0;
   mgaDB=old;

   mgaBackToFront(frontbuf, &backbuf);   
   mgaDmaFlush();

   rep->type = X_Reply;
   rep->length = 0;	
   rep->sequenceNumber = client->sequence;
   rep->dma_buffer_id = mgaActiveDmaBuffer;
   rep->width = frontbuf->width;
   rep->height = frontbuf->height;

   WriteToClient( client, sizeof(xReply), (char *) &reply );

   return client->noClientException;
}

static void mgaClientSwapBuffers( XSMesaBuffer b ) 
{
   SwapBufferReq vp;
   xReply reply;
   mgaBufferPtr buf;
   int i;

   if (!b->db_state || 
       !b->backimage ||
       !(buf = (mgaBufferPtr)b->backimage->devPriv))
   {
      fprintf(stderr, "client swap buffers: wtf???\n");
      return;
   }
   
   if (mgaCtx && mgaCtx->gl_ctx) {
      FLUSH_VB(mgaCtx->gl_ctx, "mga client swap buffers");
   }

   mgaWarpFinishSerie();
   mgaglx.warp_serieStart = 0;
   mgaglx.warp_occupied = 0;
   mgaglx.swapBuffersCount++;

   vp.front_drawable = b->frontbuffer->id;    
   vp.back_width = buf->Width;
   vp.back_height =  buf->Height;
   vp.back_pitch = buf->Pitch;
   vp.attrib = buf->Attrib;
   vp.back_setup_size = buf->SetupSize;
   
   for (i = 0 ; i < MGA_SETUP_SIZE ; i++)      
      vp.back_setup[i] = buf->Setup[i];

   vp.dma_buffer_id = mgaActiveDmaBuffer;
   vp.dma_primaryDwords = dma_buffer->primaryDwords;
   vp.dma_secondaryDwords = dma_buffer->secondaryDwords;
   vp.flag = 0;

   flushed = 1;

   if (mgaglx.c_textureSwaps) {
      vp.flag |= FLG_TEX_SWAP;
      mgaglx.c_textureSwaps = 0;
   }

   if (send_vendor_private( X_GLXMgaSwapBuffers,
			    (char *)&vp, sizeof(vp), &reply, 0, 0 ))
   {
      SwapBufferReply *rep = (SwapBufferReply *)&reply;

      b->frontbuffer->width = rep->width;
      b->frontbuffer->height = rep->height;

      mgaActiveDmaBuffer = rep->dma_buffer_id;
      mgaDmaResetBuffer();
   }
   else
      FatalError("clientSwapBuffers failed");
}







/* ===========================================================================
 */

int mgaGLXVendorPrivate( ClientPtr client,
			 XSMesaContext ctx, 
			 xGLXVendorPrivateReq *stuff )
{
   if (!__glx_is_server) 
      return GLXUnsupportedPrivateRequest;

   switch (stuff->opcode) {
   case X_GLXDirectGoDirect:
      return mgaGLXGoDirect( client );
   case X_GLXDirectRelease:
      return mgaGLXReleaseDirect( client );
   case X_GLXMgaSwapBuffers:
      return mgaGLXDirectSwapBuffers( client, stuff );
   case X_GLXMgaDmaFlush:
      return mgaGLXDirectDMAFlush( client, stuff );
   case X_GLXMgaFBGeom:
      return mgaGLXDirectGetGeometry( client, stuff );
   }

   mgaError("not-handled case");
   return GLXUnsupportedPrivateRequest;
}


int mgaGLXAllowDirect( ClientPtr client )
{
   if (mgaglx.dmaDriver < 2) {
      mgaError("Don't allow direct clients with pseudo-dma");
      return 0;
   }

   return 1;
}

