#ifndef MGA_DIRECT_H
#define MGA_DIRECT_H

#include "xsmesa.h"

extern int __glx_is_server;

extern int mgaGLXVendorPrivate( ClientPtr client,
				XSMesaContext ctx, 
				xGLXVendorPrivateReq *stuff );


extern int mgaGLXAllowDirect( ClientPtr client );


extern void mgaClientGetGeometry( DrawablePtr b );

#endif




