/* -*- mode: C; c-basic-offset:8 -*- */
/*
 * GLX Hardware Device Driver for Matrox G200/G400
 * Copyright (C) 1999 Jeff Hartmann
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * JEFF HARTMANN, OR ANY OTHER CONTRIBUTORS BE LIABLE FOR ANY CLAIM, 
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR 
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE 
 * OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *
 * original by Jeff Hartmann <slicer@ionet.net>
 * 6/16/99: rewrite by John Carmack <johnc@idsoftware.com>
 */

#include <stdlib.h>
#include <errno.h>
#include <unistd.h>
#include <sys/mman.h>
#include <stdio.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>
#if defined(__i386__) && !defined(__FreeBSD__)
#include <asm/sigcontext.h>
#endif

#include "mm.h"
#include "mgabuf.h"
#include "mgadd.h"
#include "g200_mac.h"
#include "mgalib.h"
#include "mgalog.h"
#include "mgadirect.h"
#include "mgawarp.h"
#include "mgastate.h"

#include "pb.h"

/* public vars */
mgaDma_buffer	*dma_buffer;			/* dmaBuffers[ activeDmaBuffer ] */


/* This will be overwritten from the default values when glx.so is
 * loaded on the client.
 */
void mgaServerDmaFlush( int wait );
void    (*mgaDoDmaFlush)( int ) = mgaServerDmaFlush;
mgaUI32	mgaActiveDmaBuffer = 0;	



static	mgaUI32	registersLocked;		/* true when the registers are memory protected */

static void UnlockRegisters( void );
void mgaDmaResetBuffer( void );
static void mgaFlushPseudoDma( void );

void MgaSetSyncBusy( void ) { 
	/* set the DWGSYNC register to our magic value */
	OUTREG( MGAREG_DWGSYNC, SYNC_DMA_BUSY );
	while ( INREG( MGAREG_DWGSYNC ) != SYNC_DMA_BUSY ) {
		/* X might have left something drawing */
	}
}

static void delay( void ) {
}

/*
 * mgaWaitForDmaCompletion
 *
 */
#define	TIMEOUT_USEC 1000000

int mgaWaitForDmaCompletion( void ) {
	int		primAdr;
	int         i;
	int		startTime;
	int		curTime;
	int             iters = 0;

	if ( mgaglx.skipDma ) {
		return 0;
	}
	
	startTime = 0;
	curTime = 0;
	while ( 1 ) {
		primAdr = INREG( MGAREG_DWGSYNC );
		if ( primAdr != SYNC_DMA_BUSY ) {
			break;
		}

		iters++;
		curTime = usec();
		if ( startTime == 0 || curTime < startTime /*wrap case*/) {
			startTime = curTime;
		} else if ( curTime - startTime > TIMEOUT_USEC ) { 
			mgaMsg( 1, "waitForDmaCompletion timed out\n" );
			break;
		}

		/* spin in place a bit so we aren't hammering the register */
		for ( i = 0 ; i < 10000 ; i++ ) {
			delay();
		}
	}

	mgaMsg( 10, "waitForDmaCompletion, usec: %d\n", curTime - startTime );
	if ( !(INREG(MGAREG_STATUS) & STAT_endprdmasts_enable) ) {
		mgaMsg( 1, "waitForDmaCompletion: still going!\n" );
	}

	if ( registersLocked ) {
		UnlockRegisters();
	}

	return iters;
}

/*
 * mgaDmaResetBuffer
 */
void mgaDmaResetBuffer() {
	dma_buffer = dmaBuffers[ mgaActiveDmaBuffer ];
	dma_buffer->primaryDwords = 0;
	dma_buffer->secondaryDwords = 0;

	/* This is required because each dma buffer is finished by a
	 * return to 2d state, as expected by the X server.  Could
	 * alternately do the stuff to make the fallback inside the
	 * signal handler, but this way is nicer if we ever support
	 * multiple direct clients.
	 */
	if (mgaDB && mgaCtx) {		
		if (MESA_VERBOSE&VERBOSE_DRIVER)
			fprintf(stderr, "needEnter3D and ENTER3D in mgaDmaResetBuffer\n");
		mgaCtx->new_state |= MGA_NEW_CONTEXT;
	}
}


static void UnlockRegisters( void ) {
	mprotect( MGAMMIOBase, 0x3000, PROT_READ | PROT_WRITE );
	registersLocked = 0;
}

#if defined(__i386__) && !defined(__FreeBSD__)
static void RegisterAccessSignalHandler( int signal, struct sigcontext sc) {
	if(((void *)sc.cr2 < (void *)MGAMMIOBase )||
	   ((void *)sc.cr2 > (void *)(MGAMMIOBase + 0x3000))){
		/* Oops, a real segmentation fault. This might be a good place
		 * to set a breakpoint */
		FatalError("Segmentation fault!\n");
	}
#else
static void RegisterAccessSignalHandler( int signal) {
#endif  
	if ( !registersLocked ) {
		mgaMsg( 10, "RegisterAccessSignalHandler() without registersLocked\n" );
		FatalError("RegisterAccessSignalHandler() without registersLocked\n");
	}
	
	/* someone has tried to access hardware registers, so make
           sure dma is completed */
	mgaMsg( 10, "RegisterAccessSignalHandler()\n" );
	mgaglx.c_signals++;
	mgaWaitForDmaCompletion();
	mgaMsg( 10, "Leaving RASH()\n" );
}

static void LockRegisters( void ) {
	/* cause a SIGSEGV if the X server tries to write a hardware register */
	mprotect( MGAMMIOBase, 0x3000, /* PROT_NONE */ PROT_READ );
#ifndef __FreeBSD__
	signal( SIGSEGV, RegisterAccessSignalHandler );
#else
	signal( SIGBUS, RegisterAccessSignalHandler );
#endif
	registersLocked = 1;
}

int	xchangeDummy;

#ifndef NO_MTRR
static void FlushWriteCombining( void ) {
#ifdef USE_X86_ASM
	__asm__ volatile( " push %%eax ; xchg %%eax, %0 ; pop %%eax" : : "m" (xchangeDummy));
	__asm__ volatile( " push %%eax ; push %%ebx ; push %%ecx ; push %%edx ; movl $0,%%eax ; cpuid ; pop %%edx ; pop %%ecx ; pop %%ebx ; pop %%eax" : /* no outputs */ :  /* no inputs */ );
#endif
}
#endif

/*
 * mgaFlushRealDma
 */
void mgaFlushRealDma( void ) {
	int		count;
	mgaUI32	dmaEnd;

	if ( mgaglx.skipDma ) {
		return;
	}
	mgaMsg( 11, "mgaFlushRealDma()\n" );

#ifndef	NO_MTRR
	/* make sure any write combining data is flushed */
	FlushWriteCombining();
#endif

	/* if we are using a card memory buffer, do a read to 
	   guarantee the store buffer is flushed */
	xchangeDummy = dma_buffer->virtualAddress[dma_buffer->primaryDwords];

	/* program the physical registers to start dma going */
	count = dma_buffer->primaryDwords;
	dmaEnd = dma_buffer->physicalAddress + count*4;

	OUTREG( MGAREG_PRIMADDRESS, dma_buffer->physicalAddress );
	OUTREG( MGAREG_PRIMEND, dmaEnd | use_agp);

	/* if we are going to run async, throw a signal if X tries to use
	the hardware registers */
	if ( mgaglx.dmaDriver == 3 ) {
		LockRegisters();
	}
}

/*
 * mgaDmaFlush
 * Send all pending commands off to the hardware.
 * If we are running async, the hardware will be drawing
 * while we return to do other things.
 */
void mgaServerDmaFlush( int wait ) {
	int		start, end;
	DMALOCALS;

	/* if the buffer only contained an ENTER3D, just change in place */
	if ( !dma_buffer->primaryDwords ) {
		if (wait)
			mgaWaitForDmaCompletion();

		mgaDmaResetBuffer();
		return;
	}

	mgaglx.c_dmaFlush++;
	
	if ( registersLocked ) {
		UnlockRegisters();
	}

	/* wait for the last buffer to complete */
	if ( !mgaWaitForDmaCompletion() ) {
		mgaglx.hardwareWentIdle = 1;
	}

	MgaSetSyncBusy();


	/* Add the commands at the end of the buffer to go back to
	 * drawing on the front buffer the way the X server expects.
	 */
	memcpy(dma_buffer->virtualAddress + dma_buffer->primaryDwords, 
		mgaFrontBuffer->Setup, 
		sizeof(mgaUI32) * mgaFrontBuffer->SetupSize);
	dma_buffer->primaryDwords += mgaFrontBuffer->SetupSize;
	

	/* add a draw sync command at the end so we can tell when dma is done */
	MGADMAGETPTR( 4 );
	DMAOUTREG( MGAREG_DMAPAD, 0 );
	DMAOUTREG( MGAREG_DMAPAD, 0 );
	DMAOUTREG( MGAREG_DMAPAD, 0 );
	DMAOUTREG( MGAREG_DWGSYNC, 0 );
	DMAADVANCE();

	/* collect timing information if we are going syncronously */
	if ( mgaglx.dmaDriver != 3 ) {
 		start = usec();
 	} else {
 		start = end = 0;
 	}
 	
 	if ( mgaglx.dmaDriver < 2 ) {
	 	mgaFlushPseudoDma();
	 } else {
 		mgaFlushRealDma();
		if ( mgaglx.dmaDriver == 2 || wait ) {
			/* wait until the dma completes */
			mgaWaitForDmaCompletion();
		}
 	}
 

 	if ( mgaglx.dmaDriver != 3 ) {
		end = usec();
	}

	mgaMsg(9, "flushmode %i, buffer %i: prim dwords:%i  sec dwords:%i  usec:%i\n", 
		mgaglx.dmaDriver,  mgaActiveDmaBuffer,
		dma_buffer->primaryDwords,
		dma_buffer->secondaryDwords, end - start );	

	/* swap to using the other buffer */
	mgaActiveDmaBuffer ^= 1;

	mgaDmaResetBuffer();	
}

/*
 * mgaDmaFlush
 */
void mgaDmaFlush( void ) {
	mgaWarpFinishSerie();
	mgaglx.warp_serieStart = 0;
	mgaglx.warp_occupied = 0;

	mgaDoDmaFlush( 0 );
}

/*
 * mgaDmaFinish
 */
void mgaDmaFinish( void ) {
	mgaWarpFinishSerie();
	mgaglx.warp_serieStart = 0;
	mgaglx.warp_occupied = 0;

	mgaDoDmaFlush( 1 );
}



/*
 * mgaDmaOverflow
 * This is called when MGADMAGETPTR is at the end of the buffer
 */
void mgaDmaOverflow( int newDwords ) {
	mgaMsg( 9, "mgaDmaOverflow(%i)\n", newDwords );
	if ( dma_buffer->secondaryDwords > 
	     dma_buffer->maxSecondaryDwords ) {
		FatalError("mgaDmaOverflow():  secondary buffer overflow\n");
	}

	/* flush all the current commands so we will have another
           empty buffer */
	mgaDmaFlush();

	/* Overflow can happen anywhere, so normal update mechanisms
	 * aren't sufficient.  FIXME: this may be a problem if
	 * texture upload caused the overflow, because the updateHwState
	 * may cause recursion into it...
	 */
	if (mgaCtx) {
		mgaCtx->new_state |= MGA_NEW_CONTEXT;
		mgaDDUpdateHwState( mgaCtx->gl_ctx );
	}

	mgaglx.c_overflows++;
	if ( newDwords > dma_buffer->maxPrimaryDwords ) {
 		FatalError("mgaDmaOverflow > maxPrimaryDwords");
	}
}

/*
 * mgaWaitDrawingEngine
 * This will not return until the drawing engine has completed
 * drawing pixels and it is safe to read or write the framebuffer
 * for software rendering.
 */
int mgaWaitDrawingEngine( void ) {
	/* note this for the performance block display */
	mgaglx.c_drawWaits++;

	/* make sure all pending dma has completed */
	mgaDmaFinish();

	return 0;
}



/* secondary dma is for ILOAD and VERTEX transfers, and can be properly
   simulated with pseudo dma if needed.  The data pointer should be from
   a previous mgaAllocSecondaryBuffer() */
void mgaSecondaryDma( transferType_t transferType, mgaUI32 *data, int dwords ) {
	int		base;
	int		offset;
	DMALOCALS;

	if ( data < dma_buffer->virtualAddress + dma_buffer->maxPrimaryDwords ) {
		FatalError( "mgaSecondaryDma error: below start\n" );
	}
	
	if ( dwords <= 0 ) {
		FatalError( "mgaSecondaryDma error: dwords <= 0\n" );
	}

	if ( transferType & ~3 ) {
		FatalError( "mgaSecondaryDma error: bad transferType\n" );
	}
	
	if ( data - dma_buffer->virtualAddress + dwords > 
	     dma_buffer->maxSecondaryDwords + dma_buffer->maxPrimaryDwords ) {
		FatalError( "mgaSecondaryDma error: past end\n" );
	}
	
	/* add dma commands to start a secondary dma channel */

	offset = (char *)data - (char *)dma_buffer->virtualAddress;
	mgaMsg( 9, "mgaSecondaryDma: %i, %i\n", offset, dwords * 4 );
	
	base = dma_buffer->physicalAddress + offset;
		
	MGADMAGETPTR(5);

	DMAOUTREG(MGAREG_SECADDRESS, ( base | transferType ) );
	DMAOUTREG(MGAREG_SECEND, ( ( base + dwords*4 ) | use_agp ) );

	/* don't pad the extra registers, because when secondary dma ends,
	it will always fetch a new quad */
	DMAADVANCECHOP();
}

extern ClientPtr direct_client;  
/*
 * mgaDmaExecute
 * Add a block of data to the dma buffer
 */
void mgaDmaExecute( mgaUI32 *code, int dwords ) {
  
  if (!direct_client)
  {    
	CHECK_CONTEXT( \
		mgaError("Context not valid in mgaDmaExecute(). %d %d\n", VALID_MGA_CONTEXT(mgaCtx), VALID_MGA_BUFFER(mgaDB)); \
		mgaDmaResetBuffer(); \
		return; \
	);
  }
  
	if( (dma_buffer->maxPrimaryDwords - dma_buffer->primaryDwords) < dwords)
	{
		 mgaDmaFlush();
	}
	memcpy( dma_buffer->virtualAddress + dma_buffer->primaryDwords, 
		code, sizeof(mgaUI32) * dwords );
	dma_buffer->primaryDwords += dwords;
}



/*
 * mgaFlushPseudoDma
 * Hand feed a dma buffer to the card, simulating secondary dma as needed.
 * This will parse the buffer even if skipdma is set, allowing safe
 * range checking.
 */
static void mgaFlushPseudoDma( void ) {
	mgaUI32	save;
	mgaUI32	*src, *p;
	int	i, j;
	int	mode;
	int	dwords;
	int	count;

	count = dma_buffer->primaryDwords;

	mgaMsg( 20, "primary pseudoDma: %i dwords\n", count );
	
	mgaglx.hardwareWentIdle = 1;
	
	if ( !mgaglx.skipDma ) {
		save = INREG(MGAREG_OPMODE);
		OUTREG( MGAREG_OPMODE,(save & OM_dmamod_MASK) | (TT_GENERAL<<2) );
	}
  
	p = pseudoDmaVirtual;
	
  	src = dma_buffer->virtualAddress;
	for ( i = 0 ; i < count ; ) {
		src = dma_buffer->virtualAddress + i;
		
		/* check for a secondary dma start */
		if ( *(mgaUI8 *)src == ADRINDEX(MGAREG_SECADDRESS) ) {
			mgaUI32	start, end;
			
			start = src[1];
			end = src[2];

			mode = start & 3;
			start = ( start & ~3 ) - dma_buffer->physicalAddress;
			end = ( end & ~3 ) - dma_buffer->physicalAddress;
			
			if ( ( start >> 2 ) < dma_buffer->maxPrimaryDwords ) {
				FatalError( "mgaFlushPseudoDma: start before buffer: %i", start );
			}
						
			if ( ( end >> 2 ) > dma_buffer->maxSecondaryDwords + dma_buffer->maxPrimaryDwords ) {
				FatalError( "mgaFlushPseudoDma: end after buffer: %i", end );
			}
			
			if ( start >= end ) {
				FatalError( "mgaFlushPseudoDma: start >= end: %i, %i", start, end );
			}
			
			dwords = ( end - start ) >> 2;
			
			src = dma_buffer->virtualAddress + ( start >> 2 );
			
			mgaMsg( 20, "secondary pseudoDma: %i dwords, mode %i\n", dwords, mode );

			if ( !mgaglx.skipDma ) {			
				OUTREG( MGAREG_OPMODE,(save & OM_dmamod_MASK) | (mode<<2) );

				for ( j = 0 ; j < dwords ; j++ ) {
					p[j] = src[j];
				}
					
				/* we will fetch a new general index word immediately */
				OUTREG( MGAREG_OPMODE,(save & OM_dmamod_MASK) | (TT_GENERAL<<2) );
			}
			i += 3;
			continue;
		}
		
		if ( !mgaglx.skipDma ) {
			p[0] = src[0];
			p[1] = src[1];
			p[2] = src[2];
			p[3] = src[3];
			p[4] = src[4];
		}
		
		i += 5;
		if ( i > count ) {
			FatalError( "mgaFlushPseudoDma: didn't end with a full quad" );
		}
	}

	if ( !mgaglx.skipDma ) {
		OUTREG(MGAREG_OPMODE,save);
	}
}
















