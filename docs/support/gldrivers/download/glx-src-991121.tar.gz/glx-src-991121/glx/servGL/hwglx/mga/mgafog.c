/*
 * GLX Hardware Device Driver for Matrox Millenium G200
 * Copyright (C) 1999 Wittawat Yamwong
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * WITTAWAT YAMWONG, OR ANY OTHER CONTRIBUTORS BE LIABLE FOR ANY CLAIM, 
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR 
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE 
 * OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *
 *    Wittawat Yamwong <Wittawat.Yamwong@stud.uni-hannover.de>
 */

/* $Id: mgafog.c,v 1.4 1999/11/01 01:09:38 johnc Exp $ */

#include <math.h>

#include "mesaglx/types.h"
#include "mesaglx/macros.h"

#include "g200_mac.h"
#include "mgalib.h"
#include "mgafog.h"

static float NoFog(mgaContextPtr ctx, float z)
{
  return 1.0F;
}

static float LinearFactor(mgaContextPtr ctx, float z)
{
  return CLAMP((ctx->Fog.Const2 - abs(z)) * ctx->Fog.Const1, 0.0F, 1.0F);
}

static float ExpFactor(mgaContextPtr ctx, float z)
{
  return exp(ctx->Fog.Const1 * abs(z));
}

static float Exp2Factor(mgaContextPtr ctx, float z)
{
  return exp(ctx->Fog.Const1 * z*z);
}

void mgaInitFogAttrib(mgaFogAttribPtr fa)
{
  fa->Factor = NoFog;
  fa->Apply = 0;
}

void mgaUpdateFogAttrib(mgaContextPtr ctx)
{
  GLcontext *gl_ctx = ctx->gl_ctx;
  if (gl_ctx->Fog.Enabled && gl_ctx->FogMode == FOG_FRAGMENT) {
    switch (gl_ctx->Fog.Mode) {
    case GL_LINEAR:
      ctx->Fog.Const1 = 1.0F/(gl_ctx->Fog.End - gl_ctx->Fog.Start);
      ctx->Fog.Const2 = gl_ctx->Fog.End;
      ctx->Fog.Factor = LinearFactor;
      break;
    case GL_EXP:
      ctx->Fog.Const1 = -gl_ctx->Fog.Density;
      ctx->Fog.Factor = ExpFactor;
      break;
    case GL_EXP2:
      ctx->Fog.Const1 = -gl_ctx->Fog.Density*gl_ctx->Fog.Density;
      ctx->Fog.Factor = Exp2Factor;
      break;
    default:
      ctx->Fog.Factor = NoFog;
      break;
    }
    ctx->Fog.Color = MGAPACKCOLOR888((mgaUI8)(gl_ctx->Fog.Color[0]*255.0F), \
				     (mgaUI8)(gl_ctx->Fog.Color[1]*255.0F), \
				     (mgaUI8)(gl_ctx->Fog.Color[2]*255.0F));
    ctx->Fog.Apply = 1;
    ctx->DB->Setup[MGA_SETUP_MACCESS] |= MA_fogen_enable;
  } else {
    ctx->Fog.Factor = NoFog;
    ctx->Fog.Apply = 0;
    if (ctx->DB)
      ctx->DB->Setup[MGA_SETUP_MACCESS] &= ~MA_fogen_enable;
  }
}
