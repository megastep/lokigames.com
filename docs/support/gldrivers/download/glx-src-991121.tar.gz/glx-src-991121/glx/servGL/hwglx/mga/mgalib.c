/*
 * GLX Hardware Device Driver for Matrox Millenium G200
 * Copyright (C) 1999 Wittawat Yamwong
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * WITTAWAT YAMWONG, OR ANY OTHER CONTRIBUTORS BE LIABLE FOR ANY CLAIM, 
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR 
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE 
 * OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *
 *    Wittawat Yamwong <Wittawat.Yamwong@stud.uni-hannover.de>
 */

/* $Id: mgalib.c,v 1.4 1999/09/30 11:05:53 keithw Exp $ */

#include <unistd.h> /* for usleep() */
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>
#include <sys/mman.h>
#include <stdio.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>

#include "mesaglx/types.h" /* DEPTH_BITS */

#include "g200_mac.h"
#include "mm.h"
#include "mgalib.h"
#include "mgalog.h"
#include "mgawarp.h"

mgaBufferPtr mgaDB = NULL;
mgaBufferPtr mgaFrontBuffer = NULL;
mgaContextPtr mgaCtx = NULL;

int	usec( void ) {
	struct timeval tv;
	struct timezone tz;
	
	gettimeofday( &tv, &tz );
	
	return (tv.tv_sec & 2047) * 1000000 + tv.tv_usec;
}


void mgaSoftReset()
{
  /* 
   * Soft reset 
   * This will reset 3D engine. If you don't do this, 3D drawing may not work
   * correctly. (esp. line with depth)
   * I have to do soft reset every time I turn on my computer.
   * If you don't use 3d line, everything should be ok w/o reset.
   */
  OUTREG(MGAREG_RST, R_softreset_enable);
  usleep(20); /* in spec. minimum 10us */
  OUTREG(MGAREG_RST, R_softreset_disable);
}

/*
 * - Palette format is TW16 (RGB565)
 * - pal MUST be padded as follow: sizeof(pal) = (len+1)/2 dword
 * - After the call you must reprogramm MACCESS and PITCH. It depends on
 *   which context you are in. (ie 2D or 3D)
 */
void mgaLoadTexturePalette(mgaUI16 *pal, mgaUI8 start, mgaUI16 len)
{
  DMALOCALS;
  int n;
  mgaUI32 *data = (mgaUI32 *) pal;

  MGADMAGETPTR( 16 + len/2);
  
  DMAOUTREG(MGAREG_AR0,len-1);
  DMAOUTREG(MGAREG_AR3,0);
  MGADMA_PITCH(1024);
  MGADMA_YDSTLEN(start,len);
  DMAOUTREG(MGAREG_YDSTORG,0);
  DMAOUTREG(MGAREG_FXBNDRY,0);
  DMAOUTREG(MGAREG_MACCESS,MA_pwidth_16 | MA_tlutload_enable);
  MGADMA_DWGCTL_EXEC(DC_opcod_iload | DC_atype_rstr | DC_linear_linear |
		  DC_shftzero_enable | DC_sgnzero_enable | 
		     (0xc << DC_bop_SHIFT) | DC_bltmod_bfcol);
  DMAADVANCE();
  for (n=0; n<((len+1)/2); n++)
    DMAOUTREG(MGAREG_DMAPAD, data[n]);
  DMAADVANCE();

  MGADMAGETPTR( 10 );
  mgaMsg(7, "mgaLoadTexturePalette: mgaFrontBuffer = %d\n", mgaFrontBuffer);
  DMAOUTREG(MGAREG_YDSTORG,MGAydstorg); /* for X server */
  if ( mgaFrontBuffer ) {
  	DMAOUTREG(MGAREG_MACCESS,mgaFrontBuffer->Setup[MGA_SETUP_MACCESS]);
  	DMAOUTREG(MGAREG_PITCH,mgaFrontBuffer->Setup[MGA_SETUP_PITCH]);
  } else {
	DMAOUTREG(MGAREG_PITCH,mgaDB->Setup[MGA_SETUP_PITCH]);
    	DMAOUTREG(MGAREG_MACCESS,mgaDB->Setup[MGA_SETUP_MACCESS]);
  }
  DMAADVANCE();
  mgaWaitDrawingEngine();
}

      
