#ifndef _MGA_SPAN_H
#define _MGA_SPAN_H

extern void mgaDDInitSpans( GLcontext *ctx );

#endif
