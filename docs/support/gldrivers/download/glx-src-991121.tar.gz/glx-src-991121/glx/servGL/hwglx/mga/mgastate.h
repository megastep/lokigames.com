#ifndef _MGA_STATE_H
#define _MGA_STATE_H


extern void mgaDDInitStatePointers(GLcontext *ctx);
extern void mgaDDUpdateHwState( GLcontext *ctx );
extern void mgaDDUpdateState( GLcontext *ctx );
extern void mgaDDReducedPrimitiveChange( GLcontext *ctx, GLenum prim );



#endif
