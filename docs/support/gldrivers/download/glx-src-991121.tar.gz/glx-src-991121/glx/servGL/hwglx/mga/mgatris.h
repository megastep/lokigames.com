/* $Id: mgatris.h,v 1.4 1999/09/30 11:05:53 keithw Exp $ */
/*
 * GLX Hardware Device Driver for Matrox Millenium G200
 * Copyright (C) 1999 Wittawat Yamwong
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * WITTAWAT YAMWONG, OR ANY OTHER CONTRIBUTORS BE LIABLE FOR ANY CLAIM, 
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR 
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE 
 * OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *
 *    Wittawat Yamwong <Wittawat.Yamwong@stud.uni-hannover.de>
 */

#ifndef MGATIS_INC
#define MGATIS_INC

#include "mesaglx/types.h"

extern void mgaDDChooseRenderState(GLcontext *ctx);
extern void mgaDDTrifuncInit();


/* Todo: 
 *    - multidraw, ...
 *    - Antialiasing (?)
 *    - line and polygon stipple
 *    - select and feedback 
 *    - stencil 
 *    - point parameters
 *    - 
 */
#define MGA_ANTIALIAS_BIT   0       /* ignored for now, no fallback */
#define MGA_FLAT_BIT	0x1
#define MGA_OFFSET_BIT	0x2	/* 3.1 only */
#define MGA_TWOSIDE_BIT	0x4	/* 3.1 only */
#define MGA_NODRAW_BIT	0x8
#define MGA_FALLBACK_BIT	0x10

/* Not in use:
 */
#define MGA_FEEDBACK_BIT    0x20
#define MGA_SELECT_BIT      0x40
#define MGA_POINT_PARAM_BIT 0x80	/* not needed? */




static inline void mga_draw_triangle( mga_warp_vertex *v0, 
				      mga_warp_vertex *v1, 
				      mga_warp_vertex *v2 )
{
   mga_warp_vertex *wv = (mga_warp_vertex *)mgaAllocSecondaryBuffer( 3 * 8 );

#if 0
   fprintf(stderr, "mga_draw_triangle( %p, %p, %p )\n", v0, v1, v2);
#endif

#if 0
#define WID 640
#define HI 480
   {
      GLuint print = 0, draw = 1;
      GLfloat area = ((v0->x - v2->x) * (v1->y - v2->y) -
		      (v0->y - v2->y) * (v1->x - v2->x));

      if (v0->x < -.501 || v0->x > WID || v0->y < -.501 || v0->y > HI ||
	  v1->x < -.501 || v1->x > WID || v1->y < -.501 || v1->y > HI ||
	  v2->x < -.501 || v2->x > WID || v2->y < -.501 || v2->y > HI) {
	 fprintf(stderr, "not clipped\n");
	 print = 1;
      } 

      if (area == 0 && ((v0 == v1) || (v1 == v2))) {
	 fprintf(stderr, "zero area %p %p %p\n", v0, v1, v2);
	 draw = 0;
      }

      if (print) {
	 fprintf(stderr,"v0: %f %f %f %f tex: %f %f\n",
		 v0->x, v0->y, v0->z, v0->rhw, v0->tu0, v0->tv0);
	 fprintf(stderr,"v1: %f %f %f %f tex: %f %f\n",
		 v1->x, v1->y, v1->z, v1->rhw, v1->tu0, v1->tv0);
	 fprintf(stderr,"v2: %f %f %f %f tex: %f %f\n",
		 v2->x, v2->y, v2->z, v2->rhw, v2->tu0, v2->tv0);
	 return;
      }
      
      if (!draw) return;
   }
#endif

   wv[0] = *v0;
   wv[1] = *v1;
   wv[2] = *v2;
}


static inline void mga_draw_point( mga_warp_vertex *tmp, float sz )
{
   mga_warp_vertex *wv = (mga_warp_vertex *)mgaAllocSecondaryBuffer(6*8);

   wv[0] = *tmp;
   wv[0].x = tmp->x - sz;
   wv[0].y = tmp->y - sz;

   wv[1] = *tmp;
   wv[1].x = tmp->x + sz;
   wv[1].y = tmp->y - sz;

   wv[2] = *tmp;
   wv[2].x = tmp->x + sz;
   wv[2].y = tmp->y + sz;

   wv[3] = *tmp;
   wv[3].x = tmp->x + sz;
   wv[3].y = tmp->y + sz;

   wv[4] = *tmp;
   wv[4].x = tmp->x - sz;
   wv[4].y = tmp->y + sz;

   wv[5] = *tmp;
   wv[5].x = tmp->x - sz;
   wv[5].y = tmp->y - sz;
}


static inline void mga_draw_line( mga_warp_vertex *tmp0, 
				  mga_warp_vertex *tmp1,
				  float width )
{
   mga_warp_vertex *wv = (mga_warp_vertex *)mgaAllocSecondaryBuffer( 6 * 8 );
   float dx, dy, ix, iy;

   dx = tmp0->x - tmp1->x;
   dy = tmp0->y - tmp1->y;

   ix = width * .5; iy = 0;
   if (dx * dx > dy * dy) {
      iy = ix; ix = 0;
   }

   wv[0] = *tmp0;
   wv[0].x = tmp0->x - ix;
   wv[0].y = tmp0->y - iy;

   wv[1] = *tmp1;
   wv[1].x = tmp1->x + ix;
   wv[1].y = tmp1->y + iy;

   wv[2] = *tmp0;
   wv[2].x = tmp0->x + ix;
   wv[2].y = tmp0->y + iy;
	 
   wv[3] = *tmp0;
   wv[3].x = tmp0->x - ix;
   wv[3].y = tmp0->y - iy;

   wv[4] = *tmp1;
   wv[4].x = tmp1->x - ix;
   wv[4].y = tmp1->y - iy;

   wv[5] = *tmp1;
   wv[5].x = tmp1->x + ix;
   wv[5].y = tmp1->y + iy;
}

#endif
