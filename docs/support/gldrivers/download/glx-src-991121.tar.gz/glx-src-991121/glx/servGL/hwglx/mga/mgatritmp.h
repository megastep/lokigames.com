
static inline void TAG(triangle)( GLcontext *ctx, GLuint e0,
				  GLuint e1, GLuint e2, GLuint pv )
{
   mga_warp_vertex *wv = (mga_warp_vertex *)mgaAllocSecondaryBuffer( 3 * 8 );

   struct vertex_buffer *VB = ctx->VB;
   mgaVertexPtr mgaVB = MGA_DRIVER_DATA(VB)->verts;

   const mga_warp_vertex *v0 = &mgaVB[e0].v.warp;  
   const mga_warp_vertex *v1 = &mgaVB[e1].v.warp;  
   const mga_warp_vertex *v2 = &mgaVB[e2].v.warp;  


#if (IND & MGA_OFFSET_BIT)
   GLfloat offset = ctx->Polygon.OffsetUnits * 1.0/0x10000;
#endif

#if (IND & (MGA_FLAT_BIT|MGA_TWOSIDE_BIT))
   int c0 = *(int *)&mgaVB[pv].v.warp.color; 
   int c1 = c0;
   int c2 = c0;
#endif

   (void) VB;

#if (IND & (MGA_TWOSIDE_BIT|MGA_OFFSET_BIT)) 
   {
      GLfloat ex = v0->x - v2->x;
      GLfloat ey = v0->y - v2->y;
      GLfloat fx = v1->x - v2->x;
      GLfloat fy = v1->y - v2->y;
      GLfloat c = ex*fy-ey*fx;
	 
#if (IND & MGA_TWOSIDE_BIT) 
      {
	 GLuint facing = (c>0.0) ^ ctx->Polygon.FrontBit;
	 GLubyte (*vbcolor)[4] = VB->Color[facing]->data;
	 if (IND & MGA_FLAT_BIT) {
	    MGA_COLOR((char *)&c0,vbcolor[pv]);
	    c2 = c1 = c0;
	 } else {
	    MGA_COLOR((char *)&c0,vbcolor[e0]);
	    MGA_COLOR((char *)&c1,vbcolor[e1]);
	    MGA_COLOR((char *)&c2,vbcolor[e2]);
	 }
      }
#endif
      
#if (IND & MGA_OFFSET_BIT) 
      {
	 if (c * c > 1e-16) {
	    GLfloat factor = ctx->Polygon.OffsetFactor;
	    GLfloat ez = v0->z - v2->z;
	    GLfloat fz = v1->z - v2->z;
	    GLfloat a = ey*fz-ez*fy;
	    GLfloat b = ez*fx-ex*fz;
	    GLfloat ic = 1.0 / c;
	    GLfloat ac = a * ic;
	    GLfloat bc = b * ic;
	    if (ac<0.0F)  ac = -ac;
	    if (bc<0.0F)  bc = -bc;
	    offset += MAX2( ac, bc ) * factor;
	 }
      }
#endif
   }
#endif  

   mgaglx.c_triangles++;

   wv[0] = *v0;
#if (IND & (MGA_FLAT_BIT|MGA_TWOSIDE_BIT))
   *((int *)(&wv[0].color)) = c0;
#endif
#if (IND & MGA_OFFSET_BIT)
   wv[0].z = v0->z + offset;
#endif


   wv[1] = *v1;
#if (IND & (MGA_FLAT_BIT|MGA_TWOSIDE_BIT))
   *((int *)(&wv[1].color)) = c1;
#endif
#if (IND & MGA_OFFSET_BIT)
   wv[1].z = v1->z + offset;
#endif

   wv[2] = *v2;
#if (IND & (MGA_FLAT_BIT|MGA_TWOSIDE_BIT))
   *((int *)(&wv[2].color)) = c2;
#endif
#if (IND & MGA_OFFSET_BIT)
   wv[2].z = v2->z + offset;
#endif

}



static void TAG(quad)( GLcontext *ctx, GLuint v0,
		       GLuint v1, GLuint v2, GLuint v3, 
		       GLuint pv )
{
   TAG(triangle)( ctx, v0, v1, v3, pv );
   TAG(triangle)( ctx, v1, v2, v3, pv );
}


#if ((IND & ~MGA_FLAT_BIT) == 0)

static void TAG(line)( GLcontext *ctx, GLuint v0, GLuint v1, GLuint pv )
{
   mgaVertexPtr mgaVB = MGA_DRIVER_DATA(ctx->VB)->verts;
   mga_warp_vertex tmp0 = mgaVB[v0].v.warp;
   mga_warp_vertex tmp1 = mgaVB[v1].v.warp;
   float width = ctx->Line.Width;

   if (IND & MGA_FLAT_BIT) {
      *(int *)&tmp1.color = *(int *)&tmp0.color = 
	 *(int *)&mgaVB[pv].v.warp.color;
   }

   mga_draw_line( &tmp0, &tmp1, width );
}


static void TAG(points)( GLcontext *ctx, GLuint first, GLuint last )
{
   int i;
   struct vertex_buffer *VB = ctx->VB;
   mgaVertexPtr mgaVB = MGA_DRIVER_DATA(VB)->verts;
   GLfloat sz = ctx->Point.Size * .5;

   /* Culling is disabled automatically via. the
    * ctx->Driver.ReducedPrimitiveChange() callback.  
    */

   for(i=first;i<=last;i++) {
      if(VB->ClipMask[i]==0) {
	 mga_warp_vertex *tmp = &mgaVB[i].v.warp;
	 mga_draw_point( tmp, sz );
      }
   }
}

#endif


static void TAG(init)()
{
   tri_tab[IND] = TAG(triangle);
   quad_tab[IND] = TAG(quad);

#if ((IND & ~MGA_FLAT_BIT) == 0) 
   line_tab[IND] = TAG(line);
   points_tab[IND] = TAG(points);
#endif
}


#undef IND
#undef TAG
