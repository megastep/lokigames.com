/* $Id: mgavb.c,v 1.19 1999/11/18 17:22:05 andree Exp $ */
/*
 * GLX Hardware Device Driver for Matrox Millenium G200
 * Copyright (C) 1999 Wittawat Yamwong
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * WITTAWAT YAMWONG, OR ANY OTHER CONTRIBUTORS BE LIABLE FOR ANY CLAIM, 
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR 
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE 
 * OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *
 *    Wittawat Yamwong <Wittawat.Yamwong@stud.uni-hannover.de>
 */
 
#include "mgalib.h"
#include "mgavb.h"
#include "mgalog.h"
#include "mgadma.h"
#include "mgawarp.h"
#include "xsmesaP.h"
#include "xsmesa.h"

#include "stages.h"

#include "os.h"
#include <stdio.h>
#include <stdlib.h>

extern mgaContextPtr mgaCtx;
extern mgaBufferPtr mgaDB;

#define TEX {					\
  v->v.warp.tu0 = tc[i][0];			\
  v->v.warp.tv0 = tc[i][1];			\
}

#define SPC {					\
  GLubyte *spec = &(VB->Spec[0][i][0]);		\
  v->v.warp.specular.red = spec[0];		\
  v->v.warp.specular.green = spec[1];		\
  v->v.warp.specular.blue = spec[2];		\
}

#define FOG {						\
  v->v.warp.specular.alpha =				\
    255.0 * mgaCtx->Fog.Factor(mgaCtx,			\
			       VB->EyePtr->data[i][2]);	\
}

#define COL {					\
  GLubyte *col = &(VB->Color[0]->data[i][0]);	\
  v->v.warp.color.blue  = col[2];		\
  v->v.warp.color.green = col[1];		\
  v->v.warp.color.red   = col[0];		\
  v->v.warp.color.alpha = col[3];		\
}

/* The warp code we have doesn't seem to support projective texturing
 * in the multitexture case.  (Would require another 1/w value for the
 * second set of texcoords).  This may be a problem for the g400.  
 */
#define TEX4						\
  if (VB->TexCoordPtr[0]->size == 4)			\
  {							\
     GLfloat (*tc)[4] = VB->TexCoordPtr[0]->data;	\
     v = &(MGA_DRIVER_DATA(VB)->verts[start]);		\
     mgaCtx->setupdone &= ~MGA_WIN_BIT;			\
     for (i=start; i < end; i++, v++)	{		\
        float oow = 1.0 / tc[i][3];			\
	v->v.warp.rhw *= tc[i][3];			\
	v->v.warp.tu0 *= oow;				\
	v->v.warp.tv0 *= oow;				\
     }							\
  }

#define WIN_TEX4 TEX4

#define COORD							\
      GLfloat *win = VB->Win.data[i];				\
      v->v.warp.rhw =               win[3];			\
      v->v.warp.z = (1.0/0x10000) * win[2];			\
      v->v.warp.x =                 win[0] - 0.5F;		\
      v->v.warp.y =          -      win[1] + mgaHeightFloat; 

#define NOP




#define SETUPFUNC(name,win,col,tex,tex4,spec,fog)			\
static void name(struct vertex_buffer *VB, GLuint start, GLuint end)	\
{									\
   mgaVertexPtr v;							\
   GLfloat (*tc)[4], mgaHeightFloat = mgaDB->Height - 0.5;		\
   int i;								\
   (void) tc; (void) mgaHeightFloat;					\
									\
   CHECK_CONTEXT( return; );						\
									\
   gl_import_client_data( VB, VB->ctx->RenderFlags,			\
			  (VB->ClipOrMask				\
			   ? VEC_WRITABLE|VEC_GOOD_STRIDE		\
			   : VEC_GOOD_STRIDE));				\
									\
   tc = VB->TexCoordPtr[0]->data;					\
									\
   v = &(MGA_DRIVER_DATA(VB)->verts[start]);				\
									\
   if (VB->ClipOrMask == 0)						\
      for (i=start; i < end; i++, v++) {				\
	 win;								\
	 col;								\
	 tex;								\
	 spec;								\
	 fog;								\
      }									\
   else									\
      for (i=start; i < end; i++, v++) {				\
	 if (VB->ClipMask[i] == 0) {					\
	    win;							\
	    tex;							\
	    spec;							\
	    fog;							\
	 }								\
	    col;							\
      }						  		        \
   tex4;								\
}



 
SETUPFUNC(rs_w,		COORD,NOP,NOP,NOP,NOP,NOP)
SETUPFUNC(rs_wt,	COORD,NOP,TEX,WIN_TEX4,NOP,NOP)
SETUPFUNC(rs_wf,	COORD,NOP,NOP,NOP,NOP,FOG)
SETUPFUNC(rs_wft,	COORD,NOP,TEX,WIN_TEX4,NOP,FOG)
SETUPFUNC(rs_wg,	COORD,COL,NOP,NOP,NOP,NOP)
SETUPFUNC(rs_wgt,	COORD,COL,TEX,WIN_TEX4,NOP,NOP)
SETUPFUNC(rs_wgst,	COORD,COL,TEX,WIN_TEX4,SPC,NOP)
SETUPFUNC(rs_wgf,	COORD,COL,NOP,NOP,NOP,FOG)
SETUPFUNC(rs_wgft,	COORD,COL,TEX,WIN_TEX4,NOP,FOG)
SETUPFUNC(rs_wgfst,	COORD,COL,TEX,WIN_TEX4,SPC,FOG)

SETUPFUNC(rs_t,		NOP,NOP,TEX,TEX4,NOP,NOP)
SETUPFUNC(rs_f,		NOP,NOP,NOP,NOP,NOP,FOG)
SETUPFUNC(rs_ft,	NOP,NOP,TEX,TEX4,NOP,FOG)
SETUPFUNC(rs_g,		NOP,COL,NOP,NOP,NOP,NOP)
SETUPFUNC(rs_gt,	NOP,COL,TEX,TEX4,NOP,NOP)
SETUPFUNC(rs_gst,	NOP,COL,TEX,TEX4,SPC,NOP)
SETUPFUNC(rs_gf,	NOP,COL,NOP,NOP,NOP,FOG)
SETUPFUNC(rs_gft,	NOP,COL,TEX,TEX4,NOP,FOG)
SETUPFUNC(rs_gfst,	NOP,COL,TEX,TEX4,SPC,FOG)



static void rs_invalid(struct vertex_buffer *VB, GLuint start, GLuint end)
{
  mgaError("mgaRasterSetup(): invalid combination, "
	   "specular color requested w/o texture!\n");
}

typedef void (*setupFunc)(struct vertex_buffer *,GLuint,GLuint);

static setupFunc setup_func[0x80];

void mgaDDSetupInit( void )
{
   int i;

   for (i = 0 ; i < 0x80 ; i++)
      setup_func[i] = rs_invalid;
   
   /* Functions to build vert's from scratch */
   setup_func[MGA_WIN_BIT] = rs_w;
   setup_func[MGA_WIN_BIT|MGA_TEX0_BIT] = rs_wt;
   setup_func[MGA_WIN_BIT|MGA_FOG_BIT] = rs_wf;
   setup_func[MGA_WIN_BIT|MGA_FOG_BIT|MGA_TEX0_BIT] = rs_wft;
   setup_func[MGA_WIN_BIT|MGA_RGBA_BIT] = rs_wg;
   setup_func[MGA_WIN_BIT|MGA_RGBA_BIT|MGA_TEX0_BIT] = rs_wgt;
   setup_func[MGA_WIN_BIT|MGA_RGBA_BIT|MGA_SPEC_BIT|MGA_TEX0_BIT] = rs_wgst;
   setup_func[MGA_WIN_BIT|MGA_RGBA_BIT|MGA_FOG_BIT] = rs_wgf;
   setup_func[MGA_WIN_BIT|MGA_RGBA_BIT|MGA_FOG_BIT|MGA_TEX0_BIT] = rs_wgft;
   setup_func[MGA_WIN_BIT|MGA_RGBA_BIT|MGA_FOG_BIT|MGA_SPEC_BIT|MGA_TEX0_BIT] = rs_wgfst;

   /* Repair functions */
   setup_func[MGA_TEX0_BIT] = rs_t;
   setup_func[MGA_FOG_BIT] = rs_f;
   setup_func[MGA_FOG_BIT|MGA_TEX0_BIT] = rs_ft;
   setup_func[MGA_RGBA_BIT] = rs_g;
   setup_func[MGA_RGBA_BIT|MGA_TEX0_BIT] = rs_gt;
   setup_func[MGA_RGBA_BIT|MGA_SPEC_BIT|MGA_TEX0_BIT] = rs_gst;
   setup_func[MGA_RGBA_BIT|MGA_FOG_BIT] = rs_gf;
   setup_func[MGA_RGBA_BIT|MGA_FOG_BIT|MGA_TEX0_BIT] = rs_gft;
   setup_func[MGA_RGBA_BIT|MGA_FOG_BIT|MGA_SPEC_BIT|MGA_TEX0_BIT] = rs_gfst;

}


void mgaPrintSetupFlags(char *msg, GLuint flags )
{
   mgaMsg(4, "%s: %d %s%s%s%s%s%s%s\n",
	   msg,
	   flags,
	   (flags & MGA_WIN_BIT)      ? " xyzw," : "", 
	   (flags & MGA_RGBA_BIT)     ? " rgba," : "",
	   (flags & MGA_SPEC_BIT)     ? " spec," : "",
	   (flags & MGA_FOG_BIT)      ? " fog," : "",
	   (flags & MGA_TEX0_BIT)     ? " tex-0," : "",
	   (flags & MGA_TEX1_BIT)     ? " tex-1," : "",
	   (flags & MGA_ALPHA_BIT)    ? " alpha," : "");
}




void mgaChooseRasterSetupFunc(GLcontext *ctx)
{
  int funcindex = (MGA_WIN_BIT | MGA_RGBA_BIT);

  if (ctx->Texture.Enabled & 0xf) {
      if (ctx->Texture.Unit[0].EnvMode == GL_REPLACE)
	 funcindex &= ~MGA_RGBA_BIT;

     funcindex |= MGA_TEX0_BIT;
  }

  if (ctx->Texture.Enabled & 0xf0)
     funcindex |= MGA_TEX1_BIT;

  if (ctx->Color.BlendEnabled)
     funcindex |= MGA_ALPHA_BIT;

  if (ctx->Light.Model.ColorControl == GL_SEPARATE_SPECULAR_COLOR)
     funcindex |= MGA_SPEC_BIT;

  if (ctx->Fog.Enabled)
     funcindex |= MGA_FOG_BIT;

  if (0)
     mgaPrintSetupFlags("xsmesa: full setup function", funcindex); 

  mgaCtx->setupindex = funcindex;
  ctx->Driver.RasterSetup = setup_func[funcindex &~MGA_ALPHA_BIT ];
}


void mgaDDViewport( GLcontext *ctx, 
		    GLint x, GLint y, 
		    GLsizei width, GLsizei height )
{
  mgaMsg(10, "mgaDDViewport %d %d %d %d\n", x,y, width,height);
  mgaMsg(10, "\tmgaDB = %p\n", mgaDB);
  if (mgaDB) 
    mgaMsg(10, "\tmagic = %x\n", mgaDB->magic);
}


void mgaDDDepthRange( GLcontext *ctx, GLclampd nearval, GLclampd farval )
{
}




void mgaDDCheckPartialRasterSetup( GLcontext *ctx, struct gl_pipeline_stage *d )
{
   GLuint tmp = mgaCtx->setupdone;

   d->type = 0;
   mgaCtx->setupdone = 0;	/* cleared if we return */

   if ((ctx->Array.Summary & VERT_OBJ_ANY) == 0)
      return;

   if (ctx->IndirectTriangles) 
      return;

   mgaCtx->setupdone = tmp;

   /* disabled until we have a merge&render op */
   /*     d->inputs = available; */
   /*     d->outputs = VERT_RAST_SETUP_PART; */
   /*     d->type = PIPE_PRECALC; */
}


/* Repair existing precalculated vertices with new data.
 */
void mgaDDPartialRasterSetup( struct vertex_buffer *VB )
{
   GLuint new = VB->pipeline->new_outputs;
   GLuint available = VB->pipeline->outputs;
   GLuint ind = 0;

   if (new & VERT_WIN) {
      new = available;
      ind |= MGA_WIN_BIT | MGA_FOG_BIT;
   }

   if (new & VERT_RGBA)
      ind |= MGA_RGBA_BIT | MGA_SPEC_BIT;

   if (new & VERT_TEX0_ANY) 
      ind |= MGA_TEX0_BIT;

   if (new & VERT_TEX1_ANY)
      ind |= MGA_TEX1_BIT;

   mgaCtx->setupdone &= ~ind;
   ind &= mgaCtx->setupindex;
   mgaCtx->setupdone |= ind;

   mgaPrintSetupFlags("xsmesa: partial setup function", ind);

   if (ind) 
      setup_func[ind&~MGA_ALPHA_BIT]( VB, VB->Start, VB->Count );   
}


void mgaDDDoRasterSetup( struct vertex_buffer *VB )
{
   GLcontext *ctx = VB->ctx;

   if (VB->Type == VB_CVA_PRECALC) 
      mgaDDPartialRasterSetup( VB );
   else if (ctx->Driver.RasterSetup)
      ctx->Driver.RasterSetup( VB, VB->CopyStart, VB->Count );
}




void mgaDDResizeVB( struct vertex_buffer *VB, GLuint size )
{
   mgaVertexBufferPtr mvb = MGA_DRIVER_DATA(VB);

   while (mvb->size < size)
      mvb->size *= 2;

   free( mvb->vert_store );
   mvb->vert_store = malloc( sizeof(mgaVertex) * mvb->size + 31);
   if (!mvb->vert_store) 
      FatalError("mga-glx: out of memory !\n");

   mvb->verts = (mgaVertexPtr)(((unsigned long)mvb->vert_store + 31) & ~31);

   gl_vector1ui_free( &mvb->clipped_elements );
   gl_vector1ui_alloc( &mvb->clipped_elements, VEC_WRITABLE, mvb->size, 32 );   
   if (!mvb->clipped_elements.start) 
      FatalError("mga-glx: out of memory !\n");

   free( VB->ClipMask );
   VB->ClipMask = (GLubyte *)malloc(sizeof(GLubyte) * mvb->size);
   if (!VB->ClipMask) 
      FatalError("mga-glx: out of memory !\n");

   if (VB->Type == VB_IMMEDIATE) {
      free( mvb->primitive );
      free( mvb->next_primitive );
      mvb->primitive = (GLuint *)malloc( sizeof(GLuint) * mvb->size );
      mvb->next_primitive = (GLuint *)malloc( sizeof(GLuint) * mvb->size );
      if (!mvb->primitive || !mvb->next_primitive)
	 FatalError("mga-glx: out of memory!");
   }
}


void mgaDDRegisterVB( struct vertex_buffer *VB )
{
   mgaVertexBufferPtr mvb;

   mvb = (mgaVertexBufferPtr)calloc( 1, sizeof(*mvb) );

   /* This looks like it allocates a lot of memory, but it basically
    * just sets an upper limit on how much can be used - nothing like
    * this amount will ever be turned into 'real' memory.
    */
   mvb->size = VB->Size * 5;
   mvb->vert_store = malloc( sizeof(mgaVertex) * mvb->size + 31);
   if (!mvb->vert_store) 
      FatalError("mga-glx: out of memory !\n");
   
   mvb->verts = (mgaVertexPtr)(((unsigned long)mvb->vert_store + 31) & ~31);

   gl_vector1ui_alloc( &mvb->clipped_elements, VEC_WRITABLE, mvb->size, 32 );
   if (!mvb->clipped_elements.start) 
      FatalError("mga-glx: out of memory !\n");

   free( VB->ClipMask );
   VB->ClipMask = (GLubyte *)malloc(sizeof(GLubyte) * mvb->size);
   if (!VB->ClipMask) 
      FatalError("mga-glx: out of memory !\n");

   mvb->primitive = (GLuint *)malloc( sizeof(GLuint) * mvb->size );
   mvb->next_primitive = (GLuint *)malloc( sizeof(GLuint) * mvb->size );
   if (!mvb->primitive || !mvb->next_primitive)
      FatalError("mga-glx: out of memory!");
   
   VB->driver_data = mvb;
}


void mgaDDUnregisterVB( struct vertex_buffer *VB )
{
   mgaVertexBufferPtr mvb = MGA_DRIVER_DATA(VB);
   
   if (mvb) {
      if (mvb->vert_store) free(mvb->vert_store);
      if (mvb->primitive) free(mvb->primitive);
      if (mvb->next_primitive) free(mvb->next_primitive);
      gl_vector1ui_free( &mvb->clipped_elements );
      free(mvb);
      VB->driver_data = 0;
   }      
}
