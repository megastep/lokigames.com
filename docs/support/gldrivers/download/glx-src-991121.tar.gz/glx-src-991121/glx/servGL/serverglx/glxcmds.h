
/*
 * GLX Server Extension
 * Copyright (C) 1998 Terence Ripperda (ripperda@engr.sgi.com)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License; or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful;
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not; write to the Free
 * Software Foundation; Inc.; 675 Mass Ave; Cambridge; MA 02139; USA.
 */

#ifndef GLX_CMDS
#define GLX_CMDS

int GLnoop(ClientPtr client);
int GLRender(ClientPtr client);
int GLRender_swapped(ClientPtr client);
int GLRenderLarge(ClientPtr client);
int GLRenderLarge_swapped(ClientPtr client);
int GLCreateContext(ClientPtr client);
int GLDestroyContext(ClientPtr client);
int GLMakeCurrent(ClientPtr client);
int GLIsDirect(ClientPtr client);
int GLQueryVersion(ClientPtr client);
int GLWaitGL(ClientPtr client);
int GLWaitX(ClientPtr client);
int GLCopyContext(ClientPtr client);
int GLSwapBuffers(ClientPtr client);
int GLUseXFont(ClientPtr client);
int GLCreateGLXPixmap(ClientPtr client);
int GLGetVisualConfigs(ClientPtr client);
int GLDestroyGLXPixmap(ClientPtr client);
int GLVendorPrivate(ClientPtr client);
int GLVendorPrivateWithReply(ClientPtr client);
int GLQueryServerString(ClientPtr client);
int GLClientInfo(ClientPtr client);
int GLNewList(ClientPtr client);
int GLEndList(ClientPtr client);
int GLDeleteLists(ClientPtr client);
int GLGenLists(ClientPtr client);
int GLFeedbackBuffer(ClientPtr client);
int GLSelectBuffer(ClientPtr client);
int GLRenderMode(ClientPtr client);
int GLFinish(ClientPtr client);
int GLPixelStoref(ClientPtr client);
int GLPixelStorei(ClientPtr client);
int GLReadPixels(ClientPtr client);
int GLGetBooleanv(ClientPtr client);
int GLGetClipPlane(ClientPtr client);
int GLGetDoublev(ClientPtr client);
int GLGetError(ClientPtr client);
int GLGetFloatv(ClientPtr client);
int GLGetIntegerv(ClientPtr client);
int GLGetLightfv(ClientPtr client);
int GLGetLightiv(ClientPtr client);
int GLGetMapdv(ClientPtr client);
int GLGetMapfv(ClientPtr client);
int GLGetMapiv(ClientPtr client);
int GLGetMaterialfv(ClientPtr client);
int GLGetMaterialiv(ClientPtr client);
int GLGetPixelMapfv(ClientPtr client);
int GLGetPixelMapuiv(ClientPtr client);
int GLGetPixelMapusv(ClientPtr client);
int GLGetPolygonStipple(ClientPtr client);
int GLGetString(ClientPtr client);
int GLGetTexEnvfv(ClientPtr client);
int GLGetTexEnviv(ClientPtr client);
int GLGetTexGendv(ClientPtr client);
int GLGetTexGenfv(ClientPtr client);
int GLGetTexGeniv(ClientPtr client);
int GLGetTexImage(ClientPtr client);
int GLGetTexParameterfv(ClientPtr client);
int GLGetTexParameteriv(ClientPtr client);
int GLGetTexLevelParameterfv(ClientPtr client);
int GLGetTexLevelParameteriv(ClientPtr client);
int GLIsEnabled(ClientPtr client);
int GLIsList(ClientPtr client);
int GLFlush(ClientPtr client);
int GLAreTexturesResident(ClientPtr client);
int GLDeleteTextures(ClientPtr client);
int GLGenTextures(ClientPtr client);


#endif
