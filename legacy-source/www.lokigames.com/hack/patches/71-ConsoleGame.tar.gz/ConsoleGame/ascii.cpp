#include <iostream.h>

int main()
{
  char c;

  while (c != '.') {
    cin >> c;
    cout << int(c) << '\t' << c << endl;
  }
  return(0);
}
