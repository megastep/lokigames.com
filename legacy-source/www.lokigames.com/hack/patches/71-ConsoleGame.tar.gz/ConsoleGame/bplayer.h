#ifndef _BPLAYER_H
#define _BPLAYER_H

class BasePlayer {
 private:

  int             Civ_Type;
  DArray<Units>   Army;
  DArray<City>    Cities;

  bool            focus;

 public:

  BasePlayer();
  ~BasePlayer();
};

#endif

