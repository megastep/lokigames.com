#include "city.h"

City::City(char* n, int o, int xx, int yy) : Pos(xx, yy)
{
    name = new char[_DEFAULT_MAX_LENGTH];
    strcpy(name, n);
    owner = o;
    capitol = false;
}

City::City()
{
  // empty city....
}
