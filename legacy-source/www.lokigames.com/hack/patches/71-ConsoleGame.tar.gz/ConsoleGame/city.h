#ifndef _CITY_H
#define _CITY_H

#ifndef _DEFAULT_MAX_LENGTH
#define _DEFAULT_MAX_LENGTH 255
#endif

#include "pos.h"

class City : public Pos {
 private:

  char * name;
  int    owner;
  int    population;
  bool   capitol;

 public:

  City::City(char * n, int o, int xx, int yy);
  City::City();
  char displayChar() { if (!capitol) return('C');
                       else return('*'); }
};

#endif _CITY_H




