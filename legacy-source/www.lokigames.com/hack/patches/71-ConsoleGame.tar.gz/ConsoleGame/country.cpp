#include "country.h"

Country::Country() {
  Army   = new DArray<Unit>(50);
  Cities = new DArray<City>(50);
}

Country::~Country() {
  delete Army;
  delete Cities;
}

char Country::onTile(int r, int c) {
  int i;
  int j;
  char t;
  City * CTemp;
  Unit * UTemp;
  
  // Search city first because
  //  and units on a City Tile won't show up
  //  on the display.....
  j = Cities->getSize();
  
  for (i = 0; i < j; i ++) {
    CTemp = new City( Cities->ret(i));
    if (CTemp->x == c && CTemp->y == r) {
      //cout << "There is a city on me!!!!!\n";
      t = CTemp->displayChar();
      delete CTemp;
      return(t);
    }
    else delete CTemp;
  }

  // Ok, not in any city I know of...
  j = Army->getSize();
  
  for (i = 0; i < j; i ++) {
    UTemp = new Unit(Army->ret(i));
    if (UTemp->x == c && UTemp->y == r) {
      //cout << "There is a unit on me!!!!\n";
      t = UTemp->displayChar();
      delete UTemp;
      return(t);
    }
    delete UTemp;
  }
  //cout << "There is NOTHING on me!!!!";
  return(0);
}
