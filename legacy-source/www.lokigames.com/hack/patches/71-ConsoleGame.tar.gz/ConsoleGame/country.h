#ifndef _COUNTRY_H
#define _COUNTRY_H

#include "unit.h"
#include "city.h"
#include "darray.h"

class Country {
 private:

  static int nextID;

  int ID;

  DArray<Unit> * Army;
  DArray<City> * Cities;
  
 public:

  Country();
  ~Country();

  char onTile(int r, int c);
};

#endif


