#ifndef _DARRAY_H
#define _DARRAY_H

#include <iostream.h>
#include <stdlib.h>

template <class T>
class DArray {
 private:

  int defined;
  T * data; 
  int size;

  void resize(int deltaSize = 5);
  
 public:

  DArray(int sz = 25);
  DArray(const DArray& copyMe);

  ~DArray();

  T&   operator[](int index);
  void set       (int index, T& obj);
  T    ret       (int index) { return(data[index]); }
  int  getSize   ()          { return(size); }
};

template <class T>
void DArray<T>::resize(int deltaSize) {
  if (deltaSize <= 0) return;
  
  T * temp = new T[size + deltaSize];
  int i;

  for (i = 0; i < size; i ++) {
    temp[i] = data[i];
  }
  
  delete [] data; data = temp; temp = 0;
  size += deltaSize;
}

template <class T>
DArray<T>::DArray(int sz) {
  defined = 12345;
  if (sz <= 0) sz = 25;
  size = sz;
  data = new T[sz];
}

template <class T>
DArray<T>::DArray(const DArray& copyMe) {
  int i;

  if (defined == 12345) {
    delete[] data;
  }

  data = new T[copyMe.size];
  for (i = 0; i < size; i ++) data[i] = copyMe[i];
}
    
template <class T>
DArray<T>::~DArray() {
  if (defined == 12345) {
    delete [] data;
    data   =  0;
    size   =  0;
    defined = 1;
  }
}

template <class T>
void DArray<T>::set(int index, T& oh_hell) {
  if (defined != 12345) {
    cerr << "Attempt to read/write undefined DArray...\n";
    exit(2);
  }
  
  if (index < 0) index += size;
  if (index >= size) {
    cerr << "Index out of bounds.....\n";
    exit(2);
  }
  
  data[index] = oh_hell;
}

template <class T>
T& DArray<T>::operator[] (int index) {
  if (defined != 12345) {
    cerr << "Attempt to read/write undefined DArray...\n";
    exit(2);
  }
  
  if (index < 0) {
    // use perl type referencing??
    index += size;
  }

  if (index >= size) {
    // out of bounds..
    cerr << "Index out of bounds.......\n";
    exit(2);
  }

  return(data[index]);
}

#endif
