#include "db.h"
#include <iostream.h>
#include <fstream.h>
#include <string.h>

DB::DB(char * f) {
  ifstream file;
  int      i, j;
  int      temp;
  char*    tempr;
  file.open(f);
  
  // read in database.... :: gulp ::
  // first line is number of records...
  file >> records;
  // second line is number of fields (INCLUDING PRIMARY KEY O_o AND NAME!!!!)
  file >> field_size;
  
  /*cout << "DATABASE DEBUG.......\n"
       << "Records : " << records << "\tFields : " << field_size << endl;
  */

  field_size --;
  
  fields = new DArray<int  >( records * field_size );
  name   = new DArray<char*>( records              );
  
  for (i = 0; i < records; i ++) {
    for (j = 0; j < field_size; j ++) {
      file >> temp;
      //cout << "Read in :? " << temp << endl;
      (*fields)[(i * field_size) + j] = temp;
    }
    tempr = new char[DEFAULT_MAX_SIZE];
    file.getline(tempr, DEFAULT_MAX_SIZE - 1, '\n');
    name->set(i, tempr);
    tempr = 0;
  }
  file.close();
}
 
DB::~DB() {
  delete fields;
  delete name;
}

int DB::getRecord(int key, int field)
{
  int i, temp;
  for (i = 0; i < records; i ++) {
    temp = fields->ret(i * field_size);
    if (temp == key) {
      temp = fields->ret( (i * field_size) + field );
      return(temp);
    }
  }
  return ERROR_YOU_BASTARD;
}

void DB::displayTable(int option) {
  int i, j;
  if (option == 1) {
    cout << "*************************************************************************\n";
    for (i = 0; i < records; i ++) {
      cout << (*name)[i] << " -=- " << char( (*fields)[(i * field_size) + 3] ) << endl; 
     }
cout << "*************************************************************************\n";
    return;
  }

  cout << "Key\t";
  for (i = 1; i < field_size; i ++) cout << "F" << char(i + '0') << '\t';
     cout << "Name\n";
     cout << "*************************************************************************\n";
     for (i = 0; i < records; i ++) {
     for (j = 0; j < field_size; j ++) {
        cout << (*fields)[(i * field_size) + j] << '\t';
     }
     cout << (*name)[i] << endl;
  }
  cout << "*************************************************************************\n";
    
  return;
}

char* DB::getName( int key )
{
  int i;
  int meta_temp;
  char * temp = new char[DEFAULT_MAX_SIZE];
  
  for (i = 0; i < records; i ++) {
    meta_temp = fields->ret(i * field_size);
    if (meta_temp == key) {
      strcpy(temp, name->ret(i));
      return(temp);
    }
  }    
  // GOD DAMNED ANSI C++ SPEC IS THE BASTARD
  //  I WANNA BE IN CHARGE -- NOT THIS CRAPPY ASS COMPILER
  return ((char*)(ERROR_YOU_BASTARD));
}




