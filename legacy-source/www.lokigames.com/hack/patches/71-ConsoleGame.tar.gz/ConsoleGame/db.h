#ifndef _DB_H
#define _DB_H

#include "darray.h"

#define DEFAULT_MAX_SIZE  255
#define ERROR_YOU_BASTARD 254

class DB {
 private:
  
  // field 0 IS ALWAYS primary key
  int              records;
  int              field_size;  // does not include name
  DArray<int>*     fields;
  DArray<char *>*  name;

 public:
  
  DB(char * f);
  ~DB();
  
  int   getRecord   (int key, int field);
  char* getName     (int key);
  void  displayTable(int option = 0);
};

#endif



