#include <iostream.h>
#include "eyes.h"

EyeBall::EyeBall(World* mappymappyjoyjoy) {
  Map = mappymappyjoyjoy;
}

void EyeBall::MapWindow(int topLeftX, int topLeftY) {
    // default to 80 columns
    //  with 18 rows

    int i, j;
    int it, jt;
    char k;
    int upperLimitX = Map->map_cols;
    int upperLimitY = Map->map_rows;

    // draw row by row obviously.....

    i = topLeftX; 
    j = topLeftY;
    it = jt = 0;

    //cout << "TopLeftX    : " << i << "\tTopLeftY : " << j << endl;
    //cout << "upperLimitX : " << upperLimitX << "\tUpperLimitY : " << upperLimitY << endl;
    
    do {

      do {
	
	//cout << "(i : " << i << "),(j : " << j << ")" << endl;
	// get Cell info for (i,j)
	k = Map->display(i, j);
	// display on screen....
	cout << k;
	// Update j first...
	if (++j >= upperLimitX) {
	  j = 0;
	}
	jt ++;
      } while (jt < 80 && j != topLeftX);

      // Now display linebreak
      cout << endl;
      // Now incremenate i and reset j
      if (++i >= upperLimitY) {
	i = 0;
      }
      it ++;
      j = topLeftY; jt = 0;
    } while( it < 23 && i != topLeftY);
    return;
}
	


