#ifndef _EYEBALL_H
#define _EYEBALL_H

#include "world.h"

class EyeBall {
  friend class World;
 private:

  World * Map;
  void MapWindow(int topLeftX = 0, int topLeftY = 0);
  
 public:

  EyeBall(World* mappy);
  
  void drawScreen() { MapWindow(); return; }
};

#endif _EYEBALL_H

