#include "sam.h"
#include <iostream.h>

int main()
{
  char choice;

  OMNI *demigod = new OMNI(2, 25);
  demigod->init();  

  cout << "--=== << Console Civ:CTP >> ===--\n"
       << "  on elite hack from SamBeckett  \n"
       << "        aka Rick Bischoff        \n"
       << "       beckett@ductape.net       \n"
       << "---------------------------------\n";
  cout << "\n\n\n";
  while (1) {
   
  cout << "---------------------------------\n"
       << " (1) -=- Draw Map                \n"
       << " (2) -=- Regen Map               \n"
       << " (3) -=- Select Unit Attacker    \n"
       << " (4) -=- Select Unit Defender    \n"
       << " (5) -=- Battle                  \n"
       << " (6) -=- Reset Attacker          \n"
       << " (7) -=- Reset Defender          \n"
       << " (8) -=- Display Unit Info       \n"
       << " (9) -=- Quit                    \n"
       << "---------------------------------\n"
       << "  please note this is pre-alpha  \n"
       << "and will stay there for enternity\n"
       << "---------------------------------\n"
       << " Enter Choice :                  \n";

  cin >> choice;
  choice -= '0';
  switch (choice) {
  case 0:
    cout << "muhahahahhahaa\n";
    break;
  case 1:
    demigod->redraw();
    break;
  case 2:
    demigod->regen();
    demigod->redraw();
    break;
  case 3:
    demigod->selectAttacker();
    break;
  case 4:
    demigod->selectDefender();
    break;
  case 5:
    demigod->attack();
    break;
  case 6:
    demigod->resetAttacker();
    break;
  case 7:
    demigod->resetDefender();
    break;
  case 8:
    demigod->displayUnitInfo();
    break;
  case 9:
    delete demigod;
    cout << "thank you and please, come again.\n";
    return(0);
  }
  }
  return(0);
}




