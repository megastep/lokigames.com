#ifndef _HOLY_SCHNIKIES
#define _HOLY_SCHNIKIES

class Pos {
 public:
  
  Pos(int xx, int yy) {
    x = xx;
    y = yy;
  }

  Pos() {
    x = -1;
    y = -1;
  }

  int x;
  int y;
};

#endif _HOLY_SCHNIKIES
