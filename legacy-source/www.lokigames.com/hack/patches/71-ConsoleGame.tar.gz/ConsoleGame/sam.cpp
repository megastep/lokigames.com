#include "sam.h"
#include "eyes.h"
#include "unit.h"

OMNI::OMNI(int numberOfPlayers, int MapSize)
 { 
    Map = new World(this, MapSize, MapSize);
    WM = new EyeBall(Map);
    Countries = new DArray<Country>(numberOfPlayers);
    players = numberOfPlayers;
    currentTurn = 0;
  }

char OMNI::onTile(int r, int c)
{
  int i;
  char t = 0;

  Country temp;

  for (i = 0; i < players; i ++) {
    temp = (*Countries)[i];
    t = temp.onTile(r, c);
    if (t != 0) break;
  }
  return(t);
}

void OMNI::init()
{
  // draw map.....
  //WM->drawScreen();
  // this is where the main game loop would go etc
}

void OMNI::redraw()
{
  WM->drawScreen();
  Map->showDB();
}

void OMNI::regen()
{
  Map->regen();
  //WM->drawScreen();
  //Map->showDB();
}

void OMNI::selectAttacker()
{
  if (attacker == 0) { attacker = new Unit(0); }
  attacker->showDB();
  int key;

  cout << "Enter key of unit to select : ";
  cin  >> key;
  delete attacker; attacker = new Unit(key);
}

void OMNI::selectDefender()
{
  if (defender == 0) { defender = new Unit(0); }
  defender->showDB();
  int key;
  
  cout << "Enter key of unit to select : ";
  cin >> key;
  delete defender; defender = new Unit(key);
}

void OMNI::attack()
{
  if (doBattle((*attacker), (*defender))) {
    cout << "\nAttacker wins...\n";
  } else {
    cout << "\nDefender wins...\n";
  }
 
  displayUnitInfo();
}

void OMNI::displayUnitInfo() 
{
  if (attacker == 0) attacker = new Unit(0);
  attacker->displayUnitInfo();

  if (defender == 0) defender = new Unit(0);
  defender->displayUnitInfo();
  
  return;
}

void OMNI::resetAttacker()
{
  if (attacker == 0) {
    attacker = new Unit(0);
  }
  attacker->reset();
  attacker->displayUnitInfo();
}

void OMNI::resetDefender()
{
  if (defender == 0) {
    defender = new Unit(0);
  }
  defender->reset();
  defender->displayUnitInfo();
}

  







