#ifndef _SUPREME_BEING
#define _SUPREME_BEING

#include "darray.h"
#include "world.h"
#include "country.h"
#include "eyes.h"
#include "unit.h"

class World;
class Country;
class EyeBall;

class OMNI {
 private:

  EyeBall         * WM;
  World           * Map;
  DArray<Country> * Countries;
  int               currentTurn;
  int               players;

  /* followign data members for demo purposes only */
  Unit             * attacker;
  Unit             * defender;

 public:

  OMNI(int numberOfPlayers, int MapSize);

  // Search all countries, units and cities
  //  for a unit on this tile.. returns (NULL) if nothing
  //  is on..
  void init();
  char onTile(int r, int c);
  
  void redraw();
  void  regen();
  
  /* following functions for demo purposes only */
  void selectAttacker();
  void selectDefender();
  void attack();
  void resetAttacker();
  void resetDefender();
  void displayUnitInfo();
  
};

#endif    

