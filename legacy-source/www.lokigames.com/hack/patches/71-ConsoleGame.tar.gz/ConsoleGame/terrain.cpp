#include "db.h"
#include "terrain.h"
#include "stdlib.h"

int Terrain::defined;
DB* Terrain::terrainDB;

Terrain::Terrain(int t) {
  if (defined != 22345) {
    terrainDB = new DB("terrain.db");
    defined = 22345;
    //terrainDB->displayTable();
  }
  terrainType = rand() % 4;
}

Terrain::~Terrain() {
}

int Terrain::regen() {
  verifyDB();
  terrainType = rand() % 4;
}

int Terrain::movePenalty() {
  verifyDB();
  return( terrainDB->getRecord( terrainType, 1 ) );
}

int Terrain::moveMask() {
  verifyDB();
  return( terrainDB->getRecord( terrainType, 2 ) );
}

char Terrain::displayChar() {
  verifyDB();
  char t = terrainDB->getRecord( terrainType, 3 );
  //cout << "returning : " << t << ',' << int(t) << endl;
  return(t);
}

char* Terrain::getName() {
  verifyDB();
  return( terrainDB->getName( terrainType ));
}





