#ifndef _TERRAIN_H
#define _TERRAIN_H

#include <iostream.h>
#include "db.h"

class Terrain {
 private:

  static int  defined;
  static DB * terrainDB;
  
  int         terrainType;

  void verifyDB() {
    if (defined != 22345) {
      cerr << "terrain DB not loaded or someshit.. go to hell and die\n";
      exit(2);
    }
  }
  
 public:

  void showDB() {
    verifyDB();
    terrainDB->displayTable(1);
    
  }

  Terrain(int t = 0);
  ~Terrain();

  // returns what type the terrain is (i.e., is it land? water? both? space? all three??)
  // uses same scheme as unit-movement masks, except in this case, the zero-bit means that....
  // NOTHING (and I do mean nothing) can move on this tile..... NOT EVEN YOUR DOG, STINKY.
  
  int    regen();
  int    movePenalty();
  int    moveMask();
  char   displayChar();
  char * getName();
};

#endif


