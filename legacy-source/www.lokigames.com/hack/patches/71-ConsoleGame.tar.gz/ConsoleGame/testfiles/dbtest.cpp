#include "db.h"

/* main program to verify the database is functioning correctly..

it is. (tested using a lot of differnt db.test files)

*/

int main()
{
  DB test("db.test");
  test.displayTable();
  return(0);
}
