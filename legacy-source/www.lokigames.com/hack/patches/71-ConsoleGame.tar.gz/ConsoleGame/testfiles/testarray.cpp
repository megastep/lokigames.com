#include "darray.h"
#include <iostream.h>

/* used to test dynamic array ...
   appears to be functioning correctly from this....
*/

int main()
{
  DArray<int> test(50);
  int         i;

  for (i = 0; i < 50; i ++) {
    test[i] = i;
  }

  for (i = 0; i < 50; i ++) {
    cout << test[i] << ' ';
  }
  cout << endl << test[49] << '\t' << test[-1] << endl;
  test[-1] = 50; // no error
  cout << endl << test[49] << '\t' << test[-1] << endl;
  cout << test[49];
  test[50] = 50; // error??

  return(0);
}

