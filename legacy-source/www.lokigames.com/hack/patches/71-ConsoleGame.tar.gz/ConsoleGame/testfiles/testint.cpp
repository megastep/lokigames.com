#include <iostream.h>

int main()
{
  cout << sizeof(int);
}
