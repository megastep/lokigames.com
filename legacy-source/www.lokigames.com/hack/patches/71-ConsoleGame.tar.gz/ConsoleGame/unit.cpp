#include "unit.h"
#include "db.h"
#include <iostream.h>
#include <stdlib.h>

int Unit::defined;
DB* Unit::unitDB;

Unit::Unit(int type, int xx, int yy) : Pos(xx, yy) {
  if (defined != 22345) {
    unitDB = new DB("unit.db");
    //   unitDB->displayTable();
    defined = 22345;
  }
  
  fortified = false;
  unitType = type;
  resetUnit();
}

Unit::Unit() {
  if (defined != 22345) {
    unitDB = new DB("unit.db");
    //unitDB->displayTable();
    defined = 22345;
  }
  
  // empty unit....???
}

void Unit::verifyDB()
{
  if (defined != 22345) {
    cerr << "Unit DB not loaded.. ???";
    exit(2);
  }
}

char * Unit::getName() {
  char * temp = unitDB->getName( unitType );
  return(temp);
}

void Unit::reset() { resetUnit(); }
void Unit::resetUnit() {
  health   = 100;
  ac       = unitDB->getRecord( unitType, 1 );
  attack   = unitDB->getRecord( unitType, 2 );
  mp       = unitDB->getRecord( unitType, 3 );
  moveMask = unitDB->getRecord( unitType, 4 );
  sight    = unitDB->getRecord( unitType, 5 );
};  

char Unit::displayChar() {
  char temp = unitDB->getRecord( unitType, 6 );
  return(temp);
}

void Unit::displayUnitInfo()
{
  char * temp = getName();
  cout << "Name : " << temp << endl; delete temp;
  cout << "**************************************\n";
  cout << " Health : " << health << endl;
  cout << " Attack : " << attack << endl;
  cout << " Armor  : " << ac     << endl;
  cout << " Moves  : " << mp     << endl;
  cout << " Move#  : " << moveMask << endl;
  cout << " Sight  : " << sight  << endl;
  cout << "**************************************\n";
  return;
}

// Returns TRUE if a wins......
// False is D wins...
// (someone has to win.. god damnit)
//
// Attack Procedure:
//  if defender is fortified, award armor class bonus
//  begin
//    calculate chance to hit : 
//       Attacker Level * 10 minus [ (-5 * Defender Armor Class) + acBonus ]
//    if d100 < chanceToHit then
//       Deal Attacker Damage to Defender Health
//    endif
//    if Defender is still alive (attacker gets first strike)
//       same subproc as above, but with necessary variable changes
//  loop while both are alive
//  if defender is dead return true...
//  else return false..

bool doBattle(Unit &a, Unit &d) {
  int acBonus = 0;
  int chanceToHit;
  int dice;

  if (d.fortified) { acBonus -= 2; }
  while (a.health > 0 && d.health > 0) {
    // Attacker striking defender....
    chanceToHit = (a.attack * 10) - (-5 * (d.ac + acBonus));
    if (chanceToHit < 0) chanceToHit = 2;
    if (chanceToHit > 100) chanceToHit = 97;
    // Roll d100..
    dice = rand() % 100;
    if (dice < chanceToHit) {
      // Hit.. Ruh-roh
      d.health -= a.attack;
    }

    if (d.health > 0) {
      // Defender ratialiting... "YOU BASTARD!"
      chanceToHit = (d.attack * 10) - (-5 * (a.ac));
      if (chanceToHit <= 0)   chanceToHit = 2;
      if (chanceToHit >= 100) chanceToHit = 97;
      // Roll d100
      dice = rand() % 100;
      if (dice < chanceToHit) {
	a.health -= d.attack;
      }
    }
  }
  
  return (d.health <= 0);
}








