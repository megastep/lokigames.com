#ifndef _UNIT_H
#define _UNIT_H

#include "db.h"
#include "pos.h"

class Unit : public Pos {
  
  friend bool doBattle(Unit &a, Unit &b);

 private:

  static int   defined;
  static DB  * unitDB;
  
  
  DB *    upgradeDB;  // use in the future for upgrades that don't have global effects....

  void  verifyDB();
  
  destructDB();
  //reset     ();

  int   unitType;
  int   health;
  int   attack;
  int   ac;

  int   mp;
  int   moveMask;

  int   sight;

  bool  fortified;
  
 public:

  
  Unit(int type, int xx = -1, int yy = -1);
  Unit();
  void  reset();
  void  resetUnit();
  void  displayUnitInfo();
  void  showDB() { verifyDB(); unitDB->displayTable(); }
  char  displayChar();
  char* getName();
};

#endif
 






