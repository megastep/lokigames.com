#include "world.h"
#include "terrain.h"
#include <iostream.h>

World::World(OMNI * SAM, int r, int c)
{
    if (r <= 0 || c <= 0) r = 23; c = 76;
    map_rows = r; map_cols = c;
    Map = new DArray<Terrain>(map_rows *  map_cols);
    HAL = SAM;
}

World::~World() {
  delete Map;
  Map = 0;
}

void World::regen() {
  int i;
  int s = Map->getSize();
  Terrain temp;

  for (i = 0; i < s; i ++) {
    temp = Map->ret(i);
    temp.regen();
    Map->set(i, temp);
  }
  return;
}

void World::showDB() {
  Terrain temp;
  temp.showDB();
  return;
}
char World::display(int r, int c) {
  // first.. find if anything is on that... and we'll have to rely
  //  on good ol' OMNI to tell us that....
  char t;
  Terrain temp;

  if (HAL == 0) { cout << "NULL POINTER!!!! O_o"; exit(2); }
  
  t = HAL->onTile(r,c);
  
  if (t == 0) {
    // get displaychar from terrain info...
    temp = Map->ret(index(r,c));
    t = temp.displayChar();
  } else {
    // for some GOD AWFUL reason
    // t is not zero far more than it should be
    //cout << "NOT ZERO O_o";
  }
  return(t);
}

void World::display() {
  int i;
  int j;
  Terrain t;

  char c;

  for (i = 0; i < map_rows; i ++) {
    for (j = 0; j < map_cols; j ++) {
      t = Map->ret(index(i,j));
      c = t.displayChar();
      cout << c;
    }
    cout << endl;
  }
  return;
}







