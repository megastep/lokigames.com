#ifndef _WORLD_H
#define _WORLD_H

#include "terrain.h"
#include "eyes.h"
#include "sam.h"

class EyeBall;
class OMNI;

class World {
  friend class Eyeball;
 private:

  OMNI            * HAL;
  DArray<Terrain> * Map;
  
  int  index(int r, int c) { return( (r * map_cols) + c ); }

 public:

  World(OMNI * SAM, int r = 23, int c = 76); 
  ~World();

  char display(int r, int c);
  void display();
  void regen();
  void showDB();
  int  map_rows;
  int  map_cols;
};

#endif



