<?

$pagetype = 'overview';

$title = 'Reviews';

$headline_pic = '<IMG SRC="_img/headlines/reviews.gif" ALT="" WIDTH="333" HEIGHT="24" BORDER="0">';
$headline_text = '';

$keywords = '';

$description = '';

require $DOCUMENT_ROOT.'/_global/_php/tmpl_'.$pagetype.'.phps';

?>
