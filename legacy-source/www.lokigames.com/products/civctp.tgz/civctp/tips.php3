<?

$pagetype = 'overview';

$title = 'Game Tips';

$headline_pic = '<IMG SRC="_img/headlines/gametips.gif" ALT="" WIDTH="333" HEIGHT="24" BORDER="0">';
$headline_text = '';

$keywords = '';

$description = '';

require $DOCUMENT_ROOT.'/_global/_php/tmpl_'.$pagetype.'.phps';

?>
