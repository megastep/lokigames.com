<?

$pagetype = 'overview';

$title = 'Product Updates';

$headline_pic = '';
$headline_text = 'Product Updates for Civilization: Call to Power';

$keywords = '';

$description = '';

require $DOCUMENT_ROOT.'/_global/_php/tmpl_'.$pagetype.'.phps';

?>
