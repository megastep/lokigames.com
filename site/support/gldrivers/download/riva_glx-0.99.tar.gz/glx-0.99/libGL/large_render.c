
/*
 * GLX Server Extension
 * Copyright (C) 1996  Steven G. Parker  (sparker@cs.utah.edu)
 * Copyright (C) 1998, 1999  Terence Ripperda (ripperda@sgi.com)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * STEPHEN PARKER, TERENCE RIPPERDA, OR ANY OTHER CONTRIBUTORS BE LIABLE FOR 
 * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, 
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE 
 * OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

/*
 * GL Rendering Commands that may be Large
 * modified July 14, 1998 by Terence Ripperda (ripperda@engr.sgi.com)
 *
 * to help clean up some of the code and files I am splitting them 
 * up along more distinguished lines. This file corresponds to 
 * section 9.3.6 of the GLX Extension for OpenGL Protocol Specification
 * Version 1.2. This section describes the protocol for OpenGL calls
 * that Render and are generally large.
 */

#include "glxlib.h"
#include "large_render.h"
#include <stdio.h>


void __glx_CallLists(GLsizei n, GLenum type, const GLvoid* lists)
{
    int _size=GLX_list_size(n, type)+GLX_list_pad(n, type);
    char* buffer;
    __gl_get_render_large_buffer(
         8,            /* size of fixed parms */
         _size,        /* size of variable large parm (unpadded) */
         2,            /* opcode */
         1,            /* byte boundaries for splitting data */
         &buffer       /* adjusted start point-4 for fixed parms */ 
    );
    PUT_int(buffer+4, n);
    PUT_enum(buffer+8, type);
    PUT_buffer( buffer+12, lists, _size);
}


void __glx_PixelMapfv( GLenum map,  GLint mapsize, const  GLfloat* values)
{
    int _size = sizeof(GLfloat)*mapsize;
    char* buffer;
    __gl_get_render_large_buffer(
          8,                /* size of fixed parms */
          _size,            /* size of variable large parm (unpadded) */
          168,              /* opcode */
          sizeof(GLfloat),  /* split on control point bndry */
          &buffer           /* adjusted start point-4 for fixed parms */ 
    );
    PUT_enum(buffer+4, map);
    PUT_int(buffer+8, mapsize);
    PUT_buffer( buffer+12, values, _size);
}


 
void __glx_PixelMapuiv( GLenum map,  GLint mapsize, const  GLuint* values)
{
    int _size = sizeof(GLint)*mapsize;
    char* buffer;
    __gl_get_render_large_buffer(
         8,            /* size of fixed parms */
         _size,        /* size of variable large parm (unpadded) */
         169,          /* opcode */
         4,            /* byte boundaries for splitting data */
         &buffer       /* adjusted start point-4 for fixed parms */ 
    );
    PUT_enum(buffer+4, map);
    PUT_int(buffer+8, mapsize);
    PUT_buffer( buffer + 12, (const char*)values, _size);
 }


 
void __glx_PixelMapusv( GLenum map,  GLint mapsize, const  GLushort* values)
{
    int _size= sizeof(GLushort)*mapsize;
    char* buffer;
    __gl_get_render_large_buffer(
         8,            /* size of fixed parms */
         _size,        /* size of variable large parm (unpadded) */
         170,          /* opcode */
         1,            /* byte boundaries for splitting data */
         &buffer       /* adjusted start point-4 for fixed parms */ 
    );
    PUT_enum(buffer+4, map);
    PUT_int(buffer+8, mapsize);
    PUT_buffer( buffer + 12, (const char*)values, _size);
}

void __glx_PrioritizeTextures( GLint n, const  GLuint* textures, const  
               GLfloat* priorities)
{
	int n_textures;
	int _cnt = 0;
	int n_priorities = 4 * n;
	int _size = 0;
	char* buffer=NULL;
        __gl_get_render_buffer(buffer, _size);
       
        n_textures = 4 * n;
        _size = 8 + (4 * n) + (4 * n);
	PUT_short(buffer, _size);
	PUT_short(buffer+2, 4118);
	PUT_int(buffer+4, n);
	for(_cnt=0;_cnt<n_textures;_cnt++){
		PUT_uint(buffer+8+_cnt*4, textures[_cnt]);
	}
	for(_cnt=0;_cnt<n_priorities;_cnt++){
		PUT_float(buffer+8+_cnt*4, priorities[_cnt]);
	}
}


