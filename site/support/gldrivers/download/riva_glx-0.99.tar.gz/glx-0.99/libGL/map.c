
/*
 * GLX Server Extension
 * Copyright (C) 1996  Steven G. Parker  (sparker@cs.utah.edu)
 * Copyright (C) 1998, 1999  Terence Ripperda (ripperda@sgi.com)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * STEPHEN PARKER, TERENCE RIPPERDA, OR ANY OTHER CONTRIBUTORS BE LIABLE FOR 
 * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, 
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE 
 * OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

/*
 * GL Rendering Commands with Evaluator Map Data
 * modified July 14, 1998 by Terence Ripperda (ripperda@engr.sgi.com)
 *
 * to help clean up some of the code and files I am splitting them 
 * up along more distinguished lines. This file corresponds to 
 * section 9.3.6 of the GLX Extension for OpenGL Protocol Specification
 * Version 1.2. This section describes the protocol for OpenGL calls
 * that Render and contain/transfer evaluator map data.
 */

#include "glxlib.h"
#include <stdio.h>



void __glx_Map1d(GLenum target, GLdouble u1, GLdouble u2, GLint stride,
	     GLint order, const GLdouble* points)
{
    int n_values = GLX_map1_size(target);
    int _size=n_values*order*8;
    char* buffer;
    __gl_get_render_large_buffer(
         24,           /* size of fixed parms */
         _size,        /* size of variable large parm (unpadded) */
         143,          /* opcode */
         sizeof(GLdouble)*n_values,   /* split on control point bndry */
         &buffer       /* adjusted start point-4 for fixed parms */ 
    );
    PUT_double(buffer+4, u1);
    PUT_double(buffer+12, u2);
    PUT_enum(buffer+20, target);
    PUT_int(buffer+24, order);
#ifdef DEBUG_RENDER_LARGE
    fprintf( stderr,
             "glMap1d: target 0x%x, u1 %e, u2 %e, stride %d, order %d\n",
             target, u1, u2, stride, order
           );
#endif
    PUT_large_map2d( buffer+28, points, 1, order, 1, stride, n_values );
}



void __glx_Map1f(GLenum target, GLfloat u1, GLfloat u2, GLint stride,
	     GLint order, const GLfloat* points)

{
    int n_values = GLX_map1_size(target);
    int _size=n_values*order*4;
    char *buffer;
    __gl_get_render_large_buffer(
         16,           /* size of fixed parms */
         _size,        /* size of variable large parm (unpadded) */
         144,          /* opcode */
         sizeof(GLfloat)*n_values,   /* split on control point bndry */
         &buffer       /* adjusted start point-4 for fixed parms */ 
    );
    PUT_enum(buffer+4, target);
    PUT_float(buffer+8, u1);
    PUT_float(buffer+12, u2);
    PUT_int(buffer+16, order);
#ifdef DEBUG_RENDER_LARGE
    fprintf( stderr, 
             "glMap1f: target 0x%x, u1 %f, u2 %f, stride %d, order %d\n",
             target, u1, u2, stride, order
           );
#endif
    PUT_large_map2f( buffer+20, points, 1, order, 1, stride, n_values );
}



void __glx_Map2d(GLenum target, GLdouble u1, GLdouble u2, GLint ustride,
	     GLint uorder, GLdouble v1, GLdouble v2, GLint vstride,
	     GLint vorder, const GLdouble* points)
{
    int n_values = GLX_map2_size(target);
    int _size=n_values*uorder*vorder*8;
    char* buffer;
    __gl_get_render_large_buffer(
         44,           /* size of fixed parms */
         _size,        /* size of variable large parm (unpadded) */
         145,          /* opcode */
         sizeof(GLdouble)*n_values,   /* split on control point bndry */
         &buffer       /* adjusted start point-4 for fixed parms */ 
    );
    PUT_double(buffer+4, u1);
    PUT_double(buffer+12, u2);
    PUT_double(buffer+20, v1);
    PUT_double(buffer+28, v2);
    PUT_enum(buffer+36, target);
    PUT_int(buffer+40, uorder);
    PUT_int(buffer+44, vorder);
#ifdef DEBUG_RENDER_LARGE
    fprintf( stderr,
             "glMap2d: target 0x%x, u1 %e, u2 %e, ustride %d, uorder %d\n\
                 v1 %e, v2 %e, vstride %d, vorder %d\n",
             target,
             u1, u2, ustride, uorder,
             v1, v2, vstride, vorder
           );
#endif
    PUT_large_map2d(
       buffer+48, points,
       uorder, vorder,
       ustride, vstride,
       n_values
    );
}


void __glx_Map2f(GLenum target, GLfloat u1, GLfloat u2, GLint ustride,
	     GLint uorder, GLfloat v1, GLfloat v2, GLint vstride,
	     GLint vorder, const GLfloat* points)
{
    int n_values = GLX_map2_size(target);
    int _size=n_values*uorder*vorder*4;
    char* buffer;
    __gl_get_render_large_buffer(
         28,           /* size of fixed parms */
         _size,        /* size of variable large parm (unpadded) */
         146,          /* opcode */
         sizeof(GLfloat)*n_values,   /* split on control point bndry */
         &buffer       /* adjusted start point-4 for fixed parms */ 
    );
    PUT_enum(buffer+4, target);
    PUT_float(buffer+8, u1);
    PUT_float(buffer+12, u2);
    PUT_int(buffer+16, uorder);
    PUT_float(buffer+20, v1);
    PUT_float(buffer+24, v2);
    PUT_int(buffer+28, vorder);
#ifdef DEBUG_RENDER_LARGE
    fprintf( stderr,
             "glMap2f: target 0x%x, u1 %e, u2 %e, ustride %d, uorder %d\n\
                 v1 %e, v2 %e, vstride %d, vorder %d\n",
             target,
             u1, u2, ustride, uorder,
             v1, v2, vstride, vorder
           );
#endif
    PUT_large_map2f( 
       buffer+32, points, 
       uorder, vorder, 
       ustride, vstride, 
       n_values
    );
}

