
/*
 * GLX Server Extension
 * Copyright (C) 1996  Steven G. Parker  (sparker@cs.utah.edu)
 * Copyright (C) 1998, 1999  Terence Ripperda (ripperda@sgi.com)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * STEPHEN PARKER, TERENCE RIPPERDA, OR ANY OTHER CONTRIBUTORS BE LIABLE FOR 
 * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, 
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE 
 * OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

/*
 * GL Rendering Commands with Pixel Data
 * modified July 14, 1998 by Terence Ripperda (ripperda@engr.sgi.com)
 *
 * to help clean up some of the code and files I am splitting them 
 * up along more distinguished lines. This file corresponds to 
 * section 9.3.6 of the GLX Extension for OpenGL Protocol Specification
 * Version 1.2. This section describes the protocol for OpenGL calls
 * that Render and contain/transfer pixel data.
 */

#include "glxlib.h"
#include <stdio.h>


#define __GLX_PUT_PIXEL_DATA_ARGUMENTS				\
    PUT_byte(buffer+5, GLCurrent->unpack_lsb_first);		\
    PUT_uint(buffer+8, DEFAULT_UNPACK_ROW_LENGTH);		\
    PUT_uint(buffer+12, DEFAULT_UNPACK_SKIP_ROWS);		\
    PUT_uint(buffer+16, DEFAULT_UNPACK_SKIP_PIXELS);		\
    PUT_uint(buffer+20, GLCurrent->unpack_alignment);

void __glx_Bitmap(GLsizei width, GLsizei height,
	      GLfloat xorig, GLfloat yorig,
	      GLfloat xmove, GLfloat ymove,
	      const GLubyte* bitmap)
{
    char* buffer;
    int s=GLX_image_size(width, height, GL_COLOR_INDEX, GL_BITMAP);
    __gl_get_render_large_buffer(
         44,           /* size of fixed parms */
         s,            /* size of variable large parm (unpadded) */
         5,            /* opcode */
         1,            /* byte boundaries for splitting data */
         &buffer       /* adjusted start point-4 for fixed parms */ 
    );
    __GLX_PUT_PIXEL_DATA_ARGUMENTS;
    PUT_int(buffer+24, width);
    PUT_int(buffer+28, height);
    PUT_float(buffer+32, xorig);
    PUT_float(buffer+36, yorig);
    PUT_float(buffer+40, xmove);
    PUT_float(buffer+44, ymove);
    if (GLCurrent->need_unpacking) {
       PUT_unpacked_bitmap( buffer+48, bitmap, width, height);
    } else {
       PUT_buffer( buffer+48, bitmap, s);
    }
}


void __glx_DrawPixels(GLsizei width, GLsizei height,
		  GLenum format, GLenum type, const GLvoid*pixels)
{
    char* buffer;
    int s=GLX_image_size(width, height, format, type);
    __gl_get_render_large_buffer(
         36,           /* size of fixed parms */
         s,            /* size of variable large parm (unpadded) */
         173,          /* opcode */
         1,            /* byte boundaries for splitting data */
         &buffer       /* adjusted start point-4 for fixed parms */ 
    );
    __GLX_PUT_PIXEL_DATA_ARGUMENTS;
    PUT_sizei(buffer+24, width);
    PUT_sizei(buffer+28, height);
    PUT_enum(buffer+32, format);
    PUT_enum(buffer+36, type);
    if (GLCurrent->need_unpacking) {
       PUT_unpacked_buffer( buffer+40, pixels, width, height, type, format);
    } else {
       PUT_buffer( buffer+40, pixels, s);
    }
}


void __glx_PolygonStipple(const GLubyte* mask)
{
    char* buffer;
    int s=GLX_image_size(32, 32, GL_COLOR_INDEX, GL_BITMAP);
    __gl_get_render_large_buffer(
         20,           /* size of fixed parms */
         s,            /* size of variable large parm (unpadded) */
         102,          /* opcode */
         1,            /* byte boundaries for splitting data */
         &buffer       /* adjusted start point-4 for fixed parms */
    );
    PUT_byte(buffer+5, GLCurrent->unpack_lsb_first);
    PUT_uint(buffer+8, 32);
    PUT_uint(buffer+12, GLCurrent->unpack_skip_rows);
    PUT_uint(buffer+16, GLCurrent->unpack_skip_pixels);
    PUT_uint(buffer+20, GLCurrent->unpack_alignment); 
    if (GLCurrent->need_unpacking) {
       PUT_unpacked_bitmap( buffer+24, mask, 32, 32);
    } else {
       PUT_buffer( buffer+24, mask, s);
    }
}


void __glx_TexImage1D(GLenum target, GLint level, GLint components,
		  GLsizei width, GLint border, GLenum format,
		  GLenum type, const GLvoid*pixels)
{
    char* buffer;
    int s=GLX_image_size(width, 1, format, type);
    __gl_get_render_large_buffer(
         52,           /* size of fixed parms */
         s,            /* size of variable large parm (unpadded) */
         109,          /* opcode */
         1,            /* byte boundaries for splitting data */
         &buffer       /* adjusted start point-4 for fixed parms */ 
    );
    __GLX_PUT_PIXEL_DATA_ARGUMENTS;
    PUT_enum(buffer+24, target);
    PUT_int(buffer+28, level);
    PUT_int(buffer+32, components);
    PUT_sizei(buffer+36, width);
    PUT_int(buffer+44, border);
    PUT_enum(buffer+48, format);
    PUT_enum(buffer+52, type);

    if (GLCurrent->need_unpacking) {
       PUT_unpacked_buffer( buffer+56, pixels, width, 1, type, format);
    } else {
       PUT_buffer( buffer+56, pixels, s);
    }
}


void __glx_TexSubImage1D(GLenum target, GLint level, GLint xoffset,
                  GLsizei width, GLenum format, GLenum type,
                  const GLvoid *pixels)
{
    char* buffer;
    int s=GLX_image_size(width, 1, format, type);
    __gl_get_render_large_buffer(
         56,           /* size of fixed parms */
         s,            /* size of variable large parm (unpadded) */
         4099,         /* opcode */
         1,            /* byte boundaries for splitting data */
         &buffer       /* adjusted start point-4 for fixed parms */ 
    );
    __GLX_PUT_PIXEL_DATA_ARGUMENTS;
    PUT_enum(buffer+24, target);
    PUT_int(buffer+28, level);
    PUT_int(buffer+32, xoffset);
    PUT_int(buffer+36, 0);       /* y offset */
    PUT_int(buffer+40, width);
    PUT_int(buffer+44, 1);       /* height */
    PUT_enum(buffer+48, format);
    PUT_enum(buffer+52, type);

    if (GLCurrent->need_unpacking) {
       PUT_unpacked_buffer( buffer+60, pixels, width, 1, type, format);
    } else {
       PUT_buffer( buffer+60, pixels, s);
    }
}


void __glx_TexImage2D(GLenum target, GLint level, GLint components,
		  GLsizei width, GLsizei height, GLint border,
		  GLenum format, GLenum type, const GLvoid*pixels)
{
    char* buffer;
    int s=GLX_image_size(width, height, format, type);
    __gl_get_render_large_buffer(
         52,           /* size of fixed parms */
         s,            /* size of variable large parm (unpadded) */
         110,          /* opcode */
         1,            /* byte boundaries for splitting data */
         &buffer       /* adjusted start point-4 for fixed parms */ 
    );
    __GLX_PUT_PIXEL_DATA_ARGUMENTS;
    PUT_enum(buffer+24, target);
    PUT_int(buffer+28, level);
    PUT_int(buffer+32, components);
    PUT_sizei(buffer+36, width);
    PUT_sizei(buffer+40, height);
    PUT_int(buffer+44, border);
    PUT_enum(buffer+48, format);
    PUT_enum(buffer+52, type);

    if (GLCurrent->need_unpacking) {
       PUT_unpacked_buffer( buffer+56, pixels, width, height, type, format);
    } else {
       PUT_buffer( buffer+56, pixels, s);
    }
}


void __glx_TexSubImage2D(GLenum target, GLint level, GLint xoffset,
                  GLint yoffset, GLsizei width, GLsizei height,
                  GLenum format, GLenum type, const GLvoid *pixels) 
{
    char* buffer;
    int s=GLX_image_size(width, height, format, type);
    __gl_get_render_large_buffer(
         56,           /* size of fixed parms */
         s,            /* size of variable large parm (unpadded) */
         4100,         /* opcode */
         1,            /* byte boundaries for splitting data */
         &buffer       /* adjusted start point-4 for fixed parms */ 
    );
    __GLX_PUT_PIXEL_DATA_ARGUMENTS;
    PUT_enum(buffer+24, target);
    PUT_int(buffer+28, level);
    PUT_int(buffer+32, xoffset);
    PUT_int(buffer+36, yoffset);
    PUT_int(buffer+40, width);
    PUT_int(buffer+44, height);
    PUT_enum(buffer+48, format);
    PUT_enum(buffer+52, type);

    if (GLCurrent->need_unpacking) {
       PUT_unpacked_buffer( buffer+60, pixels, width, height, type, format);
    } else {
       PUT_buffer( buffer+60, pixels, s);
    }
}

