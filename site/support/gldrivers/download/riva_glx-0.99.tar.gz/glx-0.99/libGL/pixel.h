/* pixel.h,v 1.1 1998/10/10 11:36:59 ripperda Exp */

/*
 * Mesa 3-D graphics library
 * Version:  3.0
 * Copyright (C) 1995-1998  Brian Paul
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * BRIAN PAUL BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
 * AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */


/*
 * pixel.h,v
 * Revision 1.1  1998/10/10 11:36:59  ripperda
 * keep missing some of these new files..
 *
 */

#ifndef PIXEL_H
#define PIXEL_H


#include "glxlib.h"

void __glx_Bitmap(GLsizei width, GLsizei height,
              GLfloat xorig, GLfloat yorig,
              GLfloat xmove, GLfloat ymove,
              const GLubyte* bitmap);

void __glx_DrawPixels(GLsizei width, GLsizei height,
                  GLenum format, GLenum type, const GLvoid *pixels);

void __glx_PolygonStipple(const GLubyte* mask);

void __glx_TexImage1D(GLenum target, GLint level, GLint components,                  GLsizei width, GLint border, GLenum format,
                  GLenum type, const GLvoid*pixels);

void __glx_TexSubImage1D(GLenum target, GLint level, GLint xoffset,
                  GLsizei width, GLenum format, GLenum type,
                  const GLvoid *pixels);

void __glx_TexImage2D(GLenum target, GLint level, GLint components,
                  GLsizei width, GLsizei height, GLint border,
                  GLenum format, GLenum type, const GLvoid*pixels);

void __glx_TexSubImage2D(GLenum target, GLint level, GLint xoffset,
                  GLint yoffset, GLsizei width, GLsizei height,
                  GLenum format, GLenum type, const GLvoid *pixels);



#endif



