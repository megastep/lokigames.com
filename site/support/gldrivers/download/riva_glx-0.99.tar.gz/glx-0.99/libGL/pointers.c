/* pointers.c,v 1.1 1998/10/10 11:31:28 ripperda Exp */

/*
 * Mesa 3-D graphics library
 * Version:  3.0
 * Copyright (C) 1995-1998  Brian Paul
 * Copyright (C) 1998 Terence Ripperda (ripperda@sgi.com)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * BRIAN PAUL, TERENCE RIPPERDA, OR ANY OTHER CONTRIBUTORS BE LIABLE FOR ANY 
 * CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT 
 * OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR  
 * THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */


/*
 * pointers.c,v
 * Revision 1.1  1998/10/10 11:31:28  ripperda
 * added for api table, integrating with Mesa
 *
 * Revision 3.3  1998/06/07 22:18:52  brianp
 * implemented GL_EXT_multitexture extension
 *
 * Revision 3.2  1998/02/20 04:50:44  brianp
 * implemented GL_SGIS_multitexture
 *
 * Revision 3.1  1998/02/01 20:05:10  brianp
 * added glDrawRangeElements()
 *
 * Revision 3.0  1998/01/31 21:00:28  brianp
 * initial rev
 *
 */

#include "glxlib.h"
#include "pointers.h"
#include "misc.h"


/*
 * For debugging
 */
static void check_pointers( struct gl_api_table *table )
{
   void **entry;
   int numentries = sizeof( struct gl_api_table ) / sizeof(void*);
   int i;

   entry = (void **) table;

   for (i=0;i<numentries;i++) {
      if (!entry[i]) {
         printf("found uninitialized function pointer at %d\n", i );
         __glx_problem( "Missing pointer in pointers.c");
         /*abort()*/
      }
   }
}

#if 0
/*
 * Assign all the pointers in 'table' to point to Mesa's immediate-mode
 * execution functions.
 */
static void init_direct_execution_pointers( struct gl_api_table *table )
{
   table->Accum = gl_Accum;
   table->AlphaFunc = gl_AlphaFunc;
   table->AreTexturesResident = gl_AreTexturesResident;
   table->ArrayElement = gl_ArrayElement;
   table->Begin = gl_Begin;
   table->BindTexture = gl_BindTexture;
   table->Bitmap = gl_Bitmap;
   table->BlendColor = gl_BlendColor;
   table->BlendEquation = gl_BlendEquation;
   table->BlendFunc = gl_BlendFunc;
   table->CallList = gl_CallList;
   table->CallLists = gl_CallLists;
   table->Clear = gl_Clear;
   table->ClearAccum = gl_ClearAccum;
   table->ClearColor = gl_ClearColor;
   table->ClearDepth = gl_ClearDepth;
   table->ClearIndex = gl_ClearIndex;
   table->ClearStencil = gl_ClearStencil;
   table->ClipPlane = gl_ClipPlane;
   table->Color3f = gl_Color3f;
   table->Color3fv = gl_Color3fv;
   table->Color4f = gl_Color4f;
   table->Color4fv = gl_Color4fv;
   table->Color4ub = gl_Color4ub;
   table->Color4ubv = gl_Color4ubv;
   table->ColorMask = gl_ColorMask;
   table->ColorMaterial = gl_ColorMaterial;
   table->ColorPointer = gl_ColorPointer;
   table->ColorTable = gl_ColorTable;
   table->ColorSubTable = gl_ColorSubTable;
   table->CopyPixels = gl_CopyPixels;
   table->CopyTexImage1D = gl_CopyTexImage1D;
   table->CopyTexImage2D = gl_CopyTexImage2D;
   table->CopyTexSubImage1D = gl_CopyTexSubImage1D;
   table->CopyTexSubImage2D = gl_CopyTexSubImage2D;
   table->CopyTexSubImage3DEXT = gl_CopyTexSubImage3DEXT;
   table->CullFace = gl_CullFace;
   table->DeleteLists = gl_DeleteLists;
   table->DeleteTextures = gl_DeleteTextures;
   table->DepthFunc = gl_DepthFunc;
   table->DepthMask = gl_DepthMask;
   table->DepthRange = gl_DepthRange;
   table->Disable = gl_Disable;
   table->DisableClientState = gl_DisableClientState;
   table->DrawArrays = gl_DrawArrays;
   table->DrawBuffer = gl_DrawBuffer;
   table->DrawElements = gl_DrawElements;
   table->DrawPixels = gl_DrawPixels;
   table->DrawRangeElements = gl_DrawRangeElements;
   table->EdgeFlag = gl_EdgeFlag;
   table->EdgeFlagPointer = gl_EdgeFlagPointer;
   table->Enable = gl_Enable;
   table->EnableClientState = gl_EnableClientState;
   table->End = gl_End;
   table->EndList = gl_EndList;
   table->EvalCoord1f = gl_EvalCoord1f;
   table->EvalCoord2f = gl_EvalCoord2f;
   table->EvalMesh1 = gl_EvalMesh1;
   table->EvalMesh2 = gl_EvalMesh2;
   table->EvalPoint1 = gl_EvalPoint1;
   table->EvalPoint2 = gl_EvalPoint2;
   table->FeedbackBuffer = gl_FeedbackBuffer;
   table->Finish = gl_Finish;
   table->Flush = gl_Flush;
   table->Fogfv = gl_Fogfv;
   table->FrontFace = gl_FrontFace;
   table->Frustum = gl_Frustum;
   table->GenLists = gl_GenLists;
   table->GenTextures = gl_GenTextures;
   table->GetBooleanv = gl_GetBooleanv;
   table->GetClipPlane = gl_GetClipPlane;
   table->GetColorTable = gl_GetColorTable;
   table->GetColorTableParameteriv = gl_GetColorTableParameteriv;
   table->GetDoublev = gl_GetDoublev;
   table->GetError = gl_GetError;
   table->GetFloatv = gl_GetFloatv;
   table->GetIntegerv = gl_GetIntegerv;
   table->GetPointerv = gl_GetPointerv;
   table->GetLightfv = gl_GetLightfv;
   table->GetLightiv = gl_GetLightiv;
   table->GetMapdv = gl_GetMapdv;
   table->GetMapfv = gl_GetMapfv;
   table->GetMapiv = gl_GetMapiv;
   table->GetMaterialfv = gl_GetMaterialfv;
   table->GetMaterialiv = gl_GetMaterialiv;
   table->GetPixelMapfv = gl_GetPixelMapfv;
   table->GetPixelMapuiv = gl_GetPixelMapuiv;
   table->GetPixelMapusv = gl_GetPixelMapusv;
   table->GetPolygonStipple = gl_GetPolygonStipple;
   table->GetString = gl_GetString;
   table->GetTexEnvfv = gl_GetTexEnvfv;
   table->GetTexEnviv = gl_GetTexEnviv;
   table->GetTexGendv = gl_GetTexGendv;
   table->GetTexGenfv = gl_GetTexGenfv;
   table->GetTexGeniv = gl_GetTexGeniv;
   table->GetTexImage = gl_GetTexImage;
   table->GetTexLevelParameterfv = gl_GetTexLevelParameterfv;
   table->GetTexLevelParameteriv = gl_GetTexLevelParameteriv;
   table->GetTexParameterfv = gl_GetTexParameterfv;
   table->GetTexParameteriv = gl_GetTexParameteriv;
   table->Hint = gl_Hint;
   table->Indexf = gl_Indexf;
   table->Indexi = gl_Indexi;
   table->IndexMask = gl_IndexMask;
   table->IndexPointer = gl_IndexPointer;
   table->InitNames = gl_InitNames;
   table->InterleavedArrays = gl_InterleavedArrays;
   table->IsEnabled = gl_IsEnabled;
   table->IsList = gl_IsList;
   table->IsTexture = gl_IsTexture;
   table->LightModelfv = gl_LightModelfv;
   table->Lightfv = gl_Lightfv;
   table->LineStipple = gl_LineStipple;
   table->LineWidth = gl_LineWidth;
   table->ListBase = gl_ListBase;
   table->LoadIdentity = gl_LoadIdentity;
   table->LoadMatrixf = gl_LoadMatrixf;
   table->LoadName = gl_LoadName;
   table->LogicOp = gl_LogicOp;
   table->Map1f = gl_Map1f;
   table->Map2f = gl_Map2f;
   table->MapGrid1f = gl_MapGrid1f;
   table->MapGrid2f = gl_MapGrid2f;
   table->Materialfv = gl_Materialfv;
   table->MatrixMode = gl_MatrixMode;
   table->MultMatrixf = gl_MultMatrixf;
   table->NewList = gl_NewList;
   table->Normal3f = gl_Normal3f;
   table->NormalPointer = gl_NormalPointer;
   table->Normal3fv = gl_Normal3fv;
   table->Ortho = gl_Ortho;
   table->PassThrough = gl_PassThrough;
   table->PixelMapfv = gl_PixelMapfv;
   table->PixelStorei = gl_PixelStorei;
   table->PixelTransferf = gl_PixelTransferf;
   table->PixelZoom = gl_PixelZoom;
   table->PointSize = gl_PointSize;
   table->PolygonMode = gl_PolygonMode;
   table->PolygonOffset = gl_PolygonOffset;
   table->PolygonStipple = gl_PolygonStipple;
   table->PopAttrib = gl_PopAttrib;
   table->PopClientAttrib = gl_PopClientAttrib;
   table->PopMatrix = gl_PopMatrix;
   table->PopName = gl_PopName;
   table->PrioritizeTextures = gl_PrioritizeTextures;
   table->PushAttrib = gl_PushAttrib;
   table->PushClientAttrib = gl_PushClientAttrib;
   table->PushMatrix = gl_PushMatrix;
   table->PushName = gl_PushName;
   table->RasterPos4f = gl_RasterPos4f;
   table->ReadBuffer = gl_ReadBuffer;
   table->ReadPixels = gl_ReadPixels;
   table->Rectf = gl_Rectf;
   table->RenderMode = gl_RenderMode;
   table->Rotatef = gl_Rotatef;
   table->Scalef = gl_Scalef;
   table->Scissor = gl_Scissor;
   table->SelectBuffer = gl_SelectBuffer;
   table->ShadeModel = gl_ShadeModel;
   table->StencilFunc = gl_StencilFunc;
   table->StencilMask = gl_StencilMask;
   table->StencilOp = gl_StencilOp;
   table->TexCoord2f = gl_TexCoord2f;
   table->TexCoord4f = gl_TexCoord4f;
   table->TexCoordPointer = gl_TexCoordPointer;
   table->TexEnvfv = gl_TexEnvfv;
   table->TexGenfv = gl_TexGenfv;
   table->TexImage1D = gl_TexImage1D;
   table->TexImage2D = gl_TexImage2D;
   table->TexImage3DEXT = gl_TexImage3DEXT;
   table->TexSubImage1D = gl_TexSubImage1D;
   table->TexSubImage2D = gl_TexSubImage2D;
   table->TexSubImage3DEXT = gl_TexSubImage3DEXT;
   table->PointParameterfvEXT = gl_PointParameterfvEXT;
   table->TexParameterfv = gl_TexParameterfv;
   table->Translatef = gl_Translatef;
   table->Vertex2f = gl_vertex2f_nop;
   table->Vertex3f = gl_vertex3f_nop;
   table->Vertex4f = gl_vertex4f_nop;
   table->Vertex3fv = gl_vertex3fv_nop;
   table->VertexPointer = gl_VertexPointer;
   table->Viewport = gl_Viewport;

   /* GL_MESA_window_pos extension */
   table->WindowPos4fMESA = gl_WindowPos4fMESA;

   /* GL_MESA_resize_buffers extension */
   table->ResizeBuffersMESA = gl_ResizeBuffersMESA;

   /* GL_SGIS_multitexture / GL_EXT_multitexture */
   table->MultiTexCoord4f = gl_MultiTexCoord4f;
   table->MultiTexCoordPointer = gl_MultiTexCoordPointer;
   table->InterleavedTextureCoordSets = gl_InterleavedTextureCoordSets;
   table->SelectTextureSGIS = gl_SelectTextureSGIS;
   table->SelectTexture = gl_SelectTexture;
   table->SelectTextureCoordSet = gl_SelectTextureCoordSet;
   table->SelectTextureTransform = gl_SelectTextureTransform;
}
#endif

/*
 * Assign all the pointers in 'table' to point to Mesa's immediate-mode
 * execution functions.
 */
static void init_indirect_execution_pointers( struct gl_api_table *table )
{
   table->Accum = __glx_Accum;
   table->AlphaFunc = __glx_AlphaFunc;
   table->AreTexturesResident = __glx_AreTexturesResident;
   table->ArrayElement = __glx_ArrayElement;
   table->Begin = __glx_Begin;
   table->BindTexture = __glx_BindTexture;
   table->Bitmap = __glx_Bitmap;
   table->BlendColor = __glx_BlendColorEXT;
   table->BlendEquation = __glx_BlendEquationEXT;
   table->BlendFunc = __glx_BlendFunc;
   table->CallList = __glx_CallList;
   table->CallLists = __glx_CallLists;
   table->Clear = __glx_Clear;
   table->ClearAccum = __glx_ClearAccum;
   table->ClearColor = __glx_ClearColor;
   table->ClearDepth = __glx_ClearDepth;
   table->ClearIndex = __glx_ClearIndex;
   table->ClearStencil = __glx_ClearStencil;
   table->ClipPlane = __glx_ClipPlane;
   table->Color3f = __glx_Color3f;
   table->Color3fv = __glx_Color3fv;
   table->Color4f = __glx_Color4f;
   table->Color4fv = __glx_Color4fv;
   table->Color4ub = __glx_Color4ub;
   table->Color4ubv = __glx_Color4ubv;
   table->ColorMask = __glx_ColorMask;
   table->ColorMaterial = __glx_ColorMaterial;
   table->ColorPointer = __glx_ColorPointer;
#if 0
   table->ColorTable = __glx_ColorTable;
   table->ColorSubTable = __glx_ColorSubTable;
#endif
   table->CopyPixels = __glx_CopyPixels;
   table->CopyTexImage1D = __glx_CopyTexImage1D;
   table->CopyTexImage2D = __glx_CopyTexImage2D;
   table->CopyTexSubImage1D = __glx_CopyTexSubImage1D;
   table->CopyTexSubImage2D = __glx_CopyTexSubImage2D;
#if 0
   table->CopyTexSubImage3DEXT = __glx_CopyTexSubImage3DEXT;
#endif
   table->CullFace = __glx_CullFace;
   table->DeleteLists = __glx_DeleteLists;
   table->DeleteTextures = __glx_DeleteTextures;
   table->DepthFunc = __glx_DepthFunc;
   table->DepthMask = __glx_DepthMask;
   table->DepthRange = __glx_DepthRange;
   table->Disable = __glx_Disable;
   table->DisableClientState = __glx_DisableClientState;
   table->DrawArrays = __glx_DrawArrays;
   table->DrawBuffer = __glx_DrawBuffer;
   table->DrawElements = __glx_DrawElements;
   table->DrawPixels = __glx_DrawPixels;
   table->DrawRangeElements = __glx_DrawRangeElements;
   table->EdgeFlag = __glx_EdgeFlag;
   table->EdgeFlagPointer = __glx_EdgeFlagPointer;
   table->Enable = __glx_Enable;
   table->EnableClientState = __glx_EnableClientState;
   table->End = __glx_End;
   table->EndList = __glx_EndList;
   table->EvalCoord1f = __glx_EvalCoord1f;
   table->EvalCoord2f = __glx_EvalCoord2f;
   table->EvalMesh1 = __glx_EvalMesh1;
   table->EvalMesh2 = __glx_EvalMesh2;
   table->EvalPoint1 = __glx_EvalPoint1;
   table->EvalPoint2 = __glx_EvalPoint2;
   table->FeedbackBuffer = __glx_FeedbackBuffer;
   table->Finish = __glx_Finish;
   table->Flush = __glx_Flush;
   table->Fogfv = __glx_Fogfv;
   table->FrontFace = __glx_FrontFace;
   table->Frustum = __glx_Frustum;
   table->GenLists = __glx_GenLists;
   table->GenTextures = __glx_GenTextures;
   table->GetBooleanv = __glx_GetBooleanv;
   table->GetClipPlane = __glx_GetClipPlane;
#if 0
   table->GetColorTable = __glx_GetColorTable;
   table->GetColorTableParameteriv = __glx_GetColorTableParameteriv;
#endif
   table->GetDoublev = __glx_GetDoublev;
   table->GetError = __glx_GetError;
   table->GetFloatv = __glx_GetFloatv;
   table->GetIntegerv = __glx_GetIntegerv;
   table->GetPointerv = __glx_GetPointerv;
   table->GetLightfv = __glx_GetLightfv;
   table->GetLightiv = __glx_GetLightiv;
   table->GetMapdv = __glx_GetMapdv;
   table->GetMapfv = __glx_GetMapfv;
   table->GetMapiv = __glx_GetMapiv;
   table->GetMaterialfv = __glx_GetMaterialfv;
   table->GetMaterialiv = __glx_GetMaterialiv;
   table->GetPixelMapfv = __glx_GetPixelMapfv;
   table->GetPixelMapuiv = __glx_GetPixelMapuiv;
   table->GetPixelMapusv = __glx_GetPixelMapusv;
   table->GetPolygonStipple = __glx_GetPolygonStipple;
   table->GetString = __glx_GetString;
   table->GetTexEnvfv = __glx_GetTexEnvfv;
   table->GetTexEnviv = __glx_GetTexEnviv;
   table->GetTexGendv = __glx_GetTexGendv;
   table->GetTexGenfv = __glx_GetTexGenfv;
   table->GetTexGeniv = __glx_GetTexGeniv;
   table->GetTexImage = __glx_GetTexImage;
   table->GetTexLevelParameterfv = __glx_GetTexLevelParameterfv;
   table->GetTexLevelParameteriv = __glx_GetTexLevelParameteriv;
   table->GetTexParameterfv = __glx_GetTexParameterfv;
   table->GetTexParameteriv = __glx_GetTexParameteriv;
   table->Hint = __glx_Hint;
   table->Indexf = __glx_Indexf;
   table->Indexi = __glx_Indexi;
   table->IndexMask = __glx_IndexMask;
   table->IndexPointer = __glx_IndexPointer;
   table->InitNames = __glx_InitNames;
   table->InterleavedArrays = __glx_InterleavedArrays;
   table->IsEnabled = __glx_IsEnabled;
   table->IsList = __glx_IsList;
   table->IsTexture = __glx_IsTexture;
   table->LightModelfv = __glx_LightModelfv;
   table->Lightfv = __glx_Lightfv;
   table->LineStipple = __glx_LineStipple;
   table->LineWidth = __glx_LineWidth;
   table->ListBase = __glx_ListBase;
   table->LoadIdentity = __glx_LoadIdentity;
   table->LoadMatrixf = __glx_LoadMatrixf;
   table->LoadName = __glx_LoadName;
   table->LogicOp = __glx_LogicOp;
   table->Map1d = __glx_Map1d;
   table->Map1f = __glx_Map1f;
   table->Map2d = __glx_Map2d;
   table->Map2f = __glx_Map2f;
   table->MapGrid1f = __glx_MapGrid1f;
   table->MapGrid2f = __glx_MapGrid2f;
   table->Materialfv = __glx_Materialfv;
   table->MatrixMode = __glx_MatrixMode;
   table->MultMatrixf = __glx_MultMatrixf;
   table->NewList = __glx_NewList;
   table->Normal3f = __glx_Normal3f;
   table->NormalPointer = __glx_NormalPointer;
   table->Normal3fv = __glx_Normal3fv;
   table->Ortho = __glx_Ortho;
   table->PassThrough = __glx_PassThrough;
   table->PixelMapfv = __glx_PixelMapfv;
   table->PixelStorei = __glx_PixelStorei;
   table->PixelTransferf = __glx_PixelTransferf;
   table->PixelZoom = __glx_PixelZoom;
   table->PointSize = __glx_PointSize;
   table->PolygonMode = __glx_PolygonMode;
   table->PolygonOffset = __glx_PolygonOffset;
   table->PolygonStipple = __glx_PolygonStipple;
   table->PopAttrib = __glx_PopAttrib;
   table->PopClientAttrib = __glx_PopClientAttrib;
   table->PopMatrix = __glx_PopMatrix;
   table->PopName = __glx_PopName;
   table->PrioritizeTextures = __glx_PrioritizeTextures;
   table->PushAttrib = __glx_PushAttrib;
   table->PushClientAttrib = __glx_PushClientAttrib;
   table->PushMatrix = __glx_PushMatrix;
   table->PushName = __glx_PushName;
   table->RasterPos4f = __glx_RasterPos4f;
   table->ReadBuffer = __glx_ReadBuffer;
   table->ReadPixels = __glx_ReadPixels;
   table->Rectf = __glx_Rectf;
   table->RenderMode = __glx_RenderMode;
   table->Rotatef = __glx_Rotatef;
   table->Scalef = __glx_Scalef;
   table->Scissor = __glx_Scissor;
   table->SelectBuffer = __glx_SelectBuffer;
   table->ShadeModel = __glx_ShadeModel;
   table->StencilFunc = __glx_StencilFunc;
   table->StencilMask = __glx_StencilMask;
   table->StencilOp = __glx_StencilOp;
   table->TexCoord2f = __glx_TexCoord2f;
   table->TexCoord4f = __glx_TexCoord4f;
   table->TexCoordPointer = __glx_TexCoordPointer;
   table->TexEnvfv = __glx_TexEnvfv;
   table->TexGenfv = __glx_TexGenfv;
   table->TexImage1D = __glx_TexImage1D;
   table->TexImage2D = __glx_TexImage2D;
#if 0
   table->TexImage3DEXT = __glx_TexImage3DEXT;
#endif
   table->TexSubImage1D = __glx_TexSubImage1D;
   table->TexSubImage2D = __glx_TexSubImage2D;
#if 0
   table->TexSubImage3DEXT = __glx_TexSubImage3DEXT;
   table->PointParameterfvEXT = __glx_PointParameterfvEXT;
#endif
   table->TexParameterfv = __glx_TexParameterfv;
   table->Translatef = __glx_Translatef;

   table->Vertex2d = __glx_Vertex2d;
   table->Vertex2dv = __glx_Vertex2dv;
   table->Vertex2f = __glx_Vertex2f;
   table->Vertex2fv = __glx_Vertex2fv;
   table->Vertex2i = __glx_Vertex2i;
   table->Vertex2iv = __glx_Vertex2iv;
   table->Vertex2s = __glx_Vertex2s;
   table->Vertex2sv = __glx_Vertex2sv;

   table->Vertex3d = __glx_Vertex3d;
   table->Vertex3dv = __glx_Vertex3dv;
   table->Vertex3f = __glx_Vertex3f;
   table->Vertex3fv = __glx_Vertex3fv;
   table->Vertex3i = __glx_Vertex3i;
   table->Vertex3iv = __glx_Vertex3iv;
   table->Vertex3s = __glx_Vertex3s;
   table->Vertex3sv = __glx_Vertex3sv;

   table->Vertex4d = __glx_Vertex4d;
   table->Vertex4dv = __glx_Vertex4dv;
   table->Vertex4f = __glx_Vertex4f;
   table->Vertex4fv = __glx_Vertex4fv;
   table->Vertex4i = __glx_Vertex4i;
   table->Vertex4iv = __glx_Vertex4iv;
   table->Vertex4s = __glx_Vertex4s;
   table->Vertex4sv = __glx_Vertex4sv;

   table->VertexPointer = __glx_VertexPointer;
   table->Viewport = __glx_Viewport;

#if 0
   /* GL_MESA_window_pos extension */
   table->WindowPos4fMESA = __glx_WindowPos4fMESA;

   /* GL_MESA_resize_buffers extension */
   table->ResizeBuffersMESA = __glx_ResizeBuffersMESA;

   /* GL_SGIS_multitexture / GL_EXT_multitexture */
   table->MultiTexCoord4f = __glx_MultiTexCoord4f;
   table->MultiTexCoordPointer = __glx_MultiTexCoordPointer;
   table->InterleavedTextureCoordSets = __glx_InterleavedTextureCoordSets;
   table->SelectTextureSGIS = __glx_SelectTextureSGIS;
   table->SelectTexture = __glx_SelectTexture;
   table->SelectTextureCoordSet = __glx_SelectTextureCoordSet;
   table->SelectTextureTransform = __glx_SelectTextureTransform;
#endif
}


#if 0
/*
 * Assign all the pointers in 'table' to point to Mesa's display list
 * building functions.
 */
static void init_dlist_pointers( struct gl_api_table *table )
{
   table->Accum = gl_save_Accum;
   table->AlphaFunc = gl_save_AlphaFunc;
   table->AreTexturesResident = gl_AreTexturesResident;
   table->ArrayElement = gl_save_ArrayElement;
   table->Begin = gl_save_Begin;
   table->BindTexture = gl_save_BindTexture;
   table->Bitmap = gl_save_Bitmap;
   table->BlendColor = gl_save_BlendColor;
   table->BlendEquation = gl_save_BlendEquation;
   table->BlendFunc = gl_save_BlendFunc;
   table->CallList = gl_save_CallList;
   table->CallLists = gl_save_CallLists;
   table->Clear = gl_save_Clear;
   table->ClearAccum = gl_save_ClearAccum;
   table->ClearColor = gl_save_ClearColor;
   table->ClearDepth = gl_save_ClearDepth;
   table->ClearIndex = gl_save_ClearIndex;
   table->ClearStencil = gl_save_ClearStencil;
   table->ClipPlane = gl_save_ClipPlane;
   table->Color3f = gl_save_Color3f;
   table->Color3fv = gl_save_Color3fv;
   table->Color4f = gl_save_Color4f;
   table->Color4fv = gl_save_Color4fv;
   table->Color4ub = gl_save_Color4ub;
   table->Color4ubv = gl_save_Color4ubv;
   table->ColorMask = gl_save_ColorMask;
   table->ColorMaterial = gl_save_ColorMaterial;
   table->ColorPointer = gl_ColorPointer;
   table->ColorTable = gl_save_ColorTable;
   table->ColorSubTable = gl_save_ColorSubTable;
   table->CopyPixels = gl_save_CopyPixels;
   table->CopyTexImage1D = gl_save_CopyTexImage1D;
   table->CopyTexImage2D = gl_save_CopyTexImage2D;
   table->CopyTexSubImage1D = gl_save_CopyTexSubImage1D;
   table->CopyTexSubImage2D = gl_save_CopyTexSubImage2D;
   table->CopyTexSubImage3DEXT = gl_save_CopyTexSubImage3DEXT;
   table->CullFace = gl_save_CullFace;
   table->DeleteLists = gl_DeleteLists;   /* NOT SAVED */
   table->DeleteTextures = gl_DeleteTextures;  /* NOT SAVED */
   table->DepthFunc = gl_save_DepthFunc;
   table->DepthMask = gl_save_DepthMask;
   table->DepthRange = gl_save_DepthRange;
   table->Disable = gl_save_Disable;
   table->DisableClientState = gl_DisableClientState;  /* NOT SAVED */
   table->DrawArrays = gl_save_DrawArrays;
   table->DrawBuffer = gl_save_DrawBuffer;
   table->DrawElements = gl_save_DrawElements;
   table->DrawPixels = gl_save_DrawPixels;
   table->DrawRangeElements = gl_save_DrawRangeElements;
   table->EdgeFlag = gl_save_EdgeFlag;
   table->EdgeFlagPointer = gl_EdgeFlagPointer;
   table->Enable = gl_save_Enable;
   table->EnableClientState = gl_EnableClientState;   /* NOT SAVED */
   table->End = gl_save_End;
   table->EndList = gl_EndList;   /* NOT SAVED */
   table->EvalCoord1f = gl_save_EvalCoord1f;
   table->EvalCoord2f = gl_save_EvalCoord2f;
   table->EvalMesh1 = gl_save_EvalMesh1;
   table->EvalMesh2 = gl_save_EvalMesh2;
   table->EvalPoint1 = gl_save_EvalPoint1;
   table->EvalPoint2 = gl_save_EvalPoint2;
   table->FeedbackBuffer = gl_FeedbackBuffer;   /* NOT SAVED */
   table->Finish = gl_Finish;   /* NOT SAVED */
   table->Flush = gl_Flush;   /* NOT SAVED */
   table->Fogfv = gl_save_Fogfv;
   table->FrontFace = gl_save_FrontFace;
   table->Frustum = gl_save_Frustum;
   table->GenLists = gl_GenLists;   /* NOT SAVED */
   table->GenTextures = gl_GenTextures;   /* NOT SAVED */

   /* NONE OF THESE COMMANDS ARE COMPILED INTO DISPLAY LISTS */
   table->GetBooleanv = gl_GetBooleanv;
   table->GetClipPlane = gl_GetClipPlane;
   table->GetColorTable = gl_GetColorTable;
   table->GetColorTableParameteriv = gl_GetColorTableParameteriv;
   table->GetDoublev = gl_GetDoublev;
   table->GetError = gl_GetError;
   table->GetFloatv = gl_GetFloatv;
   table->GetIntegerv = gl_GetIntegerv;
   table->GetString = gl_GetString;
   table->GetLightfv = gl_GetLightfv;
   table->GetLightiv = gl_GetLightiv;
   table->GetMapdv = gl_GetMapdv;
   table->GetMapfv = gl_GetMapfv;
   table->GetMapiv = gl_GetMapiv;
   table->GetMaterialfv = gl_GetMaterialfv;
   table->GetMaterialiv = gl_GetMaterialiv;
   table->GetPixelMapfv = gl_GetPixelMapfv;
   table->GetPixelMapuiv = gl_GetPixelMapuiv;
   table->GetPixelMapusv = gl_GetPixelMapusv;
   table->GetPointerv = gl_GetPointerv;
   table->GetPolygonStipple = gl_GetPolygonStipple;
   table->GetTexEnvfv = gl_GetTexEnvfv;
   table->GetTexEnviv = gl_GetTexEnviv;
   table->GetTexGendv = gl_GetTexGendv;
   table->GetTexGenfv = gl_GetTexGenfv;
   table->GetTexGeniv = gl_GetTexGeniv;
   table->GetTexImage = gl_GetTexImage;
   table->GetTexLevelParameterfv = gl_GetTexLevelParameterfv;
   table->GetTexLevelParameteriv = gl_GetTexLevelParameteriv;
   table->GetTexParameterfv = gl_GetTexParameterfv;
   table->GetTexParameteriv = gl_GetTexParameteriv;

   table->Hint = gl_save_Hint;
   table->IndexMask = gl_save_IndexMask;
   table->Indexf = gl_save_Indexf;
   table->Indexi = gl_save_Indexi;
   table->IndexPointer = gl_IndexPointer;
   table->InitNames = gl_save_InitNames;
   table->InterleavedArrays = gl_save_InterleavedArrays;
   table->IsEnabled = gl_IsEnabled;   /* NOT SAVED */
   table->IsTexture = gl_IsTexture;   /* NOT SAVED */
   table->IsList = gl_IsList;   /* NOT SAVED */
   table->LightModelfv = gl_save_LightModelfv;
   table->Lightfv = gl_save_Lightfv;
   table->LineStipple = gl_save_LineStipple;
   table->LineWidth = gl_save_LineWidth;
   table->ListBase = gl_save_ListBase;
   table->LoadIdentity = gl_save_LoadIdentity;
   table->LoadMatrixf = gl_save_LoadMatrixf;
   table->LoadName = gl_save_LoadName;
   table->LogicOp = gl_save_LogicOp;
   table->Map1f = gl_save_Map1f;
   table->Map2f = gl_save_Map2f;
   table->MapGrid1f = gl_save_MapGrid1f;
   table->MapGrid2f = gl_save_MapGrid2f;
   table->Materialfv = gl_save_Materialfv;
   table->MatrixMode = gl_save_MatrixMode;
   table->MultMatrixf = gl_save_MultMatrixf;
   table->NewList = gl_save_NewList;
   table->Normal3f = gl_save_Normal3f;
   table->Normal3fv = gl_save_Normal3fv;
   table->NormalPointer = gl_NormalPointer;  /* NOT SAVED */
   table->Ortho = gl_save_Ortho;
   table->PointParameterfvEXT = gl_save_PointParameterfvEXT;
   table->PassThrough = gl_save_PassThrough;
   table->PixelMapfv = gl_save_PixelMapfv;
   table->PixelStorei = gl_PixelStorei;   /* NOT SAVED */
   table->PixelTransferf = gl_save_PixelTransferf;
   table->PixelZoom = gl_save_PixelZoom;
   table->PointSize = gl_save_PointSize;
   table->PolygonMode = gl_save_PolygonMode;
   table->PolygonOffset = gl_save_PolygonOffset;
   table->PolygonStipple = gl_save_PolygonStipple;
   table->PopAttrib = gl_save_PopAttrib;
   table->PopClientAttrib = gl_PopClientAttrib;  /* NOT SAVED */
   table->PopMatrix = gl_save_PopMatrix;
   table->PopName = gl_save_PopName;
   table->PrioritizeTextures = gl_save_PrioritizeTextures;
   table->PushAttrib = gl_save_PushAttrib;
   table->PushClientAttrib = gl_PushClientAttrib;  /* NOT SAVED */
   table->PushMatrix = gl_save_PushMatrix;
   table->PushName = gl_save_PushName;
   table->RasterPos4f = gl_save_RasterPos4f;
   table->ReadBuffer = gl_save_ReadBuffer;
   table->ReadPixels = gl_ReadPixels;   /* NOT SAVED */
   table->Rectf = gl_save_Rectf;
   table->RenderMode = gl_RenderMode;   /* NOT SAVED */
   table->Rotatef = gl_save_Rotatef;
   table->Scalef = gl_save_Scalef;
   table->Scissor = gl_save_Scissor;
   table->SelectBuffer = gl_SelectBuffer;   /* NOT SAVED */
   table->ShadeModel = gl_save_ShadeModel;
   table->StencilFunc = gl_save_StencilFunc;
   table->StencilMask = gl_save_StencilMask;
   table->StencilOp = gl_save_StencilOp;
   table->TexCoord2f = gl_save_TexCoord2f;
   table->TexCoord4f = gl_save_TexCoord4f;
   table->TexCoordPointer = gl_TexCoordPointer;  /* NOT SAVED */
   table->TexEnvfv = gl_save_TexEnvfv;
   table->TexGenfv = gl_save_TexGenfv;
   table->TexImage1D = gl_save_TexImage1D;
   table->TexImage2D = gl_save_TexImage2D;
   table->TexImage3DEXT = gl_save_TexImage3DEXT;
   table->TexSubImage1D = gl_save_TexSubImage1D;
   table->TexSubImage2D = gl_save_TexSubImage2D;
   table->TexSubImage3DEXT = gl_save_TexSubImage3DEXT;
   table->TexParameterfv = gl_save_TexParameterfv;
   table->Translatef = gl_save_Translatef;
   table->Vertex2f = gl_save_Vertex2f;
   table->Vertex3f = gl_save_Vertex3f;
   table->Vertex4f = gl_save_Vertex4f;
   table->Vertex3fv = gl_save_Vertex3fv;
   table->VertexPointer = gl_VertexPointer;  /* NOT SAVED */
   table->Viewport = gl_save_Viewport;

   /* GL_MESA_window_pos extension */
   table->WindowPos4fMESA = gl_save_WindowPos4fMESA;

   /* GL_MESA_resize_buffers extension */
   table->ResizeBuffersMESA = gl_ResizeBuffersMESA;

   /* GL_SGIS_multitexture */
   table->MultiTexCoord4f = gl_save_MultiTexCoord4f;
   table->MultiTexCoordPointer = gl_MultiTexCoordPointer;   /* NOT SAVED */
   table->InterleavedTextureCoordSets = gl_InterleavedTextureCoordSets;  /* NOT SAVED */
   table->SelectTextureSGIS = gl_save_SelectTextureSGIS;
   table->SelectTexture = gl_save_SelectTexture;
   table->SelectTextureCoordSet = gl_save_SelectTextureCoordSet;
   table->SelectTextureTransform = gl_save_SelectTextureTransform;
}
#endif


void gl_init_api_function_pointers( GLContext *ctx )
{
#if 0
   if (ctx->DirectContext) {
      init_direct_execution_pointers( &ctx->Exec );
   } else {
#endif
      init_indirect_execution_pointers( &ctx->API );
#if 0
   }

   init_dlist_pointers( &ctx->Save );

   /* make sure there's no NULL pointers */
   check_pointers( &ctx->Save );
   check_pointers( &ctx->API);
#endif
}

