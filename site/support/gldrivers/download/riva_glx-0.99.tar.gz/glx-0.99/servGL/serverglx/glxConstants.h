
/*
 * GLX Server Extension
 * Copyright (C) 1998, 1999 Terence Ripperda (ripperda@sgi.com)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * TERENCE RIPPERDA, OR ANY OTHER CONTRIBUTORS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, 
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
 * DEALINGS IN THE SOFTWARE.
 */

#ifndef GLX_CONSTANTS_H
#define GLX_CONSTANTS_H

#include "resource.h"

#define GLX_MAJOR_VERSION 1
#define GLX_MINOR_VERSION 2

#define GLX_MAX_CLIENTS 10

#define GLX_PACKAGE_VERSION "0.9"
#define GLX_PROTOCOL_VERSION "1.2"

#define GLX_VENDOR_STRING "XFree86 GLX protocol written by Steven G. Parker"
#define GLX_EXTENSIONS_STRING " GLX_None "

typedef struct glRGBA {
    float r,g,b,a;
} glRGBA;

extern RESTYPE glContexts;
extern RESTYPE glPixmaps;
extern RESTYPE glWindows;
extern RESTYPE glxClients;

int __glxErrorBase;
int __glxReqBase;
int __glxEventBase;

#endif /* GLX_CONSTANTS_H */
