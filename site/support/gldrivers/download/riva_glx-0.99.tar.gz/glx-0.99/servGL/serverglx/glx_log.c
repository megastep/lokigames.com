
/*
 * GLX Server Extension
 * Copyright (C) 1998, 1999 Terence Ripperda (ripperda@sgi.com)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * TERENCE RIPPERDA, OR ANY OTHER CONTRIBUTORS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, 
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
 * DEALINGS IN THE SOFTWARE.
 */

#include "glx_log.h"
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>


static char *log = NULL;
static FILE *fPtr = NULL;
static GLboolean verbose = GL_TRUE;
static GLboolean logging = GL_FALSE;
static char *glx_init_string = "GLX_DEBUG";

/*
 * currently, just return. But I may need to change this behavior
 * later, so I want to make that easy to do.
 */

#define GLX_NO_FILE_DESC						\
   if (!fildes) fprintf(stderr, "GLX: missing fildes!!\n");		\
   if (!fPtr) fprintf(stderr, "GLX: missing fPtr!!\n");			\
   return;

#define GLX_CHECK_LOGGING						\
   if ( (!log) || (!logging) ) {					\
      return;								\
   }

#if 1
#define GLX_CHECK_FILE
#else
#define GLX_CHECK_FILE							\
   if ( (fPtr == NULL)  || !fildes) GLX_NO_FILE_DESC;
#endif


#define GLX_START_LOG							\
   fPtr = fopen(log, "a");

#define GLX_FINISH_LOG							\
   fclose(fPtr);							\
   fPtr = NULL;

int
glx_set_log_file(char *new_log) {
   if (new_log == 0) return 1;
   if (log) free(log);
   log = strdup(new_log);
   return glx_clear_log();
}

void
glx_log_initialize() {

   /** don't clear the log contents if already logging **/
   if ( (!logging) && (getenv(glx_init_string)) ) {
      fprintf(stderr, "turning logging on!\n");
      logging = GL_TRUE;
      glx_clear_log();
   }
}


void
glx_log_finish() {
/**
   if (fPtr) fclose(fPtr);
   if (fildes) close(fildes);
**/
}

int
glx_clear_log() {
   if (!log) return 1;
   if (!logging) return 0;

   if (fPtr) fclose(fPtr);
#if 0
   if (fildes) close(fildes);

   fildes = open(log, O_WRONLY | O_CREAT | O_TRUNC );
   if (fildes == 0) {
      fprintf(stderr, "GLX: Couldn't get file descriptor!\n");
      return 1;
   }
#endif

   fPtr = fopen(log, "w");
   if (fPtr == NULL) {
      fprintf(stderr, "GLX: Couldn't get file pointer!\n");
      return 1;
   }
   fprintf(fPtr, "Log Cleared\n");
   fprintf(stderr, "Log Cleared\n");

   GLX_FINISH_LOG;
   return 0;
}

void
glx_log_silent() {
   GLX_CHECK_LOGGING;
   verbose = GL_FALSE;
}

void
glx_log_verbose() {
   GLX_CHECK_LOGGING;
   verbose = GL_TRUE;
}

void
glx_log_print(const char *s, const char *__file, unsigned int __line) {
   GLX_CHECK_LOGGING;
   GLX_CHECK_FILE;

   GLX_START_LOG;
   if (verbose) {
      fprintf(fPtr, "%s\n", s);
   } else {
      fprintf(fPtr, "%s", s);
   }

   GLX_FINISH_LOG;
   return;
}

void
glx_log_op_request(int op) {
   GLX_CHECK_LOGGING;
   GLX_CHECK_FILE;

   GLX_START_LOG;
   switch (op) {
      case 0:
         fprintf(fPtr, "Decoding: Invalid (0)");
         break;
      case 1:
         fprintf(fPtr, "Decoding: CallList");
         break;
      case 2:
         fprintf(fPtr, "Decoding: CallLists");
         break;
      case 3:
         fprintf(fPtr, "Decoding: ListBase");
         break;
      case 4:
         fprintf(fPtr, "Decoding: Begin");
         break;
      case 5:
         fprintf(fPtr, "Decoding: Bitmap");
         break;
      case 6:
         fprintf(fPtr, "Decoding: Color3bv");
         break;
      case 7:
         fprintf(fPtr, "Decoding: Color3dv");
         break;
      case 8:
         fprintf(fPtr, "Decoding: Color3fv");
         break;
      case 9:
         fprintf(fPtr, "Decoding: Color3iv");
         break;
      case 10:
         fprintf(fPtr, "Decoding: Color3sv");
         break;
      case 11:
         fprintf(fPtr, "Decoding: Color3ubv");
         break;
      case 12:
         fprintf(fPtr, "Decoding: Color3uiv");
         break;
      case 13:
         fprintf(fPtr, "Decoding: Color3usv");
         break;
      case 14:
         fprintf(fPtr, "Decoding: Color4bv");
         break;
      case 15:
         fprintf(fPtr, "Decoding: Color4dv");
         break;
      case 16:
         fprintf(fPtr, "Decoding: Color4fv");
         break;
      case 17:
         fprintf(fPtr, "Decoding: Color4fi");
         break;
      case 18:
         fprintf(fPtr, "Decoding: Color4sv");
         break;
      case 19:
         fprintf(fPtr, "Decoding: Color4ubv");
         break;
      case 20:
         fprintf(fPtr, "Decoding: Color4uiv");
         break;
      case 21:
         fprintf(fPtr, "Decoding: Color4usv");
         break;
      case 22:
         fprintf(fPtr, "Decoding: EdgeFlag");
         break;
      case 23:
         fprintf(fPtr, "Decoding: End");
         break;
      case 24:
         fprintf(fPtr, "Decoding: Indexdv");
         break;
      case 25:
         fprintf(fPtr, "Decoding: Indexfv");
         break;
      case 26:
         fprintf(fPtr, "Decoding: Indexiv");
         break;
      case 27:
         fprintf(fPtr, "Decoding: Indexsv");
         break;
      case 28:
         fprintf(fPtr, "Decoding: Normal3bv");
         break;
      case 29:
         fprintf(fPtr, "Decoding: Normal3dv");
         break;
      case 30:
         fprintf(fPtr, "Decoding: Normal3fv");
         break;
      case 31:
         fprintf(fPtr, "Decoding: Normal3iv");
         break;
      case 32:
         fprintf(fPtr, "Decoding: Normal3sv");
         break;
      case 33:
         fprintf(fPtr, "Decoding: RasterPos2dv");
         break;
      case 34:
         fprintf(fPtr, "Decoding: RasterPos2fv");
         break;
      case 35:
         fprintf(fPtr, "Decoding: RasterPos2iv");
         break;
      case 36:
         fprintf(fPtr, "Decoding: RasterPos2sv");
         break;
      case 37:
         fprintf(fPtr, "Decoding: RasterPos3dv");
         break;
      case 38:
         fprintf(fPtr, "Decoding: RasterPos3fv");
         break;
      case 39:
         fprintf(fPtr, "Decoding: RasterPos3iv");
         break;
      case 40:
         fprintf(fPtr, "Decoding: RasterPos3sv");
         break;
      case 41:
         fprintf(fPtr, "Decoding: RasterPos4dv");
         break;
      case 42:
         fprintf(fPtr, "Decoding: RasterPos4fv");
         break;
      case 43:
         fprintf(fPtr, "Decoding: RasterPos4iv");
         break;
      case 44:
         fprintf(fPtr, "Decoding: RasterPos4sv");
         break;
      case 45:
         fprintf(fPtr, "Decoding: Rectdv");
         break;
      case 46:
         fprintf(fPtr, "Decoding: Rectfv");
         break;
      case 47:
         fprintf(fPtr, "Decoding: Rectiv");
         break;
      case 48:
         fprintf(fPtr, "Decoding: Rectsv");
         break;
      case 49:
         fprintf(fPtr, "Decoding: TexCoord1dv");
         break;
      case 50:
         fprintf(fPtr, "Decoding: TexCoord1fv");
         break;
      case 51:
         fprintf(fPtr, "Decoding: TexCoord1iv");
         break;
      case 52:
         fprintf(fPtr, "Decoding: TexCoord1sv");
         break;
      case 53:
         fprintf(fPtr, "Decoding: TexCoord2dv");
         break;
      case 54:
         fprintf(fPtr, "Decoding: TexCoord2fv");
         break;
      case 55:
         fprintf(fPtr, "Decoding: TexCoord2iv");
         break;
      case 56:
         fprintf(fPtr, "Decoding: TexCoord2sv");
         break;
      case 57:
         fprintf(fPtr, "Decoding: TexCoord3dv");
         break;
      case 58:
         fprintf(fPtr, "Decoding: TexCoord3fv");
         break;
      case 59:
         fprintf(fPtr, "Decoding: TexCoord3iv");
         break;
      case 60:
         fprintf(fPtr, "Decoding: TexCoord3sv");
         break;
      case 61:
         fprintf(fPtr, "Decoding: TexCoord4dv");
         break;
      case 62:
         fprintf(fPtr, "Decoding: TexCoord4fv");
         break;
      case 63:
         fprintf(fPtr, "Decoding: TexCoord4iv");
         break;
      case 64:
         fprintf(fPtr, "Decoding: TexCoord4sv");
         break;
      case 65:
         fprintf(fPtr, "Decoding: Vertex2dv");
         break;
      case 66:
         fprintf(fPtr, "Decoding: Vertex2fv");
         break;
      case 67:
         fprintf(fPtr, "Decoding: Vertex2iv");
         break;
      case 68:
         fprintf(fPtr, "Decoding: Vertex2sv");
         break;
      case 69:
         fprintf(fPtr, "Decoding: Vertex3dv");
         break;
      case 70:
         fprintf(fPtr, "Decoding: Vertex3fv");
         break;
      case 71:
         fprintf(fPtr, "Decoding: Vertex3iv");
         break;
      case 72:
         fprintf(fPtr, "Decoding: Vertex3sv");
         break;
      case 73:
         fprintf(fPtr, "Decoding: Vertex4dv");
         break;
      case 74:
         fprintf(fPtr, "Decoding: Vertex4fv");
         break;
      case 75:
         fprintf(fPtr, "Decoding: Vertex4iv");
         break;
      case 76:
         fprintf(fPtr, "Decoding: Vertex4sv");
         break;
      case 77:
         fprintf(fPtr, "Decoding: ClipPlane");
         break;
      case 78:
         fprintf(fPtr, "Decoding: ColorMaterial");
         break;
      case 79:
         fprintf(fPtr, "Decoding: CullFace");
         break;
      case 80:
         fprintf(fPtr, "Decoding: Fogf");
         break;
      case 81:
         fprintf(fPtr, "Decoding: Fogfv");
         break;
      case 82:
         fprintf(fPtr, "Decoding: Fogi");
         break;
      case 83:
         fprintf(fPtr, "Decoding: Fogiv");
         break;
      case 84:
         fprintf(fPtr, "Decoding: FrontFace");
         break;
      case 85:
         fprintf(fPtr, "Decoding: Hint");
         break;
      case 86:
         fprintf(fPtr, "Decoding: Lightf");
         break;
      case 87:
         fprintf(fPtr, "Decoding: Lightfv");
         break;
      case 88:
         fprintf(fPtr, "Decoding: Lighti");
         break;
      case 89:
         fprintf(fPtr, "Decoding: Lightiv");
         break;
      case 90:
         fprintf(fPtr, "Decoding: LightModelf");
         break;
      case 91:
         fprintf(fPtr, "Decoding: LightModelfv");
         break;
      case 92:
         fprintf(fPtr, "Decoding: LightModeli");
         break;
      case 93:
         fprintf(fPtr, "Decoding: LightModeliv");
         break;
      case 94:
         fprintf(fPtr, "Decoding: LineStipple");
         break;
      case 95:
         fprintf(fPtr, "Decoding: LineWidth");
         break;
      case 96:
         fprintf(fPtr, "Decoding: Materialf");
         break;
      case 97:
         fprintf(fPtr, "Decoding: Materialfv");
         break;
      case 98:
         fprintf(fPtr, "Decoding: Materiali");
         break;
      case 99:
         fprintf(fPtr, "Decoding: Materialiv");
         break;
      case 100:
         fprintf(fPtr, "Decoding: PointSize");
         break;
      case 101:
         fprintf(fPtr, "Decoding: PolygonMode");
         break;
      case 102:
         fprintf(fPtr, "Decoding: PolygonStipple");
         break;
      case 103:
         fprintf(fPtr, "Decoding: Scissor");
         break;
      case 104:
         fprintf(fPtr, "Decoding: ShadeModel");
         break;
      case 105:
         fprintf(fPtr, "Decoding: TexParameterf");
         break;
      case 106:
         fprintf(fPtr, "Decoding: TexParameterfv");
         break;
      case 107:
         fprintf(fPtr, "Decoding: TexParameteri");
         break;
      case 108:
         fprintf(fPtr, "Decoding: TexParameteriv");
         break;
      case 109:
         fprintf(fPtr, "Decoding: TexImage1D");
         break;
      case 110:
         fprintf(fPtr, "Decoding: TexImage2D");
         break;
      case 111:
         fprintf(fPtr, "Decoding: TexEnvf");
         break;
      case 112:
         fprintf(fPtr, "Decoding: TexEnvfv");
         break;
      case 113:
         fprintf(fPtr, "Decoding: TexEnvi");
         break;
      case 114:
         fprintf(fPtr, "Decoding: TexEnviv");
         break;
      case 115:
         fprintf(fPtr, "Decoding: TexGend");
         break;
      case 116:
         fprintf(fPtr, "Decoding: TexGendv");
         break;
      case 117:
         fprintf(fPtr, "Decoding: TexGenf");
         break;
      case 118:
         fprintf(fPtr, "Decoding: TexGenfv");
         break;
      case 119:
         fprintf(fPtr, "Decoding: TexGeni");
         break;
      case 120:
         fprintf(fPtr, "Decoding: TexGeniv");
         break;
      case 121:
         fprintf(fPtr, "Decoding: InitNames");
         break;
      case 122:
         fprintf(fPtr, "Decoding: LoadName");
         break;
      case 123:
         fprintf(fPtr, "Decoding: PassThrough");
         break;
      case 124:
         fprintf(fPtr, "Decoding: PopName");
         break;
      case 125:
         fprintf(fPtr, "Decoding: PushName");
         break;
      case 126:
         fprintf(fPtr, "Decoding: DrawBuffer");
         break;
      case 127:
         fprintf(fPtr, "Decoding: Clear ");
         break;
      case 128:
         fprintf(fPtr, "Decoding: ClearAccum");
         break;
      case 129:
         fprintf(fPtr, "Decoding: ClearIndex");
         break;
      case 130:
         fprintf(fPtr, "Decoding: ClearColor");
         break;
      case 131:
         fprintf(fPtr, "Decoding: ClearStencil");
         break;
      case 132:
         fprintf(fPtr, "Decoding: ClearDepth");
         break;
      case 133:
         fprintf(fPtr, "Decoding: StencilMask");
         break;
      case 134:
         fprintf(fPtr, "Decoding: ColorMask");
         break;
      case 135:
         fprintf(fPtr, "Decoding: DepthMask");
         break;
      case 136:
         fprintf(fPtr, "Decoding: IndexMask");
         break;
      case 137:
         fprintf(fPtr, "Decoding: Accum");
         break;
      case 138:
         fprintf(fPtr, "Decoding: Disable");
         break;
      case 139:
         fprintf(fPtr, "Decoding: Enable ");
         break;
      case 140:
         fprintf(fPtr, "Decoding: Invalid (140)");
         break;
      case 141:
         fprintf(fPtr, "Decoding: PopAttrib");
         break;
      case 142:
         fprintf(fPtr, "Decoding: PushAttrib");
         break;
      case 143:
         fprintf(fPtr, "Decoding: Map1d");
         break;
      case 144:
         fprintf(fPtr, "Decoding: Map1f");
         break;
      case 145:
         fprintf(fPtr, "Decoding: Map2d");
         break;
      case 146:
         fprintf(fPtr, "Decoding: Map2f");
         break;
      case 147:
         fprintf(fPtr, "Decoding: MapGrid1d");
         break;
      case 148:
         fprintf(fPtr, "Decoding: MapGrid1f");
         break;
      case 149:
         fprintf(fPtr, "Decoding: MapGrid2d");
         break;
      case 150:
         fprintf(fPtr, "Decoding: MapGrid2f");
         break;
      case 151:
         fprintf(fPtr, "Decoding: EvalCoord1dv");
         break;
      case 152:
         fprintf(fPtr, "Decoding: EvalCoord1fv");
         break;
      case 153:
         fprintf(fPtr, "Decoding: EvalCoord2dv");
         break;
      case 154:
         fprintf(fPtr, "Decoding: EvalCoord2fv");
         break;
      case 155:
         fprintf(fPtr, "Decoding: EvalMesh1");
         break;
      case 156:
         fprintf(fPtr, "Decoding: EvalPoint1");
         break;
      case 157:
         fprintf(fPtr, "Decoding: EvalMesh2");
         break;
      case 158:
         fprintf(fPtr, "Decoding: EvalPoint2");
         break;
      case 159:
         fprintf(fPtr, "Decoding: AlphaFunc");
         break;
      case 160:
         fprintf(fPtr, "Decoding: BlendFunc");
         break;
      case 161:
         fprintf(fPtr, "Decoding: LogicOp");
         break;
      case 162:
         fprintf(fPtr, "Decoding: StencilFunc");
         break;
      case 163:
         fprintf(fPtr, "Decoding: StencilOp");
         break;
      case 164:
         fprintf(fPtr, "Decoding: DepthFunc");
         break;
      case 165:
         fprintf(fPtr, "Decoding: PixelZoom");
         break;
      case 166:
         fprintf(fPtr, "Decoding: PixelTransferf");
         break;
      case 167:
         fprintf(fPtr, "Decoding: PixelTransferi");
         break;
      case 168:
         fprintf(fPtr, "Decoding: PixelMapf");
         break;
      case 169:
         fprintf(fPtr, "Decoding: PixelMapuiv");
         break;
      case 170:
         fprintf(fPtr, "Decoding: PixelMapusv");
         break;
      case 171:
         fprintf(fPtr, "Decoding: ReadBuffer");
         break;
      case 172:
         fprintf(fPtr, "Decoding: CopyPixels");
         break;
      case 173:
         fprintf(fPtr, "Decoding: DrawPixels");
         break;
      case 174:
         fprintf(fPtr, "Decoding: DepthRange");
         break;
      case 175:
         fprintf(fPtr, "Decoding: Frustum");
         break;
      case 176:
         fprintf(fPtr, "Decoding: LoadIdentity");
         break;
      case 177:
         fprintf(fPtr, "Decoding: LoadMatrixf");
         break;
      case 178:
         fprintf(fPtr, "Decoding: LoadMatrixd");
         break;
      case 179:
         fprintf(fPtr, "Decoding: MatrixMode");
         break;
      case 180:
         fprintf(fPtr, "Decoding: MultMatrixf");
         break;
      case 181:
         fprintf(fPtr, "Decoding: MultMatrixd");
         break;
      case 182:
         fprintf(fPtr, "Decoding: Ortho");
         break;
      case 183:
         fprintf(fPtr, "Decoding: PopMatrix");
         break;
      case 184:
         fprintf(fPtr, "Decoding: PushMatrix");
         break;
      case 185:
         fprintf(fPtr, "Decoding: Rotated");
         break;
      case 186:
         fprintf(fPtr, "Decoding: Rotatef");
         break;
      case 187:
         fprintf(fPtr, "Decoding: Scaled");
         break;
      case 188:
         fprintf(fPtr, "Decoding: Scalef");
         break;
      case 189:
         fprintf(fPtr, "Decoding: Translated");
         break;
      case 190:
         fprintf(fPtr, "Decoding: Translatef");
         break;
      case 191:
         fprintf(fPtr, "Decoding: Viewport");
         break;
      case 193:
         fprintf(fPtr, "Decoding: DrawArrays");
         break;
      case 4099:
         fprintf(fPtr, "Decoding: TexSubImage1D");
         break;
      case 4100:
         fprintf(fPtr, "Decoding: TexSubImage2D");
         break;
      case 4116:
         fprintf(fPtr, "Decoding: DrawArrays");
         break;
      case 4117:
         fprintf(fPtr, "Decoding: BindTexture");
         break;
      default:
         fprintf(fPtr, "Decoding: op %d unknown or unsupported", op);
   }

   GLX_FINISH_LOG;
   return;
}

void
glx_log_glx_request(int op) {
   GLX_CHECK_LOGGING;
   GLX_CHECK_FILE;

   GLX_START_LOG;
   switch (op) {
      case 1:
         fprintf(fPtr, "Render");
         break;
      case 2:
         fprintf(fPtr, "RenderLarge");
         break;
      case 3:
         fprintf(fPtr, "CreateContext");
         break;
      case 4:
         fprintf(fPtr, "DestroyContext");
         break;
      case 5:
         fprintf(fPtr, "MakeCurrent");
         break;
      case 6:
         fprintf(fPtr, "IsDirect");
         break;
      case 7:
         fprintf(fPtr, "QueryVersion");
         break;
      case 8:
         fprintf(fPtr, "WaitGL");
         break;
      case 9:
         fprintf(fPtr, "WaitX");
         break;
      case 10:
         fprintf(fPtr, "CopyContext");
         break;
      case 11:
         fprintf(fPtr, "SwapBuffers");
         break;
      case 12:
         fprintf(fPtr, "UseXFont");
         break;
      case 13:
         fprintf(fPtr, "CreateGLXPixmap");
         break;
      case 14:
         fprintf(fPtr, "GetVisualConfigs");
         break;
      case 15:
         fprintf(fPtr, "DestroyGLXPixmap");
         break;
      case 16:
         fprintf(fPtr, "VendorPrivate");
         break;
      case 17:
         fprintf(fPtr, "VendorPrivateWithReply");
         break;
      case 19:
         fprintf(fPtr, "QueryServerString");
         break;
      case 20:
         fprintf(fPtr, "ClientInfo");
         break;
      case 101:
         fprintf(fPtr, "NewList");
         break;
      case 102:
         fprintf(fPtr, "EndList");
         break;
      case 103:
         fprintf(fPtr, "DeleteLists");
         break;
      case 104:
         fprintf(fPtr, "GenLists");
         break;
      case 105:
         fprintf(fPtr, "FeedbackBuffer");
         break;
      case 106:
         fprintf(fPtr, "SelectBuffer");
         break;
      case 107:
         fprintf(fPtr, "RenderMode");
         break;
      case 108:
         fprintf(fPtr, "Finish");
         break;
      case 109:
         fprintf(fPtr, "PixelStoref");
         break;
      case 110:
         fprintf(fPtr, "PixelStorei");
         break;
      case 111:
         fprintf(fPtr, "ReadPixels");
         break;
      case 112:
         fprintf(fPtr, "GetBooleanv");
         break;
      case 113:
         fprintf(fPtr, "GetClipPlane");
         break;
      case 114:
         fprintf(fPtr, "GetDoublev");
         break;
      case 115:
         fprintf(fPtr, "GetError");
         break;
      case 116:
         fprintf(fPtr, "GetFloatv");
         break;
      case 117:
         fprintf(fPtr, "GetIntegerv");
         break;
      case 118:
         fprintf(fPtr, "GetLightfv");
         break;
      case 119:
         fprintf(fPtr, "GetLightiv");
         break;
      case 120:
         fprintf(fPtr, "GetMapdv");
         break;
      case 121:
         fprintf(fPtr, "GetMapfv");
         break;
      case 122:
         fprintf(fPtr, "GetMapiv");
         break;
      case 123:
         fprintf(fPtr, "GetMaterialfv");
         break;
      case 124:
         fprintf(fPtr, "GetMaterialiv");
         break;
      case 125:
         fprintf(fPtr, "GetPixelMapfv");
         break;
      case 126:
         fprintf(fPtr, "GetPixelMapuiv");
         break;
      case 127:
         fprintf(fPtr, "GetPixelMapusv");
         break;
      case 128:
         fprintf(fPtr, "GetPolygonStipple");
         break;
      case 129:
         fprintf(fPtr, "GetString");
         break;
      case 130:
         fprintf(fPtr, "GetTexEnvfv");
         break;
      case 131:
         fprintf(fPtr, "GetTexEnviv");
         break;
      case 132:
         fprintf(fPtr, "GetTexGendv");
         break;
      case 133:
         fprintf(fPtr, "GetTexGenfv");
         break;
      case 134:
         fprintf(fPtr, "GetTexGeniv");
         break;
      case 135:
         fprintf(fPtr, "GetTexImage");
         break;
      case 136:
         fprintf(fPtr, "GetTexParameterfv");
         break;
      case 137:
         fprintf(fPtr, "GetTexParameteriv");
         break;
      case 138:
         fprintf(fPtr, "GetTexLevelParameterfv");
         break;
      case 139:
         fprintf(fPtr, "GetTexLevelParameteriv");
         break;
      case 140:
         fprintf(fPtr, "IsEnabled");
         break;
      case 141:
         fprintf(fPtr, "IsList");
         break;
      case 142:
         fprintf(fPtr, "Flush");
         break;
      case 143:
         fprintf(fPtr, "AreTexturesResident");
         break;
      case 144:
         fprintf(fPtr, "DeleteTextures");
         break;
      case 145:
         fprintf(fPtr, "GenTextures");
         break;
      default:
         fprintf(fPtr, "Invalid (%d)", op);
   }

   GLX_FINISH_LOG;
   return;
}

void
glx_log_enum(GLenum the_enum) {
   GLX_CHECK_LOGGING;
   GLX_CHECK_FILE;

   GLX_START_LOG;
   switch (the_enum) {

#if 0
      case GL_FALSE:
         fprintf(fPtr, "GL_FALSE\n");
         break;

      case GL_TRUE:
         fprintf(fPtr, "GL_TRUE\n");
         break;
#endif

      case GL_BYTE:
         fprintf(fPtr, "GL_BYTE\n");
         break;

      case GL_UNSIGNED_BYTE:
         fprintf(fPtr, "GL_UNSIGNED_BYTE\n");
         break;

      case GL_SHORT:
         fprintf(fPtr, "GL_SHORT\n");
         break;

      case GL_UNSIGNED_SHORT:
         fprintf(fPtr, "GL_UNSIGNED_SHORT\n");
         break;

      case GL_INT:
         fprintf(fPtr, "GL_INT\n");
         break;

      case GL_UNSIGNED_INT:
         fprintf(fPtr, "GL_UNSIGNED_INT\n");
         break;

      case GL_FLOAT:
         fprintf(fPtr, "GL_FLOAT\n");
         break;

      case GL_DOUBLE:
         fprintf(fPtr, "GL_DOUBLE\n");
         break;

      case GL_2_BYTES:
         fprintf(fPtr, "GL_2_BYTES\n");
         break;

      case GL_3_BYTES:
         fprintf(fPtr, "GL_3_BYTES\n");
         break;

      case GL_4_BYTES:
         fprintf(fPtr, "GL_4_BYTES\n");
         break;

      case GL_LINES:
         fprintf(fPtr, "GL_LINES\n");
         break;

      case GL_POINTS:
         fprintf(fPtr, "GL_POINTS\n");
         break;

      case GL_LINE_STRIP:
         fprintf(fPtr, "GL_LINE_STRIP\n");
         break;

      case GL_LINE_LOOP:
         fprintf(fPtr, "GL_LINE_LOOP\n");
         break;

      case GL_TRIANGLES:
         fprintf(fPtr, "GL_TRIANGLES\n");
         break;

      case GL_TRIANGLE_STRIP:
         fprintf(fPtr, "GL_TRIANGLE_STRIP\n");
         break;

      case GL_TRIANGLE_FAN:
         fprintf(fPtr, "GL_TRIANGLE_FAN\n");
         break;

      case GL_QUADS:
         fprintf(fPtr, "GL_QUADS\n");
         break;

      case GL_QUAD_STRIP:
         fprintf(fPtr, "GL_QUAD_STRIP\n");
         break;

      case GL_POLYGON:
         fprintf(fPtr, "GL_POLYGON\n");
         break;

      case GL_EDGE_FLAG:
         fprintf(fPtr, "GL_EDGE_FLAG\n");
         break;


      /****  skipping vertex arrays for now ****/

      case GL_MATRIX_MODE:
         fprintf(fPtr, "GL_MATRIX_MODE\n");
         break;

      case GL_PROJECTION:
         fprintf(fPtr, "GL_PROJECTION\n");
         break;

      case GL_MODELVIEW:
         fprintf(fPtr, "GL_MODELVIEW\n");
         break;

      case GL_TEXTURE:
         fprintf(fPtr, "GL_TEXTURE\n");
         break;

      /**** skipping points for now ****/


      /**** skipping lines for now ****/

      /**** polygon ****/
      case GL_POINT:
         fprintf(fPtr, "GL_POINT\n");
         break;

      case GL_LINE:
         fprintf(fPtr, "GL_LINE\n");
         break;

      case GL_FILL:
         fprintf(fPtr, "GL_FILL\n");
         break;

      case GL_CCW:
         fprintf(fPtr, "GL_CCW\n");
         break;

      case GL_CW:
         fprintf(fPtr, "GL_CW\n");
         break;

      case GL_FRONT:
         fprintf(fPtr, "GL_FRONT\n");
         break;

      case GL_BACK:
         fprintf(fPtr, "GL_BACK\n");
         break;

      case GL_CULL_FACE:
         fprintf(fPtr, "GL_CULL_FACE\n");
         break;

      case GL_CULL_FACE_MODE:
         fprintf(fPtr, "GL_CULL_FACE_MODE\n");
         break;

      case GL_POLYGON_SMOOTH:
         fprintf(fPtr, "GL_POLYGON_SMOOTH\n");
         break;

      case GL_POLYGON_STIPPLE:
         fprintf(fPtr, "GL_POLYGON_STIPPLE\n");
         break;

      case GL_FRONT_FACE:
         fprintf(fPtr, "GL_FRONT_FACE\n");
         break;

      case GL_POLYGON_MODE:
         fprintf(fPtr, "GL_POLYGON_MODE\n");
         break;

      case GL_POLYGON_OFFSET_FACTOR:
         fprintf(fPtr, "GL_POLYGON_OFFSET_FACTOR\n");
         break;

      case GL_POLYGON_OFFSET_UNITS:
         fprintf(fPtr, "GL_POLYGON_OFFSET_UNITS\n");
         break;

      case GL_POLYGON_OFFSET_POINT:
         fprintf(fPtr, "GL_POLYGON_OFFSET_POINT\n");
         break;

      case GL_POLYGON_OFFSET_LINE:
         fprintf(fPtr, "GL_POLYGON_OFFSET_LINE\n");
         break;

      case GL_POLYGON_OFFSET_FILL:
         fprintf(fPtr, "GL_POLYGON_OFFSET_FILL\n");
         break;


      /**** skipping display lists for now ****/


      case GL_NEVER:
         fprintf(fPtr, "GL_NEVER\n");
         break;

      case GL_LESS:
         fprintf(fPtr, "GL_LESS\n");
         break;

      case GL_GEQUAL:
         fprintf(fPtr, "GL_GEQUAL\n");
         break;

      case GL_LEQUAL:
         fprintf(fPtr, "GL_LEQUAL\n");
         break;

      case GL_GREATER:
         fprintf(fPtr, "GL_GREATER\n");
         break;

      case GL_NOTEQUAL:
         fprintf(fPtr, "GL_NOTEQUAL\n");
         break;

      case GL_EQUAL:
         fprintf(fPtr, "GL_EQUAL\n");
         break;

      case GL_ALWAYS:
         fprintf(fPtr, "GL_ALWAYS\n");
         break;

      case GL_DEPTH_TEST:
         fprintf(fPtr, "GL_DEPTH_TEST\n");
         break;

      case GL_DEPTH_BITS:
         fprintf(fPtr, "GL_DEPTH_BITS\n");
         break;

      case GL_DEPTH_CLEAR_VALUE:
         fprintf(fPtr, "GL_DEPTH_CLEAR_VALUE\n");
         break;

      case GL_DEPTH_FUNC:
         fprintf(fPtr, "GL_DEPTH_FUNC\n");
         break;

      case GL_DEPTH_RANGE:
         fprintf(fPtr, "GL_DEPTH_RANGE\n");
         break;

      case GL_DEPTH_WRITEMASK:
         fprintf(fPtr, "GL_DEPTH_WRITEMASK\n");
         break;

      case GL_DEPTH_COMPONENT:
         fprintf(fPtr, "GL_DEPTH_COMPONENT\n");
         break;


      /**** lighting ****/

      case GL_LIGHTING:
         fprintf(fPtr, "GL_LIGHTING\n");
         break;

      case GL_LIGHT0:
         fprintf(fPtr, "GL_LIGHT0\n");
         break;

      case GL_LIGHT1:
         fprintf(fPtr, "GL_LIGHT1\n");
         break;

      case GL_LIGHT2:
         fprintf(fPtr, "GL_LIGHT2\n");
         break;

      case GL_LIGHT3:
         fprintf(fPtr, "GL_LIGHT3\n");
         break;

      case GL_LIGHT4:
         fprintf(fPtr, "GL_LIGHT4\n");
         break;

      case GL_LIGHT5:
         fprintf(fPtr, "GL_LIGHT5\n");
         break;

      case GL_LIGHT6:
         fprintf(fPtr, "GL_LIGHT6\n");
         break;

      case GL_LIGHT7:
         fprintf(fPtr, "GL_LIGHT7\n");
         break;

      case GL_SPOT_EXPONENT:
         fprintf(fPtr, "GL_SPOT_EXPONENT\n");
         break;

      case GL_SPOT_CUTOFF:
         fprintf(fPtr, "GL_SPOT_CUTOFF\n");
         break;

      case GL_CONSTANT_ATTENUATION:
         fprintf(fPtr, "GL_CONSTANT_ATTENUATION\n");
         break;

      case GL_LINEAR_ATTENUATION:
         fprintf(fPtr, "GL_LINEAR_ATTENUATION\n");
         break;

      case GL_QUADRATIC_ATTENUATION:
         fprintf(fPtr, "GL_QUADRATIC_ATTENUATION\n");
         break;

      case GL_AMBIENT:
         fprintf(fPtr, "GL_AMBIENT\n");
         break;

      case GL_DIFFUSE:
         fprintf(fPtr, "GL_DIFFUSE\n");
         break;

      case GL_SPECULAR:
         fprintf(fPtr, "GL_SPECULAR\n");
         break;

      case GL_SHININESS:
         fprintf(fPtr, "GL_SHININESS\n");
         break;

      case GL_EMISSION:
         fprintf(fPtr, "GL_EMISSION\n");
         break;

      case GL_POSITION:
         fprintf(fPtr, "GL_POSITION\n");
         break;

      case GL_SPOT_DIRECTION:
         fprintf(fPtr, "GL_SPOT_DIRECTION\n");
         break;

      case GL_AMBIENT_AND_DIFFUSE:
         fprintf(fPtr, "GL_AMBIENT_AND_DIFFUSE\n");
         break;

      case GL_COLOR_INDEXES:
         fprintf(fPtr, "GL_COLOR_INDEXES\n");
         break;

      case GL_LIGHT_MODEL_TWO_SIDE:
         fprintf(fPtr, "GL_LIGHT_MODEL_TWO_SIDE\n");
         break;

      case GL_LIGHT_MODEL_LOCAL_VIEWER:
         fprintf(fPtr, "GL_LIGHT_MODEL_LOCAL_VIEWER\n");
         break;

      case GL_LIGHT_MODEL_AMBIENT:
         fprintf(fPtr, "GL_LIGHT_MODEL_AMBIENT\n");
         break;

      case GL_FRONT_AND_BACK:
         fprintf(fPtr, "GL_FRONT_AND_BACK\n");
         break;

      case GL_SHADE_MODEL:
         fprintf(fPtr, "GL_SHADE_MODEL\n");
         break;

      case GL_FLAT:
         fprintf(fPtr, "GL_FLAT\n");
         break;

      case GL_SMOOTH:
         fprintf(fPtr, "GL_SMOOTH\n");
         break;

      case GL_COLOR_MATERIAL:
         fprintf(fPtr, "GL_COLOR_MATERIAL\n");
         break;

      case GL_COLOR_MATERIAL_FACE:
         fprintf(fPtr, "GL_COLOR_MATERIAL_FACE\n");
         break;

      case GL_COLOR_MATERIAL_PARAMETER:
         fprintf(fPtr, "GL_COLOR_MATERIAL_PARAMETER\n");
         break;

      case GL_NORMALIZE:
         fprintf(fPtr, "GL_NORMALIZE\n");
         break;

      /** buffers **/

      case GL_RGB:
         fprintf(fPtr, "GL_RGB\n");
         break;

      case GL_RGBA:
         fprintf(fPtr, "GL_RGBA\n");
         break;

      /** utility enumerations **/

      case GL_VENDOR:
         fprintf(fPtr, "GL_VENDOR\n");
         break;

      case GL_RENDERER:
         fprintf(fPtr, "GL_RENDERER\n");
         break;

      case GL_VERSION:
         fprintf(fPtr, "GL_VERSION\n");
         break;

      case GL_EXTENSIONS:
         fprintf(fPtr, "GL_EXTENSIONS\n");
         break;

      default:
         fprintf(fPtr, "unhandled\n");

   }

   GLX_FINISH_LOG;
   return;
}


void
glx_log_mask(GLenum mask) {
   int temp = 0;
   GLX_CHECK_LOGGING;
   GLX_CHECK_FILE;

   GLX_START_LOG;
   if (mask & GL_ALL_ATTRIB_BITS) {
       fprintf(fPtr, " all bits");
       mask = 0;
   }

   temp = 0x001;
   while (mask) {
      switch (mask & temp) {
         case GL_CURRENT_BIT:
            fprintf(fPtr, " gl_current_bit");
            mask = mask & ~GL_CURRENT_BIT;
            break;
         case GL_POINT_BIT:
            fprintf(fPtr, " gl_point_bit");
            mask = mask & ~GL_POINT_BIT;
            break;
         case GL_LINE_BIT:
            fprintf(fPtr, " gl_line_bit");
            mask = mask & ~GL_LINE_BIT;
            break;
         case GL_POLYGON_BIT:
            fprintf(fPtr, " gl_polygon_bit");
            mask = mask & ~GL_POLYGON_BIT;
            break;
         case GL_POLYGON_STIPPLE_BIT:
            fprintf(fPtr, " gl_polygon_stipple_bit");
            mask = mask & ~GL_POLYGON_STIPPLE_BIT;
            break;
         case GL_PIXEL_MODE_BIT:
            fprintf(fPtr, " gl_pixel_mode_bit");
            mask = mask & ~GL_PIXEL_MODE_BIT;
            break;
         case GL_LIGHTING_BIT:
            fprintf(fPtr, " gl_lighting_bit");
            mask = mask & ~GL_LIGHTING_BIT;
            break;
         case GL_FOG_BIT:
            fprintf(fPtr, " gl_fog_bit");
            mask = mask & ~GL_FOG_BIT;
            break;
         case GL_DEPTH_BUFFER_BIT:
            fprintf(fPtr, " gl_depth_buffer_bit");
            mask = mask & ~GL_DEPTH_BUFFER_BIT;
            break;
         case GL_ACCUM_BUFFER_BIT:
            fprintf(fPtr, " gl_accum_buffer_bit");
            mask = mask & ~GL_ACCUM_BUFFER_BIT;
            break;
         case GL_STENCIL_BUFFER_BIT:
            fprintf(fPtr, " gl_stencil_buffer_bit");
            mask = mask & ~GL_STENCIL_BUFFER_BIT;
            break;
         case GL_VIEWPORT_BIT:
            fprintf(fPtr, " gl_viewport_bit");
            mask = mask & ~GL_VIEWPORT_BIT;
            break;
         case GL_TRANSFORM_BIT:
            fprintf(fPtr, " gl_transform_bit");
            mask = mask & ~GL_TRANSFORM_BIT;
            break;
         case GL_ENABLE_BIT:
            fprintf(fPtr, " gl_enable_bit");
            mask = mask & ~GL_ENABLE_BIT;
            break;
         case GL_COLOR_BUFFER_BIT:
            fprintf(fPtr, " gl_color_buffer_bit");
            mask = mask & ~GL_COLOR_BUFFER_BIT;
            break;
         case GL_HINT_BIT:
            fprintf(fPtr, " gl_hint_bit");
            mask = mask & ~GL_HINT_BIT;
            break;
         case GL_EVAL_BIT:
            fprintf(fPtr, " gl_eval_bit");
            mask = mask & ~GL_EVAL_BIT;
            break;
         case GL_LIST_BIT:
            fprintf(fPtr, " gl_list_bit");
            mask = mask & ~GL_LIST_BIT;
            break;
         case GL_TEXTURE_BIT:
            fprintf(fPtr, " gl_texture_bit");
            mask = mask & ~GL_TEXTURE_BIT;
            break;
         case GL_SCISSOR_BIT:
            fprintf(fPtr, " gl_scissor_bit");
            mask = mask & ~GL_SCISSOR_BIT;
            break;
         default:
            fprintf(fPtr, " unknown");
            mask = 0;
            break;
      }
      temp = temp << 1;
   }

   fprintf(fPtr, "\n");

   GLX_FINISH_LOG;
   return;
}

void
glx_log_int(int num) {
   GLX_CHECK_LOGGING;
   GLX_CHECK_FILE;

   GLX_START_LOG;
   if (verbose) {
      fprintf(fPtr, "glX Print: %d\n", num);
   } else {
      fprintf(fPtr, "%d", num);
   }

   GLX_FINISH_LOG;
   return;
}

void
glx_log_uint(unsigned int num) {
   GLX_CHECK_LOGGING;
   GLX_CHECK_FILE;

   GLX_START_LOG;
   if (verbose) {
      fprintf(fPtr, "glX Print: %u\n", num);
   } else {
      fprintf(fPtr, "%u", num);
   }

   GLX_FINISH_LOG;
   return;
}

void
glx_log_float(float num) {
   GLX_CHECK_LOGGING;
   GLX_CHECK_FILE;

   GLX_START_LOG;
   if (verbose) {
      fprintf(fPtr, "glX Print: %1.2f\n", num);
   } else {
      fprintf(fPtr, "%1.2f", num);
   }

   GLX_FINISH_LOG;
   return;
}

void
glx_log_bool(GLboolean bool) {
   GLX_CHECK_LOGGING;
   GLX_CHECK_FILE;

   GLX_START_LOG;
   if (verbose) {
      if (bool == GL_TRUE) fprintf(fPtr, "glX Print: true\n");
      else fprintf(fPtr, "glX Print: false\n"); 
   } else {
      if (bool == GL_TRUE) fprintf(fPtr, "true");
      else fprintf(fPtr, "false"); 
   }

   GLX_FINISH_LOG;
   return;
}

