
/*
 * GLX Server Extension
 * Copyright (C) 1998, 1999 Terence Ripperda (ripperda@sgi.com)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * TERENCE RIPPERDA, OR ANY OTHER CONTRIBUTORS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, 
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
 * DEALINGS IN THE SOFTWARE.
 */

#ifndef __glx_log
#define __glx_log

#include <GL/gl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef GLX_LOG

int glx_set_log_file(char *new_log);
void glx_log_initialize();
void glx_log_finish();
int glx_clear_log();
void glx_log_op_request(int op);
void glx_log_glx_request(int op);
void glx_log_silent();
void glx_log_verbose();
void glx_log_print(const char *s, const char *__file, unsigned int __line);
void glx_log_enum(GLenum the_enum);
void glx_log_mask(GLenum mask);
void glx_log_int(int num);
void glx_log_uint(unsigned int num);
void glx_log_float(float num);
void glx_log_bool(GLboolean bool);

#define set_log_file(log)       glx_set_log_file(log)
#define log_initialize()	glx_log_initialize()
#define log_finish()		glx_log_finish()
#define clear_log()             glx_clear_log()
#define log_op_request(op)      glx_log_op_request(op)
#define log_glx_request(op)     glx_log_glx_request(op)
#define log_silent()            glx_log_silent()
#define log_verbose()           glx_log_verbose()
#define log_print(s)            glx_log_print(s, __FILE__, __LINE__)
#define log_enum(enum)          glx_log_enum(enum)
#define log_mask(mask)          glx_log_mask(mask)
#define log_int(num)            glx_log_int(num)
#define log_uint(num)           glx_log_uint(num)
#define log_float(num)          glx_log_float(num)
#define log_bool(bool)          glx_log_bool(bool)

#else    /** #ifdef GLX_LOG **/

#define set_log_file(log) 	0
#define log_initialize()
#define log_finish()
#define log_off()
#define clear_log()      
#define log_op_request(op) 
#define log_glx_request(op) 
#define log_silent()         
#define log_verbose()       
#define log_print(s) 
#define log_enum(enum)     
#define log_mask(mask)
#define log_int(num)      
#define log_uint(num)      
#define log_float(num)   
#define log_bool(bool)

#endif   /** #ifdef GLX_LOG **/ 

#endif
