
/*
 * GLX Server Extension
 * Copyright (C) 1998, 1999 Terence Ripperda (ripperda@sgi.com)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * TERENCE RIPPERDA, OR ANY OTHER CONTRIBUTORS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, 
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
 * DEALINGS IN THE SOFTWARE.
 */

#include "glx_varray.h"
#include <GL/gl.h>
#include <stdio.h>
#include <stdlib.h>
#include "glxcommon.h"
#include "extnsionst.h"
#include "dixstruct.h"
#include "scrnintstr.h"
#include "glx_log.h"
#include "glxrender.h"

#define GLX_LOG_FLOAT_ARRAY(comps, verts, stride, start)	\
   {								\
      int i, j;							\
      unsigned char *ptr = (unsigned char *) start;		\
      log_silent();						\
      for (i = 0; i < verts; i++) {				\
         for (j = 0; j < comps; j++) {				\
            log_float( *( ((float *) ptr) + j ) );			\
            log_print(" ");					\
         }							\
         log_print("\n");					\
         ptr += stride;						\
      }								\
      log_verbose();						\
   }

#define GLX_LOG_ARRAY_NEW(comps, type, off, verts, start)		\
   {							\
      log_print("\tnumber components: ");		\
      log_int(comps);					\
      log_print("\n\tdata type: ");			\
      log_enum(type);					\
      log_print("\n\toffset into array: ");		\
      log_int(off);					\
      log_print("\n");					\
      log_print("\n\tstarting address of verts: ");	\
      log_int(verts);					\
      log_print("\n\tstart of this array: ");		\
      log_int(start);					\
      log_print("\n");					\
   }

#define GLX_LOG_ARRAY(comps, type, off)	 		\
   {							\
      log_print("\tnumber components: ");		\
      log_int(comps);					\
      log_print("\n\tdata type: ");			\
      log_enum(type);					\
      log_print("\n\toffset into array: ");		\
      log_int(off);					\
      log_print("\n");					\
   }


int
get_length(GLenum array_type, struct array_info *records,
               int num_records, int num_vertices) {
   int comp_size = 0;
   int array_size = 0;
   int i = 0;

   for (i = 0; i < num_records; i++) {
      if ( ( (GLenum) (records[i].array_type) ) == array_type) {
         comp_size = records[i].j *
            GLX_data_size( (GLenum) records[i].data_type );
         comp_size = GLX_pad(comp_size);
         array_size = comp_size * num_vertices;
         break;
      }
   }

   return array_size;
}

int
GLX_varray_size(int num_verts, int num_arrays, void *arrays) {
   unsigned int size = 0;

   size  = get_length(GL_EDGE_FLAG_ARRAY, arrays, num_arrays, num_verts);
   size += get_length(GL_TEXTURE_COORD_ARRAY, arrays, num_arrays, num_verts);
   size += get_length(GL_COLOR_ARRAY, arrays, num_arrays, num_verts);
   size += get_length(GL_INDEX_ARRAY, arrays, num_arrays, num_verts);
   size += get_length(GL_NORMAL_ARRAY, arrays, num_arrays, num_verts);
   size += get_length(GL_VERTEX_ARRAY, arrays, num_arrays, num_verts);

   return (size / 4);
}

int
GLX_array_info_size(int num_arrays) {
   /** return number of arrays * number of elements in a single array **/
   ErrorF("array info size: %d\n", num_arrays * 
          ( sizeof(struct array_info) / sizeof(int) ) );
   return num_arrays * ( sizeof(struct array_info) / sizeof(int) );
}

/*
 * find a specific array record for a given array.
 * return the number of bytes the arrays elements require, based on the
 * array's type and number of components
 */

int
get_comp_size(GLenum array_type, struct array_info *records, 
               int num_records) {
   int comp_size = 0;
   int i = 0;

   for (i = 0; i < num_records; i++) {
      if ( ( (GLenum) (records[i].array_type) ) == array_type) {
         comp_size = records[i].j * 
            GLX_data_size( (GLenum) records[i].data_type );
         break;
      }
   }

   return comp_size;
}



GLenum
get_enum(GLenum array_type, struct array_info *records, 
               int num_records) {
   int i = 0;

   for (i = 0; i < num_records; i++) {
      if ( ( (GLenum) (records[i].array_type) ) == array_type) {
         return (GLenum) records[i].data_type;
      }
   }
   return GL_FALSE;
}


unsigned int
get_num_comps(GLenum array_type, struct array_info *records, 
               int num_records) {
   int i = 0;

   for (i = 0; i < num_records; i++) {
      if ( ( (GLenum) (records[i].array_type) ) == array_type) {
         return (unsigned int) records[i].j;
      }
   }
   return 0;
}


/* 
 * since the beginning of each type of array in the packed and padded
 * interleaved array coming across the wire is offset cumulatively, use
 * a waterfall method to calculate the offsets.
 */

int
glx_varray_calc_offsets(struct glx_varray *arrays) {
   unsigned int i, j;
   unsigned int element_size = 0;

   for (i = 0; i < GLX_MAX_ARRAY_INFOS; i++) {
      if (arrays[i].num_comps != 0) {
         element_size = arrays[i].num_comps *
            GLX_pad( GLX_data_size(arrays[i].data_type) );
         for (j = i + 1; j < GLX_MAX_ARRAY_INFOS; j++) {
            arrays[j].offset += element_size;
         }
      }
   }
   return 0;
}


void
GLX_swap_varray(int num_comps, GLenum data_type, int num_vertices, 
                int glx_stride, void *start) {

   unsigned int data_size = GLX_data_size(data_type);
   unsigned char *array = (unsigned char *) start;
   register int _n, i;

   switch (data_size) {
      case 4:

            switch (num_comps) {
               case 3: 
                  for (i = 0; i < num_vertices; i++) {
                     swapl( ( ( (unsigned int *) array ) + 0 ), _n );
                     swapl( ( ( (unsigned int *) array ) + 1 ), _n );
                     swapl( ( ( (unsigned int *) array ) + 2 ), _n );
                     array += glx_stride;
                  }
                  break;
               case 4: 
                  for (i = 0; i < num_vertices; i++) {
                     swapl( ( (unsigned int *) array ) + 0, _n );
                     swapl( ( (unsigned int *) array ) + 1, _n );
                     swapl( ( (unsigned int *) array ) + 2, _n );
                     swapl( ( (unsigned int *) array ) + 3, _n );
                     array += glx_stride;
                  }
                  break;
               case 2: 
                  for (i = 0; i < num_vertices; i++) {
                     swapl( ( (unsigned int *) array ) + 0, _n );
                     swapl( ( (unsigned int *) array ) + 1, _n );
                     array += glx_stride;
                  }
                  break;
               case 1: 
                  for (i = 0; i < num_vertices; i++) {
                     swapl( ( (unsigned int *) array ) + 0, _n );
                     array += glx_stride;
                  }
                  break;
               default:
                  log_print("Attempt to swap odd number of components");
                  break;
            }

         break;
      case 2:

            switch (num_comps) {
               case 3: 
                  for (i = 0; i < num_vertices; i++) {
                     swaps( ( (unsigned short *) array ) + 0, _n );
                     swaps( ( (unsigned short *) array ) + 1, _n );
                     swaps( ( (unsigned short *) array ) + 2, _n );
                     array += glx_stride;
                  }
                  break;
               case 4: 
                  for (i = 0; i < num_vertices; i++) {
                     swaps( ( (unsigned short *) array ) + 0, _n );
                     swaps( ( (unsigned short *) array ) + 1, _n );
                     swaps( ( (unsigned short *) array ) + 2, _n );
                     swaps( ( (unsigned short *) array ) + 3, _n );
                     array += glx_stride;
                  }
                  break;
               case 2: 
                  for (i = 0; i < num_vertices; i++) {
                     swaps( ( (unsigned short *) array ) + 0, _n );
                     swaps( ( (unsigned short *) array ) + 1, _n );
                     array += glx_stride;
                  }
                  break;
               case 1: 
                  for (i = 0; i < num_vertices; i++) {
                     swaps( ( (unsigned short *) array ) + 0, _n );
                     array += glx_stride;
                  }
                  break;
               default:
                  log_print("Attempt to swap odd number of components");
                  break;
            }

         break;
      case 8:

            switch (num_comps) {
               case 3: 
                  for (i = 0; i < num_vertices; i++) {
                     swapd( ( (double *) array ) + 0, _n );
                     swapd( ( (double *) array ) + 1, _n );
                     swapd( ( (double *) array ) + 2, _n );
                     array += glx_stride;
                  }
                  break;
               case 4: 
                  for (i = 0; i < num_vertices; i++) {
                     swapd( ( (double *) array ) + 0, _n );
                     swapd( ( (double *) array ) + 1, _n );
                     swapd( ( (double *) array ) + 2, _n );
                     swapd( ( (double *) array ) + 3, _n );
                     array += glx_stride;
                  }
                  break;
               case 2: 
                  for (i = 0; i < num_vertices; i++) {
                     swapd( ( (double *) array ) + 0, _n );
                     swapd( ( (double *) array ) + 1, _n );
                     array += glx_stride;
                  }
                  break;
               case 1: 
                  for (i = 0; i < num_vertices; i++) {
                     swapd( ( (double *) array ) + 0, _n );
                     array += glx_stride;
                  }
                  break;
               default:
                  log_print("Attempt to swap odd number of components");
                  break;
            }

         break;
      case 1:
         /** don't need to swap **/
         break;
      default:
         log_print("Attempt to swap unrecognized data size array");
         break;
   }
}


int 
GLX_DrawArrays(int n, int m, GLenum mode, struct array_info *infos,
                 void *glx_vertices)
{
   unsigned int glx_stride;
   unsigned int i;
   unsigned char *start = NULL;
   unsigned int num_comps = 0;
   GLenum data_type;
   unsigned int offset = 0;

   struct glx_varray arrays[GLX_MAX_ARRAY_INFOS];
 
   log_print("DrawArrays");
   memset( &arrays, 0, sizeof(struct glx_varray) * GLX_MAX_ARRAY_INFOS);


   /* get all enums */
   arrays[GLX_EDGEFLAG].data_type = get_enum(GL_EDGE_FLAG_ARRAY, infos, m);
   arrays[GLX_TEXTURE].data_type  = 
      get_enum(GL_TEXTURE_COORD_ARRAY, infos, m);
   arrays[GLX_COLOR].data_type    = get_enum(GL_COLOR_ARRAY, infos, m);
   arrays[GLX_INDEX].data_type    = get_enum(GL_INDEX_ARRAY, infos, m);
   arrays[GLX_NORMAL].data_type   = get_enum(GL_NORMAL_ARRAY, infos, m);
   arrays[GLX_VERTEX].data_type   = get_enum(GL_VERTEX_ARRAY, infos, m);

   /* get number of components for each array */
   arrays[GLX_EDGEFLAG].num_comps = 
      get_num_comps(GL_EDGE_FLAG_ARRAY, infos, m);
   arrays[GLX_TEXTURE].num_comps  = 
      get_num_comps(GL_TEXTURE_COORD_ARRAY, infos, m);
   arrays[GLX_COLOR].num_comps    = get_num_comps(GL_COLOR_ARRAY, infos, m);
   arrays[GLX_INDEX].num_comps    = get_num_comps(GL_INDEX_ARRAY, infos, m);
   arrays[GLX_NORMAL].num_comps   = get_num_comps(GL_NORMAL_ARRAY, infos, m);
   arrays[GLX_VERTEX].num_comps   = get_num_comps(GL_VERTEX_ARRAY, infos, m);

   glx_varray_calc_offsets(arrays);

   /** calculate the stride from one element to the next **/
   glx_stride = 0;
   for (i = 0; i < GLX_MAX_ARRAY_INFOS; i++) {
      if (arrays[i].num_comps) {
         glx_stride += GLX_pad ( arrays[i].num_comps * 
            GLX_data_size( (GLenum) arrays[i].data_type ) );
      }
   }

   log_silent();
   log_print("Vertex Array stride: ");
   log_int(glx_stride);
   log_print("\nNum Vertices: ");
   log_int(n);
   log_print("\nEnabled Arrays: ");
   log_int(m);
   log_print("\n");

   if (arrays[GLX_EDGEFLAG].num_comps) {
      log_print("Edge Flags defined\n");
      num_comps = arrays[GLX_EDGEFLAG].num_comps;
      data_type = arrays[GLX_EDGEFLAG].data_type;
      offset = arrays[GLX_EDGEFLAG].offset; 
      start = (unsigned char *) glx_vertices + offset;
      GLX_LOG_ARRAY(num_comps, data_type, offset);
      glEdgeFlagPointer( glx_stride, glx_vertices);      
      glEnableClientState( GL_EDGE_FLAG_ARRAY );
   }

   if (arrays[GLX_TEXTURE].num_comps) {
      log_print("Textures defined\n");
      num_comps = arrays[GLX_TEXTURE].num_comps;
      data_type = arrays[GLX_TEXTURE].data_type;
      offset = arrays[GLX_TEXTURE].offset; 
      start = (unsigned char *) glx_vertices + offset;
      GLX_LOG_ARRAY(num_comps, data_type, offset);
      glTexCoordPointer( num_comps, data_type, glx_stride, (void *) start);
      glEnableClientState( GL_TEXTURE_COORD_ARRAY );
   }

   if (arrays[GLX_COLOR].num_comps) {
      log_print("Colors defined\n");
      num_comps = arrays[GLX_COLOR].num_comps;
      data_type = arrays[GLX_COLOR].data_type;
      offset = arrays[GLX_COLOR].offset; 
      start = ( (unsigned char *) glx_vertices ) + offset;
      GLX_LOG_ARRAY(num_comps, data_type, offset);
      glColorPointer( num_comps, data_type, glx_stride, (void *) start);
      glEnableClientState( GL_COLOR_ARRAY );
   }

   if (arrays[GLX_INDEX].num_comps) {
      log_print("Indices defined\n");
      num_comps = arrays[GLX_INDEX].num_comps;
      data_type = arrays[GLX_INDEX].data_type;
      offset = arrays[GLX_INDEX].offset; 
      start = ( (unsigned char *) glx_vertices ) + offset;
      GLX_LOG_ARRAY(num_comps, data_type, offset);
      glIndexPointer( data_type, glx_stride, (void *) start);
      glEnableClientState( GL_INDEX_ARRAY );
   }

   if (arrays[GLX_NORMAL].num_comps) {
      log_print("Normals defined\n");
      num_comps = arrays[GLX_NORMAL].num_comps;
      data_type = arrays[GLX_NORMAL].data_type;
      offset = arrays[GLX_NORMAL].offset; 
      start = ( (unsigned char *) glx_vertices ) + offset;
      GLX_LOG_ARRAY(num_comps, data_type, offset);
      glNormalPointer( data_type, glx_stride, (void *) start);
      glEnableClientState( GL_NORMAL_ARRAY );
   }

   if (arrays[GLX_VERTEX].num_comps) {
      log_print("Vertices defined\n");
      num_comps = arrays[GLX_VERTEX].num_comps;
      data_type = arrays[GLX_VERTEX].data_type;
      offset = arrays[GLX_VERTEX].offset; 
      start = ( (unsigned char *) glx_vertices ) + offset;
      GLX_LOG_ARRAY(num_comps, data_type, offset);
      glVertexPointer( num_comps, data_type, glx_stride, (void *) start);
      glEnableClientState( GL_VERTEX_ARRAY );
   }

   log_verbose();
   glDrawArrays( mode, 0, n );

   glDisableClientState(GL_VERTEX_ARRAY);
   glDisableClientState(GL_NORMAL_ARRAY);
   glDisableClientState(GL_COLOR_ARRAY);
   glDisableClientState(GL_INDEX_ARRAY);
   glDisableClientState(GL_TEXTURE_COORD_ARRAY);
   glDisableClientState(GL_EDGE_FLAG_ARRAY);

   return 0;
}

int 
GLX_DrawArrays_swapped(int n, int m, GLenum mode, struct array_info *infos,
                 void *glx_vertices)
{
   unsigned int glx_stride;
   unsigned int i;
   unsigned char *start = NULL;
   unsigned int num_comps = 0;
   GLenum data_type;
   unsigned int offset = 0;

   struct glx_varray arrays[GLX_MAX_ARRAY_INFOS];
   memset( &arrays, 0, sizeof(struct glx_varray) * GLX_MAX_ARRAY_INFOS);

   if ( (infos == NULL) || (glx_vertices == NULL) )  return 1;
 
   log_print("swapped DrawArrays");

   /* get all enums */
   log_print("Getting enums");
   arrays[GLX_EDGEFLAG].data_type = get_enum(GL_EDGE_FLAG_ARRAY, infos, m);
   arrays[GLX_TEXTURE].data_type  = 
      get_enum(GL_TEXTURE_COORD_ARRAY, infos, m);
   arrays[GLX_COLOR].data_type    = get_enum(GL_COLOR_ARRAY, infos, m);
   arrays[GLX_INDEX].data_type    = get_enum(GL_INDEX_ARRAY, infos, m);
   arrays[GLX_NORMAL].data_type   = get_enum(GL_NORMAL_ARRAY, infos, m);
   arrays[GLX_VERTEX].data_type   = get_enum(GL_VERTEX_ARRAY, infos, m);

   /* get number of components for each array */
   log_print("Getting components");
   arrays[GLX_EDGEFLAG].num_comps = 
      get_num_comps(GL_EDGE_FLAG_ARRAY, infos, m);
   arrays[GLX_TEXTURE].num_comps  = 
      get_num_comps(GL_TEXTURE_COORD_ARRAY, infos, m);
   arrays[GLX_COLOR].num_comps    = get_num_comps(GL_COLOR_ARRAY, infos, m);
   arrays[GLX_INDEX].num_comps    = get_num_comps(GL_INDEX_ARRAY, infos, m);
   arrays[GLX_NORMAL].num_comps   = get_num_comps(GL_NORMAL_ARRAY, infos, m);
   arrays[GLX_VERTEX].num_comps   = get_num_comps(GL_VERTEX_ARRAY, infos, m);

   glx_varray_calc_offsets(arrays);

   /** calculate the stride from one element to the next **/
   glx_stride = 0;
   for (i = 0; i < GLX_MAX_ARRAY_INFOS; i++) {
      if (arrays[i].num_comps) {
         glx_stride += GLX_pad ( arrays[i].num_comps * 
            GLX_data_size( (GLenum) arrays[i].data_type ) );
      }
   }

   log_silent();
   log_print("Vertex Array stride: ");
   log_int(glx_stride);
   log_print("\nNum Vertices: ");
   log_int(n);
   log_print("\nEnabled Arrays: ");
   log_int(m);
   log_print("\n");

   if (arrays[GLX_EDGEFLAG].num_comps) {
      log_print("Edge Flags defined\n");
      num_comps = arrays[GLX_EDGEFLAG].num_comps;
      data_type = arrays[GLX_EDGEFLAG].data_type;
      offset = arrays[GLX_EDGEFLAG].offset; 
      start = ( (unsigned char *) glx_vertices ) + offset;
      GLX_LOG_ARRAY(num_comps, data_type, offset);
      GLX_swap_varray(num_comps, data_type, n, glx_stride, start);
      glEdgeFlagPointer( glx_stride, start);      
      glEnableClientState( GL_EDGE_FLAG_ARRAY );
   }

   if (arrays[GLX_TEXTURE].num_comps) {
      log_print("Textures defined\n");
      num_comps = arrays[GLX_TEXTURE].num_comps;
      data_type = arrays[GLX_TEXTURE].data_type;
      offset = arrays[GLX_TEXTURE].offset; 
      start = ( (unsigned char *) glx_vertices ) + offset;
      GLX_LOG_ARRAY(num_comps, data_type, offset);
      GLX_swap_varray(num_comps, data_type, n, glx_stride, start);
      glTexCoordPointer( num_comps, data_type, glx_stride, (void *) start);
      glEnableClientState( GL_TEXTURE_COORD_ARRAY );
   }

   if (arrays[GLX_COLOR].num_comps) {
      log_print("Colors defined\n");
      num_comps = arrays[GLX_COLOR].num_comps;
      data_type = arrays[GLX_COLOR].data_type;
      offset = arrays[GLX_COLOR].offset; 
      start = ( (unsigned char *) glx_vertices ) + offset;
      GLX_LOG_ARRAY(num_comps, data_type, offset);
      GLX_swap_varray(num_comps, data_type, n, glx_stride, start);
      glColorPointer( num_comps, data_type, glx_stride, (void *) start);
      glEnableClientState( GL_COLOR_ARRAY );
   }

   if (arrays[GLX_INDEX].num_comps) {
      log_print("Indices defined\n");
      num_comps = arrays[GLX_INDEX].num_comps;
      data_type = arrays[GLX_INDEX].data_type;
      offset = arrays[GLX_INDEX].offset; 
      start = ( (unsigned char *) glx_vertices ) + offset;
      GLX_LOG_ARRAY(num_comps, data_type, offset);
      GLX_swap_varray(num_comps, data_type, n, glx_stride, start);
      glIndexPointer( data_type, glx_stride, (void *) start);
      glEnableClientState( GL_INDEX_ARRAY );
   }

   if (arrays[GLX_NORMAL].num_comps) {
      log_print("Normals defined\n");
      num_comps = arrays[GLX_NORMAL].num_comps;
      data_type = arrays[GLX_NORMAL].data_type;
      offset = arrays[GLX_NORMAL].offset; 
      start = ( (unsigned char *) glx_vertices ) + offset;
      GLX_swap_varray(num_comps, data_type, n, glx_stride, start);
      GLX_LOG_ARRAY_NEW(num_comps, data_type, offset, glx_vertices, start);
      GLX_LOG_FLOAT_ARRAY(num_comps, n, glx_stride, start);
      glNormalPointer( data_type, glx_stride, (void *) start);
      glEnableClientState( GL_NORMAL_ARRAY );
   }

   if (arrays[GLX_VERTEX].num_comps) {
      log_print("Vertices defined\n");
      num_comps = arrays[GLX_VERTEX].num_comps;
      data_type = arrays[GLX_VERTEX].data_type;
      offset = arrays[GLX_VERTEX].offset; 
      start = ( (unsigned char *) glx_vertices ) + offset;
      GLX_swap_varray(num_comps, data_type, n, glx_stride, start);
      GLX_LOG_ARRAY_NEW(num_comps, data_type, offset, glx_vertices, start);
      GLX_LOG_FLOAT_ARRAY(num_comps, n, glx_stride, start);
      glVertexPointer( num_comps, data_type, glx_stride, (void *) start);
      glEnableClientState( GL_VERTEX_ARRAY );
   }

   log_verbose();
   glDrawArrays( mode, 0, n );

   glDisableClientState(GL_VERTEX_ARRAY);
   glDisableClientState(GL_NORMAL_ARRAY);
   glDisableClientState(GL_COLOR_ARRAY);
   glDisableClientState(GL_INDEX_ARRAY);
   glDisableClientState(GL_TEXTURE_COORD_ARRAY);
   glDisableClientState(GL_EDGE_FLAG_ARRAY);

   return 0;
}


