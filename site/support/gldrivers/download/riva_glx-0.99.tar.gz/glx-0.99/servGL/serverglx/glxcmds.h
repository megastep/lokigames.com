
/*
 * GLX Server Extension
 * Copyright (C) 1998, 1999 Terence Ripperda (ripperda@sgi.com)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * TERENCE RIPPERDA, OR ANY OTHER CONTRIBUTORS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, 
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
 * DEALINGS IN THE SOFTWARE.
 */

#ifndef GLX_CMDS
#define GLX_CMDS

int GLnoop(ClientPtr client);
int GLRender(ClientPtr client);
int GLRender_swapped(ClientPtr client);
int GLRenderLarge(ClientPtr client);
int GLRenderLarge_swapped(ClientPtr client);
int GLCreateContext(ClientPtr client);
int GLDestroyContext(ClientPtr client);
int GLMakeCurrent(ClientPtr client);
int GLIsDirect(ClientPtr client);
int GLQueryVersion(ClientPtr client);
int GLWaitGL(ClientPtr client);
int GLWaitX(ClientPtr client);
int GLCopyContext(ClientPtr client);
int GLSwapBuffers(ClientPtr client);
int GLUseXFont(ClientPtr client);
int GLCreateGLXPixmap(ClientPtr client);
int GLGetVisualConfigs(ClientPtr client);
int GLDestroyGLXPixmap(ClientPtr client);
int GLVendorPrivate(ClientPtr client);
int GLVendorPrivateWithReply(ClientPtr client);
int GLQueryServerString(ClientPtr client);
int GLClientInfo(ClientPtr client);
int GLNewList(ClientPtr client);
int GLEndList(ClientPtr client);
int GLDeleteLists(ClientPtr client);
int GLGenLists(ClientPtr client);
int GLFeedbackBuffer(ClientPtr client);
int GLSelectBuffer(ClientPtr client);
int GLRenderMode(ClientPtr client);
int GLFinish(ClientPtr client);
int GLPixelStoref(ClientPtr client);
int GLPixelStorei(ClientPtr client);
int GLReadPixels(ClientPtr client);
int GLGetBooleanv(ClientPtr client);
int GLGetClipPlane(ClientPtr client);
int GLGetDoublev(ClientPtr client);
int GLGetError(ClientPtr client);
int GLGetFloatv(ClientPtr client);
int GLGetIntegerv(ClientPtr client);
int GLGetLightfv(ClientPtr client);
int GLGetLightiv(ClientPtr client);
int GLGetMapdv(ClientPtr client);
int GLGetMapfv(ClientPtr client);
int GLGetMapiv(ClientPtr client);
int GLGetMaterialfv(ClientPtr client);
int GLGetMaterialiv(ClientPtr client);
int GLGetPixelMapfv(ClientPtr client);
int GLGetPixelMapuiv(ClientPtr client);
int GLGetPixelMapusv(ClientPtr client);
int GLGetPolygonStipple(ClientPtr client);
int GLGetString(ClientPtr client);
int GLGetTexEnvfv(ClientPtr client);
int GLGetTexEnviv(ClientPtr client);
int GLGetTexGendv(ClientPtr client);
int GLGetTexGenfv(ClientPtr client);
int GLGetTexGeniv(ClientPtr client);
int GLGetTexImage(ClientPtr client);
int GLGetTexParameterfv(ClientPtr client);
int GLGetTexParameteriv(ClientPtr client);
int GLGetTexLevelParameterfv(ClientPtr client);
int GLGetTexLevelParameteriv(ClientPtr client);
int GLIsEnabled(ClientPtr client);
int GLIsList(ClientPtr client);
int GLFlush(ClientPtr client);
int GLAreTexturesResident(ClientPtr client);
int GLDeleteTextures(ClientPtr client);
int GLGenTextures(ClientPtr client);

#endif
