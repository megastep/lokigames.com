#include <stdio.h>
#include "glxrender.h"
#include "glx_swap.h"
#include "glxdecode.h"
#include "glxdecode_swapped.h"
#include "glxcommon.h"
#include "misc.h"
#include "glx_log.h"
#include "glx_varray.h"
GLXRenderFunc GLX_render_funcs_swapped[] = {
	GLXDecodeInvalid, /* 0 */
	GLXDecodeCallList_swapped, /* 1 */
	GLXDecodeCallLists_swapped, /* 2 */
	GLXDecodeListBase_swapped, /* 3 */
	GLXDecodeBegin_swapped, /* 4 */
	GLXDecodeBitmap_swapped, /* 5 */
	GLXDecodeColor3bv_swapped, /* 6 */
	GLXDecodeColor3dv_swapped, /* 7 */
	GLXDecodeColor3fv_swapped, /* 8 */
	GLXDecodeColor3iv_swapped, /* 9 */
	GLXDecodeColor3sv_swapped, /* 10 */
	GLXDecodeColor3ubv_swapped, /* 11 */
	GLXDecodeColor3uiv_swapped, /* 12 */
	GLXDecodeColor3usv_swapped, /* 13 */
	GLXDecodeColor4bv_swapped, /* 14 */
	GLXDecodeColor4dv_swapped, /* 15 */
	GLXDecodeColor4fv_swapped, /* 16 */
	GLXDecodeColor4iv_swapped, /* 17 */
	GLXDecodeColor4sv_swapped, /* 18 */
	GLXDecodeColor4ubv_swapped, /* 19 */
	GLXDecodeColor4uiv_swapped, /* 20 */
	GLXDecodeColor4usv_swapped, /* 21 */
	GLXDecodeEdgeFlagv_swapped, /* 22 */
	GLXDecodeEnd_swapped, /* 23 */
	GLXDecodeIndexdv_swapped, /* 24 */
	GLXDecodeIndexfv_swapped, /* 25 */
	GLXDecodeIndexiv_swapped, /* 26 */
	GLXDecodeIndexsv_swapped, /* 27 */
	GLXDecodeNormal3bv_swapped, /* 28 */
	GLXDecodeNormal3dv_swapped, /* 29 */
	GLXDecodeNormal3fv_swapped, /* 30 */
	GLXDecodeNormal3iv_swapped, /* 31 */
	GLXDecodeNormal3sv_swapped, /* 32 */
	GLXDecodeRasterPos2dv_swapped, /* 33 */
	GLXDecodeRasterPos2fv_swapped, /* 34 */
	GLXDecodeRasterPos2iv_swapped, /* 35 */
	GLXDecodeRasterPos2sv_swapped, /* 36 */
	GLXDecodeRasterPos3dv_swapped, /* 37 */
	GLXDecodeRasterPos3fv_swapped, /* 38 */
	GLXDecodeRasterPos3iv_swapped, /* 39 */
	GLXDecodeRasterPos3sv_swapped, /* 40 */
	GLXDecodeRasterPos4dv_swapped, /* 41 */
	GLXDecodeRasterPos4fv_swapped, /* 42 */
	GLXDecodeRasterPos4iv_swapped, /* 43 */
	GLXDecodeRasterPos4sv_swapped, /* 44 */
	GLXDecodeRectdv_swapped, /* 45 */
	GLXDecodeRectfv_swapped, /* 46 */
	GLXDecodeRectiv_swapped, /* 47 */
	GLXDecodeRectsv_swapped, /* 48 */
	GLXDecodeTexCoord1dv_swapped, /* 49 */
	GLXDecodeTexCoord1fv_swapped, /* 50 */
	GLXDecodeTexCoord1iv_swapped, /* 51 */
	GLXDecodeTexCoord1sv_swapped, /* 52 */
	GLXDecodeTexCoord2dv_swapped, /* 53 */
	GLXDecodeTexCoord2fv_swapped, /* 54 */
	GLXDecodeTexCoord2iv_swapped, /* 55 */
	GLXDecodeTexCoord2sv_swapped, /* 56 */
	GLXDecodeTexCoord3dv_swapped, /* 57 */
	GLXDecodeTexCoord3fv_swapped, /* 58 */
	GLXDecodeTexCoord3iv_swapped, /* 59 */
	GLXDecodeTexCoord3sv_swapped, /* 60 */
	GLXDecodeTexCoord4dv_swapped, /* 61 */
	GLXDecodeTexCoord4fv_swapped, /* 62 */
	GLXDecodeTexCoord4iv_swapped, /* 63 */
	GLXDecodeTexCoord4sv_swapped, /* 64 */
	GLXDecodeVertex2dv_swapped, /* 65 */
	GLXDecodeVertex2fv_swapped, /* 66 */
	GLXDecodeVertex2iv_swapped, /* 67 */
	GLXDecodeVertex2sv_swapped, /* 68 */
	GLXDecodeVertex3dv_swapped, /* 69 */
	GLXDecodeVertex3fv_swapped, /* 70 */
	GLXDecodeVertex3iv_swapped, /* 71 */
	GLXDecodeVertex3sv_swapped, /* 72 */
	GLXDecodeVertex4dv_swapped, /* 73 */
	GLXDecodeVertex4fv_swapped, /* 74 */
	GLXDecodeVertex4iv_swapped, /* 75 */
	GLXDecodeVertex4sv_swapped, /* 76 */
	GLXDecodeClipPlane_swapped, /* 77 */
	GLXDecodeColorMaterial_swapped, /* 78 */
	GLXDecodeCullFace_swapped, /* 79 */
	GLXDecodeFogf_swapped, /* 80 */
	GLXDecodeFogfv_swapped, /* 81 */
	GLXDecodeFogi_swapped, /* 82 */
	GLXDecodeFogiv_swapped, /* 83 */
	GLXDecodeFrontFace_swapped, /* 84 */
	GLXDecodeHint_swapped, /* 85 */
	GLXDecodeLightf_swapped, /* 86 */
	GLXDecodeLightfv_swapped, /* 87 */
	GLXDecodeLighti_swapped, /* 88 */
	GLXDecodeLightiv_swapped, /* 89 */
	GLXDecodeLightModelf_swapped, /* 90 */
	GLXDecodeLightModelfv_swapped, /* 91 */
	GLXDecodeLightModeli_swapped, /* 92 */
	GLXDecodeLightModeliv_swapped, /* 93 */
	GLXDecodeLineStipple_swapped, /* 94 */
	GLXDecodeLineWidth_swapped, /* 95 */
	GLXDecodeMaterialf_swapped, /* 96 */
	GLXDecodeMaterialfv_swapped, /* 97 */
	GLXDecodeMateriali_swapped, /* 98 */
	GLXDecodeMaterialiv_swapped, /* 99 */
	GLXDecodePointSize_swapped, /* 100 */
	GLXDecodePolygonMode_swapped, /* 101 */
	GLXDecodePolygonStipple_swapped, /* 102 */
	GLXDecodeScissor_swapped, /* 103 */
	GLXDecodeShadeModel_swapped, /* 104 */
	GLXDecodeTexParameterf_swapped, /* 105 */
	GLXDecodeTexParameterfv_swapped, /* 106 */
	GLXDecodeTexParameteri_swapped, /* 107 */
	GLXDecodeTexParameteriv_swapped, /* 108 */
	GLXDecodeTexImage1D_swapped, /* 109 */
	GLXDecodeTexImage2D_swapped, /* 110 */
	GLXDecodeTexEnvf_swapped, /* 111 */
	GLXDecodeTexEnvfv_swapped, /* 112 */
	GLXDecodeTexEnvi_swapped, /* 113 */
	GLXDecodeTexEnviv_swapped, /* 114 */
	GLXDecodeTexGend_swapped, /* 115 */
	GLXDecodeTexGendv_swapped, /* 116 */
	GLXDecodeTexGenf_swapped, /* 117 */
	GLXDecodeTexGenfv_swapped, /* 118 */
	GLXDecodeTexGeni_swapped, /* 119 */
	GLXDecodeTexGeniv_swapped, /* 120 */
	GLXDecodeInitNames_swapped, /* 121 */
	GLXDecodeLoadName_swapped, /* 122 */
	GLXDecodePassThrough_swapped, /* 123 */
	GLXDecodePopName_swapped, /* 124 */
	GLXDecodePushName_swapped, /* 125 */
	GLXDecodeDrawBuffer_swapped, /* 126 */
	GLXDecodeClear_swapped, /* 127 */
	GLXDecodeClearAccum_swapped, /* 128 */
	GLXDecodeClearIndex_swapped, /* 129 */
	GLXDecodeClearColor_swapped, /* 130 */
	GLXDecodeClearStencil_swapped, /* 131 */
	GLXDecodeClearDepth_swapped, /* 132 */
	GLXDecodeStencilMask_swapped, /* 133 */
	GLXDecodeColorMask_swapped, /* 134 */
	GLXDecodeDepthMask_swapped, /* 135 */
	GLXDecodeIndexMask_swapped, /* 136 */
	GLXDecodeAccum_swapped, /* 137 */
	GLXDecodeDisable_swapped, /* 138 */
	GLXDecodeEnable_swapped, /* 139 */
	GLXDecodeInvalid, /* 140 */
	GLXDecodePopAttrib_swapped, /* 141 */
	GLXDecodePushAttrib_swapped, /* 142 */
	GLXDecodeMap1d_swapped, /* 143 */
	GLXDecodeMap1f_swapped, /* 144 */
	GLXDecodeMap2d_swapped, /* 145 */
	GLXDecodeMap2f_swapped, /* 146 */
	GLXDecodeMapGrid1d_swapped, /* 147 */
	GLXDecodeMapGrid1f_swapped, /* 148 */
	GLXDecodeMapGrid2d_swapped, /* 149 */
	GLXDecodeMapGrid2f_swapped, /* 150 */
	GLXDecodeEvalCoord1dv_swapped, /* 151 */
	GLXDecodeEvalCoord1fv_swapped, /* 152 */
	GLXDecodeEvalCoord2dv_swapped, /* 153 */
	GLXDecodeEvalCoord2fv_swapped, /* 154 */
	GLXDecodeEvalMesh1_swapped, /* 155 */
	GLXDecodeEvalPoint1_swapped, /* 156 */
	GLXDecodeEvalMesh2_swapped, /* 157 */
	GLXDecodeEvalPoint2_swapped, /* 158 */
	GLXDecodeAlphaFunc_swapped, /* 159 */
	GLXDecodeBlendFunc_swapped, /* 160 */
	GLXDecodeLogicOp_swapped, /* 161 */
	GLXDecodeStencilFunc_swapped, /* 162 */
	GLXDecodeStencilOp_swapped, /* 163 */
	GLXDecodeDepthFunc_swapped, /* 164 */
	GLXDecodePixelZoom_swapped, /* 165 */
	GLXDecodePixelTransferf_swapped, /* 166 */
	GLXDecodePixelTransferi_swapped, /* 167 */
	GLXDecodePixelMapfv_swapped, /* 168 */
	GLXDecodePixelMapuiv_swapped, /* 169 */
	GLXDecodePixelMapusv_swapped, /* 170 */
	GLXDecodeReadBuffer_swapped, /* 171 */
	GLXDecodeCopyPixels_swapped, /* 172 */
	GLXDecodeDrawPixels_swapped, /* 173 */
	GLXDecodeDepthRange_swapped, /* 174 */
	GLXDecodeFrustum_swapped, /* 175 */
	GLXDecodeLoadIdentity_swapped, /* 176 */
	GLXDecodeLoadMatrixf_swapped, /* 177 */
	GLXDecodeLoadMatrixd_swapped, /* 178 */
	GLXDecodeMatrixMode_swapped, /* 179 */
	GLXDecodeMultMatrixf_swapped, /* 180 */
	GLXDecodeMultMatrixd_swapped, /* 181 */
	GLXDecodeOrtho_swapped, /* 182 */
	GLXDecodePopMatrix_swapped, /* 183 */
	GLXDecodePushMatrix_swapped, /* 184 */
	GLXDecodeRotated_swapped, /* 185 */
	GLXDecodeRotatef_swapped, /* 186 */
	GLXDecodeScaled_swapped, /* 187 */
	GLXDecodeScalef_swapped, /* 188 */
	GLXDecodeTranslated_swapped, /* 189 */
	GLXDecodeTranslatef_swapped, /* 190 */
	GLXDecodeViewport_swapped, /* 191 */
	GLXDecodePolygonOffset_swapped, /* 192 */
	GLXDecodeDrawArrays_swapped, /* 193 */
	GLXDecodeIndexubv_swapped, /* 194 */
	GLXDecodeInvalid, /* 195 */
	GLXDecodeInvalid, /* 196 */
	GLXDecodeInvalid, /* 197 */
	GLXDecodeInvalid, /* 198 */
	GLXDecodeInvalid, /* 199 */
	GLXDecodeInvalid, /* 200 */
	GLXDecodeInvalid, /* 201 */
	GLXDecodeInvalid, /* 202 */
	GLXDecodeInvalid, /* 203 */
	GLXDecodeInvalid, /* 204 */
	GLXDecodeInvalid, /* 205 */
	GLXDecodeInvalid, /* 206 */
	GLXDecodeInvalid, /* 207 */
	GLXDecodeInvalid, /* 208 */
	GLXDecodeInvalid, /* 209 */
	GLXDecodeInvalid, /* 210 */
	GLXDecodeInvalid, /* 211 */
	GLXDecodeInvalid, /* 212 */
	GLXDecodeInvalid, /* 213 */
	GLXDecodeInvalid, /* 214 */
	GLXDecodeInvalid, /* 215 */
	GLXDecodeInvalid, /* 216 */
	GLXDecodeInvalid, /* 217 */
	GLXDecodeInvalid, /* 218 */
	GLXDecodeInvalid, /* 219 */
	GLXDecodeInvalid, /* 220 */
	GLXDecodeInvalid, /* 221 */
	GLXDecodeInvalid, /* 222 */
	GLXDecodeInvalid, /* 223 */
	GLXDecodeInvalid, /* 224 */
	GLXDecodeInvalid, /* 225 */
	GLXDecodeInvalid, /* 226 */
	GLXDecodeInvalid, /* 227 */
	GLXDecodeInvalid, /* 228 */
	GLXDecodeInvalid, /* 229 */
	GLXDecodeInvalid, /* 230 */
	GLXDecodeInvalid, /* 231 */
	GLXDecodeInvalid, /* 232 */
	GLXDecodeInvalid, /* 233 */
	GLXDecodeInvalid, /* 234 */
	GLXDecodeInvalid, /* 235 */
	GLXDecodeInvalid, /* 236 */
	GLXDecodeInvalid, /* 237 */
	GLXDecodeInvalid, /* 238 */
	GLXDecodeInvalid, /* 239 */
	GLXDecodeInvalid, /* 240 */
	GLXDecodeInvalid, /* 241 */
	GLXDecodeInvalid, /* 242 */
	GLXDecodeInvalid, /* 243 */
	GLXDecodeInvalid, /* 244 */
	GLXDecodeInvalid, /* 245 */
	GLXDecodeInvalid, /* 246 */
	GLXDecodeInvalid, /* 247 */
	GLXDecodeInvalid, /* 248 */
	GLXDecodeInvalid, /* 249 */
	GLXDecodeInvalid, /* 250 */
	GLXDecodeInvalid, /* 251 */
	GLXDecodeInvalid, /* 252 */
	GLXDecodeInvalid, /* 253 */
	GLXDecodeInvalid, /* 254 */
	GLXDecodeInvalid, /* 255 */
	GLXDecodeInvalid, /* 256 */
	GLXDecodeInvalid, /* 257 */
	GLXDecodeInvalid, /* 258 */
	GLXDecodeInvalid, /* 259 */
	GLXDecodeInvalid, /* 260 */
	GLXDecodeInvalid, /* 261 */
	GLXDecodeInvalid, /* 262 */
	GLXDecodeInvalid, /* 263 */
	GLXDecodeInvalid, /* 264 */
	GLXDecodeInvalid, /* 265 */
	GLXDecodeInvalid, /* 266 */
	GLXDecodeInvalid, /* 267 */
	GLXDecodeInvalid, /* 268 */
	GLXDecodeInvalid, /* 269 */
	GLXDecodeInvalid, /* 270 */
	GLXDecodeInvalid, /* 271 */
	GLXDecodeInvalid, /* 272 */
	GLXDecodeInvalid, /* 273 */
	GLXDecodeInvalid, /* 274 */
	GLXDecodeInvalid, /* 275 */
	GLXDecodeInvalid, /* 276 */
	GLXDecodeInvalid, /* 277 */
	GLXDecodeInvalid, /* 278 */
	GLXDecodeInvalid, /* 279 */
	GLXDecodeInvalid, /* 280 */
	GLXDecodeInvalid, /* 281 */
	GLXDecodeInvalid, /* 282 */
	GLXDecodeInvalid, /* 283 */
	GLXDecodeInvalid, /* 284 */
	GLXDecodeInvalid, /* 285 */
	GLXDecodeInvalid, /* 286 */
	GLXDecodeInvalid, /* 287 */
	GLXDecodeInvalid, /* 288 */
	GLXDecodeInvalid, /* 289 */
	GLXDecodeInvalid, /* 290 */
	GLXDecodeInvalid, /* 291 */
	GLXDecodeInvalid, /* 292 */
	GLXDecodeInvalid, /* 293 */
	GLXDecodeInvalid, /* 294 */
	GLXDecodeInvalid, /* 295 */
	GLXDecodeInvalid, /* 296 */
	GLXDecodeInvalid, /* 297 */
	GLXDecodeInvalid, /* 298 */
	GLXDecodeInvalid, /* 299 */
	GLXDecodeInvalid, /* 300 */
	GLXDecodeInvalid, /* 301 */
	GLXDecodeInvalid, /* 302 */
	GLXDecodeInvalid, /* 303 */
	GLXDecodeInvalid, /* 304 */
	GLXDecodeInvalid, /* 305 */
	GLXDecodeInvalid, /* 306 */
	GLXDecodeInvalid, /* 307 */
	GLXDecodeInvalid, /* 308 */
	GLXDecodeInvalid, /* 309 */
	GLXDecodeInvalid, /* 310 */
	GLXDecodeInvalid, /* 311 */
	GLXDecodeInvalid, /* 312 */
	GLXDecodeInvalid, /* 313 */
	GLXDecodeInvalid, /* 314 */
	GLXDecodeInvalid, /* 315 */
	GLXDecodeInvalid, /* 316 */
	GLXDecodeInvalid, /* 317 */
	GLXDecodeInvalid, /* 318 */
	GLXDecodeInvalid, /* 319 */
	GLXDecodeInvalid, /* 320 */
	GLXDecodeInvalid, /* 321 */
	GLXDecodeInvalid, /* 322 */
	GLXDecodeInvalid, /* 323 */
	GLXDecodeInvalid, /* 324 */
	GLXDecodeInvalid, /* 325 */
	GLXDecodeInvalid, /* 326 */
	GLXDecodeInvalid, /* 327 */
	GLXDecodeInvalid, /* 328 */
	GLXDecodeInvalid, /* 329 */
	GLXDecodeInvalid, /* 330 */
	GLXDecodeInvalid, /* 331 */
	GLXDecodeInvalid, /* 332 */
	GLXDecodeInvalid, /* 333 */
	GLXDecodeInvalid, /* 334 */
	GLXDecodeInvalid, /* 335 */
	GLXDecodeInvalid, /* 336 */
	GLXDecodeInvalid, /* 337 */
	GLXDecodeInvalid, /* 338 */
	GLXDecodeInvalid, /* 339 */
	GLXDecodeInvalid, /* 340 */
	GLXDecodeInvalid, /* 341 */
	GLXDecodeInvalid, /* 342 */
	GLXDecodeInvalid, /* 343 */
	GLXDecodeInvalid, /* 344 */
	GLXDecodeInvalid, /* 345 */
	GLXDecodeInvalid, /* 346 */
	GLXDecodeInvalid, /* 347 */
	GLXDecodeInvalid, /* 348 */
	GLXDecodeInvalid, /* 349 */
	GLXDecodeInvalid, /* 350 */
	GLXDecodeInvalid, /* 351 */
	GLXDecodeInvalid, /* 352 */
	GLXDecodeInvalid, /* 353 */
	GLXDecodeInvalid, /* 354 */
	GLXDecodeInvalid, /* 355 */
	GLXDecodeInvalid, /* 356 */
	GLXDecodeInvalid, /* 357 */
	GLXDecodeInvalid, /* 358 */
	GLXDecodeInvalid, /* 359 */
	GLXDecodeInvalid, /* 360 */
	GLXDecodeInvalid, /* 361 */
	GLXDecodeInvalid, /* 362 */
	GLXDecodeInvalid, /* 363 */
	GLXDecodeInvalid, /* 364 */
	GLXDecodeInvalid, /* 365 */
	GLXDecodeInvalid, /* 366 */
	GLXDecodeInvalid, /* 367 */
	GLXDecodeInvalid, /* 368 */
	GLXDecodeInvalid, /* 369 */
	GLXDecodeInvalid, /* 370 */
	GLXDecodeInvalid, /* 371 */
	GLXDecodeInvalid, /* 372 */
	GLXDecodeInvalid, /* 373 */
	GLXDecodeInvalid, /* 374 */
	GLXDecodeInvalid, /* 375 */
	GLXDecodeInvalid, /* 376 */
	GLXDecodeInvalid, /* 377 */
	GLXDecodeInvalid, /* 378 */
	GLXDecodeInvalid, /* 379 */
	GLXDecodeInvalid, /* 380 */
	GLXDecodeInvalid, /* 381 */
	GLXDecodeInvalid, /* 382 */
	GLXDecodeInvalid, /* 383 */
	GLXDecodeInvalid, /* 384 */
	GLXDecodeInvalid, /* 385 */
	GLXDecodeInvalid, /* 386 */
	GLXDecodeInvalid, /* 387 */
	GLXDecodeInvalid, /* 388 */
	GLXDecodeInvalid, /* 389 */
	GLXDecodeInvalid, /* 390 */
	GLXDecodeInvalid, /* 391 */
	GLXDecodeInvalid, /* 392 */
	GLXDecodeInvalid, /* 393 */
	GLXDecodeInvalid, /* 394 */
	GLXDecodeInvalid, /* 395 */
	GLXDecodeInvalid, /* 396 */
	GLXDecodeInvalid, /* 397 */
	GLXDecodeInvalid, /* 398 */
	GLXDecodeInvalid, /* 399 */
	GLXDecodeInvalid, /* 400 */
	GLXDecodeInvalid, /* 401 */
	GLXDecodeInvalid, /* 402 */
	GLXDecodeInvalid, /* 403 */
	GLXDecodeInvalid, /* 404 */
	GLXDecodeInvalid, /* 405 */
	GLXDecodeInvalid, /* 406 */
	GLXDecodeInvalid, /* 407 */
	GLXDecodeInvalid, /* 408 */
	GLXDecodeInvalid, /* 409 */
	GLXDecodeInvalid, /* 410 */
	GLXDecodeInvalid, /* 411 */
	GLXDecodeInvalid, /* 412 */
	GLXDecodeInvalid, /* 413 */
	GLXDecodeInvalid, /* 414 */
	GLXDecodeInvalid, /* 415 */
	GLXDecodeInvalid, /* 416 */
	GLXDecodeInvalid, /* 417 */
	GLXDecodeInvalid, /* 418 */
	GLXDecodeInvalid, /* 419 */
	GLXDecodeInvalid, /* 420 */
	GLXDecodeInvalid, /* 421 */
	GLXDecodeInvalid, /* 422 */
	GLXDecodeInvalid, /* 423 */
	GLXDecodeInvalid, /* 424 */
	GLXDecodeInvalid, /* 425 */
	GLXDecodeInvalid, /* 426 */
	GLXDecodeInvalid, /* 427 */
	GLXDecodeInvalid, /* 428 */
	GLXDecodeInvalid, /* 429 */
	GLXDecodeInvalid, /* 430 */
	GLXDecodeInvalid, /* 431 */
	GLXDecodeInvalid, /* 432 */
	GLXDecodeInvalid, /* 433 */
	GLXDecodeInvalid, /* 434 */
	GLXDecodeInvalid, /* 435 */
	GLXDecodeInvalid, /* 436 */
	GLXDecodeInvalid, /* 437 */
	GLXDecodeInvalid, /* 438 */
	GLXDecodeInvalid, /* 439 */
	GLXDecodeInvalid, /* 440 */
	GLXDecodeInvalid, /* 441 */
	GLXDecodeInvalid, /* 442 */
	GLXDecodeInvalid, /* 443 */
	GLXDecodeInvalid, /* 444 */
	GLXDecodeInvalid, /* 445 */
	GLXDecodeInvalid, /* 446 */
	GLXDecodeInvalid, /* 447 */
	GLXDecodeInvalid, /* 448 */
	GLXDecodeInvalid, /* 449 */
	GLXDecodeInvalid, /* 450 */
	GLXDecodeInvalid, /* 451 */
	GLXDecodeInvalid, /* 452 */
	GLXDecodeInvalid, /* 453 */
	GLXDecodeInvalid, /* 454 */
	GLXDecodeInvalid, /* 455 */
	GLXDecodeInvalid, /* 456 */
	GLXDecodeInvalid, /* 457 */
	GLXDecodeInvalid, /* 458 */
	GLXDecodeInvalid, /* 459 */
	GLXDecodeInvalid, /* 460 */
	GLXDecodeInvalid, /* 461 */
	GLXDecodeInvalid, /* 462 */
	GLXDecodeInvalid, /* 463 */
	GLXDecodeInvalid, /* 464 */
	GLXDecodeInvalid, /* 465 */
	GLXDecodeInvalid, /* 466 */
	GLXDecodeInvalid, /* 467 */
	GLXDecodeInvalid, /* 468 */
	GLXDecodeInvalid, /* 469 */
	GLXDecodeInvalid, /* 470 */
	GLXDecodeInvalid, /* 471 */
	GLXDecodeInvalid, /* 472 */
	GLXDecodeInvalid, /* 473 */
	GLXDecodeInvalid, /* 474 */
	GLXDecodeInvalid, /* 475 */
	GLXDecodeInvalid, /* 476 */
	GLXDecodeInvalid, /* 477 */
	GLXDecodeInvalid, /* 478 */
	GLXDecodeInvalid, /* 479 */
	GLXDecodeInvalid, /* 480 */
	GLXDecodeInvalid, /* 481 */
	GLXDecodeInvalid, /* 482 */
	GLXDecodeInvalid, /* 483 */
	GLXDecodeInvalid, /* 484 */
	GLXDecodeInvalid, /* 485 */
	GLXDecodeInvalid, /* 486 */
	GLXDecodeInvalid, /* 487 */
	GLXDecodeInvalid, /* 488 */
	GLXDecodeInvalid, /* 489 */
	GLXDecodeInvalid, /* 490 */
	GLXDecodeInvalid, /* 491 */
	GLXDecodeInvalid, /* 492 */
	GLXDecodeInvalid, /* 493 */
	GLXDecodeInvalid, /* 494 */
	GLXDecodeInvalid, /* 495 */
	GLXDecodeInvalid, /* 496 */
	GLXDecodeInvalid, /* 497 */
	GLXDecodeInvalid, /* 498 */
	GLXDecodeInvalid, /* 499 */
	GLXDecodeInvalid, /* 500 */
	GLXDecodeInvalid, /* 501 */
	GLXDecodeInvalid, /* 502 */
	GLXDecodeInvalid, /* 503 */
	GLXDecodeInvalid, /* 504 */
	GLXDecodeInvalid, /* 505 */
	GLXDecodeInvalid, /* 506 */
	GLXDecodeInvalid, /* 507 */
	GLXDecodeInvalid, /* 508 */
	GLXDecodeInvalid, /* 509 */
	GLXDecodeInvalid, /* 510 */
	GLXDecodeInvalid, /* 511 */
	GLXDecodeInvalid, /* 512 */
	GLXDecodeInvalid, /* 513 */
	GLXDecodeInvalid, /* 514 */
	GLXDecodeInvalid, /* 515 */
	GLXDecodeInvalid, /* 516 */
	GLXDecodeInvalid, /* 517 */
	GLXDecodeInvalid, /* 518 */
	GLXDecodeInvalid, /* 519 */
	GLXDecodeInvalid, /* 520 */
	GLXDecodeInvalid, /* 521 */
	GLXDecodeInvalid, /* 522 */
	GLXDecodeInvalid, /* 523 */
	GLXDecodeInvalid, /* 524 */
	GLXDecodeInvalid, /* 525 */
	GLXDecodeInvalid, /* 526 */
	GLXDecodeInvalid, /* 527 */
	GLXDecodeInvalid, /* 528 */
	GLXDecodeInvalid, /* 529 */
	GLXDecodeInvalid, /* 530 */
	GLXDecodeInvalid, /* 531 */
	GLXDecodeInvalid, /* 532 */
	GLXDecodeInvalid, /* 533 */
	GLXDecodeInvalid, /* 534 */
	GLXDecodeInvalid, /* 535 */
	GLXDecodeInvalid, /* 536 */
	GLXDecodeInvalid, /* 537 */
	GLXDecodeInvalid, /* 538 */
	GLXDecodeInvalid, /* 539 */
	GLXDecodeInvalid, /* 540 */
	GLXDecodeInvalid, /* 541 */
	GLXDecodeInvalid, /* 542 */
	GLXDecodeInvalid, /* 543 */
	GLXDecodeInvalid, /* 544 */
	GLXDecodeInvalid, /* 545 */
	GLXDecodeInvalid, /* 546 */
	GLXDecodeInvalid, /* 547 */
	GLXDecodeInvalid, /* 548 */
	GLXDecodeInvalid, /* 549 */
	GLXDecodeInvalid, /* 550 */
	GLXDecodeInvalid, /* 551 */
	GLXDecodeInvalid, /* 552 */
	GLXDecodeInvalid, /* 553 */
	GLXDecodeInvalid, /* 554 */
	GLXDecodeInvalid, /* 555 */
	GLXDecodeInvalid, /* 556 */
	GLXDecodeInvalid, /* 557 */
	GLXDecodeInvalid, /* 558 */
	GLXDecodeInvalid, /* 559 */
	GLXDecodeInvalid, /* 560 */
	GLXDecodeInvalid, /* 561 */
	GLXDecodeInvalid, /* 562 */
	GLXDecodeInvalid, /* 563 */
	GLXDecodeInvalid, /* 564 */
	GLXDecodeInvalid, /* 565 */
	GLXDecodeInvalid, /* 566 */
	GLXDecodeInvalid, /* 567 */
	GLXDecodeInvalid, /* 568 */
	GLXDecodeInvalid, /* 569 */
	GLXDecodeInvalid, /* 570 */
	GLXDecodeInvalid, /* 571 */
	GLXDecodeInvalid, /* 572 */
	GLXDecodeInvalid, /* 573 */
	GLXDecodeInvalid, /* 574 */
	GLXDecodeInvalid, /* 575 */
	GLXDecodeInvalid, /* 576 */
	GLXDecodeInvalid, /* 577 */
	GLXDecodeInvalid, /* 578 */
	GLXDecodeInvalid, /* 579 */
	GLXDecodeInvalid, /* 580 */
	GLXDecodeInvalid, /* 581 */
	GLXDecodeInvalid, /* 582 */
	GLXDecodeInvalid, /* 583 */
	GLXDecodeInvalid, /* 584 */
	GLXDecodeInvalid, /* 585 */
	GLXDecodeInvalid, /* 586 */
	GLXDecodeInvalid, /* 587 */
	GLXDecodeInvalid, /* 588 */
	GLXDecodeInvalid, /* 589 */
	GLXDecodeInvalid, /* 590 */
	GLXDecodeInvalid, /* 591 */
	GLXDecodeInvalid, /* 592 */
	GLXDecodeInvalid, /* 593 */
	GLXDecodeInvalid, /* 594 */
	GLXDecodeInvalid, /* 595 */
	GLXDecodeInvalid, /* 596 */
	GLXDecodeInvalid, /* 597 */
	GLXDecodeInvalid, /* 598 */
	GLXDecodeInvalid, /* 599 */
	GLXDecodeInvalid, /* 600 */
	GLXDecodeInvalid, /* 601 */
	GLXDecodeInvalid, /* 602 */
	GLXDecodeInvalid, /* 603 */
	GLXDecodeInvalid, /* 604 */
	GLXDecodeInvalid, /* 605 */
	GLXDecodeInvalid, /* 606 */
	GLXDecodeInvalid, /* 607 */
	GLXDecodeInvalid, /* 608 */
	GLXDecodeInvalid, /* 609 */
	GLXDecodeInvalid, /* 610 */
	GLXDecodeInvalid, /* 611 */
	GLXDecodeInvalid, /* 612 */
	GLXDecodeInvalid, /* 613 */
	GLXDecodeInvalid, /* 614 */
	GLXDecodeInvalid, /* 615 */
	GLXDecodeInvalid, /* 616 */
	GLXDecodeInvalid, /* 617 */
	GLXDecodeInvalid, /* 618 */
	GLXDecodeInvalid, /* 619 */
	GLXDecodeInvalid, /* 620 */
	GLXDecodeInvalid, /* 621 */
	GLXDecodeInvalid, /* 622 */
	GLXDecodeInvalid, /* 623 */
	GLXDecodeInvalid, /* 624 */
	GLXDecodeInvalid, /* 625 */
	GLXDecodeInvalid, /* 626 */
	GLXDecodeInvalid, /* 627 */
	GLXDecodeInvalid, /* 628 */
	GLXDecodeInvalid, /* 629 */
	GLXDecodeInvalid, /* 630 */
	GLXDecodeInvalid, /* 631 */
	GLXDecodeInvalid, /* 632 */
	GLXDecodeInvalid, /* 633 */
	GLXDecodeInvalid, /* 634 */
	GLXDecodeInvalid, /* 635 */
	GLXDecodeInvalid, /* 636 */
	GLXDecodeInvalid, /* 637 */
	GLXDecodeInvalid, /* 638 */
	GLXDecodeInvalid, /* 639 */
	GLXDecodeInvalid, /* 640 */
	GLXDecodeInvalid, /* 641 */
	GLXDecodeInvalid, /* 642 */
	GLXDecodeInvalid, /* 643 */
	GLXDecodeInvalid, /* 644 */
	GLXDecodeInvalid, /* 645 */
	GLXDecodeInvalid, /* 646 */
	GLXDecodeInvalid, /* 647 */
	GLXDecodeInvalid, /* 648 */
	GLXDecodeInvalid, /* 649 */
	GLXDecodeInvalid, /* 650 */
	GLXDecodeInvalid, /* 651 */
	GLXDecodeInvalid, /* 652 */
	GLXDecodeInvalid, /* 653 */
	GLXDecodeInvalid, /* 654 */
	GLXDecodeInvalid, /* 655 */
	GLXDecodeInvalid, /* 656 */
	GLXDecodeInvalid, /* 657 */
	GLXDecodeInvalid, /* 658 */
	GLXDecodeInvalid, /* 659 */
	GLXDecodeInvalid, /* 660 */
	GLXDecodeInvalid, /* 661 */
	GLXDecodeInvalid, /* 662 */
	GLXDecodeInvalid, /* 663 */
	GLXDecodeInvalid, /* 664 */
	GLXDecodeInvalid, /* 665 */
	GLXDecodeInvalid, /* 666 */
	GLXDecodeInvalid, /* 667 */
	GLXDecodeInvalid, /* 668 */
	GLXDecodeInvalid, /* 669 */
	GLXDecodeInvalid, /* 670 */
	GLXDecodeInvalid, /* 671 */
	GLXDecodeInvalid, /* 672 */
	GLXDecodeInvalid, /* 673 */
	GLXDecodeInvalid, /* 674 */
	GLXDecodeInvalid, /* 675 */
	GLXDecodeInvalid, /* 676 */
	GLXDecodeInvalid, /* 677 */
	GLXDecodeInvalid, /* 678 */
	GLXDecodeInvalid, /* 679 */
	GLXDecodeInvalid, /* 680 */
	GLXDecodeInvalid, /* 681 */
	GLXDecodeInvalid, /* 682 */
	GLXDecodeInvalid, /* 683 */
	GLXDecodeInvalid, /* 684 */
	GLXDecodeInvalid, /* 685 */
	GLXDecodeInvalid, /* 686 */
	GLXDecodeInvalid, /* 687 */
	GLXDecodeInvalid, /* 688 */
	GLXDecodeInvalid, /* 689 */
	GLXDecodeInvalid, /* 690 */
	GLXDecodeInvalid, /* 691 */
	GLXDecodeInvalid, /* 692 */
	GLXDecodeInvalid, /* 693 */
	GLXDecodeInvalid, /* 694 */
	GLXDecodeInvalid, /* 695 */
	GLXDecodeInvalid, /* 696 */
	GLXDecodeInvalid, /* 697 */
	GLXDecodeInvalid, /* 698 */
	GLXDecodeInvalid, /* 699 */
	GLXDecodeInvalid, /* 700 */
	GLXDecodeInvalid, /* 701 */
	GLXDecodeInvalid, /* 702 */
	GLXDecodeInvalid, /* 703 */
	GLXDecodeInvalid, /* 704 */
	GLXDecodeInvalid, /* 705 */
	GLXDecodeInvalid, /* 706 */
	GLXDecodeInvalid, /* 707 */
	GLXDecodeInvalid, /* 708 */
	GLXDecodeInvalid, /* 709 */
	GLXDecodeInvalid, /* 710 */
	GLXDecodeInvalid, /* 711 */
	GLXDecodeInvalid, /* 712 */
	GLXDecodeInvalid, /* 713 */
	GLXDecodeInvalid, /* 714 */
	GLXDecodeInvalid, /* 715 */
	GLXDecodeInvalid, /* 716 */
	GLXDecodeInvalid, /* 717 */
	GLXDecodeInvalid, /* 718 */
	GLXDecodeInvalid, /* 719 */
	GLXDecodeInvalid, /* 720 */
	GLXDecodeInvalid, /* 721 */
	GLXDecodeInvalid, /* 722 */
	GLXDecodeInvalid, /* 723 */
	GLXDecodeInvalid, /* 724 */
	GLXDecodeInvalid, /* 725 */
	GLXDecodeInvalid, /* 726 */
	GLXDecodeInvalid, /* 727 */
	GLXDecodeInvalid, /* 728 */
	GLXDecodeInvalid, /* 729 */
	GLXDecodeInvalid, /* 730 */
	GLXDecodeInvalid, /* 731 */
	GLXDecodeInvalid, /* 732 */
	GLXDecodeInvalid, /* 733 */
	GLXDecodeInvalid, /* 734 */
	GLXDecodeInvalid, /* 735 */
	GLXDecodeInvalid, /* 736 */
	GLXDecodeInvalid, /* 737 */
	GLXDecodeInvalid, /* 738 */
	GLXDecodeInvalid, /* 739 */
	GLXDecodeInvalid, /* 740 */
	GLXDecodeInvalid, /* 741 */
	GLXDecodeInvalid, /* 742 */
	GLXDecodeInvalid, /* 743 */
	GLXDecodeInvalid, /* 744 */
	GLXDecodeInvalid, /* 745 */
	GLXDecodeInvalid, /* 746 */
	GLXDecodeInvalid, /* 747 */
	GLXDecodeInvalid, /* 748 */
	GLXDecodeInvalid, /* 749 */
	GLXDecodeInvalid, /* 750 */
	GLXDecodeInvalid, /* 751 */
	GLXDecodeInvalid, /* 752 */
	GLXDecodeInvalid, /* 753 */
	GLXDecodeInvalid, /* 754 */
	GLXDecodeInvalid, /* 755 */
	GLXDecodeInvalid, /* 756 */
	GLXDecodeInvalid, /* 757 */
	GLXDecodeInvalid, /* 758 */
	GLXDecodeInvalid, /* 759 */
	GLXDecodeInvalid, /* 760 */
	GLXDecodeInvalid, /* 761 */
	GLXDecodeInvalid, /* 762 */
	GLXDecodeInvalid, /* 763 */
	GLXDecodeInvalid, /* 764 */
	GLXDecodeInvalid, /* 765 */
	GLXDecodeInvalid, /* 766 */
	GLXDecodeInvalid, /* 767 */
	GLXDecodeInvalid, /* 768 */
	GLXDecodeInvalid, /* 769 */
	GLXDecodeInvalid, /* 770 */
	GLXDecodeInvalid, /* 771 */
	GLXDecodeInvalid, /* 772 */
	GLXDecodeInvalid, /* 773 */
	GLXDecodeInvalid, /* 774 */
	GLXDecodeInvalid, /* 775 */
	GLXDecodeInvalid, /* 776 */
	GLXDecodeInvalid, /* 777 */
	GLXDecodeInvalid, /* 778 */
	GLXDecodeInvalid, /* 779 */
	GLXDecodeInvalid, /* 780 */
	GLXDecodeInvalid, /* 781 */
	GLXDecodeInvalid, /* 782 */
	GLXDecodeInvalid, /* 783 */
	GLXDecodeInvalid, /* 784 */
	GLXDecodeInvalid, /* 785 */
	GLXDecodeInvalid, /* 786 */
	GLXDecodeInvalid, /* 787 */
	GLXDecodeInvalid, /* 788 */
	GLXDecodeInvalid, /* 789 */
	GLXDecodeInvalid, /* 790 */
	GLXDecodeInvalid, /* 791 */
	GLXDecodeInvalid, /* 792 */
	GLXDecodeInvalid, /* 793 */
	GLXDecodeInvalid, /* 794 */
	GLXDecodeInvalid, /* 795 */
	GLXDecodeInvalid, /* 796 */
	GLXDecodeInvalid, /* 797 */
	GLXDecodeInvalid, /* 798 */
	GLXDecodeInvalid, /* 799 */
	GLXDecodeInvalid, /* 800 */
	GLXDecodeInvalid, /* 801 */
	GLXDecodeInvalid, /* 802 */
	GLXDecodeInvalid, /* 803 */
	GLXDecodeInvalid, /* 804 */
	GLXDecodeInvalid, /* 805 */
	GLXDecodeInvalid, /* 806 */
	GLXDecodeInvalid, /* 807 */
	GLXDecodeInvalid, /* 808 */
	GLXDecodeInvalid, /* 809 */
	GLXDecodeInvalid, /* 810 */
	GLXDecodeInvalid, /* 811 */
	GLXDecodeInvalid, /* 812 */
	GLXDecodeInvalid, /* 813 */
	GLXDecodeInvalid, /* 814 */
	GLXDecodeInvalid, /* 815 */
	GLXDecodeInvalid, /* 816 */
	GLXDecodeInvalid, /* 817 */
	GLXDecodeInvalid, /* 818 */
	GLXDecodeInvalid, /* 819 */
	GLXDecodeInvalid, /* 820 */
	GLXDecodeInvalid, /* 821 */
	GLXDecodeInvalid, /* 822 */
	GLXDecodeInvalid, /* 823 */
	GLXDecodeInvalid, /* 824 */
	GLXDecodeInvalid, /* 825 */
	GLXDecodeInvalid, /* 826 */
	GLXDecodeInvalid, /* 827 */
	GLXDecodeInvalid, /* 828 */
	GLXDecodeInvalid, /* 829 */
	GLXDecodeInvalid, /* 830 */
	GLXDecodeInvalid, /* 831 */
	GLXDecodeInvalid, /* 832 */
	GLXDecodeInvalid, /* 833 */
	GLXDecodeInvalid, /* 834 */
	GLXDecodeInvalid, /* 835 */
	GLXDecodeInvalid, /* 836 */
	GLXDecodeInvalid, /* 837 */
	GLXDecodeInvalid, /* 838 */
	GLXDecodeInvalid, /* 839 */
	GLXDecodeInvalid, /* 840 */
	GLXDecodeInvalid, /* 841 */
	GLXDecodeInvalid, /* 842 */
	GLXDecodeInvalid, /* 843 */
	GLXDecodeInvalid, /* 844 */
	GLXDecodeInvalid, /* 845 */
	GLXDecodeInvalid, /* 846 */
	GLXDecodeInvalid, /* 847 */
	GLXDecodeInvalid, /* 848 */
	GLXDecodeInvalid, /* 849 */
	GLXDecodeInvalid, /* 850 */
	GLXDecodeInvalid, /* 851 */
	GLXDecodeInvalid, /* 852 */
	GLXDecodeInvalid, /* 853 */
	GLXDecodeInvalid, /* 854 */
	GLXDecodeInvalid, /* 855 */
	GLXDecodeInvalid, /* 856 */
	GLXDecodeInvalid, /* 857 */
	GLXDecodeInvalid, /* 858 */
	GLXDecodeInvalid, /* 859 */
	GLXDecodeInvalid, /* 860 */
	GLXDecodeInvalid, /* 861 */
	GLXDecodeInvalid, /* 862 */
	GLXDecodeInvalid, /* 863 */
	GLXDecodeInvalid, /* 864 */
	GLXDecodeInvalid, /* 865 */
	GLXDecodeInvalid, /* 866 */
	GLXDecodeInvalid, /* 867 */
	GLXDecodeInvalid, /* 868 */
	GLXDecodeInvalid, /* 869 */
	GLXDecodeInvalid, /* 870 */
	GLXDecodeInvalid, /* 871 */
	GLXDecodeInvalid, /* 872 */
	GLXDecodeInvalid, /* 873 */
	GLXDecodeInvalid, /* 874 */
	GLXDecodeInvalid, /* 875 */
	GLXDecodeInvalid, /* 876 */
	GLXDecodeInvalid, /* 877 */
	GLXDecodeInvalid, /* 878 */
	GLXDecodeInvalid, /* 879 */
	GLXDecodeInvalid, /* 880 */
	GLXDecodeInvalid, /* 881 */
	GLXDecodeInvalid, /* 882 */
	GLXDecodeInvalid, /* 883 */
	GLXDecodeInvalid, /* 884 */
	GLXDecodeInvalid, /* 885 */
	GLXDecodeInvalid, /* 886 */
	GLXDecodeInvalid, /* 887 */
	GLXDecodeInvalid, /* 888 */
	GLXDecodeInvalid, /* 889 */
	GLXDecodeInvalid, /* 890 */
	GLXDecodeInvalid, /* 891 */
	GLXDecodeInvalid, /* 892 */
	GLXDecodeInvalid, /* 893 */
	GLXDecodeInvalid, /* 894 */
	GLXDecodeInvalid, /* 895 */
	GLXDecodeInvalid, /* 896 */
	GLXDecodeInvalid, /* 897 */
	GLXDecodeInvalid, /* 898 */
	GLXDecodeInvalid, /* 899 */
	GLXDecodeInvalid, /* 900 */
	GLXDecodeInvalid, /* 901 */
	GLXDecodeInvalid, /* 902 */
	GLXDecodeInvalid, /* 903 */
	GLXDecodeInvalid, /* 904 */
	GLXDecodeInvalid, /* 905 */
	GLXDecodeInvalid, /* 906 */
	GLXDecodeInvalid, /* 907 */
	GLXDecodeInvalid, /* 908 */
	GLXDecodeInvalid, /* 909 */
	GLXDecodeInvalid, /* 910 */
	GLXDecodeInvalid, /* 911 */
	GLXDecodeInvalid, /* 912 */
	GLXDecodeInvalid, /* 913 */
	GLXDecodeInvalid, /* 914 */
	GLXDecodeInvalid, /* 915 */
	GLXDecodeInvalid, /* 916 */
	GLXDecodeInvalid, /* 917 */
	GLXDecodeInvalid, /* 918 */
	GLXDecodeInvalid, /* 919 */
	GLXDecodeInvalid, /* 920 */
	GLXDecodeInvalid, /* 921 */
	GLXDecodeInvalid, /* 922 */
	GLXDecodeInvalid, /* 923 */
	GLXDecodeInvalid, /* 924 */
	GLXDecodeInvalid, /* 925 */
	GLXDecodeInvalid, /* 926 */
	GLXDecodeInvalid, /* 927 */
	GLXDecodeInvalid, /* 928 */
	GLXDecodeInvalid, /* 929 */
	GLXDecodeInvalid, /* 930 */
	GLXDecodeInvalid, /* 931 */
	GLXDecodeInvalid, /* 932 */
	GLXDecodeInvalid, /* 933 */
	GLXDecodeInvalid, /* 934 */
	GLXDecodeInvalid, /* 935 */
	GLXDecodeInvalid, /* 936 */
	GLXDecodeInvalid, /* 937 */
	GLXDecodeInvalid, /* 938 */
	GLXDecodeInvalid, /* 939 */
	GLXDecodeInvalid, /* 940 */
	GLXDecodeInvalid, /* 941 */
	GLXDecodeInvalid, /* 942 */
	GLXDecodeInvalid, /* 943 */
	GLXDecodeInvalid, /* 944 */
	GLXDecodeInvalid, /* 945 */
	GLXDecodeInvalid, /* 946 */
	GLXDecodeInvalid, /* 947 */
	GLXDecodeInvalid, /* 948 */
	GLXDecodeInvalid, /* 949 */
	GLXDecodeInvalid, /* 950 */
	GLXDecodeInvalid, /* 951 */
	GLXDecodeInvalid, /* 952 */
	GLXDecodeInvalid, /* 953 */
	GLXDecodeInvalid, /* 954 */
	GLXDecodeInvalid, /* 955 */
	GLXDecodeInvalid, /* 956 */
	GLXDecodeInvalid, /* 957 */
	GLXDecodeInvalid, /* 958 */
	GLXDecodeInvalid, /* 959 */
	GLXDecodeInvalid, /* 960 */
	GLXDecodeInvalid, /* 961 */
	GLXDecodeInvalid, /* 962 */
	GLXDecodeInvalid, /* 963 */
	GLXDecodeInvalid, /* 964 */
	GLXDecodeInvalid, /* 965 */
	GLXDecodeInvalid, /* 966 */
	GLXDecodeInvalid, /* 967 */
	GLXDecodeInvalid, /* 968 */
	GLXDecodeInvalid, /* 969 */
	GLXDecodeInvalid, /* 970 */
	GLXDecodeInvalid, /* 971 */
	GLXDecodeInvalid, /* 972 */
	GLXDecodeInvalid, /* 973 */
	GLXDecodeInvalid, /* 974 */
	GLXDecodeInvalid, /* 975 */
	GLXDecodeInvalid, /* 976 */
	GLXDecodeInvalid, /* 977 */
	GLXDecodeInvalid, /* 978 */
	GLXDecodeInvalid, /* 979 */
	GLXDecodeInvalid, /* 980 */
	GLXDecodeInvalid, /* 981 */
	GLXDecodeInvalid, /* 982 */
	GLXDecodeInvalid, /* 983 */
	GLXDecodeInvalid, /* 984 */
	GLXDecodeInvalid, /* 985 */
	GLXDecodeInvalid, /* 986 */
	GLXDecodeInvalid, /* 987 */
	GLXDecodeInvalid, /* 988 */
	GLXDecodeInvalid, /* 989 */
	GLXDecodeInvalid, /* 990 */
	GLXDecodeInvalid, /* 991 */
	GLXDecodeInvalid, /* 992 */
	GLXDecodeInvalid, /* 993 */
	GLXDecodeInvalid, /* 994 */
	GLXDecodeInvalid, /* 995 */
	GLXDecodeInvalid, /* 996 */
	GLXDecodeInvalid, /* 997 */
	GLXDecodeInvalid, /* 998 */
	GLXDecodeInvalid, /* 999 */
	GLXDecodeInvalid, /* 1000 */
	GLXDecodeInvalid, /* 1001 */
	GLXDecodeInvalid, /* 1002 */
	GLXDecodeInvalid, /* 1003 */
	GLXDecodeInvalid, /* 1004 */
	GLXDecodeInvalid, /* 1005 */
	GLXDecodeInvalid, /* 1006 */
	GLXDecodeInvalid, /* 1007 */
	GLXDecodeInvalid, /* 1008 */
	GLXDecodeInvalid, /* 1009 */
	GLXDecodeInvalid, /* 1010 */
	GLXDecodeInvalid, /* 1011 */
	GLXDecodeInvalid, /* 1012 */
	GLXDecodeInvalid, /* 1013 */
	GLXDecodeInvalid, /* 1014 */
	GLXDecodeInvalid, /* 1015 */
	GLXDecodeInvalid, /* 1016 */
	GLXDecodeInvalid, /* 1017 */
	GLXDecodeInvalid, /* 1018 */
	GLXDecodeInvalid, /* 1019 */
	GLXDecodeInvalid, /* 1020 */
	GLXDecodeInvalid, /* 1021 */
	GLXDecodeInvalid, /* 1022 */
	GLXDecodeInvalid, /* 1023 */
	GLXDecodeInvalid, /* 1024 */
	GLXDecodeInvalid, /* 1025 */
	GLXDecodeInvalid, /* 1026 */
	GLXDecodeInvalid, /* 1027 */
	GLXDecodeInvalid, /* 1028 */
	GLXDecodeInvalid, /* 1029 */
	GLXDecodeInvalid, /* 1030 */
	GLXDecodeInvalid, /* 1031 */
	GLXDecodeInvalid, /* 1032 */
	GLXDecodeInvalid, /* 1033 */
	GLXDecodeInvalid, /* 1034 */
	GLXDecodeInvalid, /* 1035 */
	GLXDecodeInvalid, /* 1036 */
	GLXDecodeInvalid, /* 1037 */
	GLXDecodeInvalid, /* 1038 */
	GLXDecodeInvalid, /* 1039 */
	GLXDecodeInvalid, /* 1040 */
	GLXDecodeInvalid, /* 1041 */
	GLXDecodeInvalid, /* 1042 */
	GLXDecodeInvalid, /* 1043 */
	GLXDecodeInvalid, /* 1044 */
	GLXDecodeInvalid, /* 1045 */
	GLXDecodeInvalid, /* 1046 */
	GLXDecodeInvalid, /* 1047 */
	GLXDecodeInvalid, /* 1048 */
	GLXDecodeInvalid, /* 1049 */
	GLXDecodeInvalid, /* 1050 */
	GLXDecodeInvalid, /* 1051 */
	GLXDecodeInvalid, /* 1052 */
	GLXDecodeInvalid, /* 1053 */
	GLXDecodeInvalid, /* 1054 */
	GLXDecodeInvalid, /* 1055 */
	GLXDecodeInvalid, /* 1056 */
	GLXDecodeInvalid, /* 1057 */
	GLXDecodeInvalid, /* 1058 */
	GLXDecodeInvalid, /* 1059 */
	GLXDecodeInvalid, /* 1060 */
	GLXDecodeInvalid, /* 1061 */
	GLXDecodeInvalid, /* 1062 */
	GLXDecodeInvalid, /* 1063 */
	GLXDecodeInvalid, /* 1064 */
	GLXDecodeInvalid, /* 1065 */
	GLXDecodeInvalid, /* 1066 */
	GLXDecodeInvalid, /* 1067 */
	GLXDecodeInvalid, /* 1068 */
	GLXDecodeInvalid, /* 1069 */
	GLXDecodeInvalid, /* 1070 */
	GLXDecodeInvalid, /* 1071 */
	GLXDecodeInvalid, /* 1072 */
	GLXDecodeInvalid, /* 1073 */
	GLXDecodeInvalid, /* 1074 */
	GLXDecodeInvalid, /* 1075 */
	GLXDecodeInvalid, /* 1076 */
	GLXDecodeInvalid, /* 1077 */
	GLXDecodeInvalid, /* 1078 */
	GLXDecodeInvalid, /* 1079 */
	GLXDecodeInvalid, /* 1080 */
	GLXDecodeInvalid, /* 1081 */
	GLXDecodeInvalid, /* 1082 */
	GLXDecodeInvalid, /* 1083 */
	GLXDecodeInvalid, /* 1084 */
	GLXDecodeInvalid, /* 1085 */
	GLXDecodeInvalid, /* 1086 */
	GLXDecodeInvalid, /* 1087 */
	GLXDecodeInvalid, /* 1088 */
	GLXDecodeInvalid, /* 1089 */
	GLXDecodeInvalid, /* 1090 */
	GLXDecodeInvalid, /* 1091 */
	GLXDecodeInvalid, /* 1092 */
	GLXDecodeInvalid, /* 1093 */
	GLXDecodeInvalid, /* 1094 */
	GLXDecodeInvalid, /* 1095 */
	GLXDecodeInvalid, /* 1096 */
	GLXDecodeInvalid, /* 1097 */
	GLXDecodeInvalid, /* 1098 */
	GLXDecodeInvalid, /* 1099 */
	GLXDecodeInvalid, /* 1100 */
	GLXDecodeInvalid, /* 1101 */
	GLXDecodeInvalid, /* 1102 */
	GLXDecodeInvalid, /* 1103 */
	GLXDecodeInvalid, /* 1104 */
	GLXDecodeInvalid, /* 1105 */
	GLXDecodeInvalid, /* 1106 */
	GLXDecodeInvalid, /* 1107 */
	GLXDecodeInvalid, /* 1108 */
	GLXDecodeInvalid, /* 1109 */
	GLXDecodeInvalid, /* 1110 */
	GLXDecodeInvalid, /* 1111 */
	GLXDecodeInvalid, /* 1112 */
	GLXDecodeInvalid, /* 1113 */
	GLXDecodeInvalid, /* 1114 */
	GLXDecodeInvalid, /* 1115 */
	GLXDecodeInvalid, /* 1116 */
	GLXDecodeInvalid, /* 1117 */
	GLXDecodeInvalid, /* 1118 */
	GLXDecodeInvalid, /* 1119 */
	GLXDecodeInvalid, /* 1120 */
	GLXDecodeInvalid, /* 1121 */
	GLXDecodeInvalid, /* 1122 */
	GLXDecodeInvalid, /* 1123 */
	GLXDecodeInvalid, /* 1124 */
	GLXDecodeInvalid, /* 1125 */
	GLXDecodeInvalid, /* 1126 */
	GLXDecodeInvalid, /* 1127 */
	GLXDecodeInvalid, /* 1128 */
	GLXDecodeInvalid, /* 1129 */
	GLXDecodeInvalid, /* 1130 */
	GLXDecodeInvalid, /* 1131 */
	GLXDecodeInvalid, /* 1132 */
	GLXDecodeInvalid, /* 1133 */
	GLXDecodeInvalid, /* 1134 */
	GLXDecodeInvalid, /* 1135 */
	GLXDecodeInvalid, /* 1136 */
	GLXDecodeInvalid, /* 1137 */
	GLXDecodeInvalid, /* 1138 */
	GLXDecodeInvalid, /* 1139 */
	GLXDecodeInvalid, /* 1140 */
	GLXDecodeInvalid, /* 1141 */
	GLXDecodeInvalid, /* 1142 */
	GLXDecodeInvalid, /* 1143 */
	GLXDecodeInvalid, /* 1144 */
	GLXDecodeInvalid, /* 1145 */
	GLXDecodeInvalid, /* 1146 */
	GLXDecodeInvalid, /* 1147 */
	GLXDecodeInvalid, /* 1148 */
	GLXDecodeInvalid, /* 1149 */
	GLXDecodeInvalid, /* 1150 */
	GLXDecodeInvalid, /* 1151 */
	GLXDecodeInvalid, /* 1152 */
	GLXDecodeInvalid, /* 1153 */
	GLXDecodeInvalid, /* 1154 */
	GLXDecodeInvalid, /* 1155 */
	GLXDecodeInvalid, /* 1156 */
	GLXDecodeInvalid, /* 1157 */
	GLXDecodeInvalid, /* 1158 */
	GLXDecodeInvalid, /* 1159 */
	GLXDecodeInvalid, /* 1160 */
	GLXDecodeInvalid, /* 1161 */
	GLXDecodeInvalid, /* 1162 */
	GLXDecodeInvalid, /* 1163 */
	GLXDecodeInvalid, /* 1164 */
	GLXDecodeInvalid, /* 1165 */
	GLXDecodeInvalid, /* 1166 */
	GLXDecodeInvalid, /* 1167 */
	GLXDecodeInvalid, /* 1168 */
	GLXDecodeInvalid, /* 1169 */
	GLXDecodeInvalid, /* 1170 */
	GLXDecodeInvalid, /* 1171 */
	GLXDecodeInvalid, /* 1172 */
	GLXDecodeInvalid, /* 1173 */
	GLXDecodeInvalid, /* 1174 */
	GLXDecodeInvalid, /* 1175 */
	GLXDecodeInvalid, /* 1176 */
	GLXDecodeInvalid, /* 1177 */
	GLXDecodeInvalid, /* 1178 */
	GLXDecodeInvalid, /* 1179 */
	GLXDecodeInvalid, /* 1180 */
	GLXDecodeInvalid, /* 1181 */
	GLXDecodeInvalid, /* 1182 */
	GLXDecodeInvalid, /* 1183 */
	GLXDecodeInvalid, /* 1184 */
	GLXDecodeInvalid, /* 1185 */
	GLXDecodeInvalid, /* 1186 */
	GLXDecodeInvalid, /* 1187 */
	GLXDecodeInvalid, /* 1188 */
	GLXDecodeInvalid, /* 1189 */
	GLXDecodeInvalid, /* 1190 */
	GLXDecodeInvalid, /* 1191 */
	GLXDecodeInvalid, /* 1192 */
	GLXDecodeInvalid, /* 1193 */
	GLXDecodeInvalid, /* 1194 */
	GLXDecodeInvalid, /* 1195 */
	GLXDecodeInvalid, /* 1196 */
	GLXDecodeInvalid, /* 1197 */
	GLXDecodeInvalid, /* 1198 */
	GLXDecodeInvalid, /* 1199 */
	GLXDecodeInvalid, /* 1200 */
	GLXDecodeInvalid, /* 1201 */
	GLXDecodeInvalid, /* 1202 */
	GLXDecodeInvalid, /* 1203 */
	GLXDecodeInvalid, /* 1204 */
	GLXDecodeInvalid, /* 1205 */
	GLXDecodeInvalid, /* 1206 */
	GLXDecodeInvalid, /* 1207 */
	GLXDecodeInvalid, /* 1208 */
	GLXDecodeInvalid, /* 1209 */
	GLXDecodeInvalid, /* 1210 */
	GLXDecodeInvalid, /* 1211 */
	GLXDecodeInvalid, /* 1212 */
	GLXDecodeInvalid, /* 1213 */
	GLXDecodeInvalid, /* 1214 */
	GLXDecodeInvalid, /* 1215 */
	GLXDecodeInvalid, /* 1216 */
	GLXDecodeInvalid, /* 1217 */
	GLXDecodeInvalid, /* 1218 */
	GLXDecodeInvalid, /* 1219 */
	GLXDecodeInvalid, /* 1220 */
	GLXDecodeInvalid, /* 1221 */
	GLXDecodeInvalid, /* 1222 */
	GLXDecodeInvalid, /* 1223 */
	GLXDecodeInvalid, /* 1224 */
	GLXDecodeInvalid, /* 1225 */
	GLXDecodeInvalid, /* 1226 */
	GLXDecodeInvalid, /* 1227 */
	GLXDecodeInvalid, /* 1228 */
	GLXDecodeInvalid, /* 1229 */
	GLXDecodeInvalid, /* 1230 */
	GLXDecodeInvalid, /* 1231 */
	GLXDecodeInvalid, /* 1232 */
	GLXDecodeInvalid, /* 1233 */
	GLXDecodeInvalid, /* 1234 */
	GLXDecodeInvalid, /* 1235 */
	GLXDecodeInvalid, /* 1236 */
	GLXDecodeInvalid, /* 1237 */
	GLXDecodeInvalid, /* 1238 */
	GLXDecodeInvalid, /* 1239 */
	GLXDecodeInvalid, /* 1240 */
	GLXDecodeInvalid, /* 1241 */
	GLXDecodeInvalid, /* 1242 */
	GLXDecodeInvalid, /* 1243 */
	GLXDecodeInvalid, /* 1244 */
	GLXDecodeInvalid, /* 1245 */
	GLXDecodeInvalid, /* 1246 */
	GLXDecodeInvalid, /* 1247 */
	GLXDecodeInvalid, /* 1248 */
	GLXDecodeInvalid, /* 1249 */
	GLXDecodeInvalid, /* 1250 */
	GLXDecodeInvalid, /* 1251 */
	GLXDecodeInvalid, /* 1252 */
	GLXDecodeInvalid, /* 1253 */
	GLXDecodeInvalid, /* 1254 */
	GLXDecodeInvalid, /* 1255 */
	GLXDecodeInvalid, /* 1256 */
	GLXDecodeInvalid, /* 1257 */
	GLXDecodeInvalid, /* 1258 */
	GLXDecodeInvalid, /* 1259 */
	GLXDecodeInvalid, /* 1260 */
	GLXDecodeInvalid, /* 1261 */
	GLXDecodeInvalid, /* 1262 */
	GLXDecodeInvalid, /* 1263 */
	GLXDecodeInvalid, /* 1264 */
	GLXDecodeInvalid, /* 1265 */
	GLXDecodeInvalid, /* 1266 */
	GLXDecodeInvalid, /* 1267 */
	GLXDecodeInvalid, /* 1268 */
	GLXDecodeInvalid, /* 1269 */
	GLXDecodeInvalid, /* 1270 */
	GLXDecodeInvalid, /* 1271 */
	GLXDecodeInvalid, /* 1272 */
	GLXDecodeInvalid, /* 1273 */
	GLXDecodeInvalid, /* 1274 */
	GLXDecodeInvalid, /* 1275 */
	GLXDecodeInvalid, /* 1276 */
	GLXDecodeInvalid, /* 1277 */
	GLXDecodeInvalid, /* 1278 */
	GLXDecodeInvalid, /* 1279 */
	GLXDecodeInvalid, /* 1280 */
	GLXDecodeInvalid, /* 1281 */
	GLXDecodeInvalid, /* 1282 */
	GLXDecodeInvalid, /* 1283 */
	GLXDecodeInvalid, /* 1284 */
	GLXDecodeInvalid, /* 1285 */
	GLXDecodeInvalid, /* 1286 */
	GLXDecodeInvalid, /* 1287 */
	GLXDecodeInvalid, /* 1288 */
	GLXDecodeInvalid, /* 1289 */
	GLXDecodeInvalid, /* 1290 */
	GLXDecodeInvalid, /* 1291 */
	GLXDecodeInvalid, /* 1292 */
	GLXDecodeInvalid, /* 1293 */
	GLXDecodeInvalid, /* 1294 */
	GLXDecodeInvalid, /* 1295 */
	GLXDecodeInvalid, /* 1296 */
	GLXDecodeInvalid, /* 1297 */
	GLXDecodeInvalid, /* 1298 */
	GLXDecodeInvalid, /* 1299 */
	GLXDecodeInvalid, /* 1300 */
	GLXDecodeInvalid, /* 1301 */
	GLXDecodeInvalid, /* 1302 */
	GLXDecodeInvalid, /* 1303 */
	GLXDecodeInvalid, /* 1304 */
	GLXDecodeInvalid, /* 1305 */
	GLXDecodeInvalid, /* 1306 */
	GLXDecodeInvalid, /* 1307 */
	GLXDecodeInvalid, /* 1308 */
	GLXDecodeInvalid, /* 1309 */
	GLXDecodeInvalid, /* 1310 */
	GLXDecodeInvalid, /* 1311 */
	GLXDecodeInvalid, /* 1312 */
	GLXDecodeInvalid, /* 1313 */
	GLXDecodeInvalid, /* 1314 */
	GLXDecodeInvalid, /* 1315 */
	GLXDecodeInvalid, /* 1316 */
	GLXDecodeInvalid, /* 1317 */
	GLXDecodeInvalid, /* 1318 */
	GLXDecodeInvalid, /* 1319 */
	GLXDecodeInvalid, /* 1320 */
	GLXDecodeInvalid, /* 1321 */
	GLXDecodeInvalid, /* 1322 */
	GLXDecodeInvalid, /* 1323 */
	GLXDecodeInvalid, /* 1324 */
	GLXDecodeInvalid, /* 1325 */
	GLXDecodeInvalid, /* 1326 */
	GLXDecodeInvalid, /* 1327 */
	GLXDecodeInvalid, /* 1328 */
	GLXDecodeInvalid, /* 1329 */
	GLXDecodeInvalid, /* 1330 */
	GLXDecodeInvalid, /* 1331 */
	GLXDecodeInvalid, /* 1332 */
	GLXDecodeInvalid, /* 1333 */
	GLXDecodeInvalid, /* 1334 */
	GLXDecodeInvalid, /* 1335 */
	GLXDecodeInvalid, /* 1336 */
	GLXDecodeInvalid, /* 1337 */
	GLXDecodeInvalid, /* 1338 */
	GLXDecodeInvalid, /* 1339 */
	GLXDecodeInvalid, /* 1340 */
	GLXDecodeInvalid, /* 1341 */
	GLXDecodeInvalid, /* 1342 */
	GLXDecodeInvalid, /* 1343 */
	GLXDecodeInvalid, /* 1344 */
	GLXDecodeInvalid, /* 1345 */
	GLXDecodeInvalid, /* 1346 */
	GLXDecodeInvalid, /* 1347 */
	GLXDecodeInvalid, /* 1348 */
	GLXDecodeInvalid, /* 1349 */
	GLXDecodeInvalid, /* 1350 */
	GLXDecodeInvalid, /* 1351 */
	GLXDecodeInvalid, /* 1352 */
	GLXDecodeInvalid, /* 1353 */
	GLXDecodeInvalid, /* 1354 */
	GLXDecodeInvalid, /* 1355 */
	GLXDecodeInvalid, /* 1356 */
	GLXDecodeInvalid, /* 1357 */
	GLXDecodeInvalid, /* 1358 */
	GLXDecodeInvalid, /* 1359 */
	GLXDecodeInvalid, /* 1360 */
	GLXDecodeInvalid, /* 1361 */
	GLXDecodeInvalid, /* 1362 */
	GLXDecodeInvalid, /* 1363 */
	GLXDecodeInvalid, /* 1364 */
	GLXDecodeInvalid, /* 1365 */
	GLXDecodeInvalid, /* 1366 */
	GLXDecodeInvalid, /* 1367 */
	GLXDecodeInvalid, /* 1368 */
	GLXDecodeInvalid, /* 1369 */
	GLXDecodeInvalid, /* 1370 */
	GLXDecodeInvalid, /* 1371 */
	GLXDecodeInvalid, /* 1372 */
	GLXDecodeInvalid, /* 1373 */
	GLXDecodeInvalid, /* 1374 */
	GLXDecodeInvalid, /* 1375 */
	GLXDecodeInvalid, /* 1376 */
	GLXDecodeInvalid, /* 1377 */
	GLXDecodeInvalid, /* 1378 */
	GLXDecodeInvalid, /* 1379 */
	GLXDecodeInvalid, /* 1380 */
	GLXDecodeInvalid, /* 1381 */
	GLXDecodeInvalid, /* 1382 */
	GLXDecodeInvalid, /* 1383 */
	GLXDecodeInvalid, /* 1384 */
	GLXDecodeInvalid, /* 1385 */
	GLXDecodeInvalid, /* 1386 */
	GLXDecodeInvalid, /* 1387 */
	GLXDecodeInvalid, /* 1388 */
	GLXDecodeInvalid, /* 1389 */
	GLXDecodeInvalid, /* 1390 */
	GLXDecodeInvalid, /* 1391 */
	GLXDecodeInvalid, /* 1392 */
	GLXDecodeInvalid, /* 1393 */
	GLXDecodeInvalid, /* 1394 */
	GLXDecodeInvalid, /* 1395 */
	GLXDecodeInvalid, /* 1396 */
	GLXDecodeInvalid, /* 1397 */
	GLXDecodeInvalid, /* 1398 */
	GLXDecodeInvalid, /* 1399 */
	GLXDecodeInvalid, /* 1400 */
	GLXDecodeInvalid, /* 1401 */
	GLXDecodeInvalid, /* 1402 */
	GLXDecodeInvalid, /* 1403 */
	GLXDecodeInvalid, /* 1404 */
	GLXDecodeInvalid, /* 1405 */
	GLXDecodeInvalid, /* 1406 */
	GLXDecodeInvalid, /* 1407 */
	GLXDecodeInvalid, /* 1408 */
	GLXDecodeInvalid, /* 1409 */
	GLXDecodeInvalid, /* 1410 */
	GLXDecodeInvalid, /* 1411 */
	GLXDecodeInvalid, /* 1412 */
	GLXDecodeInvalid, /* 1413 */
	GLXDecodeInvalid, /* 1414 */
	GLXDecodeInvalid, /* 1415 */
	GLXDecodeInvalid, /* 1416 */
	GLXDecodeInvalid, /* 1417 */
	GLXDecodeInvalid, /* 1418 */
	GLXDecodeInvalid, /* 1419 */
	GLXDecodeInvalid, /* 1420 */
	GLXDecodeInvalid, /* 1421 */
	GLXDecodeInvalid, /* 1422 */
	GLXDecodeInvalid, /* 1423 */
	GLXDecodeInvalid, /* 1424 */
	GLXDecodeInvalid, /* 1425 */
	GLXDecodeInvalid, /* 1426 */
	GLXDecodeInvalid, /* 1427 */
	GLXDecodeInvalid, /* 1428 */
	GLXDecodeInvalid, /* 1429 */
	GLXDecodeInvalid, /* 1430 */
	GLXDecodeInvalid, /* 1431 */
	GLXDecodeInvalid, /* 1432 */
	GLXDecodeInvalid, /* 1433 */
	GLXDecodeInvalid, /* 1434 */
	GLXDecodeInvalid, /* 1435 */
	GLXDecodeInvalid, /* 1436 */
	GLXDecodeInvalid, /* 1437 */
	GLXDecodeInvalid, /* 1438 */
	GLXDecodeInvalid, /* 1439 */
	GLXDecodeInvalid, /* 1440 */
	GLXDecodeInvalid, /* 1441 */
	GLXDecodeInvalid, /* 1442 */
	GLXDecodeInvalid, /* 1443 */
	GLXDecodeInvalid, /* 1444 */
	GLXDecodeInvalid, /* 1445 */
	GLXDecodeInvalid, /* 1446 */
	GLXDecodeInvalid, /* 1447 */
	GLXDecodeInvalid, /* 1448 */
	GLXDecodeInvalid, /* 1449 */
	GLXDecodeInvalid, /* 1450 */
	GLXDecodeInvalid, /* 1451 */
	GLXDecodeInvalid, /* 1452 */
	GLXDecodeInvalid, /* 1453 */
	GLXDecodeInvalid, /* 1454 */
	GLXDecodeInvalid, /* 1455 */
	GLXDecodeInvalid, /* 1456 */
	GLXDecodeInvalid, /* 1457 */
	GLXDecodeInvalid, /* 1458 */
	GLXDecodeInvalid, /* 1459 */
	GLXDecodeInvalid, /* 1460 */
	GLXDecodeInvalid, /* 1461 */
	GLXDecodeInvalid, /* 1462 */
	GLXDecodeInvalid, /* 1463 */
	GLXDecodeInvalid, /* 1464 */
	GLXDecodeInvalid, /* 1465 */
	GLXDecodeInvalid, /* 1466 */
	GLXDecodeInvalid, /* 1467 */
	GLXDecodeInvalid, /* 1468 */
	GLXDecodeInvalid, /* 1469 */
	GLXDecodeInvalid, /* 1470 */
	GLXDecodeInvalid, /* 1471 */
	GLXDecodeInvalid, /* 1472 */
	GLXDecodeInvalid, /* 1473 */
	GLXDecodeInvalid, /* 1474 */
	GLXDecodeInvalid, /* 1475 */
	GLXDecodeInvalid, /* 1476 */
	GLXDecodeInvalid, /* 1477 */
	GLXDecodeInvalid, /* 1478 */
	GLXDecodeInvalid, /* 1479 */
	GLXDecodeInvalid, /* 1480 */
	GLXDecodeInvalid, /* 1481 */
	GLXDecodeInvalid, /* 1482 */
	GLXDecodeInvalid, /* 1483 */
	GLXDecodeInvalid, /* 1484 */
	GLXDecodeInvalid, /* 1485 */
	GLXDecodeInvalid, /* 1486 */
	GLXDecodeInvalid, /* 1487 */
	GLXDecodeInvalid, /* 1488 */
	GLXDecodeInvalid, /* 1489 */
	GLXDecodeInvalid, /* 1490 */
	GLXDecodeInvalid, /* 1491 */
	GLXDecodeInvalid, /* 1492 */
	GLXDecodeInvalid, /* 1493 */
	GLXDecodeInvalid, /* 1494 */
	GLXDecodeInvalid, /* 1495 */
	GLXDecodeInvalid, /* 1496 */
	GLXDecodeInvalid, /* 1497 */
	GLXDecodeInvalid, /* 1498 */
	GLXDecodeInvalid, /* 1499 */
	GLXDecodeInvalid, /* 1500 */
	GLXDecodeInvalid, /* 1501 */
	GLXDecodeInvalid, /* 1502 */
	GLXDecodeInvalid, /* 1503 */
	GLXDecodeInvalid, /* 1504 */
	GLXDecodeInvalid, /* 1505 */
	GLXDecodeInvalid, /* 1506 */
	GLXDecodeInvalid, /* 1507 */
	GLXDecodeInvalid, /* 1508 */
	GLXDecodeInvalid, /* 1509 */
	GLXDecodeInvalid, /* 1510 */
	GLXDecodeInvalid, /* 1511 */
	GLXDecodeInvalid, /* 1512 */
	GLXDecodeInvalid, /* 1513 */
	GLXDecodeInvalid, /* 1514 */
	GLXDecodeInvalid, /* 1515 */
	GLXDecodeInvalid, /* 1516 */
	GLXDecodeInvalid, /* 1517 */
	GLXDecodeInvalid, /* 1518 */
	GLXDecodeInvalid, /* 1519 */
	GLXDecodeInvalid, /* 1520 */
	GLXDecodeInvalid, /* 1521 */
	GLXDecodeInvalid, /* 1522 */
	GLXDecodeInvalid, /* 1523 */
	GLXDecodeInvalid, /* 1524 */
	GLXDecodeInvalid, /* 1525 */
	GLXDecodeInvalid, /* 1526 */
	GLXDecodeInvalid, /* 1527 */
	GLXDecodeInvalid, /* 1528 */
	GLXDecodeInvalid, /* 1529 */
	GLXDecodeInvalid, /* 1530 */
	GLXDecodeInvalid, /* 1531 */
	GLXDecodeInvalid, /* 1532 */
	GLXDecodeInvalid, /* 1533 */
	GLXDecodeInvalid, /* 1534 */
	GLXDecodeInvalid, /* 1535 */
	GLXDecodeInvalid, /* 1536 */
	GLXDecodeInvalid, /* 1537 */
	GLXDecodeInvalid, /* 1538 */
	GLXDecodeInvalid, /* 1539 */
	GLXDecodeInvalid, /* 1540 */
	GLXDecodeInvalid, /* 1541 */
	GLXDecodeInvalid, /* 1542 */
	GLXDecodeInvalid, /* 1543 */
	GLXDecodeInvalid, /* 1544 */
	GLXDecodeInvalid, /* 1545 */
	GLXDecodeInvalid, /* 1546 */
	GLXDecodeInvalid, /* 1547 */
	GLXDecodeInvalid, /* 1548 */
	GLXDecodeInvalid, /* 1549 */
	GLXDecodeInvalid, /* 1550 */
	GLXDecodeInvalid, /* 1551 */
	GLXDecodeInvalid, /* 1552 */
	GLXDecodeInvalid, /* 1553 */
	GLXDecodeInvalid, /* 1554 */
	GLXDecodeInvalid, /* 1555 */
	GLXDecodeInvalid, /* 1556 */
	GLXDecodeInvalid, /* 1557 */
	GLXDecodeInvalid, /* 1558 */
	GLXDecodeInvalid, /* 1559 */
	GLXDecodeInvalid, /* 1560 */
	GLXDecodeInvalid, /* 1561 */
	GLXDecodeInvalid, /* 1562 */
	GLXDecodeInvalid, /* 1563 */
	GLXDecodeInvalid, /* 1564 */
	GLXDecodeInvalid, /* 1565 */
	GLXDecodeInvalid, /* 1566 */
	GLXDecodeInvalid, /* 1567 */
	GLXDecodeInvalid, /* 1568 */
	GLXDecodeInvalid, /* 1569 */
	GLXDecodeInvalid, /* 1570 */
	GLXDecodeInvalid, /* 1571 */
	GLXDecodeInvalid, /* 1572 */
	GLXDecodeInvalid, /* 1573 */
	GLXDecodeInvalid, /* 1574 */
	GLXDecodeInvalid, /* 1575 */
	GLXDecodeInvalid, /* 1576 */
	GLXDecodeInvalid, /* 1577 */
	GLXDecodeInvalid, /* 1578 */
	GLXDecodeInvalid, /* 1579 */
	GLXDecodeInvalid, /* 1580 */
	GLXDecodeInvalid, /* 1581 */
	GLXDecodeInvalid, /* 1582 */
	GLXDecodeInvalid, /* 1583 */
	GLXDecodeInvalid, /* 1584 */
	GLXDecodeInvalid, /* 1585 */
	GLXDecodeInvalid, /* 1586 */
	GLXDecodeInvalid, /* 1587 */
	GLXDecodeInvalid, /* 1588 */
	GLXDecodeInvalid, /* 1589 */
	GLXDecodeInvalid, /* 1590 */
	GLXDecodeInvalid, /* 1591 */
	GLXDecodeInvalid, /* 1592 */
	GLXDecodeInvalid, /* 1593 */
	GLXDecodeInvalid, /* 1594 */
	GLXDecodeInvalid, /* 1595 */
	GLXDecodeInvalid, /* 1596 */
	GLXDecodeInvalid, /* 1597 */
	GLXDecodeInvalid, /* 1598 */
	GLXDecodeInvalid, /* 1599 */
	GLXDecodeInvalid, /* 1600 */
	GLXDecodeInvalid, /* 1601 */
	GLXDecodeInvalid, /* 1602 */
	GLXDecodeInvalid, /* 1603 */
	GLXDecodeInvalid, /* 1604 */
	GLXDecodeInvalid, /* 1605 */
	GLXDecodeInvalid, /* 1606 */
	GLXDecodeInvalid, /* 1607 */
	GLXDecodeInvalid, /* 1608 */
	GLXDecodeInvalid, /* 1609 */
	GLXDecodeInvalid, /* 1610 */
	GLXDecodeInvalid, /* 1611 */
	GLXDecodeInvalid, /* 1612 */
	GLXDecodeInvalid, /* 1613 */
	GLXDecodeInvalid, /* 1614 */
	GLXDecodeInvalid, /* 1615 */
	GLXDecodeInvalid, /* 1616 */
	GLXDecodeInvalid, /* 1617 */
	GLXDecodeInvalid, /* 1618 */
	GLXDecodeInvalid, /* 1619 */
	GLXDecodeInvalid, /* 1620 */
	GLXDecodeInvalid, /* 1621 */
	GLXDecodeInvalid, /* 1622 */
	GLXDecodeInvalid, /* 1623 */
	GLXDecodeInvalid, /* 1624 */
	GLXDecodeInvalid, /* 1625 */
	GLXDecodeInvalid, /* 1626 */
	GLXDecodeInvalid, /* 1627 */
	GLXDecodeInvalid, /* 1628 */
	GLXDecodeInvalid, /* 1629 */
	GLXDecodeInvalid, /* 1630 */
	GLXDecodeInvalid, /* 1631 */
	GLXDecodeInvalid, /* 1632 */
	GLXDecodeInvalid, /* 1633 */
	GLXDecodeInvalid, /* 1634 */
	GLXDecodeInvalid, /* 1635 */
	GLXDecodeInvalid, /* 1636 */
	GLXDecodeInvalid, /* 1637 */
	GLXDecodeInvalid, /* 1638 */
	GLXDecodeInvalid, /* 1639 */
	GLXDecodeInvalid, /* 1640 */
	GLXDecodeInvalid, /* 1641 */
	GLXDecodeInvalid, /* 1642 */
	GLXDecodeInvalid, /* 1643 */
	GLXDecodeInvalid, /* 1644 */
	GLXDecodeInvalid, /* 1645 */
	GLXDecodeInvalid, /* 1646 */
	GLXDecodeInvalid, /* 1647 */
	GLXDecodeInvalid, /* 1648 */
	GLXDecodeInvalid, /* 1649 */
	GLXDecodeInvalid, /* 1650 */
	GLXDecodeInvalid, /* 1651 */
	GLXDecodeInvalid, /* 1652 */
	GLXDecodeInvalid, /* 1653 */
	GLXDecodeInvalid, /* 1654 */
	GLXDecodeInvalid, /* 1655 */
	GLXDecodeInvalid, /* 1656 */
	GLXDecodeInvalid, /* 1657 */
	GLXDecodeInvalid, /* 1658 */
	GLXDecodeInvalid, /* 1659 */
	GLXDecodeInvalid, /* 1660 */
	GLXDecodeInvalid, /* 1661 */
	GLXDecodeInvalid, /* 1662 */
	GLXDecodeInvalid, /* 1663 */
	GLXDecodeInvalid, /* 1664 */
	GLXDecodeInvalid, /* 1665 */
	GLXDecodeInvalid, /* 1666 */
	GLXDecodeInvalid, /* 1667 */
	GLXDecodeInvalid, /* 1668 */
	GLXDecodeInvalid, /* 1669 */
	GLXDecodeInvalid, /* 1670 */
	GLXDecodeInvalid, /* 1671 */
	GLXDecodeInvalid, /* 1672 */
	GLXDecodeInvalid, /* 1673 */
	GLXDecodeInvalid, /* 1674 */
	GLXDecodeInvalid, /* 1675 */
	GLXDecodeInvalid, /* 1676 */
	GLXDecodeInvalid, /* 1677 */
	GLXDecodeInvalid, /* 1678 */
	GLXDecodeInvalid, /* 1679 */
	GLXDecodeInvalid, /* 1680 */
	GLXDecodeInvalid, /* 1681 */
	GLXDecodeInvalid, /* 1682 */
	GLXDecodeInvalid, /* 1683 */
	GLXDecodeInvalid, /* 1684 */
	GLXDecodeInvalid, /* 1685 */
	GLXDecodeInvalid, /* 1686 */
	GLXDecodeInvalid, /* 1687 */
	GLXDecodeInvalid, /* 1688 */
	GLXDecodeInvalid, /* 1689 */
	GLXDecodeInvalid, /* 1690 */
	GLXDecodeInvalid, /* 1691 */
	GLXDecodeInvalid, /* 1692 */
	GLXDecodeInvalid, /* 1693 */
	GLXDecodeInvalid, /* 1694 */
	GLXDecodeInvalid, /* 1695 */
	GLXDecodeInvalid, /* 1696 */
	GLXDecodeInvalid, /* 1697 */
	GLXDecodeInvalid, /* 1698 */
	GLXDecodeInvalid, /* 1699 */
	GLXDecodeInvalid, /* 1700 */
	GLXDecodeInvalid, /* 1701 */
	GLXDecodeInvalid, /* 1702 */
	GLXDecodeInvalid, /* 1703 */
	GLXDecodeInvalid, /* 1704 */
	GLXDecodeInvalid, /* 1705 */
	GLXDecodeInvalid, /* 1706 */
	GLXDecodeInvalid, /* 1707 */
	GLXDecodeInvalid, /* 1708 */
	GLXDecodeInvalid, /* 1709 */
	GLXDecodeInvalid, /* 1710 */
	GLXDecodeInvalid, /* 1711 */
	GLXDecodeInvalid, /* 1712 */
	GLXDecodeInvalid, /* 1713 */
	GLXDecodeInvalid, /* 1714 */
	GLXDecodeInvalid, /* 1715 */
	GLXDecodeInvalid, /* 1716 */
	GLXDecodeInvalid, /* 1717 */
	GLXDecodeInvalid, /* 1718 */
	GLXDecodeInvalid, /* 1719 */
	GLXDecodeInvalid, /* 1720 */
	GLXDecodeInvalid, /* 1721 */
	GLXDecodeInvalid, /* 1722 */
	GLXDecodeInvalid, /* 1723 */
	GLXDecodeInvalid, /* 1724 */
	GLXDecodeInvalid, /* 1725 */
	GLXDecodeInvalid, /* 1726 */
	GLXDecodeInvalid, /* 1727 */
	GLXDecodeInvalid, /* 1728 */
	GLXDecodeInvalid, /* 1729 */
	GLXDecodeInvalid, /* 1730 */
	GLXDecodeInvalid, /* 1731 */
	GLXDecodeInvalid, /* 1732 */
	GLXDecodeInvalid, /* 1733 */
	GLXDecodeInvalid, /* 1734 */
	GLXDecodeInvalid, /* 1735 */
	GLXDecodeInvalid, /* 1736 */
	GLXDecodeInvalid, /* 1737 */
	GLXDecodeInvalid, /* 1738 */
	GLXDecodeInvalid, /* 1739 */
	GLXDecodeInvalid, /* 1740 */
	GLXDecodeInvalid, /* 1741 */
	GLXDecodeInvalid, /* 1742 */
	GLXDecodeInvalid, /* 1743 */
	GLXDecodeInvalid, /* 1744 */
	GLXDecodeInvalid, /* 1745 */
	GLXDecodeInvalid, /* 1746 */
	GLXDecodeInvalid, /* 1747 */
	GLXDecodeInvalid, /* 1748 */
	GLXDecodeInvalid, /* 1749 */
	GLXDecodeInvalid, /* 1750 */
	GLXDecodeInvalid, /* 1751 */
	GLXDecodeInvalid, /* 1752 */
	GLXDecodeInvalid, /* 1753 */
	GLXDecodeInvalid, /* 1754 */
	GLXDecodeInvalid, /* 1755 */
	GLXDecodeInvalid, /* 1756 */
	GLXDecodeInvalid, /* 1757 */
	GLXDecodeInvalid, /* 1758 */
	GLXDecodeInvalid, /* 1759 */
	GLXDecodeInvalid, /* 1760 */
	GLXDecodeInvalid, /* 1761 */
	GLXDecodeInvalid, /* 1762 */
	GLXDecodeInvalid, /* 1763 */
	GLXDecodeInvalid, /* 1764 */
	GLXDecodeInvalid, /* 1765 */
	GLXDecodeInvalid, /* 1766 */
	GLXDecodeInvalid, /* 1767 */
	GLXDecodeInvalid, /* 1768 */
	GLXDecodeInvalid, /* 1769 */
	GLXDecodeInvalid, /* 1770 */
	GLXDecodeInvalid, /* 1771 */
	GLXDecodeInvalid, /* 1772 */
	GLXDecodeInvalid, /* 1773 */
	GLXDecodeInvalid, /* 1774 */
	GLXDecodeInvalid, /* 1775 */
	GLXDecodeInvalid, /* 1776 */
	GLXDecodeInvalid, /* 1777 */
	GLXDecodeInvalid, /* 1778 */
	GLXDecodeInvalid, /* 1779 */
	GLXDecodeInvalid, /* 1780 */
	GLXDecodeInvalid, /* 1781 */
	GLXDecodeInvalid, /* 1782 */
	GLXDecodeInvalid, /* 1783 */
	GLXDecodeInvalid, /* 1784 */
	GLXDecodeInvalid, /* 1785 */
	GLXDecodeInvalid, /* 1786 */
	GLXDecodeInvalid, /* 1787 */
	GLXDecodeInvalid, /* 1788 */
	GLXDecodeInvalid, /* 1789 */
	GLXDecodeInvalid, /* 1790 */
	GLXDecodeInvalid, /* 1791 */
	GLXDecodeInvalid, /* 1792 */
	GLXDecodeInvalid, /* 1793 */
	GLXDecodeInvalid, /* 1794 */
	GLXDecodeInvalid, /* 1795 */
	GLXDecodeInvalid, /* 1796 */
	GLXDecodeInvalid, /* 1797 */
	GLXDecodeInvalid, /* 1798 */
	GLXDecodeInvalid, /* 1799 */
	GLXDecodeInvalid, /* 1800 */
	GLXDecodeInvalid, /* 1801 */
	GLXDecodeInvalid, /* 1802 */
	GLXDecodeInvalid, /* 1803 */
	GLXDecodeInvalid, /* 1804 */
	GLXDecodeInvalid, /* 1805 */
	GLXDecodeInvalid, /* 1806 */
	GLXDecodeInvalid, /* 1807 */
	GLXDecodeInvalid, /* 1808 */
	GLXDecodeInvalid, /* 1809 */
	GLXDecodeInvalid, /* 1810 */
	GLXDecodeInvalid, /* 1811 */
	GLXDecodeInvalid, /* 1812 */
	GLXDecodeInvalid, /* 1813 */
	GLXDecodeInvalid, /* 1814 */
	GLXDecodeInvalid, /* 1815 */
	GLXDecodeInvalid, /* 1816 */
	GLXDecodeInvalid, /* 1817 */
	GLXDecodeInvalid, /* 1818 */
	GLXDecodeInvalid, /* 1819 */
	GLXDecodeInvalid, /* 1820 */
	GLXDecodeInvalid, /* 1821 */
	GLXDecodeInvalid, /* 1822 */
	GLXDecodeInvalid, /* 1823 */
	GLXDecodeInvalid, /* 1824 */
	GLXDecodeInvalid, /* 1825 */
	GLXDecodeInvalid, /* 1826 */
	GLXDecodeInvalid, /* 1827 */
	GLXDecodeInvalid, /* 1828 */
	GLXDecodeInvalid, /* 1829 */
	GLXDecodeInvalid, /* 1830 */
	GLXDecodeInvalid, /* 1831 */
	GLXDecodeInvalid, /* 1832 */
	GLXDecodeInvalid, /* 1833 */
	GLXDecodeInvalid, /* 1834 */
	GLXDecodeInvalid, /* 1835 */
	GLXDecodeInvalid, /* 1836 */
	GLXDecodeInvalid, /* 1837 */
	GLXDecodeInvalid, /* 1838 */
	GLXDecodeInvalid, /* 1839 */
	GLXDecodeInvalid, /* 1840 */
	GLXDecodeInvalid, /* 1841 */
	GLXDecodeInvalid, /* 1842 */
	GLXDecodeInvalid, /* 1843 */
	GLXDecodeInvalid, /* 1844 */
	GLXDecodeInvalid, /* 1845 */
	GLXDecodeInvalid, /* 1846 */
	GLXDecodeInvalid, /* 1847 */
	GLXDecodeInvalid, /* 1848 */
	GLXDecodeInvalid, /* 1849 */
	GLXDecodeInvalid, /* 1850 */
	GLXDecodeInvalid, /* 1851 */
	GLXDecodeInvalid, /* 1852 */
	GLXDecodeInvalid, /* 1853 */
	GLXDecodeInvalid, /* 1854 */
	GLXDecodeInvalid, /* 1855 */
	GLXDecodeInvalid, /* 1856 */
	GLXDecodeInvalid, /* 1857 */
	GLXDecodeInvalid, /* 1858 */
	GLXDecodeInvalid, /* 1859 */
	GLXDecodeInvalid, /* 1860 */
	GLXDecodeInvalid, /* 1861 */
	GLXDecodeInvalid, /* 1862 */
	GLXDecodeInvalid, /* 1863 */
	GLXDecodeInvalid, /* 1864 */
	GLXDecodeInvalid, /* 1865 */
	GLXDecodeInvalid, /* 1866 */
	GLXDecodeInvalid, /* 1867 */
	GLXDecodeInvalid, /* 1868 */
	GLXDecodeInvalid, /* 1869 */
	GLXDecodeInvalid, /* 1870 */
	GLXDecodeInvalid, /* 1871 */
	GLXDecodeInvalid, /* 1872 */
	GLXDecodeInvalid, /* 1873 */
	GLXDecodeInvalid, /* 1874 */
	GLXDecodeInvalid, /* 1875 */
	GLXDecodeInvalid, /* 1876 */
	GLXDecodeInvalid, /* 1877 */
	GLXDecodeInvalid, /* 1878 */
	GLXDecodeInvalid, /* 1879 */
	GLXDecodeInvalid, /* 1880 */
	GLXDecodeInvalid, /* 1881 */
	GLXDecodeInvalid, /* 1882 */
	GLXDecodeInvalid, /* 1883 */
	GLXDecodeInvalid, /* 1884 */
	GLXDecodeInvalid, /* 1885 */
	GLXDecodeInvalid, /* 1886 */
	GLXDecodeInvalid, /* 1887 */
	GLXDecodeInvalid, /* 1888 */
	GLXDecodeInvalid, /* 1889 */
	GLXDecodeInvalid, /* 1890 */
	GLXDecodeInvalid, /* 1891 */
	GLXDecodeInvalid, /* 1892 */
	GLXDecodeInvalid, /* 1893 */
	GLXDecodeInvalid, /* 1894 */
	GLXDecodeInvalid, /* 1895 */
	GLXDecodeInvalid, /* 1896 */
	GLXDecodeInvalid, /* 1897 */
	GLXDecodeInvalid, /* 1898 */
	GLXDecodeInvalid, /* 1899 */
	GLXDecodeInvalid, /* 1900 */
	GLXDecodeInvalid, /* 1901 */
	GLXDecodeInvalid, /* 1902 */
	GLXDecodeInvalid, /* 1903 */
	GLXDecodeInvalid, /* 1904 */
	GLXDecodeInvalid, /* 1905 */
	GLXDecodeInvalid, /* 1906 */
	GLXDecodeInvalid, /* 1907 */
	GLXDecodeInvalid, /* 1908 */
	GLXDecodeInvalid, /* 1909 */
	GLXDecodeInvalid, /* 1910 */
	GLXDecodeInvalid, /* 1911 */
	GLXDecodeInvalid, /* 1912 */
	GLXDecodeInvalid, /* 1913 */
	GLXDecodeInvalid, /* 1914 */
	GLXDecodeInvalid, /* 1915 */
	GLXDecodeInvalid, /* 1916 */
	GLXDecodeInvalid, /* 1917 */
	GLXDecodeInvalid, /* 1918 */
	GLXDecodeInvalid, /* 1919 */
	GLXDecodeInvalid, /* 1920 */
	GLXDecodeInvalid, /* 1921 */
	GLXDecodeInvalid, /* 1922 */
	GLXDecodeInvalid, /* 1923 */
	GLXDecodeInvalid, /* 1924 */
	GLXDecodeInvalid, /* 1925 */
	GLXDecodeInvalid, /* 1926 */
	GLXDecodeInvalid, /* 1927 */
	GLXDecodeInvalid, /* 1928 */
	GLXDecodeInvalid, /* 1929 */
	GLXDecodeInvalid, /* 1930 */
	GLXDecodeInvalid, /* 1931 */
	GLXDecodeInvalid, /* 1932 */
	GLXDecodeInvalid, /* 1933 */
	GLXDecodeInvalid, /* 1934 */
	GLXDecodeInvalid, /* 1935 */
	GLXDecodeInvalid, /* 1936 */
	GLXDecodeInvalid, /* 1937 */
	GLXDecodeInvalid, /* 1938 */
	GLXDecodeInvalid, /* 1939 */
	GLXDecodeInvalid, /* 1940 */
	GLXDecodeInvalid, /* 1941 */
	GLXDecodeInvalid, /* 1942 */
	GLXDecodeInvalid, /* 1943 */
	GLXDecodeInvalid, /* 1944 */
	GLXDecodeInvalid, /* 1945 */
	GLXDecodeInvalid, /* 1946 */
	GLXDecodeInvalid, /* 1947 */
	GLXDecodeInvalid, /* 1948 */
	GLXDecodeInvalid, /* 1949 */
	GLXDecodeInvalid, /* 1950 */
	GLXDecodeInvalid, /* 1951 */
	GLXDecodeInvalid, /* 1952 */
	GLXDecodeInvalid, /* 1953 */
	GLXDecodeInvalid, /* 1954 */
	GLXDecodeInvalid, /* 1955 */
	GLXDecodeInvalid, /* 1956 */
	GLXDecodeInvalid, /* 1957 */
	GLXDecodeInvalid, /* 1958 */
	GLXDecodeInvalid, /* 1959 */
	GLXDecodeInvalid, /* 1960 */
	GLXDecodeInvalid, /* 1961 */
	GLXDecodeInvalid, /* 1962 */
	GLXDecodeInvalid, /* 1963 */
	GLXDecodeInvalid, /* 1964 */
	GLXDecodeInvalid, /* 1965 */
	GLXDecodeInvalid, /* 1966 */
	GLXDecodeInvalid, /* 1967 */
	GLXDecodeInvalid, /* 1968 */
	GLXDecodeInvalid, /* 1969 */
	GLXDecodeInvalid, /* 1970 */
	GLXDecodeInvalid, /* 1971 */
	GLXDecodeInvalid, /* 1972 */
	GLXDecodeInvalid, /* 1973 */
	GLXDecodeInvalid, /* 1974 */
	GLXDecodeInvalid, /* 1975 */
	GLXDecodeInvalid, /* 1976 */
	GLXDecodeInvalid, /* 1977 */
	GLXDecodeInvalid, /* 1978 */
	GLXDecodeInvalid, /* 1979 */
	GLXDecodeInvalid, /* 1980 */
	GLXDecodeInvalid, /* 1981 */
	GLXDecodeInvalid, /* 1982 */
	GLXDecodeInvalid, /* 1983 */
	GLXDecodeInvalid, /* 1984 */
	GLXDecodeInvalid, /* 1985 */
	GLXDecodeInvalid, /* 1986 */
	GLXDecodeInvalid, /* 1987 */
	GLXDecodeInvalid, /* 1988 */
	GLXDecodeInvalid, /* 1989 */
	GLXDecodeInvalid, /* 1990 */
	GLXDecodeInvalid, /* 1991 */
	GLXDecodeInvalid, /* 1992 */
	GLXDecodeInvalid, /* 1993 */
	GLXDecodeInvalid, /* 1994 */
	GLXDecodeInvalid, /* 1995 */
	GLXDecodeInvalid, /* 1996 */
	GLXDecodeInvalid, /* 1997 */
	GLXDecodeInvalid, /* 1998 */
	GLXDecodeInvalid, /* 1999 */
	GLXDecodeInvalid, /* 2000 */
	GLXDecodeInvalid, /* 2001 */
	GLXDecodeInvalid, /* 2002 */
	GLXDecodeInvalid, /* 2003 */
	GLXDecodeInvalid, /* 2004 */
	GLXDecodeInvalid, /* 2005 */
	GLXDecodeInvalid, /* 2006 */
	GLXDecodeInvalid, /* 2007 */
	GLXDecodeInvalid, /* 2008 */
	GLXDecodeInvalid, /* 2009 */
	GLXDecodeInvalid, /* 2010 */
	GLXDecodeInvalid, /* 2011 */
	GLXDecodeInvalid, /* 2012 */
	GLXDecodeInvalid, /* 2013 */
	GLXDecodeInvalid, /* 2014 */
	GLXDecodeInvalid, /* 2015 */
	GLXDecodeInvalid, /* 2016 */
	GLXDecodeInvalid, /* 2017 */
	GLXDecodeInvalid, /* 2018 */
	GLXDecodeInvalid, /* 2019 */
	GLXDecodeInvalid, /* 2020 */
	GLXDecodeInvalid, /* 2021 */
	GLXDecodeInvalid, /* 2022 */
	GLXDecodeInvalid, /* 2023 */
	GLXDecodeInvalid, /* 2024 */
	GLXDecodeInvalid, /* 2025 */
	GLXDecodeInvalid, /* 2026 */
	GLXDecodeInvalid, /* 2027 */
	GLXDecodeInvalid, /* 2028 */
	GLXDecodeInvalid, /* 2029 */
	GLXDecodeInvalid, /* 2030 */
	GLXDecodeInvalid, /* 2031 */
	GLXDecodeInvalid, /* 2032 */
	GLXDecodeInvalid, /* 2033 */
	GLXDecodeInvalid, /* 2034 */
	GLXDecodeInvalid, /* 2035 */
	GLXDecodeInvalid, /* 2036 */
	GLXDecodeInvalid, /* 2037 */
	GLXDecodeInvalid, /* 2038 */
	GLXDecodeInvalid, /* 2039 */
	GLXDecodeInvalid, /* 2040 */
	GLXDecodeInvalid, /* 2041 */
	GLXDecodeInvalid, /* 2042 */
	GLXDecodeInvalid, /* 2043 */
	GLXDecodeInvalid, /* 2044 */
	GLXDecodeInvalid, /* 2045 */
	GLXDecodeInvalid, /* 2046 */
	GLXDecodeInvalid, /* 2047 */
	GLXDecodeInvalid, /* 2048 */
	GLXDecodeInvalid, /* 2049 */
	GLXDecodeInvalid, /* 2050 */
	GLXDecodeInvalid, /* 2051 */
	GLXDecodeInvalid, /* 2052 */
	GLXDecodeInvalid, /* 2053 */
	GLXDecodeInvalid, /* 2054 */
	GLXDecodeInvalid, /* 2055 */
	GLXDecodeInvalid, /* 2056 */
	GLXDecodeInvalid, /* 2057 */
	GLXDecodeInvalid, /* 2058 */
	GLXDecodeInvalid, /* 2059 */
	GLXDecodeInvalid, /* 2060 */
	GLXDecodeInvalid, /* 2061 */
	GLXDecodeInvalid, /* 2062 */
	GLXDecodeInvalid, /* 2063 */
	GLXDecodeInvalid, /* 2064 */
	GLXDecodeInvalid, /* 2065 */
	GLXDecodeInvalid, /* 2066 */
	GLXDecodeInvalid, /* 2067 */
	GLXDecodeInvalid, /* 2068 */
	GLXDecodeInvalid, /* 2069 */
	GLXDecodeInvalid, /* 2070 */
	GLXDecodeInvalid, /* 2071 */
	GLXDecodeInvalid, /* 2072 */
	GLXDecodeInvalid, /* 2073 */
	GLXDecodeInvalid, /* 2074 */
	GLXDecodeInvalid, /* 2075 */
	GLXDecodeInvalid, /* 2076 */
	GLXDecodeInvalid, /* 2077 */
	GLXDecodeInvalid, /* 2078 */
	GLXDecodeInvalid, /* 2079 */
	GLXDecodeInvalid, /* 2080 */
	GLXDecodeInvalid, /* 2081 */
	GLXDecodeInvalid, /* 2082 */
	GLXDecodeInvalid, /* 2083 */
	GLXDecodeInvalid, /* 2084 */
	GLXDecodeInvalid, /* 2085 */
	GLXDecodeInvalid, /* 2086 */
	GLXDecodeInvalid, /* 2087 */
	GLXDecodeInvalid, /* 2088 */
	GLXDecodeInvalid, /* 2089 */
	GLXDecodeInvalid, /* 2090 */
	GLXDecodeInvalid, /* 2091 */
	GLXDecodeInvalid, /* 2092 */
	GLXDecodeInvalid, /* 2093 */
	GLXDecodeInvalid, /* 2094 */
	GLXDecodeInvalid, /* 2095 */
	GLXDecodeInvalid, /* 2096 */
	GLXDecodeInvalid, /* 2097 */
	GLXDecodeInvalid, /* 2098 */
	GLXDecodeInvalid, /* 2099 */
	GLXDecodeInvalid, /* 2100 */
	GLXDecodeInvalid, /* 2101 */
	GLXDecodeInvalid, /* 2102 */
	GLXDecodeInvalid, /* 2103 */
	GLXDecodeInvalid, /* 2104 */
	GLXDecodeInvalid, /* 2105 */
	GLXDecodeInvalid, /* 2106 */
	GLXDecodeInvalid, /* 2107 */
	GLXDecodeInvalid, /* 2108 */
	GLXDecodeInvalid, /* 2109 */
	GLXDecodeInvalid, /* 2110 */
	GLXDecodeInvalid, /* 2111 */
	GLXDecodeInvalid, /* 2112 */
	GLXDecodeInvalid, /* 2113 */
	GLXDecodeInvalid, /* 2114 */
	GLXDecodeInvalid, /* 2115 */
	GLXDecodeInvalid, /* 2116 */
	GLXDecodeInvalid, /* 2117 */
	GLXDecodeInvalid, /* 2118 */
	GLXDecodeInvalid, /* 2119 */
	GLXDecodeInvalid, /* 2120 */
	GLXDecodeInvalid, /* 2121 */
	GLXDecodeInvalid, /* 2122 */
	GLXDecodeInvalid, /* 2123 */
	GLXDecodeInvalid, /* 2124 */
	GLXDecodeInvalid, /* 2125 */
	GLXDecodeInvalid, /* 2126 */
	GLXDecodeInvalid, /* 2127 */
	GLXDecodeInvalid, /* 2128 */
	GLXDecodeInvalid, /* 2129 */
	GLXDecodeInvalid, /* 2130 */
	GLXDecodeInvalid, /* 2131 */
	GLXDecodeInvalid, /* 2132 */
	GLXDecodeInvalid, /* 2133 */
	GLXDecodeInvalid, /* 2134 */
	GLXDecodeInvalid, /* 2135 */
	GLXDecodeInvalid, /* 2136 */
	GLXDecodeInvalid, /* 2137 */
	GLXDecodeInvalid, /* 2138 */
	GLXDecodeInvalid, /* 2139 */
	GLXDecodeInvalid, /* 2140 */
	GLXDecodeInvalid, /* 2141 */
	GLXDecodeInvalid, /* 2142 */
	GLXDecodeInvalid, /* 2143 */
	GLXDecodeInvalid, /* 2144 */
	GLXDecodeInvalid, /* 2145 */
	GLXDecodeInvalid, /* 2146 */
	GLXDecodeInvalid, /* 2147 */
	GLXDecodeInvalid, /* 2148 */
	GLXDecodeInvalid, /* 2149 */
	GLXDecodeInvalid, /* 2150 */
	GLXDecodeInvalid, /* 2151 */
	GLXDecodeInvalid, /* 2152 */
	GLXDecodeInvalid, /* 2153 */
	GLXDecodeInvalid, /* 2154 */
	GLXDecodeInvalid, /* 2155 */
	GLXDecodeInvalid, /* 2156 */
	GLXDecodeInvalid, /* 2157 */
	GLXDecodeInvalid, /* 2158 */
	GLXDecodeInvalid, /* 2159 */
	GLXDecodeInvalid, /* 2160 */
	GLXDecodeInvalid, /* 2161 */
	GLXDecodeInvalid, /* 2162 */
	GLXDecodeInvalid, /* 2163 */
	GLXDecodeInvalid, /* 2164 */
	GLXDecodeInvalid, /* 2165 */
	GLXDecodeInvalid, /* 2166 */
	GLXDecodeInvalid, /* 2167 */
	GLXDecodeInvalid, /* 2168 */
	GLXDecodeInvalid, /* 2169 */
	GLXDecodeInvalid, /* 2170 */
	GLXDecodeInvalid, /* 2171 */
	GLXDecodeInvalid, /* 2172 */
	GLXDecodeInvalid, /* 2173 */
	GLXDecodeInvalid, /* 2174 */
	GLXDecodeInvalid, /* 2175 */
	GLXDecodeInvalid, /* 2176 */
	GLXDecodeInvalid, /* 2177 */
	GLXDecodeInvalid, /* 2178 */
	GLXDecodeInvalid, /* 2179 */
	GLXDecodeInvalid, /* 2180 */
	GLXDecodeInvalid, /* 2181 */
	GLXDecodeInvalid, /* 2182 */
	GLXDecodeInvalid, /* 2183 */
	GLXDecodeInvalid, /* 2184 */
	GLXDecodeInvalid, /* 2185 */
	GLXDecodeInvalid, /* 2186 */
	GLXDecodeInvalid, /* 2187 */
	GLXDecodeInvalid, /* 2188 */
	GLXDecodeInvalid, /* 2189 */
	GLXDecodeInvalid, /* 2190 */
	GLXDecodeInvalid, /* 2191 */
	GLXDecodeInvalid, /* 2192 */
	GLXDecodeInvalid, /* 2193 */
	GLXDecodeInvalid, /* 2194 */
	GLXDecodeInvalid, /* 2195 */
	GLXDecodeInvalid, /* 2196 */
	GLXDecodeInvalid, /* 2197 */
	GLXDecodeInvalid, /* 2198 */
	GLXDecodeInvalid, /* 2199 */
	GLXDecodeInvalid, /* 2200 */
	GLXDecodeInvalid, /* 2201 */
	GLXDecodeInvalid, /* 2202 */
	GLXDecodeInvalid, /* 2203 */
	GLXDecodeInvalid, /* 2204 */
	GLXDecodeInvalid, /* 2205 */
	GLXDecodeInvalid, /* 2206 */
	GLXDecodeInvalid, /* 2207 */
	GLXDecodeInvalid, /* 2208 */
	GLXDecodeInvalid, /* 2209 */
	GLXDecodeInvalid, /* 2210 */
	GLXDecodeInvalid, /* 2211 */
	GLXDecodeInvalid, /* 2212 */
	GLXDecodeInvalid, /* 2213 */
	GLXDecodeInvalid, /* 2214 */
	GLXDecodeInvalid, /* 2215 */
	GLXDecodeInvalid, /* 2216 */
	GLXDecodeInvalid, /* 2217 */
	GLXDecodeInvalid, /* 2218 */
	GLXDecodeInvalid, /* 2219 */
	GLXDecodeInvalid, /* 2220 */
	GLXDecodeInvalid, /* 2221 */
	GLXDecodeInvalid, /* 2222 */
	GLXDecodeInvalid, /* 2223 */
	GLXDecodeInvalid, /* 2224 */
	GLXDecodeInvalid, /* 2225 */
	GLXDecodeInvalid, /* 2226 */
	GLXDecodeInvalid, /* 2227 */
	GLXDecodeInvalid, /* 2228 */
	GLXDecodeInvalid, /* 2229 */
	GLXDecodeInvalid, /* 2230 */
	GLXDecodeInvalid, /* 2231 */
	GLXDecodeInvalid, /* 2232 */
	GLXDecodeInvalid, /* 2233 */
	GLXDecodeInvalid, /* 2234 */
	GLXDecodeInvalid, /* 2235 */
	GLXDecodeInvalid, /* 2236 */
	GLXDecodeInvalid, /* 2237 */
	GLXDecodeInvalid, /* 2238 */
	GLXDecodeInvalid, /* 2239 */
	GLXDecodeInvalid, /* 2240 */
	GLXDecodeInvalid, /* 2241 */
	GLXDecodeInvalid, /* 2242 */
	GLXDecodeInvalid, /* 2243 */
	GLXDecodeInvalid, /* 2244 */
	GLXDecodeInvalid, /* 2245 */
	GLXDecodeInvalid, /* 2246 */
	GLXDecodeInvalid, /* 2247 */
	GLXDecodeInvalid, /* 2248 */
	GLXDecodeInvalid, /* 2249 */
	GLXDecodeInvalid, /* 2250 */
	GLXDecodeInvalid, /* 2251 */
	GLXDecodeInvalid, /* 2252 */
	GLXDecodeInvalid, /* 2253 */
	GLXDecodeInvalid, /* 2254 */
	GLXDecodeInvalid, /* 2255 */
	GLXDecodeInvalid, /* 2256 */
	GLXDecodeInvalid, /* 2257 */
	GLXDecodeInvalid, /* 2258 */
	GLXDecodeInvalid, /* 2259 */
	GLXDecodeInvalid, /* 2260 */
	GLXDecodeInvalid, /* 2261 */
	GLXDecodeInvalid, /* 2262 */
	GLXDecodeInvalid, /* 2263 */
	GLXDecodeInvalid, /* 2264 */
	GLXDecodeInvalid, /* 2265 */
	GLXDecodeInvalid, /* 2266 */
	GLXDecodeInvalid, /* 2267 */
	GLXDecodeInvalid, /* 2268 */
	GLXDecodeInvalid, /* 2269 */
	GLXDecodeInvalid, /* 2270 */
	GLXDecodeInvalid, /* 2271 */
	GLXDecodeInvalid, /* 2272 */
	GLXDecodeInvalid, /* 2273 */
	GLXDecodeInvalid, /* 2274 */
	GLXDecodeInvalid, /* 2275 */
	GLXDecodeInvalid, /* 2276 */
	GLXDecodeInvalid, /* 2277 */
	GLXDecodeInvalid, /* 2278 */
	GLXDecodeInvalid, /* 2279 */
	GLXDecodeInvalid, /* 2280 */
	GLXDecodeInvalid, /* 2281 */
	GLXDecodeInvalid, /* 2282 */
	GLXDecodeInvalid, /* 2283 */
	GLXDecodeInvalid, /* 2284 */
	GLXDecodeInvalid, /* 2285 */
	GLXDecodeInvalid, /* 2286 */
	GLXDecodeInvalid, /* 2287 */
	GLXDecodeInvalid, /* 2288 */
	GLXDecodeInvalid, /* 2289 */
	GLXDecodeInvalid, /* 2290 */
	GLXDecodeInvalid, /* 2291 */
	GLXDecodeInvalid, /* 2292 */
	GLXDecodeInvalid, /* 2293 */
	GLXDecodeInvalid, /* 2294 */
	GLXDecodeInvalid, /* 2295 */
	GLXDecodeInvalid, /* 2296 */
	GLXDecodeInvalid, /* 2297 */
	GLXDecodeInvalid, /* 2298 */
	GLXDecodeInvalid, /* 2299 */
	GLXDecodeInvalid, /* 2300 */
	GLXDecodeInvalid, /* 2301 */
	GLXDecodeInvalid, /* 2302 */
	GLXDecodeInvalid, /* 2303 */
	GLXDecodeInvalid, /* 2304 */
	GLXDecodeInvalid, /* 2305 */
	GLXDecodeInvalid, /* 2306 */
	GLXDecodeInvalid, /* 2307 */
	GLXDecodeInvalid, /* 2308 */
	GLXDecodeInvalid, /* 2309 */
	GLXDecodeInvalid, /* 2310 */
	GLXDecodeInvalid, /* 2311 */
	GLXDecodeInvalid, /* 2312 */
	GLXDecodeInvalid, /* 2313 */
	GLXDecodeInvalid, /* 2314 */
	GLXDecodeInvalid, /* 2315 */
	GLXDecodeInvalid, /* 2316 */
	GLXDecodeInvalid, /* 2317 */
	GLXDecodeInvalid, /* 2318 */
	GLXDecodeInvalid, /* 2319 */
	GLXDecodeInvalid, /* 2320 */
	GLXDecodeInvalid, /* 2321 */
	GLXDecodeInvalid, /* 2322 */
	GLXDecodeInvalid, /* 2323 */
	GLXDecodeInvalid, /* 2324 */
	GLXDecodeInvalid, /* 2325 */
	GLXDecodeInvalid, /* 2326 */
	GLXDecodeInvalid, /* 2327 */
	GLXDecodeInvalid, /* 2328 */
	GLXDecodeInvalid, /* 2329 */
	GLXDecodeInvalid, /* 2330 */
	GLXDecodeInvalid, /* 2331 */
	GLXDecodeInvalid, /* 2332 */
	GLXDecodeInvalid, /* 2333 */
	GLXDecodeInvalid, /* 2334 */
	GLXDecodeInvalid, /* 2335 */
	GLXDecodeInvalid, /* 2336 */
	GLXDecodeInvalid, /* 2337 */
	GLXDecodeInvalid, /* 2338 */
	GLXDecodeInvalid, /* 2339 */
	GLXDecodeInvalid, /* 2340 */
	GLXDecodeInvalid, /* 2341 */
	GLXDecodeInvalid, /* 2342 */
	GLXDecodeInvalid, /* 2343 */
	GLXDecodeInvalid, /* 2344 */
	GLXDecodeInvalid, /* 2345 */
	GLXDecodeInvalid, /* 2346 */
	GLXDecodeInvalid, /* 2347 */
	GLXDecodeInvalid, /* 2348 */
	GLXDecodeInvalid, /* 2349 */
	GLXDecodeInvalid, /* 2350 */
	GLXDecodeInvalid, /* 2351 */
	GLXDecodeInvalid, /* 2352 */
	GLXDecodeInvalid, /* 2353 */
	GLXDecodeInvalid, /* 2354 */
	GLXDecodeInvalid, /* 2355 */
	GLXDecodeInvalid, /* 2356 */
	GLXDecodeInvalid, /* 2357 */
	GLXDecodeInvalid, /* 2358 */
	GLXDecodeInvalid, /* 2359 */
	GLXDecodeInvalid, /* 2360 */
	GLXDecodeInvalid, /* 2361 */
	GLXDecodeInvalid, /* 2362 */
	GLXDecodeInvalid, /* 2363 */
	GLXDecodeInvalid, /* 2364 */
	GLXDecodeInvalid, /* 2365 */
	GLXDecodeInvalid, /* 2366 */
	GLXDecodeInvalid, /* 2367 */
	GLXDecodeInvalid, /* 2368 */
	GLXDecodeInvalid, /* 2369 */
	GLXDecodeInvalid, /* 2370 */
	GLXDecodeInvalid, /* 2371 */
	GLXDecodeInvalid, /* 2372 */
	GLXDecodeInvalid, /* 2373 */
	GLXDecodeInvalid, /* 2374 */
	GLXDecodeInvalid, /* 2375 */
	GLXDecodeInvalid, /* 2376 */
	GLXDecodeInvalid, /* 2377 */
	GLXDecodeInvalid, /* 2378 */
	GLXDecodeInvalid, /* 2379 */
	GLXDecodeInvalid, /* 2380 */
	GLXDecodeInvalid, /* 2381 */
	GLXDecodeInvalid, /* 2382 */
	GLXDecodeInvalid, /* 2383 */
	GLXDecodeInvalid, /* 2384 */
	GLXDecodeInvalid, /* 2385 */
	GLXDecodeInvalid, /* 2386 */
	GLXDecodeInvalid, /* 2387 */
	GLXDecodeInvalid, /* 2388 */
	GLXDecodeInvalid, /* 2389 */
	GLXDecodeInvalid, /* 2390 */
	GLXDecodeInvalid, /* 2391 */
	GLXDecodeInvalid, /* 2392 */
	GLXDecodeInvalid, /* 2393 */
	GLXDecodeInvalid, /* 2394 */
	GLXDecodeInvalid, /* 2395 */
	GLXDecodeInvalid, /* 2396 */
	GLXDecodeInvalid, /* 2397 */
	GLXDecodeInvalid, /* 2398 */
	GLXDecodeInvalid, /* 2399 */
	GLXDecodeInvalid, /* 2400 */
	GLXDecodeInvalid, /* 2401 */
	GLXDecodeInvalid, /* 2402 */
	GLXDecodeInvalid, /* 2403 */
	GLXDecodeInvalid, /* 2404 */
	GLXDecodeInvalid, /* 2405 */
	GLXDecodeInvalid, /* 2406 */
	GLXDecodeInvalid, /* 2407 */
	GLXDecodeInvalid, /* 2408 */
	GLXDecodeInvalid, /* 2409 */
	GLXDecodeInvalid, /* 2410 */
	GLXDecodeInvalid, /* 2411 */
	GLXDecodeInvalid, /* 2412 */
	GLXDecodeInvalid, /* 2413 */
	GLXDecodeInvalid, /* 2414 */
	GLXDecodeInvalid, /* 2415 */
	GLXDecodeInvalid, /* 2416 */
	GLXDecodeInvalid, /* 2417 */
	GLXDecodeInvalid, /* 2418 */
	GLXDecodeInvalid, /* 2419 */
	GLXDecodeInvalid, /* 2420 */
	GLXDecodeInvalid, /* 2421 */
	GLXDecodeInvalid, /* 2422 */
	GLXDecodeInvalid, /* 2423 */
	GLXDecodeInvalid, /* 2424 */
	GLXDecodeInvalid, /* 2425 */
	GLXDecodeInvalid, /* 2426 */
	GLXDecodeInvalid, /* 2427 */
	GLXDecodeInvalid, /* 2428 */
	GLXDecodeInvalid, /* 2429 */
	GLXDecodeInvalid, /* 2430 */
	GLXDecodeInvalid, /* 2431 */
	GLXDecodeInvalid, /* 2432 */
	GLXDecodeInvalid, /* 2433 */
	GLXDecodeInvalid, /* 2434 */
	GLXDecodeInvalid, /* 2435 */
	GLXDecodeInvalid, /* 2436 */
	GLXDecodeInvalid, /* 2437 */
	GLXDecodeInvalid, /* 2438 */
	GLXDecodeInvalid, /* 2439 */
	GLXDecodeInvalid, /* 2440 */
	GLXDecodeInvalid, /* 2441 */
	GLXDecodeInvalid, /* 2442 */
	GLXDecodeInvalid, /* 2443 */
	GLXDecodeInvalid, /* 2444 */
	GLXDecodeInvalid, /* 2445 */
	GLXDecodeInvalid, /* 2446 */
	GLXDecodeInvalid, /* 2447 */
	GLXDecodeInvalid, /* 2448 */
	GLXDecodeInvalid, /* 2449 */
	GLXDecodeInvalid, /* 2450 */
	GLXDecodeInvalid, /* 2451 */
	GLXDecodeInvalid, /* 2452 */
	GLXDecodeInvalid, /* 2453 */
	GLXDecodeInvalid, /* 2454 */
	GLXDecodeInvalid, /* 2455 */
	GLXDecodeInvalid, /* 2456 */
	GLXDecodeInvalid, /* 2457 */
	GLXDecodeInvalid, /* 2458 */
	GLXDecodeInvalid, /* 2459 */
	GLXDecodeInvalid, /* 2460 */
	GLXDecodeInvalid, /* 2461 */
	GLXDecodeInvalid, /* 2462 */
	GLXDecodeInvalid, /* 2463 */
	GLXDecodeInvalid, /* 2464 */
	GLXDecodeInvalid, /* 2465 */
	GLXDecodeInvalid, /* 2466 */
	GLXDecodeInvalid, /* 2467 */
	GLXDecodeInvalid, /* 2468 */
	GLXDecodeInvalid, /* 2469 */
	GLXDecodeInvalid, /* 2470 */
	GLXDecodeInvalid, /* 2471 */
	GLXDecodeInvalid, /* 2472 */
	GLXDecodeInvalid, /* 2473 */
	GLXDecodeInvalid, /* 2474 */
	GLXDecodeInvalid, /* 2475 */
	GLXDecodeInvalid, /* 2476 */
	GLXDecodeInvalid, /* 2477 */
	GLXDecodeInvalid, /* 2478 */
	GLXDecodeInvalid, /* 2479 */
	GLXDecodeInvalid, /* 2480 */
	GLXDecodeInvalid, /* 2481 */
	GLXDecodeInvalid, /* 2482 */
	GLXDecodeInvalid, /* 2483 */
	GLXDecodeInvalid, /* 2484 */
	GLXDecodeInvalid, /* 2485 */
	GLXDecodeInvalid, /* 2486 */
	GLXDecodeInvalid, /* 2487 */
	GLXDecodeInvalid, /* 2488 */
	GLXDecodeInvalid, /* 2489 */
	GLXDecodeInvalid, /* 2490 */
	GLXDecodeInvalid, /* 2491 */
	GLXDecodeInvalid, /* 2492 */
	GLXDecodeInvalid, /* 2493 */
	GLXDecodeInvalid, /* 2494 */
	GLXDecodeInvalid, /* 2495 */
	GLXDecodeInvalid, /* 2496 */
	GLXDecodeInvalid, /* 2497 */
	GLXDecodeInvalid, /* 2498 */
	GLXDecodeInvalid, /* 2499 */
	GLXDecodeInvalid, /* 2500 */
	GLXDecodeInvalid, /* 2501 */
	GLXDecodeInvalid, /* 2502 */
	GLXDecodeInvalid, /* 2503 */
	GLXDecodeInvalid, /* 2504 */
	GLXDecodeInvalid, /* 2505 */
	GLXDecodeInvalid, /* 2506 */
	GLXDecodeInvalid, /* 2507 */
	GLXDecodeInvalid, /* 2508 */
	GLXDecodeInvalid, /* 2509 */
	GLXDecodeInvalid, /* 2510 */
	GLXDecodeInvalid, /* 2511 */
	GLXDecodeInvalid, /* 2512 */
	GLXDecodeInvalid, /* 2513 */
	GLXDecodeInvalid, /* 2514 */
	GLXDecodeInvalid, /* 2515 */
	GLXDecodeInvalid, /* 2516 */
	GLXDecodeInvalid, /* 2517 */
	GLXDecodeInvalid, /* 2518 */
	GLXDecodeInvalid, /* 2519 */
	GLXDecodeInvalid, /* 2520 */
	GLXDecodeInvalid, /* 2521 */
	GLXDecodeInvalid, /* 2522 */
	GLXDecodeInvalid, /* 2523 */
	GLXDecodeInvalid, /* 2524 */
	GLXDecodeInvalid, /* 2525 */
	GLXDecodeInvalid, /* 2526 */
	GLXDecodeInvalid, /* 2527 */
	GLXDecodeInvalid, /* 2528 */
	GLXDecodeInvalid, /* 2529 */
	GLXDecodeInvalid, /* 2530 */
	GLXDecodeInvalid, /* 2531 */
	GLXDecodeInvalid, /* 2532 */
	GLXDecodeInvalid, /* 2533 */
	GLXDecodeInvalid, /* 2534 */
	GLXDecodeInvalid, /* 2535 */
	GLXDecodeInvalid, /* 2536 */
	GLXDecodeInvalid, /* 2537 */
	GLXDecodeInvalid, /* 2538 */
	GLXDecodeInvalid, /* 2539 */
	GLXDecodeInvalid, /* 2540 */
	GLXDecodeInvalid, /* 2541 */
	GLXDecodeInvalid, /* 2542 */
	GLXDecodeInvalid, /* 2543 */
	GLXDecodeInvalid, /* 2544 */
	GLXDecodeInvalid, /* 2545 */
	GLXDecodeInvalid, /* 2546 */
	GLXDecodeInvalid, /* 2547 */
	GLXDecodeInvalid, /* 2548 */
	GLXDecodeInvalid, /* 2549 */
	GLXDecodeInvalid, /* 2550 */
	GLXDecodeInvalid, /* 2551 */
	GLXDecodeInvalid, /* 2552 */
	GLXDecodeInvalid, /* 2553 */
	GLXDecodeInvalid, /* 2554 */
	GLXDecodeInvalid, /* 2555 */
	GLXDecodeInvalid, /* 2556 */
	GLXDecodeInvalid, /* 2557 */
	GLXDecodeInvalid, /* 2558 */
	GLXDecodeInvalid, /* 2559 */
	GLXDecodeInvalid, /* 2560 */
	GLXDecodeInvalid, /* 2561 */
	GLXDecodeInvalid, /* 2562 */
	GLXDecodeInvalid, /* 2563 */
	GLXDecodeInvalid, /* 2564 */
	GLXDecodeInvalid, /* 2565 */
	GLXDecodeInvalid, /* 2566 */
	GLXDecodeInvalid, /* 2567 */
	GLXDecodeInvalid, /* 2568 */
	GLXDecodeInvalid, /* 2569 */
	GLXDecodeInvalid, /* 2570 */
	GLXDecodeInvalid, /* 2571 */
	GLXDecodeInvalid, /* 2572 */
	GLXDecodeInvalid, /* 2573 */
	GLXDecodeInvalid, /* 2574 */
	GLXDecodeInvalid, /* 2575 */
	GLXDecodeInvalid, /* 2576 */
	GLXDecodeInvalid, /* 2577 */
	GLXDecodeInvalid, /* 2578 */
	GLXDecodeInvalid, /* 2579 */
	GLXDecodeInvalid, /* 2580 */
	GLXDecodeInvalid, /* 2581 */
	GLXDecodeInvalid, /* 2582 */
	GLXDecodeInvalid, /* 2583 */
	GLXDecodeInvalid, /* 2584 */
	GLXDecodeInvalid, /* 2585 */
	GLXDecodeInvalid, /* 2586 */
	GLXDecodeInvalid, /* 2587 */
	GLXDecodeInvalid, /* 2588 */
	GLXDecodeInvalid, /* 2589 */
	GLXDecodeInvalid, /* 2590 */
	GLXDecodeInvalid, /* 2591 */
	GLXDecodeInvalid, /* 2592 */
	GLXDecodeInvalid, /* 2593 */
	GLXDecodeInvalid, /* 2594 */
	GLXDecodeInvalid, /* 2595 */
	GLXDecodeInvalid, /* 2596 */
	GLXDecodeInvalid, /* 2597 */
	GLXDecodeInvalid, /* 2598 */
	GLXDecodeInvalid, /* 2599 */
	GLXDecodeInvalid, /* 2600 */
	GLXDecodeInvalid, /* 2601 */
	GLXDecodeInvalid, /* 2602 */
	GLXDecodeInvalid, /* 2603 */
	GLXDecodeInvalid, /* 2604 */
	GLXDecodeInvalid, /* 2605 */
	GLXDecodeInvalid, /* 2606 */
	GLXDecodeInvalid, /* 2607 */
	GLXDecodeInvalid, /* 2608 */
	GLXDecodeInvalid, /* 2609 */
	GLXDecodeInvalid, /* 2610 */
	GLXDecodeInvalid, /* 2611 */
	GLXDecodeInvalid, /* 2612 */
	GLXDecodeInvalid, /* 2613 */
	GLXDecodeInvalid, /* 2614 */
	GLXDecodeInvalid, /* 2615 */
	GLXDecodeInvalid, /* 2616 */
	GLXDecodeInvalid, /* 2617 */
	GLXDecodeInvalid, /* 2618 */
	GLXDecodeInvalid, /* 2619 */
	GLXDecodeInvalid, /* 2620 */
	GLXDecodeInvalid, /* 2621 */
	GLXDecodeInvalid, /* 2622 */
	GLXDecodeInvalid, /* 2623 */
	GLXDecodeInvalid, /* 2624 */
	GLXDecodeInvalid, /* 2625 */
	GLXDecodeInvalid, /* 2626 */
	GLXDecodeInvalid, /* 2627 */
	GLXDecodeInvalid, /* 2628 */
	GLXDecodeInvalid, /* 2629 */
	GLXDecodeInvalid, /* 2630 */
	GLXDecodeInvalid, /* 2631 */
	GLXDecodeInvalid, /* 2632 */
	GLXDecodeInvalid, /* 2633 */
	GLXDecodeInvalid, /* 2634 */
	GLXDecodeInvalid, /* 2635 */
	GLXDecodeInvalid, /* 2636 */
	GLXDecodeInvalid, /* 2637 */
	GLXDecodeInvalid, /* 2638 */
	GLXDecodeInvalid, /* 2639 */
	GLXDecodeInvalid, /* 2640 */
	GLXDecodeInvalid, /* 2641 */
	GLXDecodeInvalid, /* 2642 */
	GLXDecodeInvalid, /* 2643 */
	GLXDecodeInvalid, /* 2644 */
	GLXDecodeInvalid, /* 2645 */
	GLXDecodeInvalid, /* 2646 */
	GLXDecodeInvalid, /* 2647 */
	GLXDecodeInvalid, /* 2648 */
	GLXDecodeInvalid, /* 2649 */
	GLXDecodeInvalid, /* 2650 */
	GLXDecodeInvalid, /* 2651 */
	GLXDecodeInvalid, /* 2652 */
	GLXDecodeInvalid, /* 2653 */
	GLXDecodeInvalid, /* 2654 */
	GLXDecodeInvalid, /* 2655 */
	GLXDecodeInvalid, /* 2656 */
	GLXDecodeInvalid, /* 2657 */
	GLXDecodeInvalid, /* 2658 */
	GLXDecodeInvalid, /* 2659 */
	GLXDecodeInvalid, /* 2660 */
	GLXDecodeInvalid, /* 2661 */
	GLXDecodeInvalid, /* 2662 */
	GLXDecodeInvalid, /* 2663 */
	GLXDecodeInvalid, /* 2664 */
	GLXDecodeInvalid, /* 2665 */
	GLXDecodeInvalid, /* 2666 */
	GLXDecodeInvalid, /* 2667 */
	GLXDecodeInvalid, /* 2668 */
	GLXDecodeInvalid, /* 2669 */
	GLXDecodeInvalid, /* 2670 */
	GLXDecodeInvalid, /* 2671 */
	GLXDecodeInvalid, /* 2672 */
	GLXDecodeInvalid, /* 2673 */
	GLXDecodeInvalid, /* 2674 */
	GLXDecodeInvalid, /* 2675 */
	GLXDecodeInvalid, /* 2676 */
	GLXDecodeInvalid, /* 2677 */
	GLXDecodeInvalid, /* 2678 */
	GLXDecodeInvalid, /* 2679 */
	GLXDecodeInvalid, /* 2680 */
	GLXDecodeInvalid, /* 2681 */
	GLXDecodeInvalid, /* 2682 */
	GLXDecodeInvalid, /* 2683 */
	GLXDecodeInvalid, /* 2684 */
	GLXDecodeInvalid, /* 2685 */
	GLXDecodeInvalid, /* 2686 */
	GLXDecodeInvalid, /* 2687 */
	GLXDecodeInvalid, /* 2688 */
	GLXDecodeInvalid, /* 2689 */
	GLXDecodeInvalid, /* 2690 */
	GLXDecodeInvalid, /* 2691 */
	GLXDecodeInvalid, /* 2692 */
	GLXDecodeInvalid, /* 2693 */
	GLXDecodeInvalid, /* 2694 */
	GLXDecodeInvalid, /* 2695 */
	GLXDecodeInvalid, /* 2696 */
	GLXDecodeInvalid, /* 2697 */
	GLXDecodeInvalid, /* 2698 */
	GLXDecodeInvalid, /* 2699 */
	GLXDecodeInvalid, /* 2700 */
	GLXDecodeInvalid, /* 2701 */
	GLXDecodeInvalid, /* 2702 */
	GLXDecodeInvalid, /* 2703 */
	GLXDecodeInvalid, /* 2704 */
	GLXDecodeInvalid, /* 2705 */
	GLXDecodeInvalid, /* 2706 */
	GLXDecodeInvalid, /* 2707 */
	GLXDecodeInvalid, /* 2708 */
	GLXDecodeInvalid, /* 2709 */
	GLXDecodeInvalid, /* 2710 */
	GLXDecodeInvalid, /* 2711 */
	GLXDecodeInvalid, /* 2712 */
	GLXDecodeInvalid, /* 2713 */
	GLXDecodeInvalid, /* 2714 */
	GLXDecodeInvalid, /* 2715 */
	GLXDecodeInvalid, /* 2716 */
	GLXDecodeInvalid, /* 2717 */
	GLXDecodeInvalid, /* 2718 */
	GLXDecodeInvalid, /* 2719 */
	GLXDecodeInvalid, /* 2720 */
	GLXDecodeInvalid, /* 2721 */
	GLXDecodeInvalid, /* 2722 */
	GLXDecodeInvalid, /* 2723 */
	GLXDecodeInvalid, /* 2724 */
	GLXDecodeInvalid, /* 2725 */
	GLXDecodeInvalid, /* 2726 */
	GLXDecodeInvalid, /* 2727 */
	GLXDecodeInvalid, /* 2728 */
	GLXDecodeInvalid, /* 2729 */
	GLXDecodeInvalid, /* 2730 */
	GLXDecodeInvalid, /* 2731 */
	GLXDecodeInvalid, /* 2732 */
	GLXDecodeInvalid, /* 2733 */
	GLXDecodeInvalid, /* 2734 */
	GLXDecodeInvalid, /* 2735 */
	GLXDecodeInvalid, /* 2736 */
	GLXDecodeInvalid, /* 2737 */
	GLXDecodeInvalid, /* 2738 */
	GLXDecodeInvalid, /* 2739 */
	GLXDecodeInvalid, /* 2740 */
	GLXDecodeInvalid, /* 2741 */
	GLXDecodeInvalid, /* 2742 */
	GLXDecodeInvalid, /* 2743 */
	GLXDecodeInvalid, /* 2744 */
	GLXDecodeInvalid, /* 2745 */
	GLXDecodeInvalid, /* 2746 */
	GLXDecodeInvalid, /* 2747 */
	GLXDecodeInvalid, /* 2748 */
	GLXDecodeInvalid, /* 2749 */
	GLXDecodeInvalid, /* 2750 */
	GLXDecodeInvalid, /* 2751 */
	GLXDecodeInvalid, /* 2752 */
	GLXDecodeInvalid, /* 2753 */
	GLXDecodeInvalid, /* 2754 */
	GLXDecodeInvalid, /* 2755 */
	GLXDecodeInvalid, /* 2756 */
	GLXDecodeInvalid, /* 2757 */
	GLXDecodeInvalid, /* 2758 */
	GLXDecodeInvalid, /* 2759 */
	GLXDecodeInvalid, /* 2760 */
	GLXDecodeInvalid, /* 2761 */
	GLXDecodeInvalid, /* 2762 */
	GLXDecodeInvalid, /* 2763 */
	GLXDecodeInvalid, /* 2764 */
	GLXDecodeInvalid, /* 2765 */
	GLXDecodeInvalid, /* 2766 */
	GLXDecodeInvalid, /* 2767 */
	GLXDecodeInvalid, /* 2768 */
	GLXDecodeInvalid, /* 2769 */
	GLXDecodeInvalid, /* 2770 */
	GLXDecodeInvalid, /* 2771 */
	GLXDecodeInvalid, /* 2772 */
	GLXDecodeInvalid, /* 2773 */
	GLXDecodeInvalid, /* 2774 */
	GLXDecodeInvalid, /* 2775 */
	GLXDecodeInvalid, /* 2776 */
	GLXDecodeInvalid, /* 2777 */
	GLXDecodeInvalid, /* 2778 */
	GLXDecodeInvalid, /* 2779 */
	GLXDecodeInvalid, /* 2780 */
	GLXDecodeInvalid, /* 2781 */
	GLXDecodeInvalid, /* 2782 */
	GLXDecodeInvalid, /* 2783 */
	GLXDecodeInvalid, /* 2784 */
	GLXDecodeInvalid, /* 2785 */
	GLXDecodeInvalid, /* 2786 */
	GLXDecodeInvalid, /* 2787 */
	GLXDecodeInvalid, /* 2788 */
	GLXDecodeInvalid, /* 2789 */
	GLXDecodeInvalid, /* 2790 */
	GLXDecodeInvalid, /* 2791 */
	GLXDecodeInvalid, /* 2792 */
	GLXDecodeInvalid, /* 2793 */
	GLXDecodeInvalid, /* 2794 */
	GLXDecodeInvalid, /* 2795 */
	GLXDecodeInvalid, /* 2796 */
	GLXDecodeInvalid, /* 2797 */
	GLXDecodeInvalid, /* 2798 */
	GLXDecodeInvalid, /* 2799 */
	GLXDecodeInvalid, /* 2800 */
	GLXDecodeInvalid, /* 2801 */
	GLXDecodeInvalid, /* 2802 */
	GLXDecodeInvalid, /* 2803 */
	GLXDecodeInvalid, /* 2804 */
	GLXDecodeInvalid, /* 2805 */
	GLXDecodeInvalid, /* 2806 */
	GLXDecodeInvalid, /* 2807 */
	GLXDecodeInvalid, /* 2808 */
	GLXDecodeInvalid, /* 2809 */
	GLXDecodeInvalid, /* 2810 */
	GLXDecodeInvalid, /* 2811 */
	GLXDecodeInvalid, /* 2812 */
	GLXDecodeInvalid, /* 2813 */
	GLXDecodeInvalid, /* 2814 */
	GLXDecodeInvalid, /* 2815 */
	GLXDecodeInvalid, /* 2816 */
	GLXDecodeInvalid, /* 2817 */
	GLXDecodeInvalid, /* 2818 */
	GLXDecodeInvalid, /* 2819 */
	GLXDecodeInvalid, /* 2820 */
	GLXDecodeInvalid, /* 2821 */
	GLXDecodeInvalid, /* 2822 */
	GLXDecodeInvalid, /* 2823 */
	GLXDecodeInvalid, /* 2824 */
	GLXDecodeInvalid, /* 2825 */
	GLXDecodeInvalid, /* 2826 */
	GLXDecodeInvalid, /* 2827 */
	GLXDecodeInvalid, /* 2828 */
	GLXDecodeInvalid, /* 2829 */
	GLXDecodeInvalid, /* 2830 */
	GLXDecodeInvalid, /* 2831 */
	GLXDecodeInvalid, /* 2832 */
	GLXDecodeInvalid, /* 2833 */
	GLXDecodeInvalid, /* 2834 */
	GLXDecodeInvalid, /* 2835 */
	GLXDecodeInvalid, /* 2836 */
	GLXDecodeInvalid, /* 2837 */
	GLXDecodeInvalid, /* 2838 */
	GLXDecodeInvalid, /* 2839 */
	GLXDecodeInvalid, /* 2840 */
	GLXDecodeInvalid, /* 2841 */
	GLXDecodeInvalid, /* 2842 */
	GLXDecodeInvalid, /* 2843 */
	GLXDecodeInvalid, /* 2844 */
	GLXDecodeInvalid, /* 2845 */
	GLXDecodeInvalid, /* 2846 */
	GLXDecodeInvalid, /* 2847 */
	GLXDecodeInvalid, /* 2848 */
	GLXDecodeInvalid, /* 2849 */
	GLXDecodeInvalid, /* 2850 */
	GLXDecodeInvalid, /* 2851 */
	GLXDecodeInvalid, /* 2852 */
	GLXDecodeInvalid, /* 2853 */
	GLXDecodeInvalid, /* 2854 */
	GLXDecodeInvalid, /* 2855 */
	GLXDecodeInvalid, /* 2856 */
	GLXDecodeInvalid, /* 2857 */
	GLXDecodeInvalid, /* 2858 */
	GLXDecodeInvalid, /* 2859 */
	GLXDecodeInvalid, /* 2860 */
	GLXDecodeInvalid, /* 2861 */
	GLXDecodeInvalid, /* 2862 */
	GLXDecodeInvalid, /* 2863 */
	GLXDecodeInvalid, /* 2864 */
	GLXDecodeInvalid, /* 2865 */
	GLXDecodeInvalid, /* 2866 */
	GLXDecodeInvalid, /* 2867 */
	GLXDecodeInvalid, /* 2868 */
	GLXDecodeInvalid, /* 2869 */
	GLXDecodeInvalid, /* 2870 */
	GLXDecodeInvalid, /* 2871 */
	GLXDecodeInvalid, /* 2872 */
	GLXDecodeInvalid, /* 2873 */
	GLXDecodeInvalid, /* 2874 */
	GLXDecodeInvalid, /* 2875 */
	GLXDecodeInvalid, /* 2876 */
	GLXDecodeInvalid, /* 2877 */
	GLXDecodeInvalid, /* 2878 */
	GLXDecodeInvalid, /* 2879 */
	GLXDecodeInvalid, /* 2880 */
	GLXDecodeInvalid, /* 2881 */
	GLXDecodeInvalid, /* 2882 */
	GLXDecodeInvalid, /* 2883 */
	GLXDecodeInvalid, /* 2884 */
	GLXDecodeInvalid, /* 2885 */
	GLXDecodeInvalid, /* 2886 */
	GLXDecodeInvalid, /* 2887 */
	GLXDecodeInvalid, /* 2888 */
	GLXDecodeInvalid, /* 2889 */
	GLXDecodeInvalid, /* 2890 */
	GLXDecodeInvalid, /* 2891 */
	GLXDecodeInvalid, /* 2892 */
	GLXDecodeInvalid, /* 2893 */
	GLXDecodeInvalid, /* 2894 */
	GLXDecodeInvalid, /* 2895 */
	GLXDecodeInvalid, /* 2896 */
	GLXDecodeInvalid, /* 2897 */
	GLXDecodeInvalid, /* 2898 */
	GLXDecodeInvalid, /* 2899 */
	GLXDecodeInvalid, /* 2900 */
	GLXDecodeInvalid, /* 2901 */
	GLXDecodeInvalid, /* 2902 */
	GLXDecodeInvalid, /* 2903 */
	GLXDecodeInvalid, /* 2904 */
	GLXDecodeInvalid, /* 2905 */
	GLXDecodeInvalid, /* 2906 */
	GLXDecodeInvalid, /* 2907 */
	GLXDecodeInvalid, /* 2908 */
	GLXDecodeInvalid, /* 2909 */
	GLXDecodeInvalid, /* 2910 */
	GLXDecodeInvalid, /* 2911 */
	GLXDecodeInvalid, /* 2912 */
	GLXDecodeInvalid, /* 2913 */
	GLXDecodeInvalid, /* 2914 */
	GLXDecodeInvalid, /* 2915 */
	GLXDecodeInvalid, /* 2916 */
	GLXDecodeInvalid, /* 2917 */
	GLXDecodeInvalid, /* 2918 */
	GLXDecodeInvalid, /* 2919 */
	GLXDecodeInvalid, /* 2920 */
	GLXDecodeInvalid, /* 2921 */
	GLXDecodeInvalid, /* 2922 */
	GLXDecodeInvalid, /* 2923 */
	GLXDecodeInvalid, /* 2924 */
	GLXDecodeInvalid, /* 2925 */
	GLXDecodeInvalid, /* 2926 */
	GLXDecodeInvalid, /* 2927 */
	GLXDecodeInvalid, /* 2928 */
	GLXDecodeInvalid, /* 2929 */
	GLXDecodeInvalid, /* 2930 */
	GLXDecodeInvalid, /* 2931 */
	GLXDecodeInvalid, /* 2932 */
	GLXDecodeInvalid, /* 2933 */
	GLXDecodeInvalid, /* 2934 */
	GLXDecodeInvalid, /* 2935 */
	GLXDecodeInvalid, /* 2936 */
	GLXDecodeInvalid, /* 2937 */
	GLXDecodeInvalid, /* 2938 */
	GLXDecodeInvalid, /* 2939 */
	GLXDecodeInvalid, /* 2940 */
	GLXDecodeInvalid, /* 2941 */
	GLXDecodeInvalid, /* 2942 */
	GLXDecodeInvalid, /* 2943 */
	GLXDecodeInvalid, /* 2944 */
	GLXDecodeInvalid, /* 2945 */
	GLXDecodeInvalid, /* 2946 */
	GLXDecodeInvalid, /* 2947 */
	GLXDecodeInvalid, /* 2948 */
	GLXDecodeInvalid, /* 2949 */
	GLXDecodeInvalid, /* 2950 */
	GLXDecodeInvalid, /* 2951 */
	GLXDecodeInvalid, /* 2952 */
	GLXDecodeInvalid, /* 2953 */
	GLXDecodeInvalid, /* 2954 */
	GLXDecodeInvalid, /* 2955 */
	GLXDecodeInvalid, /* 2956 */
	GLXDecodeInvalid, /* 2957 */
	GLXDecodeInvalid, /* 2958 */
	GLXDecodeInvalid, /* 2959 */
	GLXDecodeInvalid, /* 2960 */
	GLXDecodeInvalid, /* 2961 */
	GLXDecodeInvalid, /* 2962 */
	GLXDecodeInvalid, /* 2963 */
	GLXDecodeInvalid, /* 2964 */
	GLXDecodeInvalid, /* 2965 */
	GLXDecodeInvalid, /* 2966 */
	GLXDecodeInvalid, /* 2967 */
	GLXDecodeInvalid, /* 2968 */
	GLXDecodeInvalid, /* 2969 */
	GLXDecodeInvalid, /* 2970 */
	GLXDecodeInvalid, /* 2971 */
	GLXDecodeInvalid, /* 2972 */
	GLXDecodeInvalid, /* 2973 */
	GLXDecodeInvalid, /* 2974 */
	GLXDecodeInvalid, /* 2975 */
	GLXDecodeInvalid, /* 2976 */
	GLXDecodeInvalid, /* 2977 */
	GLXDecodeInvalid, /* 2978 */
	GLXDecodeInvalid, /* 2979 */
	GLXDecodeInvalid, /* 2980 */
	GLXDecodeInvalid, /* 2981 */
	GLXDecodeInvalid, /* 2982 */
	GLXDecodeInvalid, /* 2983 */
	GLXDecodeInvalid, /* 2984 */
	GLXDecodeInvalid, /* 2985 */
	GLXDecodeInvalid, /* 2986 */
	GLXDecodeInvalid, /* 2987 */
	GLXDecodeInvalid, /* 2988 */
	GLXDecodeInvalid, /* 2989 */
	GLXDecodeInvalid, /* 2990 */
	GLXDecodeInvalid, /* 2991 */
	GLXDecodeInvalid, /* 2992 */
	GLXDecodeInvalid, /* 2993 */
	GLXDecodeInvalid, /* 2994 */
	GLXDecodeInvalid, /* 2995 */
	GLXDecodeInvalid, /* 2996 */
	GLXDecodeInvalid, /* 2997 */
	GLXDecodeInvalid, /* 2998 */
	GLXDecodeInvalid, /* 2999 */
	GLXDecodeInvalid, /* 3000 */
	GLXDecodeInvalid, /* 3001 */
	GLXDecodeInvalid, /* 3002 */
	GLXDecodeInvalid, /* 3003 */
	GLXDecodeInvalid, /* 3004 */
	GLXDecodeInvalid, /* 3005 */
	GLXDecodeInvalid, /* 3006 */
	GLXDecodeInvalid, /* 3007 */
	GLXDecodeInvalid, /* 3008 */
	GLXDecodeInvalid, /* 3009 */
	GLXDecodeInvalid, /* 3010 */
	GLXDecodeInvalid, /* 3011 */
	GLXDecodeInvalid, /* 3012 */
	GLXDecodeInvalid, /* 3013 */
	GLXDecodeInvalid, /* 3014 */
	GLXDecodeInvalid, /* 3015 */
	GLXDecodeInvalid, /* 3016 */
	GLXDecodeInvalid, /* 3017 */
	GLXDecodeInvalid, /* 3018 */
	GLXDecodeInvalid, /* 3019 */
	GLXDecodeInvalid, /* 3020 */
	GLXDecodeInvalid, /* 3021 */
	GLXDecodeInvalid, /* 3022 */
	GLXDecodeInvalid, /* 3023 */
	GLXDecodeInvalid, /* 3024 */
	GLXDecodeInvalid, /* 3025 */
	GLXDecodeInvalid, /* 3026 */
	GLXDecodeInvalid, /* 3027 */
	GLXDecodeInvalid, /* 3028 */
	GLXDecodeInvalid, /* 3029 */
	GLXDecodeInvalid, /* 3030 */
	GLXDecodeInvalid, /* 3031 */
	GLXDecodeInvalid, /* 3032 */
	GLXDecodeInvalid, /* 3033 */
	GLXDecodeInvalid, /* 3034 */
	GLXDecodeInvalid, /* 3035 */
	GLXDecodeInvalid, /* 3036 */
	GLXDecodeInvalid, /* 3037 */
	GLXDecodeInvalid, /* 3038 */
	GLXDecodeInvalid, /* 3039 */
	GLXDecodeInvalid, /* 3040 */
	GLXDecodeInvalid, /* 3041 */
	GLXDecodeInvalid, /* 3042 */
	GLXDecodeInvalid, /* 3043 */
	GLXDecodeInvalid, /* 3044 */
	GLXDecodeInvalid, /* 3045 */
	GLXDecodeInvalid, /* 3046 */
	GLXDecodeInvalid, /* 3047 */
	GLXDecodeInvalid, /* 3048 */
	GLXDecodeInvalid, /* 3049 */
	GLXDecodeInvalid, /* 3050 */
	GLXDecodeInvalid, /* 3051 */
	GLXDecodeInvalid, /* 3052 */
	GLXDecodeInvalid, /* 3053 */
	GLXDecodeInvalid, /* 3054 */
	GLXDecodeInvalid, /* 3055 */
	GLXDecodeInvalid, /* 3056 */
	GLXDecodeInvalid, /* 3057 */
	GLXDecodeInvalid, /* 3058 */
	GLXDecodeInvalid, /* 3059 */
	GLXDecodeInvalid, /* 3060 */
	GLXDecodeInvalid, /* 3061 */
	GLXDecodeInvalid, /* 3062 */
	GLXDecodeInvalid, /* 3063 */
	GLXDecodeInvalid, /* 3064 */
	GLXDecodeInvalid, /* 3065 */
	GLXDecodeInvalid, /* 3066 */
	GLXDecodeInvalid, /* 3067 */
	GLXDecodeInvalid, /* 3068 */
	GLXDecodeInvalid, /* 3069 */
	GLXDecodeInvalid, /* 3070 */
	GLXDecodeInvalid, /* 3071 */
	GLXDecodeInvalid, /* 3072 */
	GLXDecodeInvalid, /* 3073 */
	GLXDecodeInvalid, /* 3074 */
	GLXDecodeInvalid, /* 3075 */
	GLXDecodeInvalid, /* 3076 */
	GLXDecodeInvalid, /* 3077 */
	GLXDecodeInvalid, /* 3078 */
	GLXDecodeInvalid, /* 3079 */
	GLXDecodeInvalid, /* 3080 */
	GLXDecodeInvalid, /* 3081 */
	GLXDecodeInvalid, /* 3082 */
	GLXDecodeInvalid, /* 3083 */
	GLXDecodeInvalid, /* 3084 */
	GLXDecodeInvalid, /* 3085 */
	GLXDecodeInvalid, /* 3086 */
	GLXDecodeInvalid, /* 3087 */
	GLXDecodeInvalid, /* 3088 */
	GLXDecodeInvalid, /* 3089 */
	GLXDecodeInvalid, /* 3090 */
	GLXDecodeInvalid, /* 3091 */
	GLXDecodeInvalid, /* 3092 */
	GLXDecodeInvalid, /* 3093 */
	GLXDecodeInvalid, /* 3094 */
	GLXDecodeInvalid, /* 3095 */
	GLXDecodeInvalid, /* 3096 */
	GLXDecodeInvalid, /* 3097 */
	GLXDecodeInvalid, /* 3098 */
	GLXDecodeInvalid, /* 3099 */
	GLXDecodeInvalid, /* 3100 */
	GLXDecodeInvalid, /* 3101 */
	GLXDecodeInvalid, /* 3102 */
	GLXDecodeInvalid, /* 3103 */
	GLXDecodeInvalid, /* 3104 */
	GLXDecodeInvalid, /* 3105 */
	GLXDecodeInvalid, /* 3106 */
	GLXDecodeInvalid, /* 3107 */
	GLXDecodeInvalid, /* 3108 */
	GLXDecodeInvalid, /* 3109 */
	GLXDecodeInvalid, /* 3110 */
	GLXDecodeInvalid, /* 3111 */
	GLXDecodeInvalid, /* 3112 */
	GLXDecodeInvalid, /* 3113 */
	GLXDecodeInvalid, /* 3114 */
	GLXDecodeInvalid, /* 3115 */
	GLXDecodeInvalid, /* 3116 */
	GLXDecodeInvalid, /* 3117 */
	GLXDecodeInvalid, /* 3118 */
	GLXDecodeInvalid, /* 3119 */
	GLXDecodeInvalid, /* 3120 */
	GLXDecodeInvalid, /* 3121 */
	GLXDecodeInvalid, /* 3122 */
	GLXDecodeInvalid, /* 3123 */
	GLXDecodeInvalid, /* 3124 */
	GLXDecodeInvalid, /* 3125 */
	GLXDecodeInvalid, /* 3126 */
	GLXDecodeInvalid, /* 3127 */
	GLXDecodeInvalid, /* 3128 */
	GLXDecodeInvalid, /* 3129 */
	GLXDecodeInvalid, /* 3130 */
	GLXDecodeInvalid, /* 3131 */
	GLXDecodeInvalid, /* 3132 */
	GLXDecodeInvalid, /* 3133 */
	GLXDecodeInvalid, /* 3134 */
	GLXDecodeInvalid, /* 3135 */
	GLXDecodeInvalid, /* 3136 */
	GLXDecodeInvalid, /* 3137 */
	GLXDecodeInvalid, /* 3138 */
	GLXDecodeInvalid, /* 3139 */
	GLXDecodeInvalid, /* 3140 */
	GLXDecodeInvalid, /* 3141 */
	GLXDecodeInvalid, /* 3142 */
	GLXDecodeInvalid, /* 3143 */
	GLXDecodeInvalid, /* 3144 */
	GLXDecodeInvalid, /* 3145 */
	GLXDecodeInvalid, /* 3146 */
	GLXDecodeInvalid, /* 3147 */
	GLXDecodeInvalid, /* 3148 */
	GLXDecodeInvalid, /* 3149 */
	GLXDecodeInvalid, /* 3150 */
	GLXDecodeInvalid, /* 3151 */
	GLXDecodeInvalid, /* 3152 */
	GLXDecodeInvalid, /* 3153 */
	GLXDecodeInvalid, /* 3154 */
	GLXDecodeInvalid, /* 3155 */
	GLXDecodeInvalid, /* 3156 */
	GLXDecodeInvalid, /* 3157 */
	GLXDecodeInvalid, /* 3158 */
	GLXDecodeInvalid, /* 3159 */
	GLXDecodeInvalid, /* 3160 */
	GLXDecodeInvalid, /* 3161 */
	GLXDecodeInvalid, /* 3162 */
	GLXDecodeInvalid, /* 3163 */
	GLXDecodeInvalid, /* 3164 */
	GLXDecodeInvalid, /* 3165 */
	GLXDecodeInvalid, /* 3166 */
	GLXDecodeInvalid, /* 3167 */
	GLXDecodeInvalid, /* 3168 */
	GLXDecodeInvalid, /* 3169 */
	GLXDecodeInvalid, /* 3170 */
	GLXDecodeInvalid, /* 3171 */
	GLXDecodeInvalid, /* 3172 */
	GLXDecodeInvalid, /* 3173 */
	GLXDecodeInvalid, /* 3174 */
	GLXDecodeInvalid, /* 3175 */
	GLXDecodeInvalid, /* 3176 */
	GLXDecodeInvalid, /* 3177 */
	GLXDecodeInvalid, /* 3178 */
	GLXDecodeInvalid, /* 3179 */
	GLXDecodeInvalid, /* 3180 */
	GLXDecodeInvalid, /* 3181 */
	GLXDecodeInvalid, /* 3182 */
	GLXDecodeInvalid, /* 3183 */
	GLXDecodeInvalid, /* 3184 */
	GLXDecodeInvalid, /* 3185 */
	GLXDecodeInvalid, /* 3186 */
	GLXDecodeInvalid, /* 3187 */
	GLXDecodeInvalid, /* 3188 */
	GLXDecodeInvalid, /* 3189 */
	GLXDecodeInvalid, /* 3190 */
	GLXDecodeInvalid, /* 3191 */
	GLXDecodeInvalid, /* 3192 */
	GLXDecodeInvalid, /* 3193 */
	GLXDecodeInvalid, /* 3194 */
	GLXDecodeInvalid, /* 3195 */
	GLXDecodeInvalid, /* 3196 */
	GLXDecodeInvalid, /* 3197 */
	GLXDecodeInvalid, /* 3198 */
	GLXDecodeInvalid, /* 3199 */
	GLXDecodeInvalid, /* 3200 */
	GLXDecodeInvalid, /* 3201 */
	GLXDecodeInvalid, /* 3202 */
	GLXDecodeInvalid, /* 3203 */
	GLXDecodeInvalid, /* 3204 */
	GLXDecodeInvalid, /* 3205 */
	GLXDecodeInvalid, /* 3206 */
	GLXDecodeInvalid, /* 3207 */
	GLXDecodeInvalid, /* 3208 */
	GLXDecodeInvalid, /* 3209 */
	GLXDecodeInvalid, /* 3210 */
	GLXDecodeInvalid, /* 3211 */
	GLXDecodeInvalid, /* 3212 */
	GLXDecodeInvalid, /* 3213 */
	GLXDecodeInvalid, /* 3214 */
	GLXDecodeInvalid, /* 3215 */
	GLXDecodeInvalid, /* 3216 */
	GLXDecodeInvalid, /* 3217 */
	GLXDecodeInvalid, /* 3218 */
	GLXDecodeInvalid, /* 3219 */
	GLXDecodeInvalid, /* 3220 */
	GLXDecodeInvalid, /* 3221 */
	GLXDecodeInvalid, /* 3222 */
	GLXDecodeInvalid, /* 3223 */
	GLXDecodeInvalid, /* 3224 */
	GLXDecodeInvalid, /* 3225 */
	GLXDecodeInvalid, /* 3226 */
	GLXDecodeInvalid, /* 3227 */
	GLXDecodeInvalid, /* 3228 */
	GLXDecodeInvalid, /* 3229 */
	GLXDecodeInvalid, /* 3230 */
	GLXDecodeInvalid, /* 3231 */
	GLXDecodeInvalid, /* 3232 */
	GLXDecodeInvalid, /* 3233 */
	GLXDecodeInvalid, /* 3234 */
	GLXDecodeInvalid, /* 3235 */
	GLXDecodeInvalid, /* 3236 */
	GLXDecodeInvalid, /* 3237 */
	GLXDecodeInvalid, /* 3238 */
	GLXDecodeInvalid, /* 3239 */
	GLXDecodeInvalid, /* 3240 */
	GLXDecodeInvalid, /* 3241 */
	GLXDecodeInvalid, /* 3242 */
	GLXDecodeInvalid, /* 3243 */
	GLXDecodeInvalid, /* 3244 */
	GLXDecodeInvalid, /* 3245 */
	GLXDecodeInvalid, /* 3246 */
	GLXDecodeInvalid, /* 3247 */
	GLXDecodeInvalid, /* 3248 */
	GLXDecodeInvalid, /* 3249 */
	GLXDecodeInvalid, /* 3250 */
	GLXDecodeInvalid, /* 3251 */
	GLXDecodeInvalid, /* 3252 */
	GLXDecodeInvalid, /* 3253 */
	GLXDecodeInvalid, /* 3254 */
	GLXDecodeInvalid, /* 3255 */
	GLXDecodeInvalid, /* 3256 */
	GLXDecodeInvalid, /* 3257 */
	GLXDecodeInvalid, /* 3258 */
	GLXDecodeInvalid, /* 3259 */
	GLXDecodeInvalid, /* 3260 */
	GLXDecodeInvalid, /* 3261 */
	GLXDecodeInvalid, /* 3262 */
	GLXDecodeInvalid, /* 3263 */
	GLXDecodeInvalid, /* 3264 */
	GLXDecodeInvalid, /* 3265 */
	GLXDecodeInvalid, /* 3266 */
	GLXDecodeInvalid, /* 3267 */
	GLXDecodeInvalid, /* 3268 */
	GLXDecodeInvalid, /* 3269 */
	GLXDecodeInvalid, /* 3270 */
	GLXDecodeInvalid, /* 3271 */
	GLXDecodeInvalid, /* 3272 */
	GLXDecodeInvalid, /* 3273 */
	GLXDecodeInvalid, /* 3274 */
	GLXDecodeInvalid, /* 3275 */
	GLXDecodeInvalid, /* 3276 */
	GLXDecodeInvalid, /* 3277 */
	GLXDecodeInvalid, /* 3278 */
	GLXDecodeInvalid, /* 3279 */
	GLXDecodeInvalid, /* 3280 */
	GLXDecodeInvalid, /* 3281 */
	GLXDecodeInvalid, /* 3282 */
	GLXDecodeInvalid, /* 3283 */
	GLXDecodeInvalid, /* 3284 */
	GLXDecodeInvalid, /* 3285 */
	GLXDecodeInvalid, /* 3286 */
	GLXDecodeInvalid, /* 3287 */
	GLXDecodeInvalid, /* 3288 */
	GLXDecodeInvalid, /* 3289 */
	GLXDecodeInvalid, /* 3290 */
	GLXDecodeInvalid, /* 3291 */
	GLXDecodeInvalid, /* 3292 */
	GLXDecodeInvalid, /* 3293 */
	GLXDecodeInvalid, /* 3294 */
	GLXDecodeInvalid, /* 3295 */
	GLXDecodeInvalid, /* 3296 */
	GLXDecodeInvalid, /* 3297 */
	GLXDecodeInvalid, /* 3298 */
	GLXDecodeInvalid, /* 3299 */
	GLXDecodeInvalid, /* 3300 */
	GLXDecodeInvalid, /* 3301 */
	GLXDecodeInvalid, /* 3302 */
	GLXDecodeInvalid, /* 3303 */
	GLXDecodeInvalid, /* 3304 */
	GLXDecodeInvalid, /* 3305 */
	GLXDecodeInvalid, /* 3306 */
	GLXDecodeInvalid, /* 3307 */
	GLXDecodeInvalid, /* 3308 */
	GLXDecodeInvalid, /* 3309 */
	GLXDecodeInvalid, /* 3310 */
	GLXDecodeInvalid, /* 3311 */
	GLXDecodeInvalid, /* 3312 */
	GLXDecodeInvalid, /* 3313 */
	GLXDecodeInvalid, /* 3314 */
	GLXDecodeInvalid, /* 3315 */
	GLXDecodeInvalid, /* 3316 */
	GLXDecodeInvalid, /* 3317 */
	GLXDecodeInvalid, /* 3318 */
	GLXDecodeInvalid, /* 3319 */
	GLXDecodeInvalid, /* 3320 */
	GLXDecodeInvalid, /* 3321 */
	GLXDecodeInvalid, /* 3322 */
	GLXDecodeInvalid, /* 3323 */
	GLXDecodeInvalid, /* 3324 */
	GLXDecodeInvalid, /* 3325 */
	GLXDecodeInvalid, /* 3326 */
	GLXDecodeInvalid, /* 3327 */
	GLXDecodeInvalid, /* 3328 */
	GLXDecodeInvalid, /* 3329 */
	GLXDecodeInvalid, /* 3330 */
	GLXDecodeInvalid, /* 3331 */
	GLXDecodeInvalid, /* 3332 */
	GLXDecodeInvalid, /* 3333 */
	GLXDecodeInvalid, /* 3334 */
	GLXDecodeInvalid, /* 3335 */
	GLXDecodeInvalid, /* 3336 */
	GLXDecodeInvalid, /* 3337 */
	GLXDecodeInvalid, /* 3338 */
	GLXDecodeInvalid, /* 3339 */
	GLXDecodeInvalid, /* 3340 */
	GLXDecodeInvalid, /* 3341 */
	GLXDecodeInvalid, /* 3342 */
	GLXDecodeInvalid, /* 3343 */
	GLXDecodeInvalid, /* 3344 */
	GLXDecodeInvalid, /* 3345 */
	GLXDecodeInvalid, /* 3346 */
	GLXDecodeInvalid, /* 3347 */
	GLXDecodeInvalid, /* 3348 */
	GLXDecodeInvalid, /* 3349 */
	GLXDecodeInvalid, /* 3350 */
	GLXDecodeInvalid, /* 3351 */
	GLXDecodeInvalid, /* 3352 */
	GLXDecodeInvalid, /* 3353 */
	GLXDecodeInvalid, /* 3354 */
	GLXDecodeInvalid, /* 3355 */
	GLXDecodeInvalid, /* 3356 */
	GLXDecodeInvalid, /* 3357 */
	GLXDecodeInvalid, /* 3358 */
	GLXDecodeInvalid, /* 3359 */
	GLXDecodeInvalid, /* 3360 */
	GLXDecodeInvalid, /* 3361 */
	GLXDecodeInvalid, /* 3362 */
	GLXDecodeInvalid, /* 3363 */
	GLXDecodeInvalid, /* 3364 */
	GLXDecodeInvalid, /* 3365 */
	GLXDecodeInvalid, /* 3366 */
	GLXDecodeInvalid, /* 3367 */
	GLXDecodeInvalid, /* 3368 */
	GLXDecodeInvalid, /* 3369 */
	GLXDecodeInvalid, /* 3370 */
	GLXDecodeInvalid, /* 3371 */
	GLXDecodeInvalid, /* 3372 */
	GLXDecodeInvalid, /* 3373 */
	GLXDecodeInvalid, /* 3374 */
	GLXDecodeInvalid, /* 3375 */
	GLXDecodeInvalid, /* 3376 */
	GLXDecodeInvalid, /* 3377 */
	GLXDecodeInvalid, /* 3378 */
	GLXDecodeInvalid, /* 3379 */
	GLXDecodeInvalid, /* 3380 */
	GLXDecodeInvalid, /* 3381 */
	GLXDecodeInvalid, /* 3382 */
	GLXDecodeInvalid, /* 3383 */
	GLXDecodeInvalid, /* 3384 */
	GLXDecodeInvalid, /* 3385 */
	GLXDecodeInvalid, /* 3386 */
	GLXDecodeInvalid, /* 3387 */
	GLXDecodeInvalid, /* 3388 */
	GLXDecodeInvalid, /* 3389 */
	GLXDecodeInvalid, /* 3390 */
	GLXDecodeInvalid, /* 3391 */
	GLXDecodeInvalid, /* 3392 */
	GLXDecodeInvalid, /* 3393 */
	GLXDecodeInvalid, /* 3394 */
	GLXDecodeInvalid, /* 3395 */
	GLXDecodeInvalid, /* 3396 */
	GLXDecodeInvalid, /* 3397 */
	GLXDecodeInvalid, /* 3398 */
	GLXDecodeInvalid, /* 3399 */
	GLXDecodeInvalid, /* 3400 */
	GLXDecodeInvalid, /* 3401 */
	GLXDecodeInvalid, /* 3402 */
	GLXDecodeInvalid, /* 3403 */
	GLXDecodeInvalid, /* 3404 */
	GLXDecodeInvalid, /* 3405 */
	GLXDecodeInvalid, /* 3406 */
	GLXDecodeInvalid, /* 3407 */
	GLXDecodeInvalid, /* 3408 */
	GLXDecodeInvalid, /* 3409 */
	GLXDecodeInvalid, /* 3410 */
	GLXDecodeInvalid, /* 3411 */
	GLXDecodeInvalid, /* 3412 */
	GLXDecodeInvalid, /* 3413 */
	GLXDecodeInvalid, /* 3414 */
	GLXDecodeInvalid, /* 3415 */
	GLXDecodeInvalid, /* 3416 */
	GLXDecodeInvalid, /* 3417 */
	GLXDecodeInvalid, /* 3418 */
	GLXDecodeInvalid, /* 3419 */
	GLXDecodeInvalid, /* 3420 */
	GLXDecodeInvalid, /* 3421 */
	GLXDecodeInvalid, /* 3422 */
	GLXDecodeInvalid, /* 3423 */
	GLXDecodeInvalid, /* 3424 */
	GLXDecodeInvalid, /* 3425 */
	GLXDecodeInvalid, /* 3426 */
	GLXDecodeInvalid, /* 3427 */
	GLXDecodeInvalid, /* 3428 */
	GLXDecodeInvalid, /* 3429 */
	GLXDecodeInvalid, /* 3430 */
	GLXDecodeInvalid, /* 3431 */
	GLXDecodeInvalid, /* 3432 */
	GLXDecodeInvalid, /* 3433 */
	GLXDecodeInvalid, /* 3434 */
	GLXDecodeInvalid, /* 3435 */
	GLXDecodeInvalid, /* 3436 */
	GLXDecodeInvalid, /* 3437 */
	GLXDecodeInvalid, /* 3438 */
	GLXDecodeInvalid, /* 3439 */
	GLXDecodeInvalid, /* 3440 */
	GLXDecodeInvalid, /* 3441 */
	GLXDecodeInvalid, /* 3442 */
	GLXDecodeInvalid, /* 3443 */
	GLXDecodeInvalid, /* 3444 */
	GLXDecodeInvalid, /* 3445 */
	GLXDecodeInvalid, /* 3446 */
	GLXDecodeInvalid, /* 3447 */
	GLXDecodeInvalid, /* 3448 */
	GLXDecodeInvalid, /* 3449 */
	GLXDecodeInvalid, /* 3450 */
	GLXDecodeInvalid, /* 3451 */
	GLXDecodeInvalid, /* 3452 */
	GLXDecodeInvalid, /* 3453 */
	GLXDecodeInvalid, /* 3454 */
	GLXDecodeInvalid, /* 3455 */
	GLXDecodeInvalid, /* 3456 */
	GLXDecodeInvalid, /* 3457 */
	GLXDecodeInvalid, /* 3458 */
	GLXDecodeInvalid, /* 3459 */
	GLXDecodeInvalid, /* 3460 */
	GLXDecodeInvalid, /* 3461 */
	GLXDecodeInvalid, /* 3462 */
	GLXDecodeInvalid, /* 3463 */
	GLXDecodeInvalid, /* 3464 */
	GLXDecodeInvalid, /* 3465 */
	GLXDecodeInvalid, /* 3466 */
	GLXDecodeInvalid, /* 3467 */
	GLXDecodeInvalid, /* 3468 */
	GLXDecodeInvalid, /* 3469 */
	GLXDecodeInvalid, /* 3470 */
	GLXDecodeInvalid, /* 3471 */
	GLXDecodeInvalid, /* 3472 */
	GLXDecodeInvalid, /* 3473 */
	GLXDecodeInvalid, /* 3474 */
	GLXDecodeInvalid, /* 3475 */
	GLXDecodeInvalid, /* 3476 */
	GLXDecodeInvalid, /* 3477 */
	GLXDecodeInvalid, /* 3478 */
	GLXDecodeInvalid, /* 3479 */
	GLXDecodeInvalid, /* 3480 */
	GLXDecodeInvalid, /* 3481 */
	GLXDecodeInvalid, /* 3482 */
	GLXDecodeInvalid, /* 3483 */
	GLXDecodeInvalid, /* 3484 */
	GLXDecodeInvalid, /* 3485 */
	GLXDecodeInvalid, /* 3486 */
	GLXDecodeInvalid, /* 3487 */
	GLXDecodeInvalid, /* 3488 */
	GLXDecodeInvalid, /* 3489 */
	GLXDecodeInvalid, /* 3490 */
	GLXDecodeInvalid, /* 3491 */
	GLXDecodeInvalid, /* 3492 */
	GLXDecodeInvalid, /* 3493 */
	GLXDecodeInvalid, /* 3494 */
	GLXDecodeInvalid, /* 3495 */
	GLXDecodeInvalid, /* 3496 */
	GLXDecodeInvalid, /* 3497 */
	GLXDecodeInvalid, /* 3498 */
	GLXDecodeInvalid, /* 3499 */
	GLXDecodeInvalid, /* 3500 */
	GLXDecodeInvalid, /* 3501 */
	GLXDecodeInvalid, /* 3502 */
	GLXDecodeInvalid, /* 3503 */
	GLXDecodeInvalid, /* 3504 */
	GLXDecodeInvalid, /* 3505 */
	GLXDecodeInvalid, /* 3506 */
	GLXDecodeInvalid, /* 3507 */
	GLXDecodeInvalid, /* 3508 */
	GLXDecodeInvalid, /* 3509 */
	GLXDecodeInvalid, /* 3510 */
	GLXDecodeInvalid, /* 3511 */
	GLXDecodeInvalid, /* 3512 */
	GLXDecodeInvalid, /* 3513 */
	GLXDecodeInvalid, /* 3514 */
	GLXDecodeInvalid, /* 3515 */
	GLXDecodeInvalid, /* 3516 */
	GLXDecodeInvalid, /* 3517 */
	GLXDecodeInvalid, /* 3518 */
	GLXDecodeInvalid, /* 3519 */
	GLXDecodeInvalid, /* 3520 */
	GLXDecodeInvalid, /* 3521 */
	GLXDecodeInvalid, /* 3522 */
	GLXDecodeInvalid, /* 3523 */
	GLXDecodeInvalid, /* 3524 */
	GLXDecodeInvalid, /* 3525 */
	GLXDecodeInvalid, /* 3526 */
	GLXDecodeInvalid, /* 3527 */
	GLXDecodeInvalid, /* 3528 */
	GLXDecodeInvalid, /* 3529 */
	GLXDecodeInvalid, /* 3530 */
	GLXDecodeInvalid, /* 3531 */
	GLXDecodeInvalid, /* 3532 */
	GLXDecodeInvalid, /* 3533 */
	GLXDecodeInvalid, /* 3534 */
	GLXDecodeInvalid, /* 3535 */
	GLXDecodeInvalid, /* 3536 */
	GLXDecodeInvalid, /* 3537 */
	GLXDecodeInvalid, /* 3538 */
	GLXDecodeInvalid, /* 3539 */
	GLXDecodeInvalid, /* 3540 */
	GLXDecodeInvalid, /* 3541 */
	GLXDecodeInvalid, /* 3542 */
	GLXDecodeInvalid, /* 3543 */
	GLXDecodeInvalid, /* 3544 */
	GLXDecodeInvalid, /* 3545 */
	GLXDecodeInvalid, /* 3546 */
	GLXDecodeInvalid, /* 3547 */
	GLXDecodeInvalid, /* 3548 */
	GLXDecodeInvalid, /* 3549 */
	GLXDecodeInvalid, /* 3550 */
	GLXDecodeInvalid, /* 3551 */
	GLXDecodeInvalid, /* 3552 */
	GLXDecodeInvalid, /* 3553 */
	GLXDecodeInvalid, /* 3554 */
	GLXDecodeInvalid, /* 3555 */
	GLXDecodeInvalid, /* 3556 */
	GLXDecodeInvalid, /* 3557 */
	GLXDecodeInvalid, /* 3558 */
	GLXDecodeInvalid, /* 3559 */
	GLXDecodeInvalid, /* 3560 */
	GLXDecodeInvalid, /* 3561 */
	GLXDecodeInvalid, /* 3562 */
	GLXDecodeInvalid, /* 3563 */
	GLXDecodeInvalid, /* 3564 */
	GLXDecodeInvalid, /* 3565 */
	GLXDecodeInvalid, /* 3566 */
	GLXDecodeInvalid, /* 3567 */
	GLXDecodeInvalid, /* 3568 */
	GLXDecodeInvalid, /* 3569 */
	GLXDecodeInvalid, /* 3570 */
	GLXDecodeInvalid, /* 3571 */
	GLXDecodeInvalid, /* 3572 */
	GLXDecodeInvalid, /* 3573 */
	GLXDecodeInvalid, /* 3574 */
	GLXDecodeInvalid, /* 3575 */
	GLXDecodeInvalid, /* 3576 */
	GLXDecodeInvalid, /* 3577 */
	GLXDecodeInvalid, /* 3578 */
	GLXDecodeInvalid, /* 3579 */
	GLXDecodeInvalid, /* 3580 */
	GLXDecodeInvalid, /* 3581 */
	GLXDecodeInvalid, /* 3582 */
	GLXDecodeInvalid, /* 3583 */
	GLXDecodeInvalid, /* 3584 */
	GLXDecodeInvalid, /* 3585 */
	GLXDecodeInvalid, /* 3586 */
	GLXDecodeInvalid, /* 3587 */
	GLXDecodeInvalid, /* 3588 */
	GLXDecodeInvalid, /* 3589 */
	GLXDecodeInvalid, /* 3590 */
	GLXDecodeInvalid, /* 3591 */
	GLXDecodeInvalid, /* 3592 */
	GLXDecodeInvalid, /* 3593 */
	GLXDecodeInvalid, /* 3594 */
	GLXDecodeInvalid, /* 3595 */
	GLXDecodeInvalid, /* 3596 */
	GLXDecodeInvalid, /* 3597 */
	GLXDecodeInvalid, /* 3598 */
	GLXDecodeInvalid, /* 3599 */
	GLXDecodeInvalid, /* 3600 */
	GLXDecodeInvalid, /* 3601 */
	GLXDecodeInvalid, /* 3602 */
	GLXDecodeInvalid, /* 3603 */
	GLXDecodeInvalid, /* 3604 */
	GLXDecodeInvalid, /* 3605 */
	GLXDecodeInvalid, /* 3606 */
	GLXDecodeInvalid, /* 3607 */
	GLXDecodeInvalid, /* 3608 */
	GLXDecodeInvalid, /* 3609 */
	GLXDecodeInvalid, /* 3610 */
	GLXDecodeInvalid, /* 3611 */
	GLXDecodeInvalid, /* 3612 */
	GLXDecodeInvalid, /* 3613 */
	GLXDecodeInvalid, /* 3614 */
	GLXDecodeInvalid, /* 3615 */
	GLXDecodeInvalid, /* 3616 */
	GLXDecodeInvalid, /* 3617 */
	GLXDecodeInvalid, /* 3618 */
	GLXDecodeInvalid, /* 3619 */
	GLXDecodeInvalid, /* 3620 */
	GLXDecodeInvalid, /* 3621 */
	GLXDecodeInvalid, /* 3622 */
	GLXDecodeInvalid, /* 3623 */
	GLXDecodeInvalid, /* 3624 */
	GLXDecodeInvalid, /* 3625 */
	GLXDecodeInvalid, /* 3626 */
	GLXDecodeInvalid, /* 3627 */
	GLXDecodeInvalid, /* 3628 */
	GLXDecodeInvalid, /* 3629 */
	GLXDecodeInvalid, /* 3630 */
	GLXDecodeInvalid, /* 3631 */
	GLXDecodeInvalid, /* 3632 */
	GLXDecodeInvalid, /* 3633 */
	GLXDecodeInvalid, /* 3634 */
	GLXDecodeInvalid, /* 3635 */
	GLXDecodeInvalid, /* 3636 */
	GLXDecodeInvalid, /* 3637 */
	GLXDecodeInvalid, /* 3638 */
	GLXDecodeInvalid, /* 3639 */
	GLXDecodeInvalid, /* 3640 */
	GLXDecodeInvalid, /* 3641 */
	GLXDecodeInvalid, /* 3642 */
	GLXDecodeInvalid, /* 3643 */
	GLXDecodeInvalid, /* 3644 */
	GLXDecodeInvalid, /* 3645 */
	GLXDecodeInvalid, /* 3646 */
	GLXDecodeInvalid, /* 3647 */
	GLXDecodeInvalid, /* 3648 */
	GLXDecodeInvalid, /* 3649 */
	GLXDecodeInvalid, /* 3650 */
	GLXDecodeInvalid, /* 3651 */
	GLXDecodeInvalid, /* 3652 */
	GLXDecodeInvalid, /* 3653 */
	GLXDecodeInvalid, /* 3654 */
	GLXDecodeInvalid, /* 3655 */
	GLXDecodeInvalid, /* 3656 */
	GLXDecodeInvalid, /* 3657 */
	GLXDecodeInvalid, /* 3658 */
	GLXDecodeInvalid, /* 3659 */
	GLXDecodeInvalid, /* 3660 */
	GLXDecodeInvalid, /* 3661 */
	GLXDecodeInvalid, /* 3662 */
	GLXDecodeInvalid, /* 3663 */
	GLXDecodeInvalid, /* 3664 */
	GLXDecodeInvalid, /* 3665 */
	GLXDecodeInvalid, /* 3666 */
	GLXDecodeInvalid, /* 3667 */
	GLXDecodeInvalid, /* 3668 */
	GLXDecodeInvalid, /* 3669 */
	GLXDecodeInvalid, /* 3670 */
	GLXDecodeInvalid, /* 3671 */
	GLXDecodeInvalid, /* 3672 */
	GLXDecodeInvalid, /* 3673 */
	GLXDecodeInvalid, /* 3674 */
	GLXDecodeInvalid, /* 3675 */
	GLXDecodeInvalid, /* 3676 */
	GLXDecodeInvalid, /* 3677 */
	GLXDecodeInvalid, /* 3678 */
	GLXDecodeInvalid, /* 3679 */
	GLXDecodeInvalid, /* 3680 */
	GLXDecodeInvalid, /* 3681 */
	GLXDecodeInvalid, /* 3682 */
	GLXDecodeInvalid, /* 3683 */
	GLXDecodeInvalid, /* 3684 */
	GLXDecodeInvalid, /* 3685 */
	GLXDecodeInvalid, /* 3686 */
	GLXDecodeInvalid, /* 3687 */
	GLXDecodeInvalid, /* 3688 */
	GLXDecodeInvalid, /* 3689 */
	GLXDecodeInvalid, /* 3690 */
	GLXDecodeInvalid, /* 3691 */
	GLXDecodeInvalid, /* 3692 */
	GLXDecodeInvalid, /* 3693 */
	GLXDecodeInvalid, /* 3694 */
	GLXDecodeInvalid, /* 3695 */
	GLXDecodeInvalid, /* 3696 */
	GLXDecodeInvalid, /* 3697 */
	GLXDecodeInvalid, /* 3698 */
	GLXDecodeInvalid, /* 3699 */
	GLXDecodeInvalid, /* 3700 */
	GLXDecodeInvalid, /* 3701 */
	GLXDecodeInvalid, /* 3702 */
	GLXDecodeInvalid, /* 3703 */
	GLXDecodeInvalid, /* 3704 */
	GLXDecodeInvalid, /* 3705 */
	GLXDecodeInvalid, /* 3706 */
	GLXDecodeInvalid, /* 3707 */
	GLXDecodeInvalid, /* 3708 */
	GLXDecodeInvalid, /* 3709 */
	GLXDecodeInvalid, /* 3710 */
	GLXDecodeInvalid, /* 3711 */
	GLXDecodeInvalid, /* 3712 */
	GLXDecodeInvalid, /* 3713 */
	GLXDecodeInvalid, /* 3714 */
	GLXDecodeInvalid, /* 3715 */
	GLXDecodeInvalid, /* 3716 */
	GLXDecodeInvalid, /* 3717 */
	GLXDecodeInvalid, /* 3718 */
	GLXDecodeInvalid, /* 3719 */
	GLXDecodeInvalid, /* 3720 */
	GLXDecodeInvalid, /* 3721 */
	GLXDecodeInvalid, /* 3722 */
	GLXDecodeInvalid, /* 3723 */
	GLXDecodeInvalid, /* 3724 */
	GLXDecodeInvalid, /* 3725 */
	GLXDecodeInvalid, /* 3726 */
	GLXDecodeInvalid, /* 3727 */
	GLXDecodeInvalid, /* 3728 */
	GLXDecodeInvalid, /* 3729 */
	GLXDecodeInvalid, /* 3730 */
	GLXDecodeInvalid, /* 3731 */
	GLXDecodeInvalid, /* 3732 */
	GLXDecodeInvalid, /* 3733 */
	GLXDecodeInvalid, /* 3734 */
	GLXDecodeInvalid, /* 3735 */
	GLXDecodeInvalid, /* 3736 */
	GLXDecodeInvalid, /* 3737 */
	GLXDecodeInvalid, /* 3738 */
	GLXDecodeInvalid, /* 3739 */
	GLXDecodeInvalid, /* 3740 */
	GLXDecodeInvalid, /* 3741 */
	GLXDecodeInvalid, /* 3742 */
	GLXDecodeInvalid, /* 3743 */
	GLXDecodeInvalid, /* 3744 */
	GLXDecodeInvalid, /* 3745 */
	GLXDecodeInvalid, /* 3746 */
	GLXDecodeInvalid, /* 3747 */
	GLXDecodeInvalid, /* 3748 */
	GLXDecodeInvalid, /* 3749 */
	GLXDecodeInvalid, /* 3750 */
	GLXDecodeInvalid, /* 3751 */
	GLXDecodeInvalid, /* 3752 */
	GLXDecodeInvalid, /* 3753 */
	GLXDecodeInvalid, /* 3754 */
	GLXDecodeInvalid, /* 3755 */
	GLXDecodeInvalid, /* 3756 */
	GLXDecodeInvalid, /* 3757 */
	GLXDecodeInvalid, /* 3758 */
	GLXDecodeInvalid, /* 3759 */
	GLXDecodeInvalid, /* 3760 */
	GLXDecodeInvalid, /* 3761 */
	GLXDecodeInvalid, /* 3762 */
	GLXDecodeInvalid, /* 3763 */
	GLXDecodeInvalid, /* 3764 */
	GLXDecodeInvalid, /* 3765 */
	GLXDecodeInvalid, /* 3766 */
	GLXDecodeInvalid, /* 3767 */
	GLXDecodeInvalid, /* 3768 */
	GLXDecodeInvalid, /* 3769 */
	GLXDecodeInvalid, /* 3770 */
	GLXDecodeInvalid, /* 3771 */
	GLXDecodeInvalid, /* 3772 */
	GLXDecodeInvalid, /* 3773 */
	GLXDecodeInvalid, /* 3774 */
	GLXDecodeInvalid, /* 3775 */
	GLXDecodeInvalid, /* 3776 */
	GLXDecodeInvalid, /* 3777 */
	GLXDecodeInvalid, /* 3778 */
	GLXDecodeInvalid, /* 3779 */
	GLXDecodeInvalid, /* 3780 */
	GLXDecodeInvalid, /* 3781 */
	GLXDecodeInvalid, /* 3782 */
	GLXDecodeInvalid, /* 3783 */
	GLXDecodeInvalid, /* 3784 */
	GLXDecodeInvalid, /* 3785 */
	GLXDecodeInvalid, /* 3786 */
	GLXDecodeInvalid, /* 3787 */
	GLXDecodeInvalid, /* 3788 */
	GLXDecodeInvalid, /* 3789 */
	GLXDecodeInvalid, /* 3790 */
	GLXDecodeInvalid, /* 3791 */
	GLXDecodeInvalid, /* 3792 */
	GLXDecodeInvalid, /* 3793 */
	GLXDecodeInvalid, /* 3794 */
	GLXDecodeInvalid, /* 3795 */
	GLXDecodeInvalid, /* 3796 */
	GLXDecodeInvalid, /* 3797 */
	GLXDecodeInvalid, /* 3798 */
	GLXDecodeInvalid, /* 3799 */
	GLXDecodeInvalid, /* 3800 */
	GLXDecodeInvalid, /* 3801 */
	GLXDecodeInvalid, /* 3802 */
	GLXDecodeInvalid, /* 3803 */
	GLXDecodeInvalid, /* 3804 */
	GLXDecodeInvalid, /* 3805 */
	GLXDecodeInvalid, /* 3806 */
	GLXDecodeInvalid, /* 3807 */
	GLXDecodeInvalid, /* 3808 */
	GLXDecodeInvalid, /* 3809 */
	GLXDecodeInvalid, /* 3810 */
	GLXDecodeInvalid, /* 3811 */
	GLXDecodeInvalid, /* 3812 */
	GLXDecodeInvalid, /* 3813 */
	GLXDecodeInvalid, /* 3814 */
	GLXDecodeInvalid, /* 3815 */
	GLXDecodeInvalid, /* 3816 */
	GLXDecodeInvalid, /* 3817 */
	GLXDecodeInvalid, /* 3818 */
	GLXDecodeInvalid, /* 3819 */
	GLXDecodeInvalid, /* 3820 */
	GLXDecodeInvalid, /* 3821 */
	GLXDecodeInvalid, /* 3822 */
	GLXDecodeInvalid, /* 3823 */
	GLXDecodeInvalid, /* 3824 */
	GLXDecodeInvalid, /* 3825 */
	GLXDecodeInvalid, /* 3826 */
	GLXDecodeInvalid, /* 3827 */
	GLXDecodeInvalid, /* 3828 */
	GLXDecodeInvalid, /* 3829 */
	GLXDecodeInvalid, /* 3830 */
	GLXDecodeInvalid, /* 3831 */
	GLXDecodeInvalid, /* 3832 */
	GLXDecodeInvalid, /* 3833 */
	GLXDecodeInvalid, /* 3834 */
	GLXDecodeInvalid, /* 3835 */
	GLXDecodeInvalid, /* 3836 */
	GLXDecodeInvalid, /* 3837 */
	GLXDecodeInvalid, /* 3838 */
	GLXDecodeInvalid, /* 3839 */
	GLXDecodeInvalid, /* 3840 */
	GLXDecodeInvalid, /* 3841 */
	GLXDecodeInvalid, /* 3842 */
	GLXDecodeInvalid, /* 3843 */
	GLXDecodeInvalid, /* 3844 */
	GLXDecodeInvalid, /* 3845 */
	GLXDecodeInvalid, /* 3846 */
	GLXDecodeInvalid, /* 3847 */
	GLXDecodeInvalid, /* 3848 */
	GLXDecodeInvalid, /* 3849 */
	GLXDecodeInvalid, /* 3850 */
	GLXDecodeInvalid, /* 3851 */
	GLXDecodeInvalid, /* 3852 */
	GLXDecodeInvalid, /* 3853 */
	GLXDecodeInvalid, /* 3854 */
	GLXDecodeInvalid, /* 3855 */
	GLXDecodeInvalid, /* 3856 */
	GLXDecodeInvalid, /* 3857 */
	GLXDecodeInvalid, /* 3858 */
	GLXDecodeInvalid, /* 3859 */
	GLXDecodeInvalid, /* 3860 */
	GLXDecodeInvalid, /* 3861 */
	GLXDecodeInvalid, /* 3862 */
	GLXDecodeInvalid, /* 3863 */
	GLXDecodeInvalid, /* 3864 */
	GLXDecodeInvalid, /* 3865 */
	GLXDecodeInvalid, /* 3866 */
	GLXDecodeInvalid, /* 3867 */
	GLXDecodeInvalid, /* 3868 */
	GLXDecodeInvalid, /* 3869 */
	GLXDecodeInvalid, /* 3870 */
	GLXDecodeInvalid, /* 3871 */
	GLXDecodeInvalid, /* 3872 */
	GLXDecodeInvalid, /* 3873 */
	GLXDecodeInvalid, /* 3874 */
	GLXDecodeInvalid, /* 3875 */
	GLXDecodeInvalid, /* 3876 */
	GLXDecodeInvalid, /* 3877 */
	GLXDecodeInvalid, /* 3878 */
	GLXDecodeInvalid, /* 3879 */
	GLXDecodeInvalid, /* 3880 */
	GLXDecodeInvalid, /* 3881 */
	GLXDecodeInvalid, /* 3882 */
	GLXDecodeInvalid, /* 3883 */
	GLXDecodeInvalid, /* 3884 */
	GLXDecodeInvalid, /* 3885 */
	GLXDecodeInvalid, /* 3886 */
	GLXDecodeInvalid, /* 3887 */
	GLXDecodeInvalid, /* 3888 */
	GLXDecodeInvalid, /* 3889 */
	GLXDecodeInvalid, /* 3890 */
	GLXDecodeInvalid, /* 3891 */
	GLXDecodeInvalid, /* 3892 */
	GLXDecodeInvalid, /* 3893 */
	GLXDecodeInvalid, /* 3894 */
	GLXDecodeInvalid, /* 3895 */
	GLXDecodeInvalid, /* 3896 */
	GLXDecodeInvalid, /* 3897 */
	GLXDecodeInvalid, /* 3898 */
	GLXDecodeInvalid, /* 3899 */
	GLXDecodeInvalid, /* 3900 */
	GLXDecodeInvalid, /* 3901 */
	GLXDecodeInvalid, /* 3902 */
	GLXDecodeInvalid, /* 3903 */
	GLXDecodeInvalid, /* 3904 */
	GLXDecodeInvalid, /* 3905 */
	GLXDecodeInvalid, /* 3906 */
	GLXDecodeInvalid, /* 3907 */
	GLXDecodeInvalid, /* 3908 */
	GLXDecodeInvalid, /* 3909 */
	GLXDecodeInvalid, /* 3910 */
	GLXDecodeInvalid, /* 3911 */
	GLXDecodeInvalid, /* 3912 */
	GLXDecodeInvalid, /* 3913 */
	GLXDecodeInvalid, /* 3914 */
	GLXDecodeInvalid, /* 3915 */
	GLXDecodeInvalid, /* 3916 */
	GLXDecodeInvalid, /* 3917 */
	GLXDecodeInvalid, /* 3918 */
	GLXDecodeInvalid, /* 3919 */
	GLXDecodeInvalid, /* 3920 */
	GLXDecodeInvalid, /* 3921 */
	GLXDecodeInvalid, /* 3922 */
	GLXDecodeInvalid, /* 3923 */
	GLXDecodeInvalid, /* 3924 */
	GLXDecodeInvalid, /* 3925 */
	GLXDecodeInvalid, /* 3926 */
	GLXDecodeInvalid, /* 3927 */
	GLXDecodeInvalid, /* 3928 */
	GLXDecodeInvalid, /* 3929 */
	GLXDecodeInvalid, /* 3930 */
	GLXDecodeInvalid, /* 3931 */
	GLXDecodeInvalid, /* 3932 */
	GLXDecodeInvalid, /* 3933 */
	GLXDecodeInvalid, /* 3934 */
	GLXDecodeInvalid, /* 3935 */
	GLXDecodeInvalid, /* 3936 */
	GLXDecodeInvalid, /* 3937 */
	GLXDecodeInvalid, /* 3938 */
	GLXDecodeInvalid, /* 3939 */
	GLXDecodeInvalid, /* 3940 */
	GLXDecodeInvalid, /* 3941 */
	GLXDecodeInvalid, /* 3942 */
	GLXDecodeInvalid, /* 3943 */
	GLXDecodeInvalid, /* 3944 */
	GLXDecodeInvalid, /* 3945 */
	GLXDecodeInvalid, /* 3946 */
	GLXDecodeInvalid, /* 3947 */
	GLXDecodeInvalid, /* 3948 */
	GLXDecodeInvalid, /* 3949 */
	GLXDecodeInvalid, /* 3950 */
	GLXDecodeInvalid, /* 3951 */
	GLXDecodeInvalid, /* 3952 */
	GLXDecodeInvalid, /* 3953 */
	GLXDecodeInvalid, /* 3954 */
	GLXDecodeInvalid, /* 3955 */
	GLXDecodeInvalid, /* 3956 */
	GLXDecodeInvalid, /* 3957 */
	GLXDecodeInvalid, /* 3958 */
	GLXDecodeInvalid, /* 3959 */
	GLXDecodeInvalid, /* 3960 */
	GLXDecodeInvalid, /* 3961 */
	GLXDecodeInvalid, /* 3962 */
	GLXDecodeInvalid, /* 3963 */
	GLXDecodeInvalid, /* 3964 */
	GLXDecodeInvalid, /* 3965 */
	GLXDecodeInvalid, /* 3966 */
	GLXDecodeInvalid, /* 3967 */
	GLXDecodeInvalid, /* 3968 */
	GLXDecodeInvalid, /* 3969 */
	GLXDecodeInvalid, /* 3970 */
	GLXDecodeInvalid, /* 3971 */
	GLXDecodeInvalid, /* 3972 */
	GLXDecodeInvalid, /* 3973 */
	GLXDecodeInvalid, /* 3974 */
	GLXDecodeInvalid, /* 3975 */
	GLXDecodeInvalid, /* 3976 */
	GLXDecodeInvalid, /* 3977 */
	GLXDecodeInvalid, /* 3978 */
	GLXDecodeInvalid, /* 3979 */
	GLXDecodeInvalid, /* 3980 */
	GLXDecodeInvalid, /* 3981 */
	GLXDecodeInvalid, /* 3982 */
	GLXDecodeInvalid, /* 3983 */
	GLXDecodeInvalid, /* 3984 */
	GLXDecodeInvalid, /* 3985 */
	GLXDecodeInvalid, /* 3986 */
	GLXDecodeInvalid, /* 3987 */
	GLXDecodeInvalid, /* 3988 */
	GLXDecodeInvalid, /* 3989 */
	GLXDecodeInvalid, /* 3990 */
	GLXDecodeInvalid, /* 3991 */
	GLXDecodeInvalid, /* 3992 */
	GLXDecodeInvalid, /* 3993 */
	GLXDecodeInvalid, /* 3994 */
	GLXDecodeInvalid, /* 3995 */
	GLXDecodeInvalid, /* 3996 */
	GLXDecodeInvalid, /* 3997 */
	GLXDecodeInvalid, /* 3998 */
	GLXDecodeInvalid, /* 3999 */
	GLXDecodeInvalid, /* 4000 */
	GLXDecodeInvalid, /* 4001 */
	GLXDecodeInvalid, /* 4002 */
	GLXDecodeInvalid, /* 4003 */
	GLXDecodeInvalid, /* 4004 */
	GLXDecodeInvalid, /* 4005 */
	GLXDecodeInvalid, /* 4006 */
	GLXDecodeInvalid, /* 4007 */
	GLXDecodeInvalid, /* 4008 */
	GLXDecodeInvalid, /* 4009 */
	GLXDecodeInvalid, /* 4010 */
	GLXDecodeInvalid, /* 4011 */
	GLXDecodeInvalid, /* 4012 */
	GLXDecodeInvalid, /* 4013 */
	GLXDecodeInvalid, /* 4014 */
	GLXDecodeInvalid, /* 4015 */
	GLXDecodeInvalid, /* 4016 */
	GLXDecodeInvalid, /* 4017 */
	GLXDecodeInvalid, /* 4018 */
	GLXDecodeInvalid, /* 4019 */
	GLXDecodeInvalid, /* 4020 */
	GLXDecodeInvalid, /* 4021 */
	GLXDecodeInvalid, /* 4022 */
	GLXDecodeInvalid, /* 4023 */
	GLXDecodeInvalid, /* 4024 */
	GLXDecodeInvalid, /* 4025 */
	GLXDecodeInvalid, /* 4026 */
	GLXDecodeInvalid, /* 4027 */
	GLXDecodeInvalid, /* 4028 */
	GLXDecodeInvalid, /* 4029 */
	GLXDecodeInvalid, /* 4030 */
	GLXDecodeInvalid, /* 4031 */
	GLXDecodeInvalid, /* 4032 */
	GLXDecodeInvalid, /* 4033 */
	GLXDecodeInvalid, /* 4034 */
	GLXDecodeInvalid, /* 4035 */
	GLXDecodeInvalid, /* 4036 */
	GLXDecodeInvalid, /* 4037 */
	GLXDecodeInvalid, /* 4038 */
	GLXDecodeInvalid, /* 4039 */
	GLXDecodeInvalid, /* 4040 */
	GLXDecodeInvalid, /* 4041 */
	GLXDecodeInvalid, /* 4042 */
	GLXDecodeInvalid, /* 4043 */
	GLXDecodeInvalid, /* 4044 */
	GLXDecodeInvalid, /* 4045 */
	GLXDecodeInvalid, /* 4046 */
	GLXDecodeInvalid, /* 4047 */
	GLXDecodeInvalid, /* 4048 */
	GLXDecodeInvalid, /* 4049 */
	GLXDecodeInvalid, /* 4050 */
	GLXDecodeInvalid, /* 4051 */
	GLXDecodeInvalid, /* 4052 */
	GLXDecodeInvalid, /* 4053 */
	GLXDecodeInvalid, /* 4054 */
	GLXDecodeInvalid, /* 4055 */
	GLXDecodeInvalid, /* 4056 */
	GLXDecodeInvalid, /* 4057 */
	GLXDecodeInvalid, /* 4058 */
	GLXDecodeInvalid, /* 4059 */
	GLXDecodeInvalid, /* 4060 */
	GLXDecodeInvalid, /* 4061 */
	GLXDecodeInvalid, /* 4062 */
	GLXDecodeInvalid, /* 4063 */
	GLXDecodeInvalid, /* 4064 */
	GLXDecodeInvalid, /* 4065 */
	GLXDecodeInvalid, /* 4066 */
	GLXDecodeInvalid, /* 4067 */
	GLXDecodeInvalid, /* 4068 */
	GLXDecodeInvalid, /* 4069 */
	GLXDecodeInvalid, /* 4070 */
	GLXDecodeInvalid, /* 4071 */
	GLXDecodeInvalid, /* 4072 */
	GLXDecodeInvalid, /* 4073 */
	GLXDecodeInvalid, /* 4074 */
	GLXDecodeInvalid, /* 4075 */
	GLXDecodeInvalid, /* 4076 */
	GLXDecodeInvalid, /* 4077 */
	GLXDecodeInvalid, /* 4078 */
	GLXDecodeInvalid, /* 4079 */
	GLXDecodeInvalid, /* 4080 */
	GLXDecodeInvalid, /* 4081 */
	GLXDecodeInvalid, /* 4082 */
	GLXDecodeInvalid, /* 4083 */
	GLXDecodeInvalid, /* 4084 */
	GLXDecodeInvalid, /* 4085 */
	GLXDecodeInvalid, /* 4086 */
	GLXDecodeInvalid, /* 4087 */
	GLXDecodeInvalid, /* 4088 */
	GLXDecodeInvalid, /* 4089 */
	GLXDecodeInvalid, /* 4090 */
	GLXDecodeInvalid, /* 4091 */
	GLXDecodeInvalid, /* 4092 */
	GLXDecodeInvalid, /* 4093 */
	GLXDecodeInvalid, /* 4094 */
	GLXDecodeInvalid, /* 4095 */
	GLXDecodeBlendColorEXT_swapped, /* 4096 */
	GLXDecodeBlendEquationEXT_swapped, /* 4097 */
	GLXDecodeInvalid, /* 4098 */
	GLXDecodeTexSubImage1D_swapped, /* 4099 */
	GLXDecodeTexSubImage2D_swapped, /* 4100 */
	GLXDecodeInvalid, /* 4101 */
	GLXDecodeInvalid, /* 4102 */
	GLXDecodeInvalid, /* 4103 */
	GLXDecodeInvalid, /* 4104 */
	GLXDecodeInvalid, /* 4105 */
	GLXDecodeInvalid, /* 4106 */
	GLXDecodeInvalid, /* 4107 */
	GLXDecodeInvalid, /* 4108 */
	GLXDecodeInvalid, /* 4109 */
	GLXDecodeInvalid, /* 4110 */
	GLXDecodeInvalid, /* 4111 */
	GLXDecodeInvalid, /* 4112 */
	GLXDecodeInvalid, /* 4113 */
	GLXDecodeInvalid, /* 4114 */
	GLXDecodeInvalid, /* 4115 */
	GLXDecodeDrawArrays_swapped, /* 4116 */
	GLXDecodeBindTexture_swapped, /* 4117 */
	GLXDecodePrioritizeTextures_swapped, /* 4118 */
	GLXDecodeCopyTexImage1D_swapped, /* 4119 */
	GLXDecodeCopyTexImage2D_swapped, /* 4120 */
	GLXDecodeCopyTexSubImage1D_swapped, /* 4121 */
	GLXDecodeCopyTexSubImage2D_swapped, /* 4122 */
};

int GLXDecodeCallList_swapped(int length, char* data)
{
	GLuint list = GET_uint(data+0);
	register int _n = 0;
	swapl(&list, _n);
	if(length != 4){
		fprintf(stderr, "Bad length in CallList (have %d, wanted %d)\n", length, 4);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glCallList(list);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeCallLists_swapped(int length, char* data)
{
	GLint n = GET_int(data+0);
	GLenum type = GET_enum(data+4);
	GLvoid** lists = (GLvoid**)(data+8);
	register int _n = 0;
	swapl(&n, _n);
	swapl(&type, _n);
	if(length != 8+(1*GLX_list_size(n,type))+(1*GLX_list_pad(n,type))){
		fprintf(stderr, "Bad length in CallLists (have %d, wanted %d)\n", length, 8+(1*GLX_list_size(n,type))+(1*GLX_list_pad(n,type)));
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	
        GLX_swap_array(type, GLX_list_size(n,type), (void *)lists);
	glCallLists(n, type, lists);
    
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeListBase_swapped(int length, char* data)
{
	GLuint base = GET_uint(data+0);
	register int _n = 0;
	swapl(&base, _n);
	if(length != 4){
		fprintf(stderr, "Bad length in ListBase (have %d, wanted %d)\n", length, 4);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glListBase(base);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeBegin_swapped(int length, char* data)
{
	GLenum mode = GET_enum(data+0);
	register int _n = 0;
	swapl(&mode, _n);
	if(length != 4){
		fprintf(stderr, "Bad length in Begin (have %d, wanted %d)\n", length, 4);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glBegin(mode);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeBitmap_swapped(int length, char* data)
{
	GLboolean lsb_first = GET_boolean(data+1);
	GLuint row_length = GET_uint(data+4);
	GLuint skip_rows = GET_uint(data+8);
	GLuint skip_pixels = GET_uint(data+12);
	GLuint alignment = GET_uint(data+16);
	GLint width = GET_int(data+20);
	GLint height = GET_int(data+24);
	GLfloat xorig = GET_float(data+28);
	GLfloat yorig = GET_float(data+32);
	GLfloat xmove = GET_float(data+36);
	GLfloat ymove = GET_float(data+40);
	GLubyte* pixels = (GLubyte*)(data+44);
	register int _n = 0;
	swapl(&row_length, _n);
	swapl(&skip_rows, _n);
	swapl(&skip_pixels, _n);
	swapl(&alignment, _n);
	swapl(&width, _n);
	swapl(&height, _n);
	swapl(&xorig, _n);
	swapl(&yorig, _n);
	swapl(&xmove, _n);
	swapl(&ymove, _n);
	if(length != 44+(1*GLX_image_size(width,height,GL_COLOR_INDEX,GL_BITMAP))+(1*GLX_image_pad(width,height,GL_COLOR_INDEX,GL_BITMAP))){
		fprintf(stderr, "Bad length in Bitmap (have %d, wanted %d)\n", length, 44+(1*GLX_image_size(width,height,GL_COLOR_INDEX,GL_BITMAP))+(1*GLX_image_pad(width,height,GL_COLOR_INDEX,GL_BITMAP)));
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	
	glPixelStorei(GL_UNPACK_LSB_FIRST, lsb_first);
	glPixelStorei(GL_UNPACK_ROW_LENGTH, row_length);
	glPixelStorei(GL_UNPACK_SKIP_PIXELS, skip_pixels);
	glPixelStorei(GL_UNPACK_SKIP_ROWS, skip_rows);
	glPixelStorei(GL_UNPACK_ALIGNMENT, alignment);
	glBitmap(width, height, xorig, yorig, xmove, ymove, pixels);
    
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeColor3bv_swapped(int length, char* data)
{
	GLbyte* c = (GLbyte*)(data+0);
	if(length != 4){
		fprintf(stderr, "Bad length in Color3bv (have %d, wanted %d)\n", length, 4);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glColor3bv(c);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeColor3dv_swapped(int length, char* data)
{
	GLdouble* c = (GLdouble*)(data+0);
	GLX_swapd_array(3, (double *)c);
	if(length != 24){
		fprintf(stderr, "Bad length in Color3dv (have %d, wanted %d)\n", length, 24);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glColor3dv(c);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeColor3fv_swapped(int length, char* data)
{
	GLfloat* c = (GLfloat*)(data+0);
	GLX_swapl_array(3, (GLuint *)c);
	if(length != 12){
		fprintf(stderr, "Bad length in Color3fv (have %d, wanted %d)\n", length, 12);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glColor3fv(c);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeColor3iv_swapped(int length, char* data)
{
	GLint* c = (GLint*)(data+0);
	GLX_swapl_array(3, (GLuint *)c);
	if(length != 12){
		fprintf(stderr, "Bad length in Color3iv (have %d, wanted %d)\n", length, 12);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glColor3iv(c);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeColor3sv_swapped(int length, char* data)
{
	GLshort* c = (GLshort*)(data+0);
	GLX_swaps_array(3, (short *)c);
	if(length != 8){
		fprintf(stderr, "Bad length in Color3sv (have %d, wanted %d)\n", length, 8);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glColor3sv(c);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeColor3ubv_swapped(int length, char* data)
{
	GLubyte* c = (GLubyte*)(data+0);
	if(length != 4){
		fprintf(stderr, "Bad length in Color3ubv (have %d, wanted %d)\n", length, 4);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glColor3ubv(c);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeColor3uiv_swapped(int length, char* data)
{
	GLuint* c = (GLuint*)(data+0);
	GLX_swapl_array(3, (GLuint *)c);
	if(length != 12){
		fprintf(stderr, "Bad length in Color3uiv (have %d, wanted %d)\n", length, 12);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glColor3uiv(c);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeColor3usv_swapped(int length, char* data)
{
	GLushort* c = (GLushort*)(data+0);
	GLX_swaps_array(3, (short *)c);
	if(length != 8){
		fprintf(stderr, "Bad length in Color3usv (have %d, wanted %d)\n", length, 8);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glColor3usv(c);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeColor4bv_swapped(int length, char* data)
{
	GLbyte* c = (GLbyte*)(data+0);
	if(length != 4){
		fprintf(stderr, "Bad length in Color4bv (have %d, wanted %d)\n", length, 4);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glColor4bv(c);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeColor4dv_swapped(int length, char* data)
{
	GLdouble* c = (GLdouble*)(data+0);
	GLX_swapd_array(4, (double *)c);
	if(length != 32){
		fprintf(stderr, "Bad length in Color4dv (have %d, wanted %d)\n", length, 32);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glColor4dv(c);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeColor4fv_swapped(int length, char* data)
{
	GLfloat* c = (GLfloat*)(data+0);
	GLX_swapl_array(4, (GLuint *)c);
	if(length != 16){
		fprintf(stderr, "Bad length in Color4fv (have %d, wanted %d)\n", length, 16);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glColor4fv(c);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeColor4iv_swapped(int length, char* data)
{
	GLint* c = (GLint*)(data+0);
	GLX_swapl_array(4, (GLuint *)c);
	if(length != 16){
		fprintf(stderr, "Bad length in Color4iv (have %d, wanted %d)\n", length, 16);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glColor4iv(c);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeColor4sv_swapped(int length, char* data)
{
	GLshort* c = (GLshort*)(data+0);
	GLX_swaps_array(4, (short *)c);
	if(length != 8){
		fprintf(stderr, "Bad length in Color4sv (have %d, wanted %d)\n", length, 8);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glColor4sv(c);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeColor4ubv_swapped(int length, char* data)
{
	GLubyte* c = (GLubyte*)(data+0);
	if(length != 4){
		fprintf(stderr, "Bad length in Color4ubv (have %d, wanted %d)\n", length, 4);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glColor4ubv(c);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeColor4uiv_swapped(int length, char* data)
{
	GLuint* c = (GLuint*)(data+0);
	GLX_swapl_array(4, (GLuint *)c);
	if(length != 16){
		fprintf(stderr, "Bad length in Color4uiv (have %d, wanted %d)\n", length, 16);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glColor4uiv(c);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeColor4usv_swapped(int length, char* data)
{
	GLushort* c = (GLushort*)(data+0);
	GLX_swaps_array(4, (short *)c);
	if(length != 8){
		fprintf(stderr, "Bad length in Color4usv (have %d, wanted %d)\n", length, 8);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glColor4usv(c);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeEdgeFlagv_swapped(int length, char* data)
{
	GLboolean* flag = (GLboolean*)(data+0);
	if(length != 4){
		fprintf(stderr, "Bad length in EdgeFlagv (have %d, wanted %d)\n", length, 4);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glEdgeFlagv(flag);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeEnd_swapped(int length, char* data)
{
	if(length != 0){
		fprintf(stderr, "Bad length in End (have %d, wanted %d)\n", length, 0);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glEnd();
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeIndexdv_swapped(int length, char* data)
{
	GLdouble* c = (GLdouble*)(data+0);
	GLX_swapd_array(1, (double *)c);
	if(length != 8){
		fprintf(stderr, "Bad length in Indexdv (have %d, wanted %d)\n", length, 8);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glIndexdv(c);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeIndexfv_swapped(int length, char* data)
{
	GLfloat* c = (GLfloat*)(data+0);
	GLX_swapl_array(1, (GLuint *)c);
	if(length != 4){
		fprintf(stderr, "Bad length in Indexfv (have %d, wanted %d)\n", length, 4);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glIndexfv(c);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeIndexiv_swapped(int length, char* data)
{
	GLint* c = (GLint*)(data+0);
	GLX_swapl_array(1, (GLuint *)c);
	if(length != 4){
		fprintf(stderr, "Bad length in Indexiv (have %d, wanted %d)\n", length, 4);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glIndexiv(c);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeIndexsv_swapped(int length, char* data)
{
	GLshort* c = (GLshort*)(data+0);
	GLX_swaps_array(1, (short *)c);
	if(length != 4){
		fprintf(stderr, "Bad length in Indexsv (have %d, wanted %d)\n", length, 4);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glIndexsv(c);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeNormal3bv_swapped(int length, char* data)
{
	GLbyte* v = (GLbyte*)(data+0);
	if(length != 4){
		fprintf(stderr, "Bad length in Normal3bv (have %d, wanted %d)\n", length, 4);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glNormal3bv(v);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeNormal3dv_swapped(int length, char* data)
{
	GLdouble* v = (GLdouble*)(data+0);
	GLX_swapd_array(3, (double *)v);
	if(length != 24){
		fprintf(stderr, "Bad length in Normal3dv (have %d, wanted %d)\n", length, 24);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glNormal3dv(v);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeNormal3fv_swapped(int length, char* data)
{
	GLfloat* v = (GLfloat*)(data+0);
	GLX_swapl_array(3, (GLuint *)v);
	if(length != 12){
		fprintf(stderr, "Bad length in Normal3fv (have %d, wanted %d)\n", length, 12);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glNormal3fv(v);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeNormal3iv_swapped(int length, char* data)
{
	GLint* v = (GLint*)(data+0);
	GLX_swapl_array(3, (GLuint *)v);
	if(length != 12){
		fprintf(stderr, "Bad length in Normal3iv (have %d, wanted %d)\n", length, 12);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glNormal3iv(v);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeNormal3sv_swapped(int length, char* data)
{
	GLshort* v = (GLshort*)(data+0);
	GLX_swaps_array(3, (short *)v);
	if(length != 8){
		fprintf(stderr, "Bad length in Normal3sv (have %d, wanted %d)\n", length, 8);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glNormal3sv(v);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeRasterPos2dv_swapped(int length, char* data)
{
	GLdouble* v = (GLdouble*)(data+0);
	GLX_swapd_array(2, (double *)v);
	if(length != 16){
		fprintf(stderr, "Bad length in RasterPos2dv (have %d, wanted %d)\n", length, 16);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glRasterPos2dv(v);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeRasterPos2fv_swapped(int length, char* data)
{
	GLfloat* v = (GLfloat*)(data+0);
	GLX_swapl_array(2, (GLuint *)v);
	if(length != 8){
		fprintf(stderr, "Bad length in RasterPos2fv (have %d, wanted %d)\n", length, 8);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glRasterPos2fv(v);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeRasterPos2iv_swapped(int length, char* data)
{
	GLint* v = (GLint*)(data+0);
	GLX_swapl_array(2, (GLuint *)v);
	if(length != 8){
		fprintf(stderr, "Bad length in RasterPos2iv (have %d, wanted %d)\n", length, 8);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glRasterPos2iv(v);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeRasterPos2sv_swapped(int length, char* data)
{
	GLshort* v = (GLshort*)(data+0);
	GLX_swaps_array(2, (short *)v);
	if(length != 4){
		fprintf(stderr, "Bad length in RasterPos2sv (have %d, wanted %d)\n", length, 4);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glRasterPos2sv(v);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeRasterPos3dv_swapped(int length, char* data)
{
	GLdouble* v = (GLdouble*)(data+0);
	GLX_swapd_array(3, (double *)v);
	if(length != 24){
		fprintf(stderr, "Bad length in RasterPos3dv (have %d, wanted %d)\n", length, 24);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glRasterPos3dv(v);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeRasterPos3fv_swapped(int length, char* data)
{
	GLfloat* v = (GLfloat*)(data+0);
	GLX_swapl_array(3, (GLuint *)v);
	if(length != 12){
		fprintf(stderr, "Bad length in RasterPos3fv (have %d, wanted %d)\n", length, 12);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glRasterPos3fv(v);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeRasterPos3iv_swapped(int length, char* data)
{
	GLint* v = (GLint*)(data+0);
	GLX_swapl_array(3, (GLuint *)v);
	if(length != 12){
		fprintf(stderr, "Bad length in RasterPos3iv (have %d, wanted %d)\n", length, 12);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glRasterPos3iv(v);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeRasterPos3sv_swapped(int length, char* data)
{
	GLshort* v = (GLshort*)(data+0);
	GLX_swaps_array(3, (short *)v);
	if(length != 8){
		fprintf(stderr, "Bad length in RasterPos3sv (have %d, wanted %d)\n", length, 8);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glRasterPos3sv(v);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeRasterPos4dv_swapped(int length, char* data)
{
	GLdouble* v = (GLdouble*)(data+0);
	GLX_swapd_array(4, (double *)v);
	if(length != 32){
		fprintf(stderr, "Bad length in RasterPos4dv (have %d, wanted %d)\n", length, 32);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glRasterPos4dv(v);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeRasterPos4fv_swapped(int length, char* data)
{
	GLfloat* v = (GLfloat*)(data+0);
	GLX_swapl_array(4, (GLuint *)v);
	if(length != 16){
		fprintf(stderr, "Bad length in RasterPos4fv (have %d, wanted %d)\n", length, 16);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glRasterPos4fv(v);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeRasterPos4iv_swapped(int length, char* data)
{
	GLint* v = (GLint*)(data+0);
	GLX_swapl_array(4, (GLuint *)v);
	if(length != 16){
		fprintf(stderr, "Bad length in RasterPos4iv (have %d, wanted %d)\n", length, 16);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glRasterPos4iv(v);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeRasterPos4sv_swapped(int length, char* data)
{
	GLshort* v = (GLshort*)(data+0);
	GLX_swaps_array(4, (short *)v);
	if(length != 8){
		fprintf(stderr, "Bad length in RasterPos4sv (have %d, wanted %d)\n", length, 8);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glRasterPos4sv(v);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeRectdv_swapped(int length, char* data)
{
	GLdouble* v1 = (GLdouble*)(data+0);
	GLdouble* v2 = (GLdouble*)(data+16);
	GLX_swapd_array(2, (double *)v1);
	GLX_swapd_array(2, (double *)v2);
	if(length != 32){
		fprintf(stderr, "Bad length in Rectdv (have %d, wanted %d)\n", length, 32);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glRectdv(v1, v2);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeRectfv_swapped(int length, char* data)
{
	GLfloat* v1 = (GLfloat*)(data+0);
	GLfloat* v2 = (GLfloat*)(data+8);
	GLX_swapl_array(2, (GLuint *)v1);
	GLX_swapl_array(2, (GLuint *)v2);
	if(length != 16){
		fprintf(stderr, "Bad length in Rectfv (have %d, wanted %d)\n", length, 16);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glRectfv(v1, v2);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeRectiv_swapped(int length, char* data)
{
	GLint* v1 = (GLint*)(data+0);
	GLint* v2 = (GLint*)(data+8);
	GLX_swapl_array(2, (GLuint *)v1);
	GLX_swapl_array(2, (GLuint *)v2);
	if(length != 16){
		fprintf(stderr, "Bad length in Rectiv (have %d, wanted %d)\n", length, 16);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glRectiv(v1, v2);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeRectsv_swapped(int length, char* data)
{
	GLshort* v1 = (GLshort*)(data+0);
	GLshort* v2 = (GLshort*)(data+4);
	GLX_swaps_array(2, (short *)v1);
	GLX_swaps_array(2, (short *)v2);
	if(length != 8){
		fprintf(stderr, "Bad length in Rectsv (have %d, wanted %d)\n", length, 8);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glRectsv(v1, v2);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeTexCoord1dv_swapped(int length, char* data)
{
	GLdouble* v = (GLdouble*)(data+0);
	GLX_swapd_array(1, (double *)v);
	if(length != 8){
		fprintf(stderr, "Bad length in TexCoord1dv (have %d, wanted %d)\n", length, 8);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glTexCoord1dv(v);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeTexCoord1fv_swapped(int length, char* data)
{
	GLfloat* v = (GLfloat*)(data+0);
	GLX_swapl_array(1, (GLuint *)v);
	if(length != 4){
		fprintf(stderr, "Bad length in TexCoord1fv (have %d, wanted %d)\n", length, 4);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glTexCoord1fv(v);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeTexCoord1iv_swapped(int length, char* data)
{
	GLint* v = (GLint*)(data+0);
	GLX_swapl_array(1, (GLuint *)v);
	if(length != 4){
		fprintf(stderr, "Bad length in TexCoord1iv (have %d, wanted %d)\n", length, 4);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glTexCoord1iv(v);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeTexCoord1sv_swapped(int length, char* data)
{
	GLshort* v = (GLshort*)(data+0);
	GLX_swaps_array(1, (short *)v);
	if(length != 4){
		fprintf(stderr, "Bad length in TexCoord1sv (have %d, wanted %d)\n", length, 4);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glTexCoord1sv(v);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeTexCoord2dv_swapped(int length, char* data)
{
	GLdouble* v = (GLdouble*)(data+0);
	GLX_swapd_array(2, (double *)v);
	if(length != 16){
		fprintf(stderr, "Bad length in TexCoord2dv (have %d, wanted %d)\n", length, 16);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glTexCoord2dv(v);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeTexCoord2fv_swapped(int length, char* data)
{
	GLfloat* v = (GLfloat*)(data+0);
	GLX_swapl_array(2, (GLuint *)v);
	if(length != 8){
		fprintf(stderr, "Bad length in TexCoord2fv (have %d, wanted %d)\n", length, 8);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glTexCoord2fv(v);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeTexCoord2iv_swapped(int length, char* data)
{
	GLint* v = (GLint*)(data+0);
	GLX_swapl_array(2, (GLuint *)v);
	if(length != 8){
		fprintf(stderr, "Bad length in TexCoord2iv (have %d, wanted %d)\n", length, 8);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glTexCoord2iv(v);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeTexCoord2sv_swapped(int length, char* data)
{
	GLshort* v = (GLshort*)(data+0);
	GLX_swaps_array(2, (short *)v);
	if(length != 4){
		fprintf(stderr, "Bad length in TexCoord2sv (have %d, wanted %d)\n", length, 4);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glTexCoord2sv(v);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeTexCoord3dv_swapped(int length, char* data)
{
	GLdouble* v = (GLdouble*)(data+0);
	GLX_swapd_array(3, (double *)v);
	if(length != 24){
		fprintf(stderr, "Bad length in TexCoord3dv (have %d, wanted %d)\n", length, 24);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glTexCoord3dv(v);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeTexCoord3fv_swapped(int length, char* data)
{
	GLfloat* v = (GLfloat*)(data+0);
	GLX_swapl_array(3, (GLuint *)v);
	if(length != 12){
		fprintf(stderr, "Bad length in TexCoord3fv (have %d, wanted %d)\n", length, 12);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glTexCoord3fv(v);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeTexCoord3iv_swapped(int length, char* data)
{
	GLint* v = (GLint*)(data+0);
	GLX_swapl_array(3, (GLuint *)v);
	if(length != 12){
		fprintf(stderr, "Bad length in TexCoord3iv (have %d, wanted %d)\n", length, 12);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glTexCoord3iv(v);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeTexCoord3sv_swapped(int length, char* data)
{
	GLshort* v = (GLshort*)(data+0);
	GLX_swaps_array(3, (short *)v);
	if(length != 8){
		fprintf(stderr, "Bad length in TexCoord3sv (have %d, wanted %d)\n", length, 8);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glTexCoord3sv(v);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeTexCoord4dv_swapped(int length, char* data)
{
	GLdouble* v = (GLdouble*)(data+0);
	GLX_swapd_array(4, (double *)v);
	if(length != 32){
		fprintf(stderr, "Bad length in TexCoord4dv (have %d, wanted %d)\n", length, 32);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glTexCoord4dv(v);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeTexCoord4fv_swapped(int length, char* data)
{
	GLfloat* v = (GLfloat*)(data+0);
	GLX_swapl_array(4, (GLuint *)v);
	if(length != 16){
		fprintf(stderr, "Bad length in TexCoord4fv (have %d, wanted %d)\n", length, 16);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glTexCoord4fv(v);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeTexCoord4iv_swapped(int length, char* data)
{
	GLint* v = (GLint*)(data+0);
	GLX_swapl_array(4, (GLuint *)v);
	if(length != 16){
		fprintf(stderr, "Bad length in TexCoord4iv (have %d, wanted %d)\n", length, 16);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glTexCoord4iv(v);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeTexCoord4sv_swapped(int length, char* data)
{
	GLshort* v = (GLshort*)(data+0);
	GLX_swaps_array(4, (short *)v);
	if(length != 8){
		fprintf(stderr, "Bad length in TexCoord4sv (have %d, wanted %d)\n", length, 8);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glTexCoord4sv(v);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeVertex2dv_swapped(int length, char* data)
{
	GLdouble* v = (GLdouble*)(data+0);
	GLX_swapd_array(2, (double *)v);
	if(length != 16){
		fprintf(stderr, "Bad length in Vertex2dv (have %d, wanted %d)\n", length, 16);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glVertex2dv(v);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeVertex2fv_swapped(int length, char* data)
{
	GLfloat* v = (GLfloat*)(data+0);
	GLX_swapl_array(2, (GLuint *)v);
	if(length != 8){
		fprintf(stderr, "Bad length in Vertex2fv (have %d, wanted %d)\n", length, 8);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glVertex2fv(v);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeVertex2iv_swapped(int length, char* data)
{
	GLint* v = (GLint*)(data+0);
	GLX_swapl_array(2, (GLuint *)v);
	if(length != 8){
		fprintf(stderr, "Bad length in Vertex2iv (have %d, wanted %d)\n", length, 8);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glVertex2iv(v);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeVertex2sv_swapped(int length, char* data)
{
	GLshort* v = (GLshort*)(data+0);
	GLX_swaps_array(2, (short *)v);
	if(length != 4){
		fprintf(stderr, "Bad length in Vertex2sv (have %d, wanted %d)\n", length, 4);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glVertex2sv(v);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeVertex3dv_swapped(int length, char* data)
{
	GLdouble* v = (GLdouble*)(data+0);
	GLX_swapd_array(3, (double *)v);
	if(length != 24){
		fprintf(stderr, "Bad length in Vertex3dv (have %d, wanted %d)\n", length, 24);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glVertex3dv(v);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeVertex3fv_swapped(int length, char* data)
{
	GLfloat* v = (GLfloat*)(data+0);
	GLX_swapl_array(3, (GLuint *)v);
	if(length != 12){
		fprintf(stderr, "Bad length in Vertex3fv (have %d, wanted %d)\n", length, 12);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glVertex3fv(v);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeVertex3iv_swapped(int length, char* data)
{
	GLint* v = (GLint*)(data+0);
	GLX_swapl_array(3, (GLuint *)v);
	if(length != 12){
		fprintf(stderr, "Bad length in Vertex3iv (have %d, wanted %d)\n", length, 12);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glVertex3iv(v);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeVertex3sv_swapped(int length, char* data)
{
	GLshort* v = (GLshort*)(data+0);
	GLX_swaps_array(3, (short *)v);
	if(length != 8){
		fprintf(stderr, "Bad length in Vertex3sv (have %d, wanted %d)\n", length, 8);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glVertex3sv(v);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeVertex4dv_swapped(int length, char* data)
{
	GLdouble* v = (GLdouble*)(data+0);
	GLX_swapd_array(4, (double *)v);
	if(length != 32){
		fprintf(stderr, "Bad length in Vertex4dv (have %d, wanted %d)\n", length, 32);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glVertex4dv(v);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeVertex4fv_swapped(int length, char* data)
{
	GLfloat* v = (GLfloat*)(data+0);
	GLX_swapl_array(4, (GLuint *)v);
	if(length != 16){
		fprintf(stderr, "Bad length in Vertex4fv (have %d, wanted %d)\n", length, 16);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glVertex4fv(v);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeVertex4iv_swapped(int length, char* data)
{
	GLint* v = (GLint*)(data+0);
	GLX_swapl_array(4, (GLuint *)v);
	if(length != 16){
		fprintf(stderr, "Bad length in Vertex4iv (have %d, wanted %d)\n", length, 16);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glVertex4iv(v);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeVertex4sv_swapped(int length, char* data)
{
	GLshort* v = (GLshort*)(data+0);
	GLX_swaps_array(4, (short *)v);
	if(length != 8){
		fprintf(stderr, "Bad length in Vertex4sv (have %d, wanted %d)\n", length, 8);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glVertex4sv(v);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeClipPlane_swapped(int length, char* data)
{
	GLdouble* equation = (GLdouble*)(data+0);
	GLenum plane = GET_enum(data+32);
	register int _n = 0;
	GLX_swapd_array(4, (double *)equation);
	swapl(&plane, _n);
	if(length != 36){
		fprintf(stderr, "Bad length in ClipPlane (have %d, wanted %d)\n", length, 36);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	
	glClipPlane(plane, equation);
    
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeColorMaterial_swapped(int length, char* data)
{
	GLenum face = GET_enum(data+0);
	GLenum mode = GET_enum(data+4);
	register int _n = 0;
	swapl(&face, _n);
	swapl(&mode, _n);
	if(length != 8){
		fprintf(stderr, "Bad length in ColorMaterial (have %d, wanted %d)\n", length, 8);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glColorMaterial(face, mode);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeCullFace_swapped(int length, char* data)
{
	GLenum mode = GET_enum(data+0);
	register int _n = 0;
	swapl(&mode, _n);
	if(length != 4){
		fprintf(stderr, "Bad length in CullFace (have %d, wanted %d)\n", length, 4);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glCullFace(mode);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeFogf_swapped(int length, char* data)
{
	GLenum pname = GET_enum(data+0);
	GLfloat param = GET_float(data+4);
	register int _n = 0;
	swapl(&pname, _n);
	swapl(&param, _n);
	if(length != 8){
		fprintf(stderr, "Bad length in Fogf (have %d, wanted %d)\n", length, 8);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glFogf(pname, param);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeFogfv_swapped(int length, char* data)
{
	GLenum pname = GET_enum(data+0);
	GLfloat* params = (GLfloat*)(data+4);
	register int _n = 0;
	swapl(&pname, _n);
	GLX_swapl_array(GLX_fog_size(pname), (GLuint *)params);
	if(length != 4+(4*GLX_fog_size(pname))){
		fprintf(stderr, "Bad length in Fogfv (have %d, wanted %d)\n", length, 4+(4*GLX_fog_size(pname)));
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glFogfv(pname, params);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeFogi_swapped(int length, char* data)
{
	GLenum pname = GET_enum(data+0);
	GLint param = GET_int(data+4);
	register int _n = 0;
	swapl(&pname, _n);
	swapl(&param, _n);
	if(length != 8){
		fprintf(stderr, "Bad length in Fogi (have %d, wanted %d)\n", length, 8);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glFogi(pname, param);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeFogiv_swapped(int length, char* data)
{
	GLenum pname = GET_enum(data+0);
	GLint* params = (GLint*)(data+4);
	register int _n = 0;
	swapl(&pname, _n);
	GLX_swapl_array(GLX_fog_size(pname), (GLuint *)params);
	if(length != 4+(4*GLX_fog_size(pname))){
		fprintf(stderr, "Bad length in Fogiv (have %d, wanted %d)\n", length, 4+(4*GLX_fog_size(pname)));
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glFogiv(pname, params);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeFrontFace_swapped(int length, char* data)
{
	GLenum mode = GET_enum(data+0);
	register int _n = 0;
	swapl(&mode, _n);
	if(length != 4){
		fprintf(stderr, "Bad length in FrontFace (have %d, wanted %d)\n", length, 4);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glFrontFace(mode);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeHint_swapped(int length, char* data)
{
	GLenum target = GET_enum(data+0);
	GLenum mode = GET_enum(data+4);
	register int _n = 0;
	swapl(&target, _n);
	swapl(&mode, _n);
	if(length != 8){
		fprintf(stderr, "Bad length in Hint (have %d, wanted %d)\n", length, 8);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glHint(target, mode);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeLightf_swapped(int length, char* data)
{
	GLenum light = GET_enum(data+0);
	GLenum pname = GET_enum(data+4);
	GLfloat param = GET_float(data+8);
	register int _n = 0;
	swapl(&light, _n);
	swapl(&pname, _n);
	swapl(&param, _n);
	if(length != 12){
		fprintf(stderr, "Bad length in Lightf (have %d, wanted %d)\n", length, 12);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glLightf(light, pname, param);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeLightfv_swapped(int length, char* data)
{
	GLenum light = GET_enum(data+0);
	GLenum pname = GET_enum(data+4);
	GLfloat* params = (GLfloat*)(data+8);
	register int _n = 0;
	swapl(&light, _n);
	swapl(&pname, _n);
	GLX_swapl_array(GLX_light_size(pname), (GLuint *)params);
	if(length != 8+(4*GLX_light_size(pname))){
		fprintf(stderr, "Bad length in Lightfv (have %d, wanted %d)\n", length, 8+(4*GLX_light_size(pname)));
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glLightfv(light, pname, params);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeLighti_swapped(int length, char* data)
{
	GLenum light = GET_enum(data+0);
	GLenum pname = GET_enum(data+4);
	GLint param = GET_int(data+8);
	register int _n = 0;
	swapl(&light, _n);
	swapl(&pname, _n);
	swapl(&param, _n);
	if(length != 12){
		fprintf(stderr, "Bad length in Lighti (have %d, wanted %d)\n", length, 12);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glLighti(light, pname, param);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeLightiv_swapped(int length, char* data)
{
	GLenum light = GET_enum(data+0);
	GLenum pname = GET_enum(data+4);
	GLint* params = (GLint*)(data+8);
	register int _n = 0;
	swapl(&light, _n);
	swapl(&pname, _n);
	GLX_swapl_array(GLX_light_size(pname), (GLuint *)params);
	if(length != 8+(4*GLX_light_size(pname))){
		fprintf(stderr, "Bad length in Lightiv (have %d, wanted %d)\n", length, 8+(4*GLX_light_size(pname)));
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glLightiv(light, pname, params);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeLightModelf_swapped(int length, char* data)
{
	GLenum pname = GET_enum(data+0);
	GLfloat param = GET_float(data+4);
	register int _n = 0;
	swapl(&pname, _n);
	swapl(&param, _n);
	if(length != 8){
		fprintf(stderr, "Bad length in LightModelf (have %d, wanted %d)\n", length, 8);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glLightModelf(pname, param);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeLightModelfv_swapped(int length, char* data)
{
	GLenum pname = GET_enum(data+0);
	GLfloat* params = (GLfloat*)(data+4);
	register int _n = 0;
	swapl(&pname, _n);
	GLX_swapl_array(GLX_lightmodel_size(pname), (GLuint *)params);
	if(length != 4+(4*GLX_lightmodel_size(pname))){
		fprintf(stderr, "Bad length in LightModelfv (have %d, wanted %d)\n", length, 4+(4*GLX_lightmodel_size(pname)));
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glLightModelfv(pname, params);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeLightModeli_swapped(int length, char* data)
{
	GLenum pname = GET_enum(data+0);
	GLint param = GET_int(data+4);
	register int _n = 0;
	swapl(&pname, _n);
	swapl(&param, _n);
	if(length != 8){
		fprintf(stderr, "Bad length in LightModeli (have %d, wanted %d)\n", length, 8);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glLightModeli(pname, param);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeLightModeliv_swapped(int length, char* data)
{
	GLenum pname = GET_enum(data+0);
	GLint* params = (GLint*)(data+4);
	register int _n = 0;
	swapl(&pname, _n);
	GLX_swapl_array(GLX_lightmodel_size(pname), (GLuint *)params);
	if(length != 4+(4*GLX_lightmodel_size(pname))){
		fprintf(stderr, "Bad length in LightModeliv (have %d, wanted %d)\n", length, 4+(4*GLX_lightmodel_size(pname)));
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glLightModeliv(pname, params);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeLineStipple_swapped(int length, char* data)
{
	GLint factor = GET_int(data+0);
	GLushort pattern = GET_ushort(data+4);
	register int _n = 0;
	swapl(&factor, _n);
	swaps(&pattern, _n);
	if(length != 8){
		fprintf(stderr, "Bad length in LineStipple (have %d, wanted %d)\n", length, 8);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glLineStipple(factor, pattern);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeLineWidth_swapped(int length, char* data)
{
	GLfloat width = GET_float(data+0);
	register int _n = 0;
	swapl(&width, _n);
	if(length != 4){
		fprintf(stderr, "Bad length in LineWidth (have %d, wanted %d)\n", length, 4);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glLineWidth(width);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeMaterialf_swapped(int length, char* data)
{
	GLenum face = GET_enum(data+0);
	GLenum pname = GET_enum(data+4);
	GLfloat param = GET_float(data+8);
	register int _n = 0;
	swapl(&face, _n);
	swapl(&pname, _n);
	swapl(&param, _n);
	if(length != 12){
		fprintf(stderr, "Bad length in Materialf (have %d, wanted %d)\n", length, 12);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glMaterialf(face, pname, param);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeMaterialfv_swapped(int length, char* data)
{
	GLenum face = GET_enum(data+0);
	GLenum pname = GET_enum(data+4);
	GLfloat* params = (GLfloat*)(data+8);
	register int _n = 0;
	swapl(&face, _n);
	swapl(&pname, _n);
	GLX_swapl_array(GLX_material_size(pname), (GLuint *)params);
	if(length != 8+(4*GLX_material_size(pname))){
		fprintf(stderr, "Bad length in Materialfv (have %d, wanted %d)\n", length, 8+(4*GLX_material_size(pname)));
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glMaterialfv(face, pname, params);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeMateriali_swapped(int length, char* data)
{
	GLenum face = GET_enum(data+0);
	GLenum pname = GET_enum(data+4);
	GLint param = GET_int(data+8);
	register int _n = 0;
	swapl(&face, _n);
	swapl(&pname, _n);
	swapl(&param, _n);
	if(length != 12){
		fprintf(stderr, "Bad length in Materiali (have %d, wanted %d)\n", length, 12);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glMateriali(face, pname, param);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeMaterialiv_swapped(int length, char* data)
{
	GLenum face = GET_enum(data+0);
	GLenum pname = GET_enum(data+4);
	GLint* params = (GLint*)(data+8);
	register int _n = 0;
	swapl(&face, _n);
	swapl(&pname, _n);
	GLX_swapl_array(GLX_material_size(pname), (GLuint *)params);
	if(length != 8+(4*GLX_material_size(pname))){
		fprintf(stderr, "Bad length in Materialiv (have %d, wanted %d)\n", length, 8+(4*GLX_material_size(pname)));
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glMaterialiv(face, pname, params);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodePointSize_swapped(int length, char* data)
{
	GLfloat size = GET_float(data+0);
	register int _n = 0;
	swapl(&size, _n);
	if(length != 4){
		fprintf(stderr, "Bad length in PointSize (have %d, wanted %d)\n", length, 4);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glPointSize(size);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodePolygonMode_swapped(int length, char* data)
{
	GLenum face = GET_enum(data+0);
	GLenum mode = GET_enum(data+4);
	register int _n = 0;
	swapl(&face, _n);
	swapl(&mode, _n);
	if(length != 8){
		fprintf(stderr, "Bad length in PolygonMode (have %d, wanted %d)\n", length, 8);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glPolygonMode(face, mode);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodePolygonStipple_swapped(int length, char* data)
{
	GLboolean lsb_first = GET_boolean(data+1);
	GLuint row_length = GET_uint(data+4);
	GLuint skip_rows = GET_uint(data+8);
	GLuint skip_pixels = GET_uint(data+12);
	GLuint alignment = GET_uint(data+16);
	GLubyte* mask = (GLubyte*)(data+20);
	register int _n = 0;
	swapl(&row_length, _n);
	swapl(&skip_rows, _n);
	swapl(&skip_pixels, _n);
	swapl(&alignment, _n);
	if(length != 20+(1*GLX_image_size(32,32,GL_COLOR_INDEX,GL_BITMAP))+(1*GLX_image_pad(32,32,GL_COLOR_INDEX,GL_BITMAP))){
		fprintf(stderr, "Bad length in PolygonStipple (have %d, wanted %d)\n", length, 20+(1*GLX_image_size(32,32,GL_COLOR_INDEX,GL_BITMAP))+(1*GLX_image_pad(32,32,GL_COLOR_INDEX,GL_BITMAP)));
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	
        glPixelStorei(GL_UNPACK_LSB_FIRST, lsb_first);
        glPixelStorei(GL_UNPACK_ROW_LENGTH, row_length);
        glPixelStorei(GL_UNPACK_SKIP_PIXELS, skip_pixels);
        glPixelStorei(GL_UNPACK_SKIP_ROWS, skip_rows);
        glPixelStorei(GL_UNPACK_ALIGNMENT, alignment);
        glPolygonStipple(mask);
    
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeScissor_swapped(int length, char* data)
{
	GLint x = GET_int(data+0);
	GLint y = GET_int(data+4);
	GLint width = GET_int(data+8);
	GLint height = GET_int(data+12);
	register int _n = 0;
	swapl(&x, _n);
	swapl(&y, _n);
	swapl(&width, _n);
	swapl(&height, _n);
	if(length != 16){
		fprintf(stderr, "Bad length in Scissor (have %d, wanted %d)\n", length, 16);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glScissor(x, y, width, height);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeShadeModel_swapped(int length, char* data)
{
	GLenum mode = GET_enum(data+0);
	register int _n = 0;
	swapl(&mode, _n);
	if(length != 4){
		fprintf(stderr, "Bad length in ShadeModel (have %d, wanted %d)\n", length, 4);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glShadeModel(mode);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeTexParameterf_swapped(int length, char* data)
{
	GLenum target = GET_enum(data+0);
	GLenum pname = GET_enum(data+4);
	GLfloat param = GET_float(data+8);
	register int _n = 0;
	swapl(&target, _n);
	swapl(&pname, _n);
	swapl(&param, _n);
	if(length != 12){
		fprintf(stderr, "Bad length in TexParameterf (have %d, wanted %d)\n", length, 12);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glTexParameterf(target, pname, param);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeTexParameterfv_swapped(int length, char* data)
{
	GLenum target = GET_enum(data+0);
	GLenum pname = GET_enum(data+4);
	GLfloat* params = (GLfloat*)(data+8);
	register int _n = 0;
	swapl(&target, _n);
	swapl(&pname, _n);
	GLX_swapl_array(GLX_texparameter_size(pname), (GLuint *)params);
	if(length != 8+(4*GLX_texparameter_size(pname))){
		fprintf(stderr, "Bad length in TexParameterfv (have %d, wanted %d)\n", length, 8+(4*GLX_texparameter_size(pname)));
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glTexParameterfv(target, pname, params);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeTexParameteri_swapped(int length, char* data)
{
	GLenum target = GET_enum(data+0);
	GLenum pname = GET_enum(data+4);
	GLint param = GET_int(data+8);
	register int _n = 0;
	swapl(&target, _n);
	swapl(&pname, _n);
	swapl(&param, _n);
	if(length != 12){
		fprintf(stderr, "Bad length in TexParameteri (have %d, wanted %d)\n", length, 12);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glTexParameteri(target, pname, param);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeTexParameteriv_swapped(int length, char* data)
{
	GLenum target = GET_enum(data+0);
	GLenum pname = GET_enum(data+4);
	GLint* params = (GLint*)(data+8);
	register int _n = 0;
	swapl(&target, _n);
	swapl(&pname, _n);
	GLX_swapl_array(GLX_texparameter_size(pname), (GLuint *)params);
	if(length != 8+(4*GLX_texparameter_size(pname))){
		fprintf(stderr, "Bad length in TexParameteriv (have %d, wanted %d)\n", length, 8+(4*GLX_texparameter_size(pname)));
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glTexParameteriv(target, pname, params);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeTexImage1D_swapped(int length, char* data)
{
	GLboolean swap_bytes = GET_boolean(data+0);
	GLboolean lsb_first = GET_boolean(data+1);
	GLuint row_length = GET_uint(data+4);
	GLuint skip_rows = GET_uint(data+8);
	GLuint skip_pixels = GET_uint(data+12);
	GLuint alignment = GET_uint(data+16);
	GLenum target = GET_enum(data+20);
	GLint level = GET_int(data+24);
	GLint components = GET_int(data+28);
	GLint width = GET_int(data+32);
	GLint border = GET_int(data+40);
	GLenum format = GET_enum(data+44);
	GLenum type = GET_enum(data+48);
	GLubyte* pixels = (GLubyte*)(data+52);
	register int _n = 0;
	swapl(&row_length, _n);
	swapl(&skip_rows, _n);
	swapl(&skip_pixels, _n);
	swapl(&alignment, _n);
	swapl(&target, _n);
	swapl(&level, _n);
	swapl(&components, _n);
	swapl(&width, _n);
	swapl(&border, _n);
	swapl(&format, _n);
	swapl(&type, _n);
	if(length != 52+(1*GLX_image_size(width,1,format,type))+(1*GLX_image_pad(width,1,format,type))){
		fprintf(stderr, "Bad length in TexImage1D (have %d, wanted %d)\n", length, 52+(1*GLX_image_size(width,1,format,type))+(1*GLX_image_pad(width,1,format,type)));
		return GLXBadRenderRequest;
	}
	swap_bytes = !swap_bytes;
	log_print("Calling OpenGL function");
	
	glPixelStorei(GL_UNPACK_SWAP_BYTES, swap_bytes);
	glPixelStorei(GL_UNPACK_LSB_FIRST, lsb_first);
	glPixelStorei(GL_UNPACK_ROW_LENGTH, row_length);
	glPixelStorei(GL_UNPACK_SKIP_PIXELS, skip_pixels);
	glPixelStorei(GL_UNPACK_SKIP_ROWS, skip_rows);
	glPixelStorei(GL_UNPACK_ALIGNMENT, alignment);
	glTexImage1D(target, level, components, width, border,
	             format, type, pixels);
    
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeTexImage2D_swapped(int length, char* data)
{
	GLboolean swap_bytes = GET_boolean(data+0);
	GLboolean lsb_first = GET_boolean(data+1);
	GLuint row_length = GET_uint(data+4);
	GLuint skip_rows = GET_uint(data+8);
	GLuint skip_pixels = GET_uint(data+12);
	GLuint alignment = GET_uint(data+16);
	GLenum target = GET_enum(data+20);
	GLint level = GET_int(data+24);
	GLint components = GET_int(data+28);
	GLint width = GET_int(data+32);
	GLint height = GET_int(data+36);
	GLint border = GET_int(data+40);
	GLenum format = GET_enum(data+44);
	GLenum type = GET_enum(data+48);
	GLubyte* pixels = (GLubyte*)(data+52);
	register int _n = 0;
	swapl(&row_length, _n);
	swapl(&skip_rows, _n);
	swapl(&skip_pixels, _n);
	swapl(&alignment, _n);
	swapl(&target, _n);
	swapl(&level, _n);
	swapl(&components, _n);
	swapl(&width, _n);
	swapl(&height, _n);
	swapl(&border, _n);
	swapl(&format, _n);
	swapl(&type, _n);
	if(length != 52+(1*GLX_image_size(width,height,format,type))+(1*GLX_image_pad(width,height,format,type))){
		fprintf(stderr, "Bad length in TexImage2D (have %d, wanted %d)\n", length, 52+(1*GLX_image_size(width,height,format,type))+(1*GLX_image_pad(width,height,format,type)));
		return GLXBadRenderRequest;
	}
	swap_bytes = !swap_bytes;
	log_print("Calling OpenGL function");
	
	glPixelStorei(GL_UNPACK_SWAP_BYTES, swap_bytes);
	glPixelStorei(GL_UNPACK_LSB_FIRST, lsb_first);
	glPixelStorei(GL_UNPACK_ROW_LENGTH, row_length);
	glPixelStorei(GL_UNPACK_SKIP_PIXELS, skip_pixels);
	glPixelStorei(GL_UNPACK_SKIP_ROWS, skip_rows);
	glPixelStorei(GL_UNPACK_ALIGNMENT, alignment);
	glTexImage2D(target, level, components, width, height, border,
	             format, type, pixels);
    
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeTexEnvf_swapped(int length, char* data)
{
	GLenum target = GET_enum(data+0);
	GLenum pname = GET_enum(data+4);
	GLfloat param = GET_float(data+8);
	register int _n = 0;
	swapl(&target, _n);
	swapl(&pname, _n);
	swapl(&param, _n);
	if(length != 12){
		fprintf(stderr, "Bad length in TexEnvf (have %d, wanted %d)\n", length, 12);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glTexEnvf(target, pname, param);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeTexEnvfv_swapped(int length, char* data)
{
	GLenum target = GET_enum(data+0);
	GLenum pname = GET_enum(data+4);
	GLfloat* params = (GLfloat*)(data+8);
	register int _n = 0;
	swapl(&target, _n);
	swapl(&pname, _n);
	GLX_swapl_array(GLX_texenv_size(pname), (GLuint *)params);
	if(length != 8+(4*GLX_texenv_size(pname))){
		fprintf(stderr, "Bad length in TexEnvfv (have %d, wanted %d)\n", length, 8+(4*GLX_texenv_size(pname)));
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glTexEnvfv(target, pname, params);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeTexEnvi_swapped(int length, char* data)
{
	GLenum target = GET_enum(data+0);
	GLenum pname = GET_enum(data+4);
	GLint param = GET_int(data+8);
	register int _n = 0;
	swapl(&target, _n);
	swapl(&pname, _n);
	swapl(&param, _n);
	if(length != 12){
		fprintf(stderr, "Bad length in TexEnvi (have %d, wanted %d)\n", length, 12);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glTexEnvi(target, pname, param);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeTexEnviv_swapped(int length, char* data)
{
	GLenum target = GET_enum(data+0);
	GLenum pname = GET_enum(data+4);
	GLint* params = (GLint*)(data+8);
	register int _n = 0;
	swapl(&target, _n);
	swapl(&pname, _n);
	GLX_swapl_array(GLX_texenv_size(pname), (GLuint *)params);
	if(length != 8+(4*GLX_texenv_size(pname))){
		fprintf(stderr, "Bad length in TexEnviv (have %d, wanted %d)\n", length, 8+(4*GLX_texenv_size(pname)));
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glTexEnviv(target, pname, params);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeTexGend_swapped(int length, char* data)
{
	GLenum coord = GET_enum(data+0);
	GLenum pname = GET_enum(data+4);
	GLdouble param = GET_double(data+8);
	register int _n = 0;
	swapl(&coord, _n);
	swapl(&pname, _n);
	swapd(&param, _n);
	if(length != 16){
		fprintf(stderr, "Bad length in TexGend (have %d, wanted %d)\n", length, 16);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glTexGend(coord, pname, param);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeTexGendv_swapped(int length, char* data)
{
	GLenum coord = GET_enum(data+0);
	GLenum pname = GET_enum(data+4);
	GLdouble* params = (GLdouble*)(data+8);
	register int _n = 0;
	swapl(&coord, _n);
	swapl(&pname, _n);
	GLX_swapd_array(GLX_texgen_size(pname), (double *)params);
	if(length != 8+(8*GLX_texgen_size(pname))){
		fprintf(stderr, "Bad length in TexGendv (have %d, wanted %d)\n", length, 8+(8*GLX_texgen_size(pname)));
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glTexGendv(coord, pname, params);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeTexGenf_swapped(int length, char* data)
{
	GLenum coord = GET_enum(data+0);
	GLenum pname = GET_enum(data+4);
	GLfloat param = GET_float(data+8);
	register int _n = 0;
	swapl(&coord, _n);
	swapl(&pname, _n);
	swapl(&param, _n);
	if(length != 12){
		fprintf(stderr, "Bad length in TexGenf (have %d, wanted %d)\n", length, 12);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glTexGenf(coord, pname, param);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeTexGenfv_swapped(int length, char* data)
{
	GLenum coord = GET_enum(data+0);
	GLenum pname = GET_enum(data+4);
	GLfloat* params = (GLfloat*)(data+8);
	register int _n = 0;
	swapl(&coord, _n);
	swapl(&pname, _n);
	GLX_swapl_array(GLX_texgen_size(pname), (GLuint *)params);
	if(length != 8+(4*GLX_texgen_size(pname))){
		fprintf(stderr, "Bad length in TexGenfv (have %d, wanted %d)\n", length, 8+(4*GLX_texgen_size(pname)));
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glTexGenfv(coord, pname, params);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeTexGeni_swapped(int length, char* data)
{
	GLenum coord = GET_enum(data+0);
	GLenum pname = GET_enum(data+4);
	GLint param = GET_int(data+8);
	register int _n = 0;
	swapl(&coord, _n);
	swapl(&pname, _n);
	swapl(&param, _n);
	if(length != 12){
		fprintf(stderr, "Bad length in TexGeni (have %d, wanted %d)\n", length, 12);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glTexGeni(coord, pname, param);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeTexGeniv_swapped(int length, char* data)
{
	GLenum coord = GET_enum(data+0);
	GLenum pname = GET_enum(data+4);
	GLint* params = (GLint*)(data+8);
	register int _n = 0;
	swapl(&coord, _n);
	swapl(&pname, _n);
	GLX_swapl_array(GLX_texgen_size(pname), (GLuint *)params);
	if(length != 8+(4*GLX_texgen_size(pname))){
		fprintf(stderr, "Bad length in TexGeniv (have %d, wanted %d)\n", length, 8+(4*GLX_texgen_size(pname)));
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glTexGeniv(coord, pname, params);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeInitNames_swapped(int length, char* data)
{
	if(length != 0){
		fprintf(stderr, "Bad length in InitNames (have %d, wanted %d)\n", length, 0);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glInitNames();
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeLoadName_swapped(int length, char* data)
{
	GLuint name = GET_uint(data+0);
	register int _n = 0;
	swapl(&name, _n);
	if(length != 4){
		fprintf(stderr, "Bad length in LoadName (have %d, wanted %d)\n", length, 4);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glLoadName(name);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodePassThrough_swapped(int length, char* data)
{
	GLfloat token = GET_float(data+0);
	register int _n = 0;
	swapl(&token, _n);
	if(length != 4){
		fprintf(stderr, "Bad length in PassThrough (have %d, wanted %d)\n", length, 4);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glPassThrough(token);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodePopName_swapped(int length, char* data)
{
	if(length != 0){
		fprintf(stderr, "Bad length in PopName (have %d, wanted %d)\n", length, 0);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glPopName();
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodePushName_swapped(int length, char* data)
{
	GLuint name = GET_uint(data+0);
	register int _n = 0;
	swapl(&name, _n);
	if(length != 4){
		fprintf(stderr, "Bad length in PushName (have %d, wanted %d)\n", length, 4);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glPushName(name);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeDrawBuffer_swapped(int length, char* data)
{
	GLenum mode = GET_enum(data+0);
	register int _n = 0;
	swapl(&mode, _n);
	if(length != 4){
		fprintf(stderr, "Bad length in DrawBuffer (have %d, wanted %d)\n", length, 4);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glDrawBuffer(mode);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeClear_swapped(int length, char* data)
{
	GLbitfield mask = GET_bitfield(data+0);
	register int _n = 0;
	swapl(&mask, _n);
	if(length != 4){
		fprintf(stderr, "Bad length in Clear (have %d, wanted %d)\n", length, 4);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glClear(mask);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeClearAccum_swapped(int length, char* data)
{
	GLfloat red = GET_float(data+0);
	GLfloat green = GET_float(data+4);
	GLfloat blue = GET_float(data+8);
	GLfloat alpha = GET_float(data+12);
	register int _n = 0;
	swapl(&red, _n);
	swapl(&green, _n);
	swapl(&blue, _n);
	swapl(&alpha, _n);
	if(length != 16){
		fprintf(stderr, "Bad length in ClearAccum (have %d, wanted %d)\n", length, 16);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glClearAccum(red, green, blue, alpha);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeClearIndex_swapped(int length, char* data)
{
	GLfloat index = GET_float(data+0);
	register int _n = 0;
	swapl(&index, _n);
	if(length != 4){
		fprintf(stderr, "Bad length in ClearIndex (have %d, wanted %d)\n", length, 4);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glClearIndex(index);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeClearColor_swapped(int length, char* data)
{
	GLfloat red = GET_float(data+0);
	GLfloat green = GET_float(data+4);
	GLfloat blue = GET_float(data+8);
	GLfloat alpha = GET_float(data+12);
	register int _n = 0;
	swapl(&red, _n);
	swapl(&green, _n);
	swapl(&blue, _n);
	swapl(&alpha, _n);
	if(length != 16){
		fprintf(stderr, "Bad length in ClearColor (have %d, wanted %d)\n", length, 16);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glClearColor(red, green, blue, alpha);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeClearStencil_swapped(int length, char* data)
{
	GLint s = GET_int(data+0);
	register int _n = 0;
	swapl(&s, _n);
	if(length != 4){
		fprintf(stderr, "Bad length in ClearStencil (have %d, wanted %d)\n", length, 4);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glClearStencil(s);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeClearDepth_swapped(int length, char* data)
{
	GLdouble depth = GET_double(data+0);
	register int _n = 0;
	swapd(&depth, _n);
	if(length != 8){
		fprintf(stderr, "Bad length in ClearDepth (have %d, wanted %d)\n", length, 8);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glClearDepth(depth);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeStencilMask_swapped(int length, char* data)
{
	GLuint mask = GET_uint(data+0);
	register int _n = 0;
	swapl(&mask, _n);
	if(length != 4){
		fprintf(stderr, "Bad length in StencilMask (have %d, wanted %d)\n", length, 4);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glStencilMask(mask);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeColorMask_swapped(int length, char* data)
{
	GLboolean red = GET_boolean(data+0);
	GLboolean green = GET_boolean(data+1);
	GLboolean blue = GET_boolean(data+2);
	GLboolean alpha = GET_boolean(data+3);
	register int _n = 0;
	if(length != 4){
		fprintf(stderr, "Bad length in ColorMask (have %d, wanted %d)\n", length, 4);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glColorMask(red, green, blue, alpha);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeDepthMask_swapped(int length, char* data)
{
	GLboolean flag = GET_boolean(data+0);
	register int _n = 0;
	if(length != 4){
		fprintf(stderr, "Bad length in DepthMask (have %d, wanted %d)\n", length, 4);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glDepthMask(flag);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeIndexMask_swapped(int length, char* data)
{
	GLuint mask = GET_uint(data+0);
	register int _n = 0;
	swapl(&mask, _n);
	if(length != 4){
		fprintf(stderr, "Bad length in IndexMask (have %d, wanted %d)\n", length, 4);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glIndexMask(mask);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeAccum_swapped(int length, char* data)
{
	GLenum op = GET_enum(data+0);
	GLfloat value = GET_float(data+4);
	register int _n = 0;
	swapl(&op, _n);
	swapl(&value, _n);
	if(length != 8){
		fprintf(stderr, "Bad length in Accum (have %d, wanted %d)\n", length, 8);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glAccum(op, value);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeDisable_swapped(int length, char* data)
{
	GLenum cap = GET_enum(data+0);
	register int _n = 0;
	swapl(&cap, _n);
	if(length != 4){
		fprintf(stderr, "Bad length in Disable (have %d, wanted %d)\n", length, 4);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glDisable(cap);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeEnable_swapped(int length, char* data)
{
	GLenum cap = GET_enum(data+0);
	register int _n = 0;
	swapl(&cap, _n);
	if(length != 4){
		fprintf(stderr, "Bad length in Enable (have %d, wanted %d)\n", length, 4);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glEnable(cap);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodePopAttrib_swapped(int length, char* data)
{
	if(length != 0){
		fprintf(stderr, "Bad length in PopAttrib (have %d, wanted %d)\n", length, 0);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glPopAttrib();
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodePushAttrib_swapped(int length, char* data)
{
	GLbitfield mask = GET_bitfield(data+0);
	register int _n = 0;
	swapl(&mask, _n);
	if(length != 4){
		fprintf(stderr, "Bad length in PushAttrib (have %d, wanted %d)\n", length, 4);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glPushAttrib(mask);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeMap1d_swapped(int length, char* data)
{
	GLdouble u1 = GET_double(data+0);
	GLdouble u2 = GET_double(data+8);
	GLenum target = GET_enum(data+16);
	GLint order = GET_int(data+20);
	GLdouble* points = (GLdouble*)(data+24);
	register int _n = 0;
	swapd(&u1, _n);
	swapd(&u2, _n);
	swapl(&target, _n);
	swapl(&order, _n);
	GLX_swapd_array(GLX_map1_size(target)*order, (double *)points);
	if(length != 24+(8*GLX_map1_size(target)*order)){
		fprintf(stderr, "Bad length in Map1d (have %d, wanted %d)\n", length, 24+(8*GLX_map1_size(target)*order));
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	
	glMap1d(target, u1, u2, GLX_map1_size(target), order, points);
    
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeMap1f_swapped(int length, char* data)
{
	GLenum target = GET_enum(data+0);
	GLfloat u1 = GET_float(data+4);
	GLfloat u2 = GET_float(data+8);
	GLint order = GET_int(data+12);
	GLfloat* points = (GLfloat*)(data+16);
	register int _n = 0;
	swapl(&target, _n);
	swapl(&u1, _n);
	swapl(&u2, _n);
	swapl(&order, _n);
	GLX_swapl_array(GLX_map1_size(target)*order, (GLuint *)points);
	if(length != 16+(4*GLX_map1_size(target)*order)){
		fprintf(stderr, "Bad length in Map1f (have %d, wanted %d)\n", length, 16+(4*GLX_map1_size(target)*order));
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	
	glMap1f(target, u1, u2, GLX_map1_size(target), order, points);
    
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeMap2d_swapped(int length, char* data)
{
	GLdouble u1 = GET_double(data+0);
	GLdouble u2 = GET_double(data+8);
	GLdouble v1 = GET_double(data+16);
	GLdouble v2 = GET_double(data+24);
	GLenum target = GET_enum(data+32);
	GLint uorder = GET_int(data+36);
	GLint vorder = GET_int(data+40);
	GLdouble* points = (GLdouble*)(data+44);
	register int _n = 0;
	swapd(&u1, _n);
	swapd(&u2, _n);
	swapd(&v1, _n);
	swapd(&v2, _n);
	swapl(&target, _n);
	swapl(&uorder, _n);
	swapl(&vorder, _n);
	GLX_swapd_array(GLX_map2_size(target)*uorder*vorder, (double *)points);
	if(length != 44+(8*GLX_map2_size(target)*uorder*vorder)){
		fprintf(stderr, "Bad length in Map2d (have %d, wanted %d)\n", length, 44+(8*GLX_map2_size(target)*uorder*vorder));
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	
	glMap2d(target, u1, u2, GLX_map2_size(target)*vorder, uorder, v1, v2, GLX_map2_size(target), vorder, points);
    
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeMap2f_swapped(int length, char* data)
{
	GLenum target = GET_enum(data+0);
	GLfloat u1 = GET_float(data+4);
	GLfloat u2 = GET_float(data+8);
	GLint uorder = GET_int(data+12);
	GLfloat v1 = GET_float(data+16);
	GLfloat v2 = GET_float(data+20);
	GLint vorder = GET_int(data+24);
	GLfloat* points = (GLfloat*)(data+28);
	register int _n = 0;
	swapl(&target, _n);
	swapl(&u1, _n);
	swapl(&u2, _n);
	swapl(&uorder, _n);
	swapl(&v1, _n);
	swapl(&v2, _n);
	swapl(&vorder, _n);
	GLX_swapl_array(GLX_map2_size(target)*uorder*vorder, (GLuint *)points);
	if(length != 28+(4*GLX_map2_size(target)*uorder*vorder)){
		fprintf(stderr, "Bad length in Map2f (have %d, wanted %d)\n", length, 28+(4*GLX_map2_size(target)*uorder*vorder));
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	
	glMap2f(target, u1, u2, GLX_map2_size(target)*vorder, uorder, v1, v2, GLX_map2_size(target), vorder, points);
    
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeMapGrid1d_swapped(int length, char* data)
{
	GLdouble u1 = GET_double(data+0);
	GLdouble u2 = GET_double(data+8);
	GLint un = GET_int(data+16);
	register int _n = 0;
	swapd(&u1, _n);
	swapd(&u2, _n);
	swapl(&un, _n);
	if(length != 20){
		fprintf(stderr, "Bad length in MapGrid1d (have %d, wanted %d)\n", length, 20);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	
	glMapGrid1d(un, u1, u2);
    
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeMapGrid1f_swapped(int length, char* data)
{
	GLint un = GET_int(data+0);
	GLfloat u1 = GET_float(data+4);
	GLfloat u2 = GET_float(data+8);
	register int _n = 0;
	swapl(&un, _n);
	swapl(&u1, _n);
	swapl(&u2, _n);
	if(length != 12){
		fprintf(stderr, "Bad length in MapGrid1f (have %d, wanted %d)\n", length, 12);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glMapGrid1f(un, u1, u2);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeMapGrid2d_swapped(int length, char* data)
{
	GLdouble u1 = GET_double(data+0);
	GLdouble u2 = GET_double(data+8);
	GLdouble v1 = GET_double(data+16);
	GLdouble v2 = GET_double(data+24);
	GLint un = GET_int(data+32);
	GLint vn = GET_int(data+36);
	register int _n = 0;
	swapd(&u1, _n);
	swapd(&u2, _n);
	swapd(&v1, _n);
	swapd(&v2, _n);
	swapl(&un, _n);
	swapl(&vn, _n);
	if(length != 40){
		fprintf(stderr, "Bad length in MapGrid2d (have %d, wanted %d)\n", length, 40);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	
	glMapGrid2d(un, u1, u2, vn, v1, v2);
    
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeMapGrid2f_swapped(int length, char* data)
{
	GLint un = GET_int(data+0);
	GLfloat u1 = GET_float(data+4);
	GLfloat u2 = GET_float(data+8);
	GLint vn = GET_int(data+12);
	GLfloat v1 = GET_float(data+16);
	GLfloat v2 = GET_float(data+20);
	register int _n = 0;
	swapl(&un, _n);
	swapl(&u1, _n);
	swapl(&u2, _n);
	swapl(&vn, _n);
	swapl(&v1, _n);
	swapl(&v2, _n);
	if(length != 24){
		fprintf(stderr, "Bad length in MapGrid2f (have %d, wanted %d)\n", length, 24);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glMapGrid2f(un, u1, u2, vn, v1, v2);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeEvalCoord1dv_swapped(int length, char* data)
{
	GLdouble* u = (GLdouble*)(data+0);
	GLX_swapd_array(1, (double *)u);
	if(length != 8){
		fprintf(stderr, "Bad length in EvalCoord1dv (have %d, wanted %d)\n", length, 8);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glEvalCoord1dv(u);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeEvalCoord1fv_swapped(int length, char* data)
{
	GLfloat* u = (GLfloat*)(data+0);
	GLX_swapl_array(1, (GLuint *)u);
	if(length != 4){
		fprintf(stderr, "Bad length in EvalCoord1fv (have %d, wanted %d)\n", length, 4);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glEvalCoord1fv(u);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeEvalCoord2dv_swapped(int length, char* data)
{
	GLdouble* u = (GLdouble*)(data+0);
	GLX_swapd_array(2, (double *)u);
	if(length != 16){
		fprintf(stderr, "Bad length in EvalCoord2dv (have %d, wanted %d)\n", length, 16);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glEvalCoord2dv(u);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeEvalCoord2fv_swapped(int length, char* data)
{
	GLfloat* u = (GLfloat*)(data+0);
	GLX_swapl_array(2, (GLuint *)u);
	if(length != 8){
		fprintf(stderr, "Bad length in EvalCoord2fv (have %d, wanted %d)\n", length, 8);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glEvalCoord2fv(u);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeEvalMesh1_swapped(int length, char* data)
{
	GLenum mode = GET_enum(data+0);
	GLint i1 = GET_int(data+4);
	GLint i2 = GET_int(data+8);
	register int _n = 0;
	swapl(&mode, _n);
	swapl(&i1, _n);
	swapl(&i2, _n);
	if(length != 12){
		fprintf(stderr, "Bad length in EvalMesh1 (have %d, wanted %d)\n", length, 12);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glEvalMesh1(mode, i1, i2);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeEvalPoint1_swapped(int length, char* data)
{
	GLint i = GET_int(data+0);
	register int _n = 0;
	swapl(&i, _n);
	if(length != 4){
		fprintf(stderr, "Bad length in EvalPoint1 (have %d, wanted %d)\n", length, 4);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glEvalPoint1(i);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeEvalMesh2_swapped(int length, char* data)
{
	GLenum mode = GET_enum(data+0);
	GLint i1 = GET_int(data+4);
	GLint i2 = GET_int(data+8);
	GLint j1 = GET_int(data+12);
	GLint j2 = GET_int(data+16);
	register int _n = 0;
	swapl(&mode, _n);
	swapl(&i1, _n);
	swapl(&i2, _n);
	swapl(&j1, _n);
	swapl(&j2, _n);
	if(length != 20){
		fprintf(stderr, "Bad length in EvalMesh2 (have %d, wanted %d)\n", length, 20);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glEvalMesh2(mode, i1, i2, j1, j2);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeEvalPoint2_swapped(int length, char* data)
{
	GLint i = GET_int(data+0);
	GLint j = GET_int(data+4);
	register int _n = 0;
	swapl(&i, _n);
	swapl(&j, _n);
	if(length != 8){
		fprintf(stderr, "Bad length in EvalPoint2 (have %d, wanted %d)\n", length, 8);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glEvalPoint2(i, j);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeAlphaFunc_swapped(int length, char* data)
{
	GLenum func = GET_enum(data+0);
	GLfloat ref = GET_float(data+4);
	register int _n = 0;
	swapl(&func, _n);
	swapl(&ref, _n);
	if(length != 8){
		fprintf(stderr, "Bad length in AlphaFunc (have %d, wanted %d)\n", length, 8);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glAlphaFunc(func, ref);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeBlendFunc_swapped(int length, char* data)
{
	GLenum sfactor = GET_enum(data+0);
	GLenum dfactor = GET_enum(data+4);
	register int _n = 0;
	swapl(&sfactor, _n);
	swapl(&dfactor, _n);
	if(length != 8){
		fprintf(stderr, "Bad length in BlendFunc (have %d, wanted %d)\n", length, 8);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glBlendFunc(sfactor, dfactor);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeLogicOp_swapped(int length, char* data)
{
	GLenum opcode = GET_enum(data+0);
	register int _n = 0;
	swapl(&opcode, _n);
	if(length != 4){
		fprintf(stderr, "Bad length in LogicOp (have %d, wanted %d)\n", length, 4);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glLogicOp(opcode);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeStencilFunc_swapped(int length, char* data)
{
	GLenum func = GET_enum(data+0);
	GLint ref = GET_int(data+4);
	GLuint mask = GET_uint(data+8);
	register int _n = 0;
	swapl(&func, _n);
	swapl(&ref, _n);
	swapl(&mask, _n);
	if(length != 12){
		fprintf(stderr, "Bad length in StencilFunc (have %d, wanted %d)\n", length, 12);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glStencilFunc(func, ref, mask);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeStencilOp_swapped(int length, char* data)
{
	GLenum fail = GET_enum(data+0);
	GLenum zfail = GET_enum(data+4);
	GLenum zpass = GET_enum(data+8);
	register int _n = 0;
	swapl(&fail, _n);
	swapl(&zfail, _n);
	swapl(&zpass, _n);
	if(length != 12){
		fprintf(stderr, "Bad length in StencilOp (have %d, wanted %d)\n", length, 12);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glStencilOp(fail, zfail, zpass);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeDepthFunc_swapped(int length, char* data)
{
	GLenum func = GET_enum(data+0);
	register int _n = 0;
	swapl(&func, _n);
	if(length != 4){
		fprintf(stderr, "Bad length in DepthFunc (have %d, wanted %d)\n", length, 4);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glDepthFunc(func);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodePixelZoom_swapped(int length, char* data)
{
	GLfloat xfactor = GET_float(data+0);
	GLfloat yfactor = GET_float(data+4);
	register int _n = 0;
	swapl(&xfactor, _n);
	swapl(&yfactor, _n);
	if(length != 8){
		fprintf(stderr, "Bad length in PixelZoom (have %d, wanted %d)\n", length, 8);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glPixelZoom(xfactor, yfactor);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodePixelTransferf_swapped(int length, char* data)
{
	GLenum pname = GET_enum(data+0);
	GLfloat param = GET_float(data+4);
	register int _n = 0;
	swapl(&pname, _n);
	swapl(&param, _n);
	if(length != 8){
		fprintf(stderr, "Bad length in PixelTransferf (have %d, wanted %d)\n", length, 8);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glPixelTransferf(pname, param);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodePixelTransferi_swapped(int length, char* data)
{
	GLenum pname = GET_enum(data+0);
	GLint param = GET_int(data+4);
	register int _n = 0;
	swapl(&pname, _n);
	swapl(&param, _n);
	if(length != 8){
		fprintf(stderr, "Bad length in PixelTransferi (have %d, wanted %d)\n", length, 8);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glPixelTransferi(pname, param);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodePixelMapfv_swapped(int length, char* data)
{
	GLenum map = GET_enum(data+0);
	GLint mapsize = GET_int(data+4);
	GLfloat* values = (GLfloat*)(data+8);
	register int _n = 0;
	swapl(&map, _n);
	swapl(&mapsize, _n);
	GLX_swapl_array(mapsize, (GLuint *)values);
	if(length != 8+(4*mapsize)){
		fprintf(stderr, "Bad length in PixelMapfv (have %d, wanted %d)\n", length, 8+(4*mapsize));
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glPixelMapfv(map, mapsize, values);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodePixelMapuiv_swapped(int length, char* data)
{
	GLenum map = GET_enum(data+0);
	GLint mapsize = GET_int(data+4);
	GLuint* values = (GLuint*)(data+8);
	register int _n = 0;
	swapl(&map, _n);
	swapl(&mapsize, _n);
	GLX_swapl_array(mapsize, (GLuint *)values);
	if(length != 8+(4*mapsize)){
		fprintf(stderr, "Bad length in PixelMapuiv (have %d, wanted %d)\n", length, 8+(4*mapsize));
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glPixelMapuiv(map, mapsize, values);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodePixelMapusv_swapped(int length, char* data)
{
	GLenum map = GET_enum(data+0);
	GLint mapsize = GET_int(data+4);
	GLushort* values = (GLushort*)(data+8);
	register int _n = 0;
	swapl(&map, _n);
	swapl(&mapsize, _n);
	GLX_swaps_array(mapsize, (short *)values);
	if(length != 8+(2*mapsize)){
		fprintf(stderr, "Bad length in PixelMapusv (have %d, wanted %d)\n", length, 8+(2*mapsize));
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glPixelMapusv(map, mapsize, values);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeReadBuffer_swapped(int length, char* data)
{
	GLenum mode = GET_enum(data+0);
	register int _n = 0;
	swapl(&mode, _n);
	if(length != 4){
		fprintf(stderr, "Bad length in ReadBuffer (have %d, wanted %d)\n", length, 4);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glReadBuffer(mode);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeCopyPixels_swapped(int length, char* data)
{
	GLint x = GET_int(data+0);
	GLint y = GET_int(data+4);
	GLint width = GET_int(data+8);
	GLint height = GET_int(data+12);
	GLenum type = GET_enum(data+16);
	register int _n = 0;
	swapl(&x, _n);
	swapl(&y, _n);
	swapl(&width, _n);
	swapl(&height, _n);
	swapl(&type, _n);
	if(length != 20){
		fprintf(stderr, "Bad length in CopyPixels (have %d, wanted %d)\n", length, 20);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glCopyPixels(x, y, width, height, type);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeDrawPixels_swapped(int length, char* data)
{
	GLboolean swap_bytes = GET_boolean(data+0);
	GLboolean lsb_first = GET_boolean(data+1);
	GLuint row_length = GET_uint(data+4);
	GLuint skip_rows = GET_uint(data+8);
	GLuint skip_pixels = GET_uint(data+12);
	GLuint alignment = GET_uint(data+16);
	GLint width = GET_int(data+20);
	GLint height = GET_int(data+24);
	GLenum format = GET_enum(data+28);
	GLenum type = GET_enum(data+32);
	GLubyte* pixels = (GLubyte*)(data+36);
	register int _n = 0;
	swapl(&row_length, _n);
	swapl(&skip_rows, _n);
	swapl(&skip_pixels, _n);
	swapl(&alignment, _n);
	swapl(&width, _n);
	swapl(&height, _n);
	swapl(&format, _n);
	swapl(&type, _n);
	if(length != 36+(1*GLX_image_size(width,height,format,type))+(1*GLX_image_pad(width,height,format,type))){
		fprintf(stderr, "Bad length in DrawPixels (have %d, wanted %d)\n", length, 36+(1*GLX_image_size(width,height,format,type))+(1*GLX_image_pad(width,height,format,type)));
		return GLXBadRenderRequest;
	}
	swap_bytes = !swap_bytes;
	log_print("Calling OpenGL function");
	
	glPixelStorei(GL_UNPACK_SWAP_BYTES, swap_bytes);
	glPixelStorei(GL_UNPACK_LSB_FIRST, lsb_first);
	glPixelStorei(GL_UNPACK_ROW_LENGTH, row_length);
	glPixelStorei(GL_UNPACK_SKIP_PIXELS, skip_pixels);
	glPixelStorei(GL_UNPACK_SKIP_ROWS, skip_rows);
	glPixelStorei(GL_UNPACK_ALIGNMENT, alignment);
	glDrawPixels(width, height, format, type, pixels);
    
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeDepthRange_swapped(int length, char* data)
{
	GLdouble near = GET_double(data+0);
	GLdouble far = GET_double(data+8);
	register int _n = 0;
	swapd(&near, _n);
	swapd(&far, _n);
	if(length != 16){
		fprintf(stderr, "Bad length in DepthRange (have %d, wanted %d)\n", length, 16);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glDepthRange(near, far);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeFrustum_swapped(int length, char* data)
{
	GLdouble left = GET_double(data+0);
	GLdouble right = GET_double(data+8);
	GLdouble bottom = GET_double(data+16);
	GLdouble top = GET_double(data+24);
	GLdouble near = GET_double(data+32);
	GLdouble far = GET_double(data+40);
	register int _n = 0;
	swapd(&left, _n);
	swapd(&right, _n);
	swapd(&bottom, _n);
	swapd(&top, _n);
	swapd(&near, _n);
	swapd(&far, _n);
	if(length != 48){
		fprintf(stderr, "Bad length in Frustum (have %d, wanted %d)\n", length, 48);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glFrustum(left, right, bottom, top, near, far);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeLoadIdentity_swapped(int length, char* data)
{
	if(length != 0){
		fprintf(stderr, "Bad length in LoadIdentity (have %d, wanted %d)\n", length, 0);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glLoadIdentity();
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeLoadMatrixf_swapped(int length, char* data)
{
	GLfloat* m = (GLfloat*)(data+0);
	GLX_swapl_array(16, (GLuint *)m);
	if(length != 64){
		fprintf(stderr, "Bad length in LoadMatrixf (have %d, wanted %d)\n", length, 64);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glLoadMatrixf(m);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeLoadMatrixd_swapped(int length, char* data)
{
	GLdouble* m = (GLdouble*)(data+0);
	GLX_swapd_array(16, (double *)m);
	if(length != 128){
		fprintf(stderr, "Bad length in LoadMatrixd (have %d, wanted %d)\n", length, 128);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glLoadMatrixd(m);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeMatrixMode_swapped(int length, char* data)
{
	GLenum mode = GET_enum(data+0);
	register int _n = 0;
	swapl(&mode, _n);
	if(length != 4){
		fprintf(stderr, "Bad length in MatrixMode (have %d, wanted %d)\n", length, 4);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glMatrixMode(mode);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeMultMatrixf_swapped(int length, char* data)
{
	GLfloat* m = (GLfloat*)(data+0);
	GLX_swapl_array(16, (GLuint *)m);
	if(length != 64){
		fprintf(stderr, "Bad length in MultMatrixf (have %d, wanted %d)\n", length, 64);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glMultMatrixf(m);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeMultMatrixd_swapped(int length, char* data)
{
	GLdouble* m = (GLdouble*)(data+0);
	GLX_swapd_array(16, (double *)m);
	if(length != 128){
		fprintf(stderr, "Bad length in MultMatrixd (have %d, wanted %d)\n", length, 128);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glMultMatrixd(m);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeOrtho_swapped(int length, char* data)
{
	GLdouble left = GET_double(data+0);
	GLdouble right = GET_double(data+8);
	GLdouble bottom = GET_double(data+16);
	GLdouble top = GET_double(data+24);
	GLdouble near = GET_double(data+32);
	GLdouble far = GET_double(data+40);
	register int _n = 0;
	swapd(&left, _n);
	swapd(&right, _n);
	swapd(&bottom, _n);
	swapd(&top, _n);
	swapd(&near, _n);
	swapd(&far, _n);
	if(length != 48){
		fprintf(stderr, "Bad length in Ortho (have %d, wanted %d)\n", length, 48);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glOrtho(left, right, bottom, top, near, far);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodePopMatrix_swapped(int length, char* data)
{
	if(length != 0){
		fprintf(stderr, "Bad length in PopMatrix (have %d, wanted %d)\n", length, 0);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glPopMatrix();
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodePushMatrix_swapped(int length, char* data)
{
	if(length != 0){
		fprintf(stderr, "Bad length in PushMatrix (have %d, wanted %d)\n", length, 0);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glPushMatrix();
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeRotated_swapped(int length, char* data)
{
	GLdouble angle = GET_double(data+0);
	GLdouble x = GET_double(data+8);
	GLdouble y = GET_double(data+16);
	GLdouble z = GET_double(data+24);
	register int _n = 0;
	swapd(&angle, _n);
	swapd(&x, _n);
	swapd(&y, _n);
	swapd(&z, _n);
	if(length != 32){
		fprintf(stderr, "Bad length in Rotated (have %d, wanted %d)\n", length, 32);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glRotated(angle, x, y, z);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeRotatef_swapped(int length, char* data)
{
	GLfloat angle = GET_float(data+0);
	GLfloat x = GET_float(data+4);
	GLfloat y = GET_float(data+8);
	GLfloat z = GET_float(data+12);
	register int _n = 0;
	swapl(&angle, _n);
	swapl(&x, _n);
	swapl(&y, _n);
	swapl(&z, _n);
	if(length != 16){
		fprintf(stderr, "Bad length in Rotatef (have %d, wanted %d)\n", length, 16);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glRotatef(angle, x, y, z);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeScaled_swapped(int length, char* data)
{
	GLdouble x = GET_double(data+0);
	GLdouble y = GET_double(data+8);
	GLdouble z = GET_double(data+16);
	register int _n = 0;
	swapd(&x, _n);
	swapd(&y, _n);
	swapd(&z, _n);
	if(length != 24){
		fprintf(stderr, "Bad length in Scaled (have %d, wanted %d)\n", length, 24);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glScaled(x, y, z);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeScalef_swapped(int length, char* data)
{
	GLfloat x = GET_float(data+0);
	GLfloat y = GET_float(data+4);
	GLfloat z = GET_float(data+8);
	register int _n = 0;
	swapl(&x, _n);
	swapl(&y, _n);
	swapl(&z, _n);
	if(length != 12){
		fprintf(stderr, "Bad length in Scalef (have %d, wanted %d)\n", length, 12);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glScalef(x, y, z);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeTranslated_swapped(int length, char* data)
{
	GLdouble x = GET_double(data+0);
	GLdouble y = GET_double(data+8);
	GLdouble z = GET_double(data+16);
	register int _n = 0;
	swapd(&x, _n);
	swapd(&y, _n);
	swapd(&z, _n);
	if(length != 24){
		fprintf(stderr, "Bad length in Translated (have %d, wanted %d)\n", length, 24);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glTranslated(x, y, z);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeTranslatef_swapped(int length, char* data)
{
	GLfloat x = GET_float(data+0);
	GLfloat y = GET_float(data+4);
	GLfloat z = GET_float(data+8);
	register int _n = 0;
	swapl(&x, _n);
	swapl(&y, _n);
	swapl(&z, _n);
	if(length != 12){
		fprintf(stderr, "Bad length in Translatef (have %d, wanted %d)\n", length, 12);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glTranslatef(x, y, z);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeViewport_swapped(int length, char* data)
{
	GLint x = GET_int(data+0);
	GLint y = GET_int(data+4);
	GLint width = GET_int(data+8);
	GLint height = GET_int(data+12);
	register int _n = 0;
	swapl(&x, _n);
	swapl(&y, _n);
	swapl(&width, _n);
	swapl(&height, _n);
	if(length != 16){
		fprintf(stderr, "Bad length in Viewport (have %d, wanted %d)\n", length, 16);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glViewport(x, y, width, height);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodePolygonOffset_swapped(int length, char* data)
{
	GLfloat factor = GET_float(data+0);
	GLfloat units = GET_float(data+4);
	register int _n = 0;
	swapl(&factor, _n);
	swapl(&units, _n);
	if(length != 8){
		fprintf(stderr, "Bad length in PolygonOffset (have %d, wanted %d)\n", length, 8);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glPolygonOffset(factor, units);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeDrawArrays_swapped(int length, char* data)
{
	GLint n = GET_int(data+0);
	GLint m = GET_int(data+4);
	GLenum mode = GET_enum(data+8);
	GLint* list = (GLint*)(data+12);
	GLint* verts;
	register int _n = 0;
	swapl(&n, _n);
	swapl(&m, _n);
	swapl(&mode, _n);
	GLX_swapl_array(GLX_array_info_size(m), (GLuint *)list);
	verts = (GLint*)
(data+12+(4*GLX_array_info_size(m)));
	if(length != 12+(4*GLX_array_info_size(m))+(4*GLX_varray_size(n,m,list))){
		fprintf(stderr, "Bad length in DrawArrays (have %d, wanted %d)\n", length, 12+(4*GLX_array_info_size(m))+(4*GLX_varray_size(n,m,list)));
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	
      GLX_DrawArrays_swapped(n, m, mode, (struct array_info *) list, (void *) verts);
    
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeIndexubv_swapped(int length, char* data)
{
	GLubyte* c = (GLubyte*)(data+0);
	if(length != 4){
		fprintf(stderr, "Bad length in Indexubv (have %d, wanted %d)\n", length, 4);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glIndexubv(c);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeBlendColorEXT_swapped(int length, char* data)
{
	GLfloat red = GET_float(data+0);
	GLfloat green = GET_float(data+4);
	GLfloat blue = GET_float(data+8);
	GLfloat alpha = GET_float(data+12);
	register int _n = 0;
	swapl(&red, _n);
	swapl(&green, _n);
	swapl(&blue, _n);
	swapl(&alpha, _n);
	if(length != 16){
		fprintf(stderr, "Bad length in BlendColorEXT (have %d, wanted %d)\n", length, 16);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glBlendColorEXT(red, green, blue, alpha);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeBlendEquationEXT_swapped(int length, char* data)
{
	GLenum mode = GET_enum(data+0);
	register int _n = 0;
	swapl(&mode, _n);
	if(length != 4){
		fprintf(stderr, "Bad length in BlendEquationEXT (have %d, wanted %d)\n", length, 4);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glBlendEquationEXT(mode);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeTexSubImage1D_swapped(int length, char* data)
{
	GLboolean swap_bytes = GET_boolean(data+0);
	GLboolean lsb_first = GET_boolean(data+1);
	GLuint row_length = GET_uint(data+4);
	GLuint skip_rows = GET_uint(data+8);
	GLuint skip_pixels = GET_uint(data+12);
	GLuint alignment = GET_uint(data+16);
	GLenum target = GET_enum(data+20);
	GLint level = GET_int(data+24);
	GLint xoffset = GET_int(data+28);
	GLint yoffset = GET_int(data+32);
	GLint width = GET_int(data+36);
	GLint height = GET_int(data+40);
	GLenum format = GET_enum(data+44);
	GLenum type = GET_enum(data+48);
	GLubyte* pixels = (GLubyte*)(data+56);
	register int _n = 0;
	swapl(&row_length, _n);
	swapl(&skip_rows, _n);
	swapl(&skip_pixels, _n);
	swapl(&alignment, _n);
	swapl(&target, _n);
	swapl(&level, _n);
	swapl(&xoffset, _n);
	swapl(&yoffset, _n);
	swapl(&width, _n);
	swapl(&height, _n);
	swapl(&format, _n);
	swapl(&type, _n);
	if(length != 56+(1*GLX_image_size(width,height,format,type))+(1*GLX_image_pad(width,height,format,type))){
		fprintf(stderr, "Bad length in TexSubImage1D (have %d, wanted %d)\n", length, 56+(1*GLX_image_size(width,height,format,type))+(1*GLX_image_pad(width,height,format,type)));
		return GLXBadRenderRequest;
	}
	swap_bytes = !swap_bytes;
	log_print("Calling OpenGL function");
	
	glPixelStorei(GL_UNPACK_SWAP_BYTES, swap_bytes);
	glPixelStorei(GL_UNPACK_LSB_FIRST, lsb_first);
	glPixelStorei(GL_UNPACK_ROW_LENGTH, row_length);
	glPixelStorei(GL_UNPACK_SKIP_PIXELS, skip_pixels);
	glPixelStorei(GL_UNPACK_SKIP_ROWS, skip_rows);
	glPixelStorei(GL_UNPACK_ALIGNMENT, alignment);
	glTexSubImage1D(target, level, xoffset, width, format, type, pixels);
    
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeTexSubImage2D_swapped(int length, char* data)
{
	GLboolean swap_bytes = GET_boolean(data+0);
	GLboolean lsb_first = GET_boolean(data+1);
	GLuint row_length = GET_uint(data+4);
	GLuint skip_rows = GET_uint(data+8);
	GLuint skip_pixels = GET_uint(data+12);
	GLuint alignment = GET_uint(data+16);
	GLenum target = GET_enum(data+20);
	GLint level = GET_int(data+24);
	GLint xoffset = GET_int(data+28);
	GLint yoffset = GET_int(data+32);
	GLint width = GET_int(data+36);
	GLint height = GET_int(data+40);
	GLenum format = GET_enum(data+44);
	GLenum type = GET_enum(data+48);
	GLubyte* pixels = (GLubyte*)(data+56);
	register int _n = 0;
	swapl(&row_length, _n);
	swapl(&skip_rows, _n);
	swapl(&skip_pixels, _n);
	swapl(&alignment, _n);
	swapl(&target, _n);
	swapl(&level, _n);
	swapl(&xoffset, _n);
	swapl(&yoffset, _n);
	swapl(&width, _n);
	swapl(&height, _n);
	swapl(&format, _n);
	swapl(&type, _n);
	if(length != 56+(1*GLX_image_size(width,height,format,type))+(1*GLX_image_pad(width,height,format,type))){
		fprintf(stderr, "Bad length in TexSubImage2D (have %d, wanted %d)\n", length, 56+(1*GLX_image_size(width,height,format,type))+(1*GLX_image_pad(width,height,format,type)));
		return GLXBadRenderRequest;
	}
	swap_bytes = !swap_bytes;
	log_print("Calling OpenGL function");
	
	glPixelStorei(GL_UNPACK_SWAP_BYTES, swap_bytes);
	glPixelStorei(GL_UNPACK_LSB_FIRST, lsb_first);
	glPixelStorei(GL_UNPACK_ROW_LENGTH, row_length);
	glPixelStorei(GL_UNPACK_SKIP_PIXELS, skip_pixels);
	glPixelStorei(GL_UNPACK_SKIP_ROWS, skip_rows);
	glPixelStorei(GL_UNPACK_ALIGNMENT, alignment);
	glTexSubImage2D(target, level, xoffset, yoffset, width, height,
                        format, type, pixels);
    
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeBindTexture_swapped(int length, char* data)
{
	GLenum target = GET_enum(data+0);
	GLuint texture = GET_uint(data+4);
	register int _n = 0;
	swapl(&target, _n);
	swapl(&texture, _n);
	if(length != 8){
		fprintf(stderr, "Bad length in BindTexture (have %d, wanted %d)\n", length, 8);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glBindTexture(target, texture);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodePrioritizeTextures_swapped(int length, char* data)
{
	GLint n = GET_int(data+0);
	GLuint* textures = (GLuint*)(data+4);
	GLfloat* priorities;
	register int _n = 0;
	swapl(&n, _n);
	GLX_swapl_array(4*n, (GLuint *)textures);
	priorities = (GLfloat*)
(data+4+(4*4*n));
	if(length != 4+(4*4*n)+(4*4*n)){
		fprintf(stderr, "Bad length in PrioritizeTextures (have %d, wanted %d)\n", length, 4+(4*4*n)+(4*4*n));
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glPrioritizeTextures(n, textures, priorities);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeCopyTexImage1D_swapped(int length, char* data)
{
	GLenum target = GET_enum(data+0);
	GLint level = GET_int(data+4);
	GLenum internalFormat = GET_enum(data+8);
	GLint x = GET_int(data+12);
	GLint y = GET_int(data+16);
	GLint width = GET_int(data+20);
	GLint border = GET_int(data+24);
	register int _n = 0;
	swapl(&target, _n);
	swapl(&level, _n);
	swapl(&internalFormat, _n);
	swapl(&x, _n);
	swapl(&y, _n);
	swapl(&width, _n);
	swapl(&border, _n);
	if(length != 28){
		fprintf(stderr, "Bad length in CopyTexImage1D (have %d, wanted %d)\n", length, 28);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glCopyTexImage1D(target, level, internalFormat, x, y, width, border);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeCopyTexImage2D_swapped(int length, char* data)
{
	GLenum target = GET_enum(data+0);
	GLint level = GET_int(data+4);
	GLenum internalFormat = GET_enum(data+8);
	GLint x = GET_int(data+12);
	GLint y = GET_int(data+16);
	GLint width = GET_int(data+20);
	GLint height = GET_int(data+24);
	GLint border = GET_int(data+28);
	register int _n = 0;
	swapl(&target, _n);
	swapl(&level, _n);
	swapl(&internalFormat, _n);
	swapl(&x, _n);
	swapl(&y, _n);
	swapl(&width, _n);
	swapl(&height, _n);
	swapl(&border, _n);
	if(length != 32){
		fprintf(stderr, "Bad length in CopyTexImage2D (have %d, wanted %d)\n", length, 32);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glCopyTexImage2D(target, level, internalFormat, x, y, width, height, border);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeCopyTexSubImage1D_swapped(int length, char* data)
{
	GLenum target = GET_enum(data+0);
	GLint level = GET_int(data+4);
	GLint offset = GET_int(data+8);
	GLint x = GET_int(data+12);
	GLint y = GET_int(data+16);
	GLint width = GET_int(data+20);
	register int _n = 0;
	swapl(&target, _n);
	swapl(&level, _n);
	swapl(&offset, _n);
	swapl(&x, _n);
	swapl(&y, _n);
	swapl(&width, _n);
	if(length != 24){
		fprintf(stderr, "Bad length in CopyTexSubImage1D (have %d, wanted %d)\n", length, 24);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glCopyTexSubImage1D(target, level, offset, x, y, width);
	log_print("Done with OpenGL function");
	return Success;
}

int GLXDecodeCopyTexSubImage2D_swapped(int length, char* data)
{
	GLenum target = GET_enum(data+0);
	GLint level = GET_int(data+4);
	GLint xoffset = GET_int(data+8);
	GLint yoffset = GET_int(data+12);
	GLint x = GET_int(data+16);
	GLint y = GET_int(data+20);
	GLint width = GET_int(data+24);
	GLint height = GET_int(data+28);
	register int _n = 0;
	swapl(&target, _n);
	swapl(&level, _n);
	swapl(&xoffset, _n);
	swapl(&yoffset, _n);
	swapl(&x, _n);
	swapl(&y, _n);
	swapl(&width, _n);
	swapl(&height, _n);
	if(length != 32){
		fprintf(stderr, "Bad length in CopyTexSubImage2D (have %d, wanted %d)\n", length, 32);
		return GLXBadRenderRequest;
	}
	log_print("Calling OpenGL function");
	glCopyTexSubImage2D(target, level, xoffset, yoffset, x, y, width, height);
	log_print("Done with OpenGL function");
	return Success;
}

