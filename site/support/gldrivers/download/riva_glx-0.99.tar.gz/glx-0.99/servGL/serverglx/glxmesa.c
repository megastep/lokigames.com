
/*
 * GLX Server Extension
 * Copyright (C) 1996  Steven G. Parker  (sparker@cs.utah.edu)
 * Copyright (C) 1998, 1999 Terence Ripperda (ripperda@sgi.com)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * STEVEN PARKER, TERENCE RIPPERDA, OR ANY OTHER CONTRIBUTORS BE LIABLE FOR 
 * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, 
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE 
 * OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

/* TODO:
 - destroy context should not destroy until the context is made uncurrent
 - pixmaps
 */

#include "extnsionst.h"
#include "dixstruct.h"
#include "scrnintstr.h"
#include "pixmapstr.h"
#include "windowstr.h"
#include "GL/GLXproto.h"
#include "xsmesaP.h"
#include "xsmesa.h"
#include "config.h"
#include "glx_log.h"
#include "glxcmds.h"
#include "glxrender.h"
#include "glxdecode.h"
#include "fontstruct.h"
#include "servermd.h"
#include "glxvisual.h"
#include <stdio.h>

#include "glxConstants.h"
#include "glx_clients.h"
#include "glx_dispatch.h"
#include "xf86Version.h"
#include "GL/xmesa.h"

#include <assert.h>


RESTYPE glContexts;
RESTYPE glPixmaps;
RESTYPE glWindows;
RESTYPE glxClients;

#ifdef XFree86LOADER
#include "xf86_libc.h"
#endif

extern XSMesaVisual GLfind_vis(VisualID vid);

GLX_PROCS GLXProcs;

static int ServerMesaDispatch(register ClientPtr client);
static int ServerMesaDispatch_swapped(register ClientPtr client);
static void ServerMesaReset(ExtensionEntry* extEntry)
{
    log_finish();
    ErrorF("%s Extension Reset called!\n", GLX_EXTENSION_NAME);
}

int GLDestroyMesaContext(pointer value, XID id)
{
    XSMesaContext ctx;
    fprintf(stderr, "destroying a context\n");
    ctx=(XSMesaContext)value;
    log_print("Destroying context");
    GLXProcs.DestroyContext(ctx);
    return 0;
}

int GLDestroyMesaBuffer(pointer value, XID id)
{
    XSMesaBuffer buf=(XSMesaBuffer)value;
    fprintf(stderr, "destroying a buffer\n");
    log_print("Destroying buffer");
    GLXProcs.DestroyBuffer(buf);
    return 0;
}

int GLDestroyGLXClients(pointer value, XID id)
{

    fprintf(stderr, "destroying a client: %u!\n", (unsigned int) id);   
    log_print("destroy client");

    __glXRemoveClient((int)value);
    /* xfree(client); */
    return 0;
}

void GlxExtensionInit()
{
    ExtensionEntry* extEntry;

    log_print("GlxExtensionInit");
    ErrorF("GlxExtensionInit");
    glContexts = CreateNewResourceType(GLDestroyMesaContext);
    glWindows  = CreateNewResourceType(GLDestroyMesaBuffer);
    glPixmaps  = CreateNewResourceType(GLDestroyMesaBuffer);
    glxClients = CreateNewResourceType(GLDestroyGLXClients);

    extEntry = AddExtension(GLX_EXTENSION_NAME, GLX_NUMBER_EVENTS,
			    GLX_NUMBER_ERRORS, ServerMesaDispatch,
			    ServerMesaDispatch_swapped, ServerMesaReset,
			    StandardMinorOpcode);
   
    if( !extEntry ) {
       ErrorF("GlxExtensionInit(): AddExtension() failed\n" );
       return; 
    }

    __glxErrorBase = extEntry->errorBase;
    __glxReqBase   = extEntry->base;
    __glxEventBase = extEntry->eventBase;

    /*
     * Set default XSMesa procs.
     */
    GLXProcs.CreateVisual       = XSMesaCreateVisual;
    GLXProcs.DestroyVisual      = XSMesaDestroyVisual;
    GLXProcs.CreateContext      = XSMesaCreateContext;
    GLXProcs.DestroyContext     = XSMesaDestroyContext;
    GLXProcs.MakeCurrent        = XSMesaMakeCurrent;
    GLXProcs.CopyContext        = XSMesaCopyContext;
    GLXProcs.CreateWindowBuffer = XSMesaCreateWindowBuffer;
    GLXProcs.CreatePixmapBuffer = XSMesaCreatePixmapBuffer;
    GLXProcs.DestroyBuffer      = XSMesaDestroyBuffer;
    GLXProcs.BindBuffer         = XSMesaBindBuffer;
    GLXProcs.FindBuffer         = XSMesaFindBuffer;
    GLXProcs.SwapBuffers        = XSMesaSwapBuffers;
    GLXProcs.GetBackBuffer      = XSMesaGetBackBuffer;
    GLXProcs.GetDepthBuffer     = XSMesaGetDepthBuffer;
    GLXProcs.GetCurrentContext  = XSMesaGetCurrentContext;
    GLXProcs.GetCurrentBuffer   = XSMesaGetCurrentBuffer;
    GLXProcs.FeedbackBuffer     = XSMesaFeedbackBuffer;
    GLXProcs.SelectionBuffer    = XSMesaSelectionBuffer;
    GLXProcs.GetPixel           = GLXGetPixel;
    GLXProcs.PutPixel           = GLXPutPixel;
    GLXProcs.DestroyImage       = GLXDestroyImage;
    GLXProcs.CreateImage        = GLXCreateImage;
    GLXProcs.GetDepth           = GLXGetDepth;
    GLXProcs.PutDepth           = GLXPutDepth;
    GLXProcs.CreateDepthBuffer  = GLXCreateDepthBuffer;

    /*
     * Allow hardware drivers to hook into GLX.
     */
#ifdef HW_ACCEL
    {
        extern GLboolean (*hwInitGLX)();
        if (hwInitGLX) (*hwInitGLX)();
    }
#endif

    GLFinalizeVisuals();
    __glXInitClients();
}

static int ServerMesaDispatch(register ClientPtr client)
{
    __glxClient *clientPtr = NULL;
    __glx_dispatch_proc dispatch_proc = NULL;
    REQUEST(xReq);

    clientPtr = __glXFindClient(client->index);
    if (clientPtr == NULL) {
       clientPtr = __glXAddClient(client);
       if (clientPtr == NULL) return BadAlloc;
    }

    log_silent();
    log_print("Dispatching: ");
    log_glx_request(stuff->data);
    log_print("\n");
    log_verbose();

    dispatch_proc = __glx_dispatch_table[stuff->data];
    return (*dispatch_proc)(client);
}

static int ServerMesaDispatch_swapped(register ClientPtr client)
{
    __glxClient *clientPtr = NULL;
    __glx_dispatch_proc dispatch_proc = NULL;
    REQUEST(xReq);

    clientPtr = __glXFindClient(client->index);
    if (clientPtr == NULL) {
       clientPtr = __glXAddClient(client);
       if (clientPtr == NULL) return BadAlloc;
    }

    log_silent();
    log_print("Dispatching: ");
    log_glx_request(stuff->data);
    log_print("\n");
    log_verbose();

    /** Currently, only Render and RenderLarge have _swapped versions **/
    /** Eventually, all of them should have duplicate versions **/

    if (stuff->data < 3) {
       if (stuff->data == 1) {
          return GLRender_swapped(client);
       }
       if (stuff->data == 2) {
          return GLRenderLarge_swapped(client);
       }
       return GLnoop(client);
    }
    dispatch_proc = __glx_dispatch_table[stuff->data];
    return (*dispatch_proc)(client);
}

int GLXDecodeInvalid(int length, char* data)
{
    ErrorF("2. INCOMPLETE: %d, length=%d\n", *(short*)(data-2), length);
    return Success;
}

#if defined( DYNAMIC_MODULE ) || defined( XFree86LOADER )

extern Bool GlxInitVisuals(
    VisualPtr *         /*visualp*/,
    DepthPtr *          /*depthp*/,
    int *               /*nvisualp*/,
    int *               /*ndepthp*/,
    int *               /*rootDepthp*/,
    VisualID *          /*defaultVisp*/,
    unsigned long       /*sizes*/,
    int                 /*bitsPerRGB*/
);

/*
 * Entry point of dynamic loading
 */
extern void (*GlxExtensionInitPtr)(void); 

extern Bool (*GlxInitVisualsPtr)(
    VisualPtr *         /*visualp*/,
    DepthPtr *          /*depthp*/,
    int *               /*nvisualp*/,
    int *               /*ndepthp*/,
    int *               /*rootDepthp*/,
    VisualID *          /*defaultVisp*/,
    unsigned long       /*sizes*/,
    int                 /*bitsPerRGB*/
);

#endif

#ifdef DYNAMIC_MODULE

int
#ifndef DLSYM_BUG
init_module(server_version)
#else
init_glx(server_version)
#endif
unsigned long server_version;
{

  GlxExtensionInitPtr = GlxExtensionInit;
  GlxInitVisualsPtr   = GlxInitVisuals; 

   if (set_log_file("glx_debug.log")) {
      fprintf(stderr, "glX Error: error setting log file\n");
   }
   log_initialize();
   log_print("Log initialized");

#if defined(MESA_MAJOR_VERSION) && defined(MESA_MINOR_VERSION)
  ErrorF( 
     "\t%s extension module for XFree86%s-- Mesa version %d.%d\n\t\tGLX package version %s, GLX protocol version %s.\n",
     GLX_EXTENSION_NAME, XF86_VERSION, 
     MESA_MAJOR_VERSION, XMESA_MINOR_VERSION,
     GLX_PACKAGE_VERSION, GLX_PROTOCOL_VERSION
  );
#else
  ErrorF( 
     "\t%s extension module for XFree86%s--\n\t\tGLX package version %s, GLX protocol version %s.\n",
     GLX_EXTENSION_NAME, XF86_VERSION, 
     GLX_PACKAGE_VERSION, GLX_PROTOCOL_VERSION
  );
#endif

  return 1;
}
#endif /* DYNAMIC_MODULE */

#ifdef XFree86LOADER

#include "xf86.h"
#include "xf86_ldext.h"
#include "xf86Version.h"

ExtensionModule glxExt = {
    GlxExtensionInit,
    GLX_EXTENSION_NAME,
    NULL};

void
libglxModuleInit(data,magic)
    pointer     * data;
    INT32       * magic;
{
    static int cnt = 0;

#if defined(MESA_MAJOR_VERSION) && defined(MESA_MINOR_VERSION)
    ErrorF( 
       "\t%s extension module for XFree86%s-- Mesa version %d.%d\n\t\tGLX package version %s, GLX protocol version %s.\n",
       GLX_EXTENSION_NAME, XF86_VERSION, 
       MESA_MAJOR_VERSION, XMESA_MINOR_VERSION,
       GLX_PACKAGE_VERSION, GLX_PROTOCOL_VERSION
    );
#else
    ErrorF( 
       "\t%s extension module for XFree86%s--\n\t\tGLX package version %s, GLX protocol version %s.\n",
       GLX_EXTENSION_NAME, XF86_VERSION, 
       GLX_PACKAGE_VERSION, GLX_PROTOCOL_VERSION
    );
#endif

    switch(cnt++)
    {
    case 0:
        *magic = MAGIC_LOAD_EXTENSION;
        * data = (pointer) &glxExt;
        break;
    case 1:
        *magic = MAGIC_GLX_VISUALS_INIT;
        * data = (pointer) GlxInitVisuals;
        break;
    default:
        *magic= MAGIC_DONE;
        break;
    }
    return;
}
#endif /* XFree86LOADER */

